/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/js/libs/sockjs.js"
/*!*******************************!*\
  !*** ./src/js/libs/sockjs.js ***!
  \*******************************/
(module, __unused_webpack_exports, __webpack_require__) {

/* sockjs-client v1.6.1 | http://sockjs.org | MIT license */
!function (e) {
  if (true) module.exports = e();else // removed by dead control flow
{}
}(function () {
  return function i(s, a, l) {
    function u(t, e) {
      if (!a[t]) {
        if (!s[t]) {
          var n = undefined;
          if (!e && n) return require(t, !0);
          if (c) return c(t, !0);
          var r = new Error("Cannot find module '" + t + "'");
          throw r.code = "MODULE_NOT_FOUND", r;
        }
        var o = a[t] = {
          exports: {}
        };
        s[t][0].call(o.exports, function (e) {
          return u(s[t][1][e] || e);
        }, o, o.exports, i, s, a, l);
      }
      return a[t].exports;
    }
    for (var c = undefined, e = 0; e < l.length; e++) u(l[e]);
    return u;
  }({
    1: [function (n, r, e) {
      (function (t) {
        (function () {
          "use strict";

          var e = n("./transport-list");
          r.exports = n("./main")(e), "_sockjs_onload" in t && setTimeout(t._sockjs_onload, 1);
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "./main": 14,
      "./transport-list": 16
    }],
    2: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./event");
      function i() {
        o.call(this), this.initEvent("close", !1, !1), this.wasClean = !1, this.code = 0, this.reason = "";
      }
      r(i, o), t.exports = i;
    }, {
      "./event": 4,
      "inherits": 54
    }],
    3: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./eventtarget");
      function i() {
        o.call(this);
      }
      r(i, o), i.prototype.removeAllListeners = function (e) {
        e ? delete this._listeners[e] : this._listeners = {};
      }, i.prototype.once = function (t, n) {
        var r = this,
          o = !1;
        this.on(t, function e() {
          r.removeListener(t, e), o || (o = !0, n.apply(this, arguments));
        });
      }, i.prototype.emit = function () {
        var e = arguments[0],
          t = this._listeners[e];
        if (t) {
          for (var n = arguments.length, r = new Array(n - 1), o = 1; o < n; o++) r[o - 1] = arguments[o];
          for (var i = 0; i < t.length; i++) t[i].apply(this, r);
        }
      }, i.prototype.on = i.prototype.addListener = o.prototype.addEventListener, i.prototype.removeListener = o.prototype.removeEventListener, t.exports.EventEmitter = i;
    }, {
      "./eventtarget": 5,
      "inherits": 54
    }],
    4: [function (e, t, n) {
      "use strict";

      function r(e) {
        this.type = e;
      }
      r.prototype.initEvent = function (e, t, n) {
        return this.type = e, this.bubbles = t, this.cancelable = n, this.timeStamp = +new Date(), this;
      }, r.prototype.stopPropagation = function () {}, r.prototype.preventDefault = function () {}, r.CAPTURING_PHASE = 1, r.AT_TARGET = 2, r.BUBBLING_PHASE = 3, t.exports = r;
    }, {}],
    5: [function (e, t, n) {
      "use strict";

      function r() {
        this._listeners = {};
      }
      r.prototype.addEventListener = function (e, t) {
        e in this._listeners || (this._listeners[e] = []);
        var n = this._listeners[e];
        -1 === n.indexOf(t) && (n = n.concat([t])), this._listeners[e] = n;
      }, r.prototype.removeEventListener = function (e, t) {
        var n = this._listeners[e];
        if (n) {
          var r = n.indexOf(t);
          -1 === r || (1 < n.length ? this._listeners[e] = n.slice(0, r).concat(n.slice(r + 1)) : delete this._listeners[e]);
        }
      }, r.prototype.dispatchEvent = function () {
        var e = arguments[0],
          t = e.type,
          n = 1 === arguments.length ? [e] : Array.apply(null, arguments);
        if (this["on" + t] && this["on" + t].apply(this, n), t in this._listeners) for (var r = this._listeners[t], o = 0; o < r.length; o++) r[o].apply(this, n);
      }, t.exports = r;
    }, {}],
    6: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./event");
      function i(e) {
        o.call(this), this.initEvent("message", !1, !1), this.data = e;
      }
      r(i, o), t.exports = i;
    }, {
      "./event": 4,
      "inherits": 54
    }],
    7: [function (e, t, n) {
      "use strict";

      var r = e("./utils/iframe");
      function o(e) {
        (this._transport = e).on("message", this._transportMessage.bind(this)), e.on("close", this._transportClose.bind(this));
      }
      o.prototype._transportClose = function (e, t) {
        r.postMessage("c", JSON.stringify([e, t]));
      }, o.prototype._transportMessage = function (e) {
        r.postMessage("t", e);
      }, o.prototype._send = function (e) {
        this._transport.send(e);
      }, o.prototype._close = function () {
        this._transport.close(), this._transport.removeAllListeners();
      }, t.exports = o;
    }, {
      "./utils/iframe": 47
    }],
    8: [function (e, t, n) {
      "use strict";

      var f = e("./utils/url"),
        r = e("./utils/event"),
        h = e("./facade"),
        o = e("./info-iframe-receiver"),
        d = e("./utils/iframe"),
        p = e("./location"),
        m = function () {};
      t.exports = function (l, e) {
        var u,
          c = {};
        e.forEach(function (e) {
          e.facadeTransport && (c[e.facadeTransport.transportName] = e.facadeTransport);
        }), c[o.transportName] = o, l.bootstrap_iframe = function () {
          var a;
          d.currentWindowId = p.hash.slice(1);
          r.attachEvent("message", function (t) {
            if (t.source === parent && (void 0 === u && (u = t.origin), t.origin === u)) {
              var n;
              try {
                n = JSON.parse(t.data);
              } catch (e) {
                return void m("bad json", t.data);
              }
              if (n.windowId === d.currentWindowId) switch (n.type) {
                case "s":
                  var e;
                  try {
                    e = JSON.parse(n.data);
                  } catch (e) {
                    m("bad json", n.data);
                    break;
                  }
                  var r = e[0],
                    o = e[1],
                    i = e[2],
                    s = e[3];
                  if (m(r, o, i, s), r !== l.version) throw new Error('Incompatible SockJS! Main site uses: "' + r + '", the iframe: "' + l.version + '".');
                  if (!f.isOriginEqual(i, p.href) || !f.isOriginEqual(s, p.href)) throw new Error("Can't connect to different domain from within an iframe. (" + p.href + ", " + i + ", " + s + ")");
                  a = new h(new c[o](i, s));
                  break;
                case "m":
                  a._send(n.data);
                  break;
                case "c":
                  a && a._close(), a = null;
              }
            }
          }), d.postMessage("s");
        };
      };
    }, {
      "./facade": 7,
      "./info-iframe-receiver": 10,
      "./location": 13,
      "./utils/event": 46,
      "./utils/iframe": 47,
      "./utils/url": 52,
      "debug": void 0
    }],
    9: [function (e, t, n) {
      "use strict";

      var r = e("events").EventEmitter,
        o = e("inherits"),
        s = e("./utils/object"),
        a = function () {};
      function i(e, t) {
        r.call(this);
        var o = this,
          i = +new Date();
        this.xo = new t("GET", e), this.xo.once("finish", function (e, t) {
          var n, r;
          if (200 === e) {
            if (r = +new Date() - i, t) try {
              n = JSON.parse(t);
            } catch (e) {
              a("bad json", t);
            }
            s.isObject(n) || (n = {});
          }
          o.emit("finish", n, r), o.removeAllListeners();
        });
      }
      o(i, r), i.prototype.close = function () {
        this.removeAllListeners(), this.xo.close();
      }, t.exports = i;
    }, {
      "./utils/object": 49,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    10: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("events").EventEmitter,
        i = e("./transport/sender/xhr-local"),
        s = e("./info-ajax");
      function a(e) {
        var n = this;
        o.call(this), this.ir = new s(e, i), this.ir.once("finish", function (e, t) {
          n.ir = null, n.emit("message", JSON.stringify([e, t]));
        });
      }
      r(a, o), a.transportName = "iframe-info-receiver", a.prototype.close = function () {
        this.ir && (this.ir.close(), this.ir = null), this.removeAllListeners();
      }, t.exports = a;
    }, {
      "./info-ajax": 9,
      "./transport/sender/xhr-local": 37,
      "events": 3,
      "inherits": 54
    }],
    11: [function (n, o, e) {
      (function (u) {
        (function () {
          "use strict";

          var r = n("events").EventEmitter,
            e = n("inherits"),
            i = n("./utils/event"),
            s = n("./transport/iframe"),
            a = n("./info-iframe-receiver"),
            l = function () {};
          function t(t, n) {
            var o = this;
            r.call(this);
            function e() {
              var e = o.ifr = new s(a.transportName, n, t);
              e.once("message", function (t) {
                if (t) {
                  var e;
                  try {
                    e = JSON.parse(t);
                  } catch (e) {
                    return l("bad json", t), o.emit("finish"), void o.close();
                  }
                  var n = e[0],
                    r = e[1];
                  o.emit("finish", n, r);
                }
                o.close();
              }), e.once("close", function () {
                o.emit("finish"), o.close();
              });
            }
            u.document.body ? e() : i.attachEvent("load", e);
          }
          e(t, r), t.enabled = function () {
            return s.enabled();
          }, t.prototype.close = function () {
            this.ifr && this.ifr.close(), this.removeAllListeners(), this.ifr = null;
          }, o.exports = t;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "./info-iframe-receiver": 10,
      "./transport/iframe": 22,
      "./utils/event": 46,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    12: [function (e, t, n) {
      "use strict";

      var r = e("events").EventEmitter,
        o = e("inherits"),
        i = e("./utils/url"),
        s = e("./transport/sender/xdr"),
        a = e("./transport/sender/xhr-cors"),
        l = e("./transport/sender/xhr-local"),
        u = e("./transport/sender/xhr-fake"),
        c = e("./info-iframe"),
        f = e("./info-ajax"),
        h = function () {};
      function d(e, t) {
        h(e);
        var n = this;
        r.call(this), setTimeout(function () {
          n.doXhr(e, t);
        }, 0);
      }
      o(d, r), d._getReceiver = function (e, t, n) {
        return n.sameOrigin ? new f(t, l) : a.enabled ? new f(t, a) : s.enabled && n.sameScheme ? new f(t, s) : c.enabled() ? new c(e, t) : new f(t, u);
      }, d.prototype.doXhr = function (e, t) {
        var n = this,
          r = i.addPath(e, "/info");
        h("doXhr", r), this.xo = d._getReceiver(e, r, t), this.timeoutRef = setTimeout(function () {
          h("timeout"), n._cleanup(!1), n.emit("finish");
        }, d.timeout), this.xo.once("finish", function (e, t) {
          h("finish", e, t), n._cleanup(!0), n.emit("finish", e, t);
        });
      }, d.prototype._cleanup = function (e) {
        h("_cleanup"), clearTimeout(this.timeoutRef), this.timeoutRef = null, !e && this.xo && this.xo.close(), this.xo = null;
      }, d.prototype.close = function () {
        h("close"), this.removeAllListeners(), this._cleanup(!1);
      }, d.timeout = 8e3, t.exports = d;
    }, {
      "./info-ajax": 9,
      "./info-iframe": 11,
      "./transport/sender/xdr": 34,
      "./transport/sender/xhr-cors": 35,
      "./transport/sender/xhr-fake": 36,
      "./transport/sender/xhr-local": 37,
      "./utils/url": 52,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    13: [function (e, t, n) {
      (function (e) {
        (function () {
          "use strict";

          t.exports = e.location || {
            origin: "http://localhost:80",
            protocol: "http:",
            host: "localhost",
            port: 80,
            href: "http://localhost/",
            hash: ""
          };
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {}],
    14: [function (x, _, e) {
      (function (w) {
        (function () {
          "use strict";

          x("./shims");
          var r,
            l = x("url-parse"),
            e = x("inherits"),
            u = x("./utils/random"),
            t = x("./utils/escape"),
            c = x("./utils/url"),
            i = x("./utils/event"),
            n = x("./utils/transport"),
            o = x("./utils/object"),
            f = x("./utils/browser"),
            h = x("./utils/log"),
            s = x("./event/event"),
            d = x("./event/eventtarget"),
            p = x("./location"),
            a = x("./event/close"),
            m = x("./event/trans-message"),
            v = x("./info-receiver"),
            b = function () {};
          function y(e, t, n) {
            if (!(this instanceof y)) return new y(e, t, n);
            if (arguments.length < 1) throw new TypeError("Failed to construct 'SockJS: 1 argument required, but only 0 present");
            d.call(this), this.readyState = y.CONNECTING, this.extensions = "", this.protocol = "", (n = n || {}).protocols_whitelist && h.warn("'protocols_whitelist' is DEPRECATED. Use 'transports' instead."), this._transportsWhitelist = n.transports, this._transportOptions = n.transportOptions || {}, this._timeout = n.timeout || 0;
            var r = n.sessionId || 8;
            if ("function" == typeof r) this._generateSessionId = r;else {
              if ("number" != typeof r) throw new TypeError("If sessionId is used in the options, it needs to be a number or a function.");
              this._generateSessionId = function () {
                return u.string(r);
              };
            }
            this._server = n.server || u.numberString(1e3);
            var o = new l(e);
            if (!o.host || !o.protocol) throw new SyntaxError("The URL '" + e + "' is invalid");
            if (o.hash) throw new SyntaxError("The URL must not contain a fragment");
            if ("http:" !== o.protocol && "https:" !== o.protocol) throw new SyntaxError("The URL's scheme must be either 'http:' or 'https:'. '" + o.protocol + "' is not allowed.");
            var i = "https:" === o.protocol;
            if ("https:" === p.protocol && !i && !c.isLoopbackAddr(o.hostname)) throw new Error("SecurityError: An insecure SockJS connection may not be initiated from a page loaded over HTTPS");
            t ? Array.isArray(t) || (t = [t]) : t = [];
            var s = t.sort();
            s.forEach(function (e, t) {
              if (!e) throw new SyntaxError("The protocols entry '" + e + "' is invalid.");
              if (t < s.length - 1 && e === s[t + 1]) throw new SyntaxError("The protocols entry '" + e + "' is duplicated.");
            });
            var a = c.getOrigin(p.href);
            this._origin = a ? a.toLowerCase() : null, o.set("pathname", o.pathname.replace(/\/+$/, "")), this.url = o.href, b("using url", this.url), this._urlInfo = {
              nullOrigin: !f.hasDomain(),
              sameOrigin: c.isOriginEqual(this.url, p.href),
              sameScheme: c.isSchemeEqual(this.url, p.href)
            }, this._ir = new v(this.url, this._urlInfo), this._ir.once("finish", this._receiveInfo.bind(this));
          }
          function g(e) {
            return 1e3 === e || 3e3 <= e && e <= 4999;
          }
          e(y, d), y.prototype.close = function (e, t) {
            if (e && !g(e)) throw new Error("InvalidAccessError: Invalid code");
            if (t && 123 < t.length) throw new SyntaxError("reason argument has an invalid length");
            if (this.readyState !== y.CLOSING && this.readyState !== y.CLOSED) {
              this._close(e || 1e3, t || "Normal closure", !0);
            }
          }, y.prototype.send = function (e) {
            if ("string" != typeof e && (e = "" + e), this.readyState === y.CONNECTING) throw new Error("InvalidStateError: The connection has not been established yet");
            this.readyState === y.OPEN && this._transport.send(t.quote(e));
          }, y.version = x("./version"), y.CONNECTING = 0, y.OPEN = 1, y.CLOSING = 2, y.CLOSED = 3, y.prototype._receiveInfo = function (e, t) {
            if (b("_receiveInfo", t), this._ir = null, e) {
              this._rto = this.countRTO(t), this._transUrl = e.base_url ? e.base_url : this.url, e = o.extend(e, this._urlInfo), b("info", e);
              var n = r.filterToEnabled(this._transportsWhitelist, e);
              this._transports = n.main, b(this._transports.length + " enabled transports"), this._connect();
            } else this._close(1002, "Cannot connect to server");
          }, y.prototype._connect = function () {
            for (var e = this._transports.shift(); e; e = this._transports.shift()) {
              if (b("attempt", e.transportName), e.needBody && (!w.document.body || void 0 !== w.document.readyState && "complete" !== w.document.readyState && "interactive" !== w.document.readyState)) return b("waiting for body"), this._transports.unshift(e), void i.attachEvent("load", this._connect.bind(this));
              var t = Math.max(this._timeout, this._rto * e.roundTrips || 5e3);
              this._transportTimeoutId = setTimeout(this._transportTimeout.bind(this), t), b("using timeout", t);
              var n = c.addPath(this._transUrl, "/" + this._server + "/" + this._generateSessionId()),
                r = this._transportOptions[e.transportName];
              b("transport url", n);
              var o = new e(n, this._transUrl, r);
              return o.on("message", this._transportMessage.bind(this)), o.once("close", this._transportClose.bind(this)), o.transportName = e.transportName, void (this._transport = o);
            }
            this._close(2e3, "All transports failed", !1);
          }, y.prototype._transportTimeout = function () {
            b("_transportTimeout"), this.readyState === y.CONNECTING && (this._transport && this._transport.close(), this._transportClose(2007, "Transport timed out"));
          }, y.prototype._transportMessage = function (e) {
            b("_transportMessage", e);
            var t,
              n = this,
              r = e.slice(0, 1),
              o = e.slice(1);
            switch (r) {
              case "o":
                return void this._open();
              case "h":
                return this.dispatchEvent(new s("heartbeat")), void b("heartbeat", this.transport);
            }
            if (o) try {
              t = JSON.parse(o);
            } catch (e) {
              b("bad json", o);
            }
            if (void 0 !== t) switch (r) {
              case "a":
                Array.isArray(t) && t.forEach(function (e) {
                  b("message", n.transport, e), n.dispatchEvent(new m(e));
                });
                break;
              case "m":
                b("message", this.transport, t), this.dispatchEvent(new m(t));
                break;
              case "c":
                Array.isArray(t) && 2 === t.length && this._close(t[0], t[1], !0);
            } else b("empty payload", o);
          }, y.prototype._transportClose = function (e, t) {
            b("_transportClose", this.transport, e, t), this._transport && (this._transport.removeAllListeners(), this._transport = null, this.transport = null), g(e) || 2e3 === e || this.readyState !== y.CONNECTING ? this._close(e, t) : this._connect();
          }, y.prototype._open = function () {
            b("_open", this._transport && this._transport.transportName, this.readyState), this.readyState === y.CONNECTING ? (this._transportTimeoutId && (clearTimeout(this._transportTimeoutId), this._transportTimeoutId = null), this.readyState = y.OPEN, this.transport = this._transport.transportName, this.dispatchEvent(new s("open")), b("connected", this.transport)) : this._close(1006, "Server lost session");
          }, y.prototype._close = function (t, n, r) {
            b("_close", this.transport, t, n, r, this.readyState);
            var o = !1;
            if (this._ir && (o = !0, this._ir.close(), this._ir = null), this._transport && (this._transport.close(), this._transport = null, this.transport = null), this.readyState === y.CLOSED) throw new Error("InvalidStateError: SockJS has already been closed");
            this.readyState = y.CLOSING, setTimeout(function () {
              this.readyState = y.CLOSED, o && this.dispatchEvent(new s("error"));
              var e = new a("close");
              e.wasClean = r || !1, e.code = t || 1e3, e.reason = n, this.dispatchEvent(e), this.onmessage = this.onclose = this.onerror = null, b("disconnected");
            }.bind(this), 0);
          }, y.prototype.countRTO = function (e) {
            return 100 < e ? 4 * e : 300 + e;
          }, _.exports = function (e) {
            return r = n(e), x("./iframe-bootstrap")(y, e), y;
          };
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "./event/close": 2,
      "./event/event": 4,
      "./event/eventtarget": 5,
      "./event/trans-message": 6,
      "./iframe-bootstrap": 8,
      "./info-receiver": 12,
      "./location": 13,
      "./shims": 15,
      "./utils/browser": 44,
      "./utils/escape": 45,
      "./utils/event": 46,
      "./utils/log": 48,
      "./utils/object": 49,
      "./utils/random": 50,
      "./utils/transport": 51,
      "./utils/url": 52,
      "./version": 53,
      "debug": void 0,
      "inherits": 54,
      "url-parse": 57
    }],
    15: [function (e, t, n) {
      "use strict";

      function a(e) {
        return "[object Function]" === i.toString.call(e);
      }
      function l(e) {
        return "[object String]" === f.call(e);
      }
      var o,
        c = Array.prototype,
        i = Object.prototype,
        r = Function.prototype,
        s = String.prototype,
        u = c.slice,
        f = i.toString,
        h = Object.defineProperty && function () {
          try {
            return Object.defineProperty({}, "x", {}), !0;
          } catch (e) {
            return !1;
          }
        }();
      o = h ? function (e, t, n, r) {
        !r && t in e || Object.defineProperty(e, t, {
          configurable: !0,
          enumerable: !1,
          writable: !0,
          value: n
        });
      } : function (e, t, n, r) {
        !r && t in e || (e[t] = n);
      };
      function d(e, t, n) {
        for (var r in t) i.hasOwnProperty.call(t, r) && o(e, r, t[r], n);
      }
      function p(e) {
        if (null == e) throw new TypeError("can't convert " + e + " to object");
        return Object(e);
      }
      function m() {}
      d(r, {
        bind: function (t) {
          var n = this;
          if (!a(n)) throw new TypeError("Function.prototype.bind called on incompatible " + n);
          for (var r = u.call(arguments, 1), e = Math.max(0, n.length - r.length), o = [], i = 0; i < e; i++) o.push("$" + i);
          var s = Function("binder", "return function (" + o.join(",") + "){ return binder.apply(this, arguments); }")(function () {
            if (this instanceof s) {
              var e = n.apply(this, r.concat(u.call(arguments)));
              return Object(e) === e ? e : this;
            }
            return n.apply(t, r.concat(u.call(arguments)));
          });
          return n.prototype && (m.prototype = n.prototype, s.prototype = new m(), m.prototype = null), s;
        }
      }), d(Array, {
        isArray: function (e) {
          return "[object Array]" === f.call(e);
        }
      });
      var v,
        b,
        y,
        g = Object("a"),
        w = "a" !== g[0] || !(0 in g);
      d(c, {
        forEach: function (e, t) {
          var n = p(this),
            r = w && l(this) ? this.split("") : n,
            o = t,
            i = -1,
            s = r.length >>> 0;
          if (!a(e)) throw new TypeError();
          for (; ++i < s;) i in r && e.call(o, r[i], i, n);
        }
      }, (v = c.forEach, y = b = !0, v && (v.call("foo", function (e, t, n) {
        "object" != typeof n && (b = !1);
      }), v.call([1], function () {
        y = "string" == typeof this;
      }, "x")), !(v && b && y)));
      var x = Array.prototype.indexOf && -1 !== [0, 1].indexOf(1, 2);
      d(c, {
        indexOf: function (e, t) {
          var n = w && l(this) ? this.split("") : p(this),
            r = n.length >>> 0;
          if (!r) return -1;
          var o = 0;
          for (1 < arguments.length && (o = function (e) {
            var t = +e;
            return t != t ? t = 0 : 0 !== t && t !== 1 / 0 && t !== -1 / 0 && (t = (0 < t || -1) * Math.floor(Math.abs(t))), t;
          }(t)), o = 0 <= o ? o : Math.max(0, r + o); o < r; o++) if (o in n && n[o] === e) return o;
          return -1;
        }
      }, x);
      var _,
        E = s.split;
      2 !== "ab".split(/(?:ab)*/).length || 4 !== ".".split(/(.?)(.?)/).length || "t" === "tesst".split(/(s)*/)[1] || 4 !== "test".split(/(?:)/, -1).length || "".split(/.?/).length || 1 < ".".split(/()()/).length ? (_ = void 0 === /()??/.exec("")[1], s.split = function (e, t) {
        var n = this;
        if (void 0 === e && 0 === t) return [];
        if ("[object RegExp]" !== f.call(e)) return E.call(this, e, t);
        var r,
          o,
          i,
          s,
          a = [],
          l = (e.ignoreCase ? "i" : "") + (e.multiline ? "m" : "") + (e.extended ? "x" : "") + (e.sticky ? "y" : ""),
          u = 0;
        for (e = new RegExp(e.source, l + "g"), n += "", _ || (r = new RegExp("^" + e.source + "$(?!\\s)", l)), t = void 0 === t ? -1 >>> 0 : function (e) {
          return e >>> 0;
        }(t); (o = e.exec(n)) && !(u < (i = o.index + o[0].length) && (a.push(n.slice(u, o.index)), !_ && 1 < o.length && o[0].replace(r, function () {
          for (var e = 1; e < arguments.length - 2; e++) void 0 === arguments[e] && (o[e] = void 0);
        }), 1 < o.length && o.index < n.length && c.push.apply(a, o.slice(1)), s = o[0].length, u = i, a.length >= t));) e.lastIndex === o.index && e.lastIndex++;
        return u === n.length ? !s && e.test("") || a.push("") : a.push(n.slice(u)), a.length > t ? a.slice(0, t) : a;
      }) : "0".split(void 0, 0).length && (s.split = function (e, t) {
        return void 0 === e && 0 === t ? [] : E.call(this, e, t);
      });
      var S = s.substr,
        O = "".substr && "b" !== "0b".substr(-1);
      d(s, {
        substr: function (e, t) {
          return S.call(this, e < 0 && (e = this.length + e) < 0 ? 0 : e, t);
        }
      }, O);
    }, {}],
    16: [function (e, t, n) {
      "use strict";

      t.exports = [e("./transport/websocket"), e("./transport/xhr-streaming"), e("./transport/xdr-streaming"), e("./transport/eventsource"), e("./transport/lib/iframe-wrap")(e("./transport/eventsource")), e("./transport/htmlfile"), e("./transport/lib/iframe-wrap")(e("./transport/htmlfile")), e("./transport/xhr-polling"), e("./transport/xdr-polling"), e("./transport/lib/iframe-wrap")(e("./transport/xhr-polling")), e("./transport/jsonp-polling")];
    }, {
      "./transport/eventsource": 20,
      "./transport/htmlfile": 21,
      "./transport/jsonp-polling": 23,
      "./transport/lib/iframe-wrap": 26,
      "./transport/websocket": 38,
      "./transport/xdr-polling": 39,
      "./transport/xdr-streaming": 40,
      "./transport/xhr-polling": 41,
      "./transport/xhr-streaming": 42
    }],
    17: [function (o, f, e) {
      (function (r) {
        (function () {
          "use strict";

          var i = o("events").EventEmitter,
            e = o("inherits"),
            s = o("../../utils/event"),
            a = o("../../utils/url"),
            l = r.XMLHttpRequest,
            u = function () {};
          function c(e, t, n, r) {
            u(e, t);
            var o = this;
            i.call(this), setTimeout(function () {
              o._start(e, t, n, r);
            }, 0);
          }
          e(c, i), c.prototype._start = function (e, t, n, r) {
            var o = this;
            try {
              this.xhr = new l();
            } catch (e) {}
            if (!this.xhr) return u("no xhr"), this.emit("finish", 0, "no xhr support"), void this._cleanup();
            t = a.addQuery(t, "t=" + +new Date()), this.unloadRef = s.unloadAdd(function () {
              u("unload cleanup"), o._cleanup(!0);
            });
            try {
              this.xhr.open(e, t, !0), this.timeout && "timeout" in this.xhr && (this.xhr.timeout = this.timeout, this.xhr.ontimeout = function () {
                u("xhr timeout"), o.emit("finish", 0, ""), o._cleanup(!1);
              });
            } catch (e) {
              return u("exception", e), this.emit("finish", 0, ""), void this._cleanup(!1);
            }
            if (r && r.noCredentials || !c.supportsCORS || (u("withCredentials"), this.xhr.withCredentials = !0), r && r.headers) for (var i in r.headers) this.xhr.setRequestHeader(i, r.headers[i]);
            this.xhr.onreadystatechange = function () {
              if (o.xhr) {
                var e,
                  t,
                  n = o.xhr;
                switch (u("readyState", n.readyState), n.readyState) {
                  case 3:
                    try {
                      t = n.status, e = n.responseText;
                    } catch (e) {}
                    u("status", t), 1223 === t && (t = 204), 200 === t && e && 0 < e.length && (u("chunk"), o.emit("chunk", t, e));
                    break;
                  case 4:
                    t = n.status, u("status", t), 1223 === t && (t = 204), 12005 !== t && 12029 !== t || (t = 0), u("finish", t, n.responseText), o.emit("finish", t, n.responseText), o._cleanup(!1);
                }
              }
            };
            try {
              o.xhr.send(n);
            } catch (e) {
              o.emit("finish", 0, ""), o._cleanup(!1);
            }
          }, c.prototype._cleanup = function (e) {
            if (u("cleanup"), this.xhr) {
              if (this.removeAllListeners(), s.unloadDel(this.unloadRef), this.xhr.onreadystatechange = function () {}, this.xhr.ontimeout && (this.xhr.ontimeout = null), e) try {
                this.xhr.abort();
              } catch (e) {}
              this.unloadRef = this.xhr = null;
            }
          }, c.prototype.close = function () {
            u("close"), this._cleanup(!0);
          }, c.enabled = !!l;
          var t = ["Active"].concat("Object").join("X");
          !c.enabled && t in r && (u("overriding xmlhttprequest"), c.enabled = !!new (l = function () {
            try {
              return new r[t]("Microsoft.XMLHTTP");
            } catch (e) {
              return null;
            }
          })());
          var n = !1;
          try {
            n = "withCredentials" in new l();
          } catch (e) {}
          c.supportsCORS = n, f.exports = c;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../../utils/event": 46,
      "../../utils/url": 52,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    18: [function (e, t, n) {
      (function (e) {
        (function () {
          t.exports = e.EventSource;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {}],
    19: [function (e, n, t) {
      (function (e) {
        (function () {
          "use strict";

          var t = e.WebSocket || e.MozWebSocket;
          n.exports = t ? function (e) {
            return new t(e);
          } : void 0;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {}],
    20: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./lib/ajax-based"),
        i = e("./receiver/eventsource"),
        s = e("./sender/xhr-cors"),
        a = e("eventsource");
      function l(e) {
        if (!l.enabled()) throw new Error("Transport created when disabled");
        o.call(this, e, "/eventsource", i, s);
      }
      r(l, o), l.enabled = function () {
        return !!a;
      }, l.transportName = "eventsource", l.roundTrips = 2, t.exports = l;
    }, {
      "./lib/ajax-based": 24,
      "./receiver/eventsource": 29,
      "./sender/xhr-cors": 35,
      "eventsource": 18,
      "inherits": 54
    }],
    21: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./receiver/htmlfile"),
        i = e("./sender/xhr-local"),
        s = e("./lib/ajax-based");
      function a(e) {
        if (!o.enabled) throw new Error("Transport created when disabled");
        s.call(this, e, "/htmlfile", o, i);
      }
      r(a, s), a.enabled = function (e) {
        return o.enabled && e.sameOrigin;
      }, a.transportName = "htmlfile", a.roundTrips = 2, t.exports = a;
    }, {
      "./lib/ajax-based": 24,
      "./receiver/htmlfile": 30,
      "./sender/xhr-local": 37,
      "inherits": 54
    }],
    22: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        i = e("events").EventEmitter,
        o = e("../version"),
        s = e("../utils/url"),
        a = e("../utils/iframe"),
        l = e("../utils/event"),
        u = e("../utils/random"),
        c = function () {};
      function f(e, t, n) {
        if (!f.enabled()) throw new Error("Transport created when disabled");
        i.call(this);
        var r = this;
        this.origin = s.getOrigin(n), this.baseUrl = n, this.transUrl = t, this.transport = e, this.windowId = u.string(8);
        var o = s.addPath(n, "/iframe.html") + "#" + this.windowId;
        c(e, t, o), this.iframeObj = a.createIframe(o, function (e) {
          c("err callback"), r.emit("close", 1006, "Unable to load an iframe (" + e + ")"), r.close();
        }), this.onmessageCallback = this._message.bind(this), l.attachEvent("message", this.onmessageCallback);
      }
      r(f, i), f.prototype.close = function () {
        if (c("close"), this.removeAllListeners(), this.iframeObj) {
          l.detachEvent("message", this.onmessageCallback);
          try {
            this.postMessage("c");
          } catch (e) {}
          this.iframeObj.cleanup(), this.iframeObj = null, this.onmessageCallback = this.iframeObj = null;
        }
      }, f.prototype._message = function (t) {
        if (c("message", t.data), s.isOriginEqual(t.origin, this.origin)) {
          var n;
          try {
            n = JSON.parse(t.data);
          } catch (e) {
            return void c("bad json", t.data);
          }
          if (n.windowId === this.windowId) switch (n.type) {
            case "s":
              this.iframeObj.loaded(), this.postMessage("s", JSON.stringify([o, this.transport, this.transUrl, this.baseUrl]));
              break;
            case "t":
              this.emit("message", n.data);
              break;
            case "c":
              var e;
              try {
                e = JSON.parse(n.data);
              } catch (e) {
                return void c("bad json", n.data);
              }
              this.emit("close", e[0], e[1]), this.close();
          } else c("mismatched window id", n.windowId, this.windowId);
        } else c("not same origin", t.origin, this.origin);
      }, f.prototype.postMessage = function (e, t) {
        c("postMessage", e, t), this.iframeObj.post(JSON.stringify({
          windowId: this.windowId,
          type: e,
          data: t || ""
        }), this.origin);
      }, f.prototype.send = function (e) {
        c("send", e), this.postMessage("m", e);
      }, f.enabled = function () {
        return a.iframeEnabled;
      }, f.transportName = "iframe", f.roundTrips = 2, t.exports = f;
    }, {
      "../utils/event": 46,
      "../utils/iframe": 47,
      "../utils/random": 50,
      "../utils/url": 52,
      "../version": 53,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    23: [function (s, a, e) {
      (function (i) {
        (function () {
          "use strict";

          var e = s("inherits"),
            t = s("./lib/sender-receiver"),
            n = s("./receiver/jsonp"),
            r = s("./sender/jsonp");
          function o(e) {
            if (!o.enabled()) throw new Error("Transport created when disabled");
            t.call(this, e, "/jsonp", r, n);
          }
          e(o, t), o.enabled = function () {
            return !!i.document;
          }, o.transportName = "jsonp-polling", o.roundTrips = 1, o.needBody = !0, a.exports = o;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "./lib/sender-receiver": 28,
      "./receiver/jsonp": 31,
      "./sender/jsonp": 33,
      "inherits": 54
    }],
    24: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        a = e("../../utils/url"),
        o = e("./sender-receiver"),
        l = function () {};
      function i(e, t, n, r) {
        o.call(this, e, t, function (s) {
          return function (e, t, n) {
            l("create ajax sender", e, t);
            var r = {};
            "string" == typeof t && (r.headers = {
              "Content-type": "text/plain"
            });
            var o = a.addPath(e, "/xhr_send"),
              i = new s("POST", o, t, r);
            return i.once("finish", function (e) {
              if (l("finish", e), i = null, 200 !== e && 204 !== e) return n(new Error("http status " + e));
              n();
            }), function () {
              l("abort"), i.close(), i = null;
              var e = new Error("Aborted");
              e.code = 1e3, n(e);
            };
          };
        }(r), n, r);
      }
      r(i, o), t.exports = i;
    }, {
      "../../utils/url": 52,
      "./sender-receiver": 28,
      "debug": void 0,
      "inherits": 54
    }],
    25: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("events").EventEmitter,
        i = function () {};
      function s(e, t) {
        i(e), o.call(this), this.sendBuffer = [], this.sender = t, this.url = e;
      }
      r(s, o), s.prototype.send = function (e) {
        i("send", e), this.sendBuffer.push(e), this.sendStop || this.sendSchedule();
      }, s.prototype.sendScheduleWait = function () {
        i("sendScheduleWait");
        var e,
          t = this;
        this.sendStop = function () {
          i("sendStop"), t.sendStop = null, clearTimeout(e);
        }, e = setTimeout(function () {
          i("timeout"), t.sendStop = null, t.sendSchedule();
        }, 25);
      }, s.prototype.sendSchedule = function () {
        i("sendSchedule", this.sendBuffer.length);
        var t = this;
        if (0 < this.sendBuffer.length) {
          var e = "[" + this.sendBuffer.join(",") + "]";
          this.sendStop = this.sender(this.url, e, function (e) {
            t.sendStop = null, e ? (i("error", e), t.emit("close", e.code || 1006, "Sending error: " + e), t.close()) : t.sendScheduleWait();
          }), this.sendBuffer = [];
        }
      }, s.prototype._cleanup = function () {
        i("_cleanup"), this.removeAllListeners();
      }, s.prototype.close = function () {
        i("close"), this._cleanup(), this.sendStop && (this.sendStop(), this.sendStop = null);
      }, t.exports = s;
    }, {
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    26: [function (e, n, t) {
      (function (s) {
        (function () {
          "use strict";

          var t = e("inherits"),
            o = e("../iframe"),
            i = e("../../utils/object");
          n.exports = function (r) {
            function e(e, t) {
              o.call(this, r.transportName, e, t);
            }
            return t(e, o), e.enabled = function (e, t) {
              if (!s.document) return !1;
              var n = i.extend({}, t);
              return n.sameOrigin = !0, r.enabled(n) && o.enabled();
            }, e.transportName = "iframe-" + r.transportName, e.needBody = !0, e.roundTrips = o.roundTrips + r.roundTrips - 1, e.facadeTransport = r, e;
          };
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../../utils/object": 49,
      "../iframe": 22,
      "inherits": 54
    }],
    27: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("events").EventEmitter,
        i = function () {};
      function s(e, t, n) {
        i(t), o.call(this), this.Receiver = e, this.receiveUrl = t, this.AjaxObject = n, this._scheduleReceiver();
      }
      r(s, o), s.prototype._scheduleReceiver = function () {
        i("_scheduleReceiver");
        var n = this,
          r = this.poll = new this.Receiver(this.receiveUrl, this.AjaxObject);
        r.on("message", function (e) {
          i("message", e), n.emit("message", e);
        }), r.once("close", function (e, t) {
          i("close", e, t, n.pollIsClosing), n.poll = r = null, n.pollIsClosing || ("network" === t ? n._scheduleReceiver() : (n.emit("close", e || 1006, t), n.removeAllListeners()));
        });
      }, s.prototype.abort = function () {
        i("abort"), this.removeAllListeners(), this.pollIsClosing = !0, this.poll && this.poll.abort();
      }, t.exports = s;
    }, {
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    28: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        a = e("../../utils/url"),
        l = e("./buffered-sender"),
        u = e("./polling"),
        c = function () {};
      function o(e, t, n, r, o) {
        var i = a.addPath(e, t);
        c(i);
        var s = this;
        l.call(this, e, n), this.poll = new u(r, i, o), this.poll.on("message", function (e) {
          c("poll message", e), s.emit("message", e);
        }), this.poll.once("close", function (e, t) {
          c("poll close", e, t), s.poll = null, s.emit("close", e, t), s.close();
        });
      }
      r(o, l), o.prototype.close = function () {
        l.prototype.close.call(this), c("close"), this.removeAllListeners(), this.poll && (this.poll.abort(), this.poll = null);
      }, t.exports = o;
    }, {
      "../../utils/url": 52,
      "./buffered-sender": 25,
      "./polling": 27,
      "debug": void 0,
      "inherits": 54
    }],
    29: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("events").EventEmitter,
        i = e("eventsource"),
        s = function () {};
      function a(e) {
        s(e), o.call(this);
        var n = this,
          r = this.es = new i(e);
        r.onmessage = function (e) {
          s("message", e.data), n.emit("message", decodeURI(e.data));
        }, r.onerror = function (e) {
          s("error", r.readyState, e);
          var t = 2 !== r.readyState ? "network" : "permanent";
          n._cleanup(), n._close(t);
        };
      }
      r(a, o), a.prototype.abort = function () {
        s("abort"), this._cleanup(), this._close("user");
      }, a.prototype._cleanup = function () {
        s("cleanup");
        var e = this.es;
        e && (e.onmessage = e.onerror = null, e.close(), this.es = null);
      }, a.prototype._close = function (e) {
        s("close", e);
        var t = this;
        setTimeout(function () {
          t.emit("close", null, e), t.removeAllListeners();
        }, 200);
      }, t.exports = a;
    }, {
      "debug": void 0,
      "events": 3,
      "eventsource": 18,
      "inherits": 54
    }],
    30: [function (n, c, e) {
      (function (u) {
        (function () {
          "use strict";

          var e = n("inherits"),
            r = n("../../utils/iframe"),
            o = n("../../utils/url"),
            i = n("events").EventEmitter,
            s = n("../../utils/random"),
            a = function () {};
          function l(e) {
            a(e), i.call(this);
            var t = this;
            r.polluteGlobalNamespace(), this.id = "a" + s.string(6), e = o.addQuery(e, "c=" + decodeURIComponent(r.WPrefix + "." + this.id)), a("using htmlfile", l.htmlfileEnabled);
            var n = l.htmlfileEnabled ? r.createHtmlfile : r.createIframe;
            u[r.WPrefix][this.id] = {
              start: function () {
                a("start"), t.iframeObj.loaded();
              },
              message: function (e) {
                a("message", e), t.emit("message", e);
              },
              stop: function () {
                a("stop"), t._cleanup(), t._close("network");
              }
            }, this.iframeObj = n(e, function () {
              a("callback"), t._cleanup(), t._close("permanent");
            });
          }
          e(l, i), l.prototype.abort = function () {
            a("abort"), this._cleanup(), this._close("user");
          }, l.prototype._cleanup = function () {
            a("_cleanup"), this.iframeObj && (this.iframeObj.cleanup(), this.iframeObj = null), delete u[r.WPrefix][this.id];
          }, l.prototype._close = function (e) {
            a("_close", e), this.emit("close", null, e), this.removeAllListeners();
          }, l.htmlfileEnabled = !1;
          var t = ["Active"].concat("Object").join("X");
          if (t in u) try {
            l.htmlfileEnabled = !!new u[t]("htmlfile");
          } catch (e) {}
          l.enabled = l.htmlfileEnabled || r.iframeEnabled, c.exports = l;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../../utils/iframe": 47,
      "../../utils/random": 50,
      "../../utils/url": 52,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    31: [function (t, n, e) {
      (function (c) {
        (function () {
          "use strict";

          var r = t("../../utils/iframe"),
            i = t("../../utils/random"),
            s = t("../../utils/browser"),
            o = t("../../utils/url"),
            e = t("inherits"),
            a = t("events").EventEmitter,
            l = function () {};
          function u(e) {
            l(e);
            var t = this;
            a.call(this), r.polluteGlobalNamespace(), this.id = "a" + i.string(6);
            var n = o.addQuery(e, "c=" + encodeURIComponent(r.WPrefix + "." + this.id));
            c[r.WPrefix][this.id] = this._callback.bind(this), this._createScript(n), this.timeoutId = setTimeout(function () {
              l("timeout"), t._abort(new Error("JSONP script loaded abnormally (timeout)"));
            }, u.timeout);
          }
          e(u, a), u.prototype.abort = function () {
            if (l("abort"), c[r.WPrefix][this.id]) {
              var e = new Error("JSONP user aborted read");
              e.code = 1e3, this._abort(e);
            }
          }, u.timeout = 35e3, u.scriptErrorTimeout = 1e3, u.prototype._callback = function (e) {
            l("_callback", e), this._cleanup(), this.aborting || (e && (l("message", e), this.emit("message", e)), this.emit("close", null, "network"), this.removeAllListeners());
          }, u.prototype._abort = function (e) {
            l("_abort", e), this._cleanup(), this.aborting = !0, this.emit("close", e.code, e.message), this.removeAllListeners();
          }, u.prototype._cleanup = function () {
            if (l("_cleanup"), clearTimeout(this.timeoutId), this.script2 && (this.script2.parentNode.removeChild(this.script2), this.script2 = null), this.script) {
              var e = this.script;
              e.parentNode.removeChild(e), e.onreadystatechange = e.onerror = e.onload = e.onclick = null, this.script = null;
            }
            delete c[r.WPrefix][this.id];
          }, u.prototype._scriptError = function () {
            l("_scriptError");
            var e = this;
            this.errorTimer || (this.errorTimer = setTimeout(function () {
              e.loadedOkay || e._abort(new Error("JSONP script loaded abnormally (onerror)"));
            }, u.scriptErrorTimeout));
          }, u.prototype._createScript = function (e) {
            l("_createScript", e);
            var t,
              n = this,
              r = this.script = c.document.createElement("script");
            if (r.id = "a" + i.string(8), r.src = e, r.type = "text/javascript", r.charset = "UTF-8", r.onerror = this._scriptError.bind(this), r.onload = function () {
              l("onload"), n._abort(new Error("JSONP script loaded abnormally (onload)"));
            }, r.onreadystatechange = function () {
              if (l("onreadystatechange", r.readyState), /loaded|closed/.test(r.readyState)) {
                if (r && r.htmlFor && r.onclick) {
                  n.loadedOkay = !0;
                  try {
                    r.onclick();
                  } catch (e) {}
                }
                r && n._abort(new Error("JSONP script loaded abnormally (onreadystatechange)"));
              }
            }, void 0 === r.async && c.document.attachEvent) if (s.isOpera()) (t = this.script2 = c.document.createElement("script")).text = "try{var a = document.getElementById('" + r.id + "'); if(a)a.onerror();}catch(x){};", r.async = t.async = !1;else {
              try {
                r.htmlFor = r.id, r.event = "onclick";
              } catch (e) {}
              r.async = !0;
            }
            void 0 !== r.async && (r.async = !0);
            var o = c.document.getElementsByTagName("head")[0];
            o.insertBefore(r, o.firstChild), t && o.insertBefore(t, o.firstChild);
          }, n.exports = u;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../../utils/browser": 44,
      "../../utils/iframe": 47,
      "../../utils/random": 50,
      "../../utils/url": 52,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    32: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("events").EventEmitter,
        i = function () {};
      function s(e, t) {
        i(e), o.call(this);
        var r = this;
        this.bufferPosition = 0, this.xo = new t("POST", e, null), this.xo.on("chunk", this._chunkHandler.bind(this)), this.xo.once("finish", function (e, t) {
          i("finish", e, t), r._chunkHandler(e, t), r.xo = null;
          var n = 200 === e ? "network" : "permanent";
          i("close", n), r.emit("close", null, n), r._cleanup();
        });
      }
      r(s, o), s.prototype._chunkHandler = function (e, t) {
        if (i("_chunkHandler", e), 200 === e && t) for (var n = -1;; this.bufferPosition += n + 1) {
          var r = t.slice(this.bufferPosition);
          if (-1 === (n = r.indexOf("\n"))) break;
          var o = r.slice(0, n);
          o && (i("message", o), this.emit("message", o));
        }
      }, s.prototype._cleanup = function () {
        i("_cleanup"), this.removeAllListeners();
      }, s.prototype.abort = function () {
        i("abort"), this.xo && (this.xo.close(), i("close"), this.emit("close", null, "user"), this.xo = null), this._cleanup();
      }, t.exports = s;
    }, {
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    33: [function (e, t, n) {
      (function (f) {
        (function () {
          "use strict";

          var s,
            a,
            l = e("../../utils/random"),
            u = e("../../utils/url"),
            c = function () {};
          t.exports = function (e, t, n) {
            c(e, t), s || (c("createForm"), (s = f.document.createElement("form")).style.display = "none", s.style.position = "absolute", s.method = "POST", s.enctype = "application/x-www-form-urlencoded", s.acceptCharset = "UTF-8", (a = f.document.createElement("textarea")).name = "d", s.appendChild(a), f.document.body.appendChild(s));
            var r = "a" + l.string(8);
            s.target = r, s.action = u.addQuery(u.addPath(e, "/jsonp_send"), "i=" + r);
            var o = function (t) {
              c("createIframe", t);
              try {
                return f.document.createElement('<iframe name="' + t + '">');
              } catch (e) {
                var n = f.document.createElement("iframe");
                return n.name = t, n;
              }
            }(r);
            o.id = r, o.style.display = "none", s.appendChild(o);
            try {
              a.value = t;
            } catch (e) {}
            s.submit();
            function i(e) {
              c("completed", r, e), o.onerror && (o.onreadystatechange = o.onerror = o.onload = null, setTimeout(function () {
                c("cleaning up", r), o.parentNode.removeChild(o), o = null;
              }, 500), a.value = "", n(e));
            }
            return o.onerror = function () {
              c("onerror", r), i();
            }, o.onload = function () {
              c("onload", r), i();
            }, o.onreadystatechange = function (e) {
              c("onreadystatechange", r, o.readyState, e), "complete" === o.readyState && i();
            }, function () {
              c("aborted", r), i(new Error("Aborted"));
            };
          };
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../../utils/random": 50,
      "../../utils/url": 52,
      "debug": void 0
    }],
    34: [function (r, u, e) {
      (function (l) {
        (function () {
          "use strict";

          var o = r("events").EventEmitter,
            e = r("inherits"),
            i = r("../../utils/event"),
            t = r("../../utils/browser"),
            s = r("../../utils/url"),
            a = function () {};
          function n(e, t, n) {
            a(e, t);
            var r = this;
            o.call(this), setTimeout(function () {
              r._start(e, t, n);
            }, 0);
          }
          e(n, o), n.prototype._start = function (e, t, n) {
            a("_start");
            var r = this,
              o = new l.XDomainRequest();
            t = s.addQuery(t, "t=" + +new Date()), o.onerror = function () {
              a("onerror"), r._error();
            }, o.ontimeout = function () {
              a("ontimeout"), r._error();
            }, o.onprogress = function () {
              a("progress", o.responseText), r.emit("chunk", 200, o.responseText);
            }, o.onload = function () {
              a("load"), r.emit("finish", 200, o.responseText), r._cleanup(!1);
            }, this.xdr = o, this.unloadRef = i.unloadAdd(function () {
              r._cleanup(!0);
            });
            try {
              this.xdr.open(e, t), this.timeout && (this.xdr.timeout = this.timeout), this.xdr.send(n);
            } catch (e) {
              this._error();
            }
          }, n.prototype._error = function () {
            this.emit("finish", 0, ""), this._cleanup(!1);
          }, n.prototype._cleanup = function (e) {
            if (a("cleanup", e), this.xdr) {
              if (this.removeAllListeners(), i.unloadDel(this.unloadRef), this.xdr.ontimeout = this.xdr.onerror = this.xdr.onprogress = this.xdr.onload = null, e) try {
                this.xdr.abort();
              } catch (e) {}
              this.unloadRef = this.xdr = null;
            }
          }, n.prototype.close = function () {
            a("close"), this._cleanup(!0);
          }, n.enabled = !(!l.XDomainRequest || !t.hasDomain()), u.exports = n;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../../utils/browser": 44,
      "../../utils/event": 46,
      "../../utils/url": 52,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    35: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("../driver/xhr");
      function i(e, t, n, r) {
        o.call(this, e, t, n, r);
      }
      r(i, o), i.enabled = o.enabled && o.supportsCORS, t.exports = i;
    }, {
      "../driver/xhr": 17,
      "inherits": 54
    }],
    36: [function (e, t, n) {
      "use strict";

      var r = e("events").EventEmitter;
      function o() {
        var e = this;
        r.call(this), this.to = setTimeout(function () {
          e.emit("finish", 200, "{}");
        }, o.timeout);
      }
      e("inherits")(o, r), o.prototype.close = function () {
        clearTimeout(this.to);
      }, o.timeout = 2e3, t.exports = o;
    }, {
      "events": 3,
      "inherits": 54
    }],
    37: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("../driver/xhr");
      function i(e, t, n) {
        o.call(this, e, t, n, {
          noCredentials: !0
        });
      }
      r(i, o), i.enabled = o.enabled, t.exports = i;
    }, {
      "../driver/xhr": 17,
      "inherits": 54
    }],
    38: [function (e, t, n) {
      "use strict";

      var i = e("../utils/event"),
        s = e("../utils/url"),
        r = e("inherits"),
        a = e("events").EventEmitter,
        l = e("./driver/websocket"),
        u = function () {};
      function c(e, t, n) {
        if (!c.enabled()) throw new Error("Transport created when disabled");
        a.call(this), u("constructor", e);
        var r = this,
          o = s.addPath(e, "/websocket");
        o = "https" === o.slice(0, 5) ? "wss" + o.slice(5) : "ws" + o.slice(4), this.url = o, this.ws = new l(this.url, [], n), this.ws.onmessage = function (e) {
          u("message event", e.data), r.emit("message", e.data);
        }, this.unloadRef = i.unloadAdd(function () {
          u("unload"), r.ws.close();
        }), this.ws.onclose = function (e) {
          u("close event", e.code, e.reason), r.emit("close", e.code, e.reason), r._cleanup();
        }, this.ws.onerror = function (e) {
          u("error event", e), r.emit("close", 1006, "WebSocket connection broken"), r._cleanup();
        };
      }
      r(c, a), c.prototype.send = function (e) {
        var t = "[" + e + "]";
        u("send", t), this.ws.send(t);
      }, c.prototype.close = function () {
        u("close");
        var e = this.ws;
        this._cleanup(), e && e.close();
      }, c.prototype._cleanup = function () {
        u("_cleanup");
        var e = this.ws;
        e && (e.onmessage = e.onclose = e.onerror = null), i.unloadDel(this.unloadRef), this.unloadRef = this.ws = null, this.removeAllListeners();
      }, c.enabled = function () {
        return u("enabled"), !!l;
      }, c.transportName = "websocket", c.roundTrips = 2, t.exports = c;
    }, {
      "../utils/event": 46,
      "../utils/url": 52,
      "./driver/websocket": 19,
      "debug": void 0,
      "events": 3,
      "inherits": 54
    }],
    39: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./lib/ajax-based"),
        i = e("./xdr-streaming"),
        s = e("./receiver/xhr"),
        a = e("./sender/xdr");
      function l(e) {
        if (!a.enabled) throw new Error("Transport created when disabled");
        o.call(this, e, "/xhr", s, a);
      }
      r(l, o), l.enabled = i.enabled, l.transportName = "xdr-polling", l.roundTrips = 2, t.exports = l;
    }, {
      "./lib/ajax-based": 24,
      "./receiver/xhr": 32,
      "./sender/xdr": 34,
      "./xdr-streaming": 40,
      "inherits": 54
    }],
    40: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./lib/ajax-based"),
        i = e("./receiver/xhr"),
        s = e("./sender/xdr");
      function a(e) {
        if (!s.enabled) throw new Error("Transport created when disabled");
        o.call(this, e, "/xhr_streaming", i, s);
      }
      r(a, o), a.enabled = function (e) {
        return !e.cookie_needed && !e.nullOrigin && s.enabled && e.sameScheme;
      }, a.transportName = "xdr-streaming", a.roundTrips = 2, t.exports = a;
    }, {
      "./lib/ajax-based": 24,
      "./receiver/xhr": 32,
      "./sender/xdr": 34,
      "inherits": 54
    }],
    41: [function (e, t, n) {
      "use strict";

      var r = e("inherits"),
        o = e("./lib/ajax-based"),
        i = e("./receiver/xhr"),
        s = e("./sender/xhr-cors"),
        a = e("./sender/xhr-local");
      function l(e) {
        if (!a.enabled && !s.enabled) throw new Error("Transport created when disabled");
        o.call(this, e, "/xhr", i, s);
      }
      r(l, o), l.enabled = function (e) {
        return !e.nullOrigin && (!(!a.enabled || !e.sameOrigin) || s.enabled);
      }, l.transportName = "xhr-polling", l.roundTrips = 2, t.exports = l;
    }, {
      "./lib/ajax-based": 24,
      "./receiver/xhr": 32,
      "./sender/xhr-cors": 35,
      "./sender/xhr-local": 37,
      "inherits": 54
    }],
    42: [function (l, u, e) {
      (function (a) {
        (function () {
          "use strict";

          var e = l("inherits"),
            t = l("./lib/ajax-based"),
            n = l("./receiver/xhr"),
            r = l("./sender/xhr-cors"),
            o = l("./sender/xhr-local"),
            i = l("../utils/browser");
          function s(e) {
            if (!o.enabled && !r.enabled) throw new Error("Transport created when disabled");
            t.call(this, e, "/xhr_streaming", n, r);
          }
          e(s, t), s.enabled = function (e) {
            return !e.nullOrigin && !i.isOpera() && r.enabled;
          }, s.transportName = "xhr-streaming", s.roundTrips = 2, s.needBody = !!a.document, u.exports = s;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "../utils/browser": 44,
      "./lib/ajax-based": 24,
      "./receiver/xhr": 32,
      "./sender/xhr-cors": 35,
      "./sender/xhr-local": 37,
      "inherits": 54
    }],
    43: [function (e, t, n) {
      (function (n) {
        (function () {
          "use strict";

          n.crypto && n.crypto.getRandomValues ? t.exports.randomBytes = function (e) {
            var t = new Uint8Array(e);
            return n.crypto.getRandomValues(t), t;
          } : t.exports.randomBytes = function (e) {
            for (var t = new Array(e), n = 0; n < e; n++) t[n] = Math.floor(256 * Math.random());
            return t;
          };
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {}],
    44: [function (e, t, n) {
      (function (e) {
        (function () {
          "use strict";

          t.exports = {
            isOpera: function () {
              return e.navigator && /opera/i.test(e.navigator.userAgent);
            },
            isKonqueror: function () {
              return e.navigator && /konqueror/i.test(e.navigator.userAgent);
            },
            hasDomain: function () {
              if (!e.document) return !0;
              try {
                return !!e.document.domain;
              } catch (e) {
                return !1;
              }
            }
          };
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {}],
    45: [function (e, t, n) {
      "use strict";

      var r,
        o = /[\x00-\x1f\ud800-\udfff\ufffe\uffff\u0300-\u0333\u033d-\u0346\u034a-\u034c\u0350-\u0352\u0357-\u0358\u035c-\u0362\u0374\u037e\u0387\u0591-\u05af\u05c4\u0610-\u0617\u0653-\u0654\u0657-\u065b\u065d-\u065e\u06df-\u06e2\u06eb-\u06ec\u0730\u0732-\u0733\u0735-\u0736\u073a\u073d\u073f-\u0741\u0743\u0745\u0747\u07eb-\u07f1\u0951\u0958-\u095f\u09dc-\u09dd\u09df\u0a33\u0a36\u0a59-\u0a5b\u0a5e\u0b5c-\u0b5d\u0e38-\u0e39\u0f43\u0f4d\u0f52\u0f57\u0f5c\u0f69\u0f72-\u0f76\u0f78\u0f80-\u0f83\u0f93\u0f9d\u0fa2\u0fa7\u0fac\u0fb9\u1939-\u193a\u1a17\u1b6b\u1cda-\u1cdb\u1dc0-\u1dcf\u1dfc\u1dfe\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d\u1fbb\u1fbe\u1fc9\u1fcb\u1fd3\u1fdb\u1fe3\u1feb\u1fee-\u1fef\u1ff9\u1ffb\u1ffd\u2000-\u2001\u20d0-\u20d1\u20d4-\u20d7\u20e7-\u20e9\u2126\u212a-\u212b\u2329-\u232a\u2adc\u302b-\u302c\uaab2-\uaab3\uf900-\ufa0d\ufa10\ufa12\ufa15-\ufa1e\ufa20\ufa22\ufa25-\ufa26\ufa2a-\ufa2d\ufa30-\ufa6d\ufa70-\ufad9\ufb1d\ufb1f\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufb4e\ufff0-\uffff]/g;
      t.exports = {
        quote: function (e) {
          var t = JSON.stringify(e);
          return o.lastIndex = 0, o.test(t) ? (r = r || function (e) {
            var t,
              n = {},
              r = [];
            for (t = 0; t < 65536; t++) r.push(String.fromCharCode(t));
            return e.lastIndex = 0, r.join("").replace(e, function (e) {
              return n[e] = "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4), "";
            }), e.lastIndex = 0, n;
          }(o), t.replace(o, function (e) {
            return r[e];
          })) : t;
        }
      };
    }, {}],
    46: [function (e, t, n) {
      (function (s) {
        (function () {
          "use strict";

          var n = e("./random"),
            r = {},
            o = !1,
            i = s.chrome && s.chrome.app && s.chrome.app.runtime;
          t.exports = {
            attachEvent: function (e, t) {
              void 0 !== s.addEventListener ? s.addEventListener(e, t, !1) : s.document && s.attachEvent && (s.document.attachEvent("on" + e, t), s.attachEvent("on" + e, t));
            },
            detachEvent: function (e, t) {
              void 0 !== s.addEventListener ? s.removeEventListener(e, t, !1) : s.document && s.detachEvent && (s.document.detachEvent("on" + e, t), s.detachEvent("on" + e, t));
            },
            unloadAdd: function (e) {
              if (i) return null;
              var t = n.string(8);
              return r[t] = e, o && setTimeout(this.triggerUnloadCallbacks, 0), t;
            },
            unloadDel: function (e) {
              e in r && delete r[e];
            },
            triggerUnloadCallbacks: function () {
              for (var e in r) r[e](), delete r[e];
            }
          };
          i || t.exports.attachEvent("unload", function () {
            o || (o = !0, t.exports.triggerUnloadCallbacks());
          });
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "./random": 50
    }],
    47: [function (t, p, e) {
      (function (d) {
        (function () {
          "use strict";

          var f = t("./event"),
            e = t("./browser"),
            h = function () {};
          p.exports = {
            WPrefix: "_jp",
            currentWindowId: null,
            polluteGlobalNamespace: function () {
              p.exports.WPrefix in d || (d[p.exports.WPrefix] = {});
            },
            postMessage: function (e, t) {
              d.parent !== d ? d.parent.postMessage(JSON.stringify({
                windowId: p.exports.currentWindowId,
                type: e,
                data: t || ""
              }), "*") : h("Cannot postMessage, no parent window.", e, t);
            },
            createIframe: function (e, t) {
              function n() {
                h("unattach"), clearTimeout(i);
                try {
                  a.onload = null;
                } catch (e) {}
                a.onerror = null;
              }
              function r() {
                h("cleanup"), a && (n(), setTimeout(function () {
                  a && a.parentNode.removeChild(a), a = null;
                }, 0), f.unloadDel(s));
              }
              function o(e) {
                h("onerror", e), a && (r(), t(e));
              }
              var i,
                s,
                a = d.document.createElement("iframe");
              return a.src = e, a.style.display = "none", a.style.position = "absolute", a.onerror = function () {
                o("onerror");
              }, a.onload = function () {
                h("onload"), clearTimeout(i), i = setTimeout(function () {
                  o("onload timeout");
                }, 2e3);
              }, d.document.body.appendChild(a), i = setTimeout(function () {
                o("timeout");
              }, 15e3), s = f.unloadAdd(r), {
                post: function (e, t) {
                  h("post", e, t), setTimeout(function () {
                    try {
                      a && a.contentWindow && a.contentWindow.postMessage(e, t);
                    } catch (e) {}
                  }, 0);
                },
                cleanup: r,
                loaded: n
              };
            },
            createHtmlfile: function (e, t) {
              function n() {
                clearTimeout(i), a.onerror = null;
              }
              function r() {
                u && (n(), f.unloadDel(s), a.parentNode.removeChild(a), a = u = null, CollectGarbage());
              }
              function o(e) {
                h("onerror", e), u && (r(), t(e));
              }
              var i,
                s,
                a,
                l = ["Active"].concat("Object").join("X"),
                u = new d[l]("htmlfile");
              u.open(), u.write('<html><script>document.domain="' + d.document.domain + '";<\/script></html>'), u.close(), u.parentWindow[p.exports.WPrefix] = d[p.exports.WPrefix];
              var c = u.createElement("div");
              return u.body.appendChild(c), a = u.createElement("iframe"), c.appendChild(a), a.src = e, a.onerror = function () {
                o("onerror");
              }, i = setTimeout(function () {
                o("timeout");
              }, 15e3), s = f.unloadAdd(r), {
                post: function (e, t) {
                  try {
                    setTimeout(function () {
                      a && a.contentWindow && a.contentWindow.postMessage(e, t);
                    }, 0);
                  } catch (e) {}
                },
                cleanup: r,
                loaded: n
              };
            }
          }, p.exports.iframeEnabled = !1, d.document && (p.exports.iframeEnabled = ("function" == typeof d.postMessage || "object" == typeof d.postMessage) && !e.isKonqueror());
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "./browser": 44,
      "./event": 46,
      "debug": void 0
    }],
    48: [function (e, t, n) {
      (function (r) {
        (function () {
          "use strict";

          var n = {};
          ["log", "debug", "warn"].forEach(function (e) {
            var t;
            try {
              t = r.console && r.console[e] && r.console[e].apply;
            } catch (e) {}
            n[e] = t ? function () {
              return r.console[e].apply(r.console, arguments);
            } : "log" === e ? function () {} : n.log;
          }), t.exports = n;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {}],
    49: [function (e, t, n) {
      "use strict";

      t.exports = {
        isObject: function (e) {
          var t = typeof e;
          return "function" == t || "object" == t && !!e;
        },
        extend: function (e) {
          if (!this.isObject(e)) return e;
          for (var t, n, r = 1, o = arguments.length; r < o; r++) for (n in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
          return e;
        }
      };
    }, {}],
    50: [function (e, t, n) {
      "use strict";

      var i = e("crypto"),
        s = "abcdefghijklmnopqrstuvwxyz012345";
      t.exports = {
        string: function (e) {
          for (var t = s.length, n = i.randomBytes(e), r = [], o = 0; o < e; o++) r.push(s.substr(n[o] % t, 1));
          return r.join("");
        },
        number: function (e) {
          return Math.floor(Math.random() * e);
        },
        numberString: function (e) {
          var t = ("" + (e - 1)).length;
          return (new Array(t + 1).join("0") + this.number(e)).slice(-t);
        }
      };
    }, {
      "crypto": 43
    }],
    51: [function (e, t, n) {
      "use strict";

      var o = function () {};
      t.exports = function (e) {
        return {
          filterToEnabled: function (t, n) {
            var r = {
              main: [],
              facade: []
            };
            return t ? "string" == typeof t && (t = [t]) : t = [], e.forEach(function (e) {
              e && ("websocket" !== e.transportName || !1 !== n.websocket ? t.length && -1 === t.indexOf(e.transportName) ? o("not in whitelist", e.transportName) : e.enabled(n) ? (o("enabled", e.transportName), r.main.push(e), e.facadeTransport && r.facade.push(e.facadeTransport)) : o("disabled", e.transportName) : o("disabled from server", "websocket"));
            }), r;
          }
        };
      };
    }, {
      "debug": void 0
    }],
    52: [function (e, t, n) {
      "use strict";

      var r = e("url-parse"),
        o = function () {};
      t.exports = {
        getOrigin: function (e) {
          if (!e) return null;
          var t = new r(e);
          if ("file:" === t.protocol) return null;
          var n = t.port;
          return n = n || ("https:" === t.protocol ? "443" : "80"), t.protocol + "//" + t.hostname + ":" + n;
        },
        isOriginEqual: function (e, t) {
          var n = this.getOrigin(e) === this.getOrigin(t);
          return o("same", e, t, n), n;
        },
        isSchemeEqual: function (e, t) {
          return e.split(":")[0] === t.split(":")[0];
        },
        addPath: function (e, t) {
          var n = e.split("?");
          return n[0] + t + (n[1] ? "?" + n[1] : "");
        },
        addQuery: function (e, t) {
          return e + (-1 === e.indexOf("?") ? "?" + t : "&" + t);
        },
        isLoopbackAddr: function (e) {
          return /^127\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/i.test(e) || /^\[::1\]$/.test(e);
        }
      };
    }, {
      "debug": void 0,
      "url-parse": 57
    }],
    53: [function (e, t, n) {
      t.exports = "1.6.1";
    }, {}],
    54: [function (e, t, n) {
      "function" == typeof Object.create ? t.exports = function (e, t) {
        t && (e.super_ = t, e.prototype = Object.create(t.prototype, {
          constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
          }
        }));
      } : t.exports = function (e, t) {
        if (t) {
          e.super_ = t;
          function n() {}
          n.prototype = t.prototype, e.prototype = new n(), e.prototype.constructor = e;
        }
      };
    }, {}],
    55: [function (e, t, n) {
      "use strict";

      var i = Object.prototype.hasOwnProperty;
      function s(e) {
        try {
          return decodeURIComponent(e.replace(/\+/g, " "));
        } catch (e) {
          return null;
        }
      }
      n.stringify = function (e, t) {
        t = t || "";
        var n,
          r,
          o = [];
        for (r in "string" != typeof t && (t = "?"), e) if (i.call(e, r)) {
          if ((n = e[r]) || null != n && !isNaN(n) || (n = ""), r = encodeURIComponent(r), n = encodeURIComponent(n), null === r || null === n) continue;
          o.push(r + "=" + n);
        }
        return o.length ? t + o.join("&") : "";
      }, n.parse = function (e) {
        for (var t, n = /([^=?&]+)=?([^&]*)/g, r = {}; t = n.exec(e);) {
          var o = s(t[1]),
            i = s(t[2]);
          null === o || null === i || o in r || (r[o] = i);
        }
        return r;
      };
    }, {}],
    56: [function (e, t, n) {
      "use strict";

      t.exports = function (e, t) {
        if (t = t.split(":")[0], !(e = +e)) return !1;
        switch (t) {
          case "http":
          case "ws":
            return 80 !== e;
          case "https":
          case "wss":
            return 443 !== e;
          case "ftp":
            return 21 !== e;
          case "gopher":
            return 70 !== e;
          case "file":
            return !1;
        }
        return 0 !== e;
      };
    }, {}],
    57: [function (e, n, t) {
      (function (a) {
        (function () {
          "use strict";

          var d = e("requires-port"),
            p = e("querystringify"),
            t = /^[\x00-\x20\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/,
            m = /[\n\r\t]/g,
            i = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
            l = /:\d+$/,
            u = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i,
            v = /^[a-zA-Z]:/;
          function b(e) {
            return (e || "").toString().replace(t, "");
          }
          var y = [["#", "hash"], ["?", "query"], function (e, t) {
              return w(t.protocol) ? e.replace(/\\/g, "/") : e;
            }, ["/", "pathname"], ["@", "auth", 1], [NaN, "host", void 0, 1, 1], [/:(\d*)$/, "port", void 0, 1], [NaN, "hostname", void 0, 1, 1]],
            s = {
              hash: 1,
              query: 1
            };
          function g(e) {
            var t,
              n = ("undefined" != typeof window ? window : void 0 !== a ? a : "undefined" != typeof self ? self : {}).location || {},
              r = {},
              o = typeof (e = e || n);
            if ("blob:" === e.protocol) r = new _(unescape(e.pathname), {});else if ("string" == o) for (t in r = new _(e, {}), s) delete r[t];else if ("object" == o) {
              for (t in e) t in s || (r[t] = e[t]);
              void 0 === r.slashes && (r.slashes = i.test(e.href));
            }
            return r;
          }
          function w(e) {
            return "file:" === e || "ftp:" === e || "http:" === e || "https:" === e || "ws:" === e || "wss:" === e;
          }
          function x(e, t) {
            e = (e = b(e)).replace(m, ""), t = t || {};
            var n,
              r = u.exec(e),
              o = r[1] ? r[1].toLowerCase() : "",
              i = !!r[2],
              s = !!r[3],
              a = 0;
            return i ? a = s ? (n = r[2] + r[3] + r[4], r[2].length + r[3].length) : (n = r[2] + r[4], r[2].length) : s ? (n = r[3] + r[4], a = r[3].length) : n = r[4], "file:" === o ? 2 <= a && (n = n.slice(2)) : w(o) ? n = r[4] : o ? i && (n = n.slice(2)) : 2 <= a && w(t.protocol) && (n = r[4]), {
              protocol: o,
              slashes: i || w(o),
              slashesCount: a,
              rest: n
            };
          }
          function _(e, t, n) {
            if (e = (e = b(e)).replace(m, ""), !(this instanceof _)) return new _(e, t, n);
            var r,
              o,
              i,
              s,
              a,
              l,
              u = y.slice(),
              c = typeof t,
              f = this,
              h = 0;
            for ("object" != c && "string" != c && (n = t, t = null), n && "function" != typeof n && (n = p.parse), r = !(o = x(e || "", t = g(t))).protocol && !o.slashes, f.slashes = o.slashes || r && t.slashes, f.protocol = o.protocol || t.protocol || "", e = o.rest, ("file:" === o.protocol && (2 !== o.slashesCount || v.test(e)) || !o.slashes && (o.protocol || o.slashesCount < 2 || !w(f.protocol))) && (u[3] = [/(.*)/, "pathname"]); h < u.length; h++) "function" != typeof (s = u[h]) ? (i = s[0], l = s[1], i != i ? f[l] = e : "string" == typeof i ? ~(a = "@" === i ? e.lastIndexOf(i) : e.indexOf(i)) && (e = "number" == typeof s[2] ? (f[l] = e.slice(0, a), e.slice(a + s[2])) : (f[l] = e.slice(a), e.slice(0, a))) : (a = i.exec(e)) && (f[l] = a[1], e = e.slice(0, a.index)), f[l] = f[l] || r && s[3] && t[l] || "", s[4] && (f[l] = f[l].toLowerCase())) : e = s(e, f);
            n && (f.query = n(f.query)), r && t.slashes && "/" !== f.pathname.charAt(0) && ("" !== f.pathname || "" !== t.pathname) && (f.pathname = function (e, t) {
              if ("" === e) return t;
              for (var n = (t || "/").split("/").slice(0, -1).concat(e.split("/")), r = n.length, o = n[r - 1], i = !1, s = 0; r--;) "." === n[r] ? n.splice(r, 1) : ".." === n[r] ? (n.splice(r, 1), s++) : s && (0 === r && (i = !0), n.splice(r, 1), s--);
              return i && n.unshift(""), "." !== o && ".." !== o || n.push(""), n.join("/");
            }(f.pathname, t.pathname)), "/" !== f.pathname.charAt(0) && w(f.protocol) && (f.pathname = "/" + f.pathname), d(f.port, f.protocol) || (f.host = f.hostname, f.port = ""), f.username = f.password = "", f.auth && (~(a = f.auth.indexOf(":")) ? (f.username = f.auth.slice(0, a), f.username = encodeURIComponent(decodeURIComponent(f.username)), f.password = f.auth.slice(a + 1), f.password = encodeURIComponent(decodeURIComponent(f.password))) : f.username = encodeURIComponent(decodeURIComponent(f.auth)), f.auth = f.password ? f.username + ":" + f.password : f.username), f.origin = "file:" !== f.protocol && w(f.protocol) && f.host ? f.protocol + "//" + f.host : "null", f.href = f.toString();
          }
          _.prototype = {
            set: function (e, t, n) {
              var r = this;
              switch (e) {
                case "query":
                  "string" == typeof t && t.length && (t = (n || p.parse)(t)), r[e] = t;
                  break;
                case "port":
                  r[e] = t, d(t, r.protocol) ? t && (r.host = r.hostname + ":" + t) : (r.host = r.hostname, r[e] = "");
                  break;
                case "hostname":
                  r[e] = t, r.port && (t += ":" + r.port), r.host = t;
                  break;
                case "host":
                  r[e] = t, l.test(t) ? (t = t.split(":"), r.port = t.pop(), r.hostname = t.join(":")) : (r.hostname = t, r.port = "");
                  break;
                case "protocol":
                  r.protocol = t.toLowerCase(), r.slashes = !n;
                  break;
                case "pathname":
                case "hash":
                  if (t) {
                    var o = "pathname" === e ? "/" : "#";
                    r[e] = t.charAt(0) !== o ? o + t : t;
                  } else r[e] = t;
                  break;
                case "username":
                case "password":
                  r[e] = encodeURIComponent(t);
                  break;
                case "auth":
                  var i = t.indexOf(":");
                  ~i ? (r.username = t.slice(0, i), r.username = encodeURIComponent(decodeURIComponent(r.username)), r.password = t.slice(i + 1), r.password = encodeURIComponent(decodeURIComponent(r.password))) : r.username = encodeURIComponent(decodeURIComponent(t));
              }
              for (var s = 0; s < y.length; s++) {
                var a = y[s];
                a[4] && (r[a[1]] = r[a[1]].toLowerCase());
              }
              return r.auth = r.password ? r.username + ":" + r.password : r.username, r.origin = "file:" !== r.protocol && w(r.protocol) && r.host ? r.protocol + "//" + r.host : "null", r.href = r.toString(), r;
            },
            toString: function (e) {
              e && "function" == typeof e || (e = p.stringify);
              var t,
                n = this,
                r = n.host,
                o = n.protocol;
              o && ":" !== o.charAt(o.length - 1) && (o += ":");
              var i = o + (n.protocol && n.slashes || w(n.protocol) ? "//" : "");
              return n.username ? (i += n.username, n.password && (i += ":" + n.password), i += "@") : n.password ? (i += ":" + n.password, i += "@") : "file:" !== n.protocol && w(n.protocol) && !r && "/" !== n.pathname && (i += "@"), (":" === r[r.length - 1] || l.test(n.hostname) && !n.port) && (r += ":"), i += r + n.pathname, (t = "object" == typeof n.query ? e(n.query) : n.query) && (i += "?" !== t.charAt(0) ? "?" + t : t), n.hash && (i += n.hash), i;
            }
          }, _.extractProtocol = x, _.location = g, _.trimLeft = b, _.qs = p, n.exports = _;
        }).call(this);
      }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
    }, {
      "querystringify": 55,
      "requires-port": 56
    }]
  }, {}, [1])(1);
});

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/************************************************************************/
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!***************************!*\
  !*** ./src/background.js ***!
  \***************************/
let SockJS = __webpack_require__(/*! @src/js/libs/sockjs */ "./src/js/libs/sockjs.js");
var sock = new SockJS("http://127.0.0.1:9900");
sock.onmessage = function (event) {
  const message = JSON.parse(event.data);
  console.log(message, 1818);
  switch (message.type) {
    case 'reloadExtend':
      console.log('构建完成! 耗时: ' + message.data.time + 'ms');
      if (message.data.success) {
        chrome.runtime.reload();
        console.log('✅ 构建成功，刷新扩展');
      } else {
        console.error('❌ 构建失败，错误数: ' + message.data.errors);
      }
      break;
    default:
      console.log('收到消息:', message);
  }
};

/**
 * Created by Allen Liu on 2026/3/20.
 */

//默认是打开弹窗，想要新tab打开需要去掉manifest.json里的 "default_popup": "popup.html"配置
chrome.action.onClicked.addListener(async tab => {
  chrome.tabs.create({
    url: chrome.runtime.getURL("popup.html"),
    active: true
  });
});
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUNBLENBQUMsVUFBU0EsQ0FBQyxFQUFDO0VBQUMsSUFBRyxJQUFvRCxFQUFDRSxNQUFNLENBQUNELE9BQU8sR0FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQUEsRUFBK0s7QUFBQSxDQUFDLENBQUMsWUFBVTtFQUFDLE9BQU8sU0FBU1MsQ0FBQ0EsQ0FBQ0MsQ0FBQyxFQUFDQyxDQUFDLEVBQUNDLENBQUMsRUFBQztJQUFDLFNBQVNDLENBQUNBLENBQUNDLENBQUMsRUFBQ2QsQ0FBQyxFQUFDO01BQUMsSUFBRyxDQUFDVyxDQUFDLENBQUNHLENBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBRyxDQUFDSixDQUFDLENBQUNJLENBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBSUMsQ0FBQyxHQUFDLFNBQW1DO1VBQUMsSUFBRyxDQUFDZixDQUFDLElBQUVlLENBQUMsRUFBQyxPQUFPQSxPQUFDLENBQUNELENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztVQUFDLElBQUdHLENBQUMsRUFBQyxPQUFPQSxDQUFDLENBQUNILENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztVQUFDLElBQUlJLENBQUMsR0FBQyxJQUFJQyxLQUFLLENBQUMsc0JBQXNCLEdBQUNMLENBQUMsR0FBQyxHQUFHLENBQUM7VUFBQyxNQUFNSSxDQUFDLENBQUNFLElBQUksR0FBQyxrQkFBa0IsRUFBQ0YsQ0FBQztRQUFBO1FBQUMsSUFBSUcsQ0FBQyxHQUFDVixDQUFDLENBQUNHLENBQUMsQ0FBQyxHQUFDO1VBQUNiLE9BQU8sRUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDUyxDQUFDLENBQUNJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDUSxJQUFJLENBQUNELENBQUMsQ0FBQ3BCLE9BQU8sRUFBQyxVQUFTRCxDQUFDLEVBQUM7VUFBQyxPQUFPYSxDQUFDLENBQUNILENBQUMsQ0FBQ0ksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNkLENBQUMsQ0FBQyxJQUFFQSxDQUFDLENBQUM7UUFBQSxDQUFDLEVBQUNxQixDQUFDLEVBQUNBLENBQUMsQ0FBQ3BCLE9BQU8sRUFBQ1EsQ0FBQyxFQUFDQyxDQUFDLEVBQUNDLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO01BQUE7TUFBQyxPQUFPRCxDQUFDLENBQUNHLENBQUMsQ0FBQyxDQUFDYixPQUFPO0lBQUE7SUFBQyxLQUFJLElBQUlnQixDQUFDLEdBQUMsU0FBbUMsRUFBQ2pCLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ1ksQ0FBQyxDQUFDVyxNQUFNLEVBQUN2QixDQUFDLEVBQUUsRUFBQ2EsQ0FBQyxDQUFDRCxDQUFDLENBQUNaLENBQUMsQ0FBQyxDQUFDO0lBQUMsT0FBT2EsQ0FBQztFQUFBLENBQUMsQ0FBQztJQUFDLENBQUMsRUFBQyxDQUFDLFVBQVNFLENBQUMsRUFBQ0csQ0FBQyxFQUFDbEIsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTYyxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDLElBQUlkLENBQUMsR0FBQ2UsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO1VBQUNHLENBQUMsQ0FBQ2pCLE9BQU8sR0FBQ2MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDZixDQUFDLENBQUMsRUFBQyxnQkFBZ0IsSUFBR2MsQ0FBQyxJQUFFVSxVQUFVLENBQUNWLENBQUMsQ0FBQ1csY0FBYyxFQUFDLENBQUMsQ0FBQztRQUFBLENBQUMsRUFBRUgsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLFFBQVEsRUFBQyxFQUFFO01BQUMsa0JBQWtCLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFTTCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJRyxDQUFDLEdBQUNsQixDQUFDLENBQUMsVUFBVSxDQUFDO1FBQUNxQixDQUFDLEdBQUNyQixDQUFDLENBQUMsU0FBUyxDQUFDO01BQUMsU0FBU1MsQ0FBQ0EsQ0FBQSxFQUFFO1FBQUNZLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLElBQUksQ0FBQ0ksU0FBUyxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ0MsUUFBUSxHQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ1AsSUFBSSxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUNRLE1BQU0sR0FBQyxFQUFFO01BQUE7TUFBQ1YsQ0FBQyxDQUFDVCxDQUFDLEVBQUNZLENBQUMsQ0FBQyxFQUFDUCxDQUFDLENBQUNiLE9BQU8sR0FBQ1EsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLFNBQVMsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsQ0FBQyxFQUFDLENBQUMsVUFBU1QsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLGVBQWUsQ0FBQztNQUFDLFNBQVNTLENBQUNBLENBQUEsRUFBRTtRQUFDWSxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7TUFBQTtNQUFDSixDQUFDLENBQUNULENBQUMsRUFBQ1ksQ0FBQyxDQUFDLEVBQUNaLENBQUMsQ0FBQ29CLFNBQVMsQ0FBQ0Msa0JBQWtCLEdBQUMsVUFBUzlCLENBQUMsRUFBQztRQUFDQSxDQUFDLEdBQUMsT0FBTyxJQUFJLENBQUMrQixVQUFVLENBQUMvQixDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMrQixVQUFVLEdBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDdEIsQ0FBQyxDQUFDb0IsU0FBUyxDQUFDRyxJQUFJLEdBQUMsVUFBU2xCLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO1FBQUMsSUFBSUcsQ0FBQyxHQUFDLElBQUk7VUFBQ0csQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFDLElBQUksQ0FBQ1ksRUFBRSxDQUFDbkIsQ0FBQyxFQUFDLFNBQVNkLENBQUNBLENBQUEsRUFBRTtVQUFDa0IsQ0FBQyxDQUFDZ0IsY0FBYyxDQUFDcEIsQ0FBQyxFQUFDZCxDQUFDLENBQUMsRUFBQ3FCLENBQUMsS0FBR0EsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDTixDQUFDLENBQUNvQixLQUFLLENBQUMsSUFBSSxFQUFDQyxTQUFTLENBQUMsQ0FBQztRQUFBLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQzNCLENBQUMsQ0FBQ29CLFNBQVMsQ0FBQ1EsSUFBSSxHQUFDLFlBQVU7UUFBQyxJQUFJckMsQ0FBQyxHQUFDb0MsU0FBUyxDQUFDLENBQUMsQ0FBQztVQUFDdEIsQ0FBQyxHQUFDLElBQUksQ0FBQ2lCLFVBQVUsQ0FBQy9CLENBQUMsQ0FBQztRQUFDLElBQUdjLENBQUMsRUFBQztVQUFDLEtBQUksSUFBSUMsQ0FBQyxHQUFDcUIsU0FBUyxDQUFDYixNQUFNLEVBQUNMLENBQUMsR0FBQyxJQUFJb0IsS0FBSyxDQUFDdkIsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDTSxDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUNOLENBQUMsRUFBQ00sQ0FBQyxFQUFFLEVBQUNILENBQUMsQ0FBQ0csQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDZSxTQUFTLENBQUNmLENBQUMsQ0FBQztVQUFDLEtBQUksSUFBSVosQ0FBQyxHQUFDLENBQUMsRUFBQ0EsQ0FBQyxHQUFDSyxDQUFDLENBQUNTLE1BQU0sRUFBQ2QsQ0FBQyxFQUFFLEVBQUNLLENBQUMsQ0FBQ0wsQ0FBQyxDQUFDLENBQUMwQixLQUFLLENBQUMsSUFBSSxFQUFDakIsQ0FBQyxDQUFDO1FBQUE7TUFBQyxDQUFDLEVBQUNULENBQUMsQ0FBQ29CLFNBQVMsQ0FBQ0ksRUFBRSxHQUFDeEIsQ0FBQyxDQUFDb0IsU0FBUyxDQUFDVSxXQUFXLEdBQUNsQixDQUFDLENBQUNRLFNBQVMsQ0FBQ1csZ0JBQWdCLEVBQUMvQixDQUFDLENBQUNvQixTQUFTLENBQUNLLGNBQWMsR0FBQ2IsQ0FBQyxDQUFDUSxTQUFTLENBQUNZLG1CQUFtQixFQUFDM0IsQ0FBQyxDQUFDYixPQUFPLENBQUN5QyxZQUFZLEdBQUNqQyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsZUFBZSxFQUFDLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFTVCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxTQUFTRyxDQUFDQSxDQUFDbEIsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDMkMsSUFBSSxHQUFDM0MsQ0FBQztNQUFBO01BQUNrQixDQUFDLENBQUNXLFNBQVMsQ0FBQ0gsU0FBUyxHQUFDLFVBQVMxQixDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO1FBQUMsT0FBTyxJQUFJLENBQUM0QixJQUFJLEdBQUMzQyxDQUFDLEVBQUMsSUFBSSxDQUFDNEMsT0FBTyxHQUFDOUIsQ0FBQyxFQUFDLElBQUksQ0FBQytCLFVBQVUsR0FBQzlCLENBQUMsRUFBQyxJQUFJLENBQUMrQixTQUFTLEdBQUMsQ0FBQyxJQUFJQyxJQUFJLENBQUQsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFDLEVBQUM3QixDQUFDLENBQUNXLFNBQVMsQ0FBQ21CLGVBQWUsR0FBQyxZQUFVLENBQUMsQ0FBQyxFQUFDOUIsQ0FBQyxDQUFDVyxTQUFTLENBQUNvQixjQUFjLEdBQUMsWUFBVSxDQUFDLENBQUMsRUFBQy9CLENBQUMsQ0FBQ2dDLGVBQWUsR0FBQyxDQUFDLEVBQUNoQyxDQUFDLENBQUNpQyxTQUFTLEdBQUMsQ0FBQyxFQUFDakMsQ0FBQyxDQUFDa0MsY0FBYyxHQUFDLENBQUMsRUFBQ3RDLENBQUMsQ0FBQ2IsT0FBTyxHQUFDaUIsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFDLENBQUMsRUFBQyxDQUFDLFVBQVNsQixDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxTQUFTRyxDQUFDQSxDQUFBLEVBQUU7UUFBQyxJQUFJLENBQUNhLFVBQVUsR0FBQyxDQUFDLENBQUM7TUFBQTtNQUFDYixDQUFDLENBQUNXLFNBQVMsQ0FBQ1csZ0JBQWdCLEdBQUMsVUFBU3hDLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUNkLENBQUMsSUFBSSxJQUFJLENBQUMrQixVQUFVLEtBQUcsSUFBSSxDQUFDQSxVQUFVLENBQUMvQixDQUFDLENBQUMsR0FBQyxFQUFFLENBQUM7UUFBQyxJQUFJZSxDQUFDLEdBQUMsSUFBSSxDQUFDZ0IsVUFBVSxDQUFDL0IsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxDQUFDLEtBQUdlLENBQUMsQ0FBQ3NDLE9BQU8sQ0FBQ3ZDLENBQUMsQ0FBQyxLQUFHQyxDQUFDLEdBQUNBLENBQUMsQ0FBQ3VDLE1BQU0sQ0FBQyxDQUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ2lCLFVBQVUsQ0FBQy9CLENBQUMsQ0FBQyxHQUFDZSxDQUFDO01BQUEsQ0FBQyxFQUFDRyxDQUFDLENBQUNXLFNBQVMsQ0FBQ1ksbUJBQW1CLEdBQUMsVUFBU3pDLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUMsSUFBSUMsQ0FBQyxHQUFDLElBQUksQ0FBQ2dCLFVBQVUsQ0FBQy9CLENBQUMsQ0FBQztRQUFDLElBQUdlLENBQUMsRUFBQztVQUFDLElBQUlHLENBQUMsR0FBQ0gsQ0FBQyxDQUFDc0MsT0FBTyxDQUFDdkMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxDQUFDLEtBQUdJLENBQUMsS0FBRyxDQUFDLEdBQUNILENBQUMsQ0FBQ1EsTUFBTSxHQUFDLElBQUksQ0FBQ1EsVUFBVSxDQUFDL0IsQ0FBQyxDQUFDLEdBQUNlLENBQUMsQ0FBQ3dDLEtBQUssQ0FBQyxDQUFDLEVBQUNyQyxDQUFDLENBQUMsQ0FBQ29DLE1BQU0sQ0FBQ3ZDLENBQUMsQ0FBQ3dDLEtBQUssQ0FBQ3JDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sSUFBSSxDQUFDYSxVQUFVLENBQUMvQixDQUFDLENBQUMsQ0FBQztRQUFBO01BQUMsQ0FBQyxFQUFDa0IsQ0FBQyxDQUFDVyxTQUFTLENBQUMyQixhQUFhLEdBQUMsWUFBVTtRQUFDLElBQUl4RCxDQUFDLEdBQUNvQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1VBQUN0QixDQUFDLEdBQUNkLENBQUMsQ0FBQzJDLElBQUk7VUFBQzVCLENBQUMsR0FBQyxDQUFDLEtBQUdxQixTQUFTLENBQUNiLE1BQU0sR0FBQyxDQUFDdkIsQ0FBQyxDQUFDLEdBQUNzQyxLQUFLLENBQUNILEtBQUssQ0FBQyxJQUFJLEVBQUNDLFNBQVMsQ0FBQztRQUFDLElBQUcsSUFBSSxDQUFDLElBQUksR0FBQ3RCLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxJQUFJLEdBQUNBLENBQUMsQ0FBQyxDQUFDcUIsS0FBSyxDQUFDLElBQUksRUFBQ3BCLENBQUMsQ0FBQyxFQUFDRCxDQUFDLElBQUksSUFBSSxDQUFDaUIsVUFBVSxFQUFDLEtBQUksSUFBSWIsQ0FBQyxHQUFDLElBQUksQ0FBQ2EsVUFBVSxDQUFDakIsQ0FBQyxDQUFDLEVBQUNPLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ0gsQ0FBQyxDQUFDSyxNQUFNLEVBQUNGLENBQUMsRUFBRSxFQUFDSCxDQUFDLENBQUNHLENBQUMsQ0FBQyxDQUFDYyxLQUFLLENBQUMsSUFBSSxFQUFDcEIsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDRCxDQUFDLENBQUNiLE9BQU8sR0FBQ2lCLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFTbEIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLFNBQVMsQ0FBQztNQUFDLFNBQVNTLENBQUNBLENBQUNULENBQUMsRUFBQztRQUFDcUIsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDSSxTQUFTLENBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDK0IsSUFBSSxHQUFDekQsQ0FBQztNQUFBO01BQUNrQixDQUFDLENBQUNULENBQUMsRUFBQ1ksQ0FBQyxDQUFDLEVBQUNQLENBQUMsQ0FBQ2IsT0FBTyxHQUFDUSxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFTVCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJRyxDQUFDLEdBQUNsQixDQUFDLENBQUMsZ0JBQWdCLENBQUM7TUFBQyxTQUFTcUIsQ0FBQ0EsQ0FBQ3JCLENBQUMsRUFBQztRQUFDLENBQUMsSUFBSSxDQUFDMEQsVUFBVSxHQUFDMUQsQ0FBQyxFQUFFaUMsRUFBRSxDQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMwQixpQkFBaUIsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUM1RCxDQUFDLENBQUNpQyxFQUFFLENBQUMsT0FBTyxFQUFDLElBQUksQ0FBQzRCLGVBQWUsQ0FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO01BQUE7TUFBQ3ZDLENBQUMsQ0FBQ1EsU0FBUyxDQUFDZ0MsZUFBZSxHQUFDLFVBQVM3RCxDQUFDLEVBQUNjLENBQUMsRUFBQztRQUFDSSxDQUFDLENBQUM0QyxXQUFXLENBQUMsR0FBRyxFQUFDQyxJQUFJLENBQUNDLFNBQVMsQ0FBQyxDQUFDaEUsQ0FBQyxFQUFDYyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDTyxDQUFDLENBQUNRLFNBQVMsQ0FBQzhCLGlCQUFpQixHQUFDLFVBQVMzRCxDQUFDLEVBQUM7UUFBQ2tCLENBQUMsQ0FBQzRDLFdBQVcsQ0FBQyxHQUFHLEVBQUM5RCxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUNxQixDQUFDLENBQUNRLFNBQVMsQ0FBQ29DLEtBQUssR0FBQyxVQUFTakUsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDMEQsVUFBVSxDQUFDUSxJQUFJLENBQUNsRSxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUNxQixDQUFDLENBQUNRLFNBQVMsQ0FBQ3NDLE1BQU0sR0FBQyxZQUFVO1FBQUMsSUFBSSxDQUFDVCxVQUFVLENBQUNVLEtBQUssQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDVixVQUFVLENBQUM1QixrQkFBa0IsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDaEIsQ0FBQyxDQUFDYixPQUFPLEdBQUNvQixDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsZ0JBQWdCLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFTckIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSXNELENBQUMsR0FBQ3JFLENBQUMsQ0FBQyxhQUFhLENBQUM7UUFBQ2tCLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7UUFBQ3NFLENBQUMsR0FBQ3RFLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQ3FCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztRQUFDdUUsQ0FBQyxHQUFDdkUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO1FBQUN3RSxDQUFDLEdBQUN4RSxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQUN5RSxDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztNQUFDM0QsQ0FBQyxDQUFDYixPQUFPLEdBQUMsVUFBU1csQ0FBQyxFQUFDWixDQUFDLEVBQUM7UUFBQyxJQUFJYSxDQUFDO1VBQUNJLENBQUMsR0FBQyxDQUFDLENBQUM7UUFBQ2pCLENBQUMsQ0FBQzBFLE9BQU8sQ0FBQyxVQUFTMUUsQ0FBQyxFQUFDO1VBQUNBLENBQUMsQ0FBQzJFLGVBQWUsS0FBRzFELENBQUMsQ0FBQ2pCLENBQUMsQ0FBQzJFLGVBQWUsQ0FBQ0MsYUFBYSxDQUFDLEdBQUM1RSxDQUFDLENBQUMyRSxlQUFlLENBQUM7UUFBQSxDQUFDLENBQUMsRUFBQzFELENBQUMsQ0FBQ0ksQ0FBQyxDQUFDdUQsYUFBYSxDQUFDLEdBQUN2RCxDQUFDLEVBQUNULENBQUMsQ0FBQ2lFLGdCQUFnQixHQUFDLFlBQVU7VUFBQyxJQUFJbEUsQ0FBQztVQUFDNEQsQ0FBQyxDQUFDTyxlQUFlLEdBQUNOLENBQUMsQ0FBQ08sSUFBSSxDQUFDeEIsS0FBSyxDQUFDLENBQUMsQ0FBQztVQUFDckMsQ0FBQyxDQUFDOEQsV0FBVyxDQUFDLFNBQVMsRUFBQyxVQUFTbEUsQ0FBQyxFQUFDO1lBQUMsSUFBR0EsQ0FBQyxDQUFDbUUsTUFBTSxLQUFHQyxNQUFNLEtBQUcsS0FBSyxDQUFDLEtBQUdyRSxDQUFDLEtBQUdBLENBQUMsR0FBQ0MsQ0FBQyxDQUFDcUUsTUFBTSxDQUFDLEVBQUNyRSxDQUFDLENBQUNxRSxNQUFNLEtBQUd0RSxDQUFDLENBQUMsRUFBQztjQUFDLElBQUlFLENBQUM7Y0FBQyxJQUFHO2dCQUFDQSxDQUFDLEdBQUNnRCxJQUFJLENBQUNxQixLQUFLLENBQUN0RSxDQUFDLENBQUMyQyxJQUFJLENBQUM7Y0FBQSxDQUFDLFFBQU16RCxDQUFDLEVBQUM7Z0JBQUMsT0FBTyxLQUFLeUUsQ0FBQyxDQUFDLFVBQVUsRUFBQzNELENBQUMsQ0FBQzJDLElBQUksQ0FBQztjQUFBO2NBQUMsSUFBRzFDLENBQUMsQ0FBQ3NFLFFBQVEsS0FBR2QsQ0FBQyxDQUFDTyxlQUFlLEVBQUMsUUFBTy9ELENBQUMsQ0FBQzRCLElBQUk7Z0JBQUUsS0FBSSxHQUFHO2tCQUFDLElBQUkzQyxDQUFDO2tCQUFDLElBQUc7b0JBQUNBLENBQUMsR0FBQytELElBQUksQ0FBQ3FCLEtBQUssQ0FBQ3JFLENBQUMsQ0FBQzBDLElBQUksQ0FBQztrQkFBQSxDQUFDLFFBQU16RCxDQUFDLEVBQUM7b0JBQUN5RSxDQUFDLENBQUMsVUFBVSxFQUFDMUQsQ0FBQyxDQUFDMEMsSUFBSSxDQUFDO29CQUFDO2tCQUFLO2tCQUFDLElBQUl2QyxDQUFDLEdBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFBQ1MsQ0FBQyxHQUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUFDVSxDQUFDLEdBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUM7a0JBQUMsSUFBR3lFLENBQUMsQ0FBQ3ZELENBQUMsRUFBQ0csQ0FBQyxFQUFDWixDQUFDLEVBQUNDLENBQUMsQ0FBQyxFQUFDUSxDQUFDLEtBQUdOLENBQUMsQ0FBQzBFLE9BQU8sRUFBQyxNQUFNLElBQUluRSxLQUFLLENBQUMsd0NBQXdDLEdBQUNELENBQUMsR0FBQyxrQkFBa0IsR0FBQ04sQ0FBQyxDQUFDMEUsT0FBTyxHQUFDLElBQUksQ0FBQztrQkFBQyxJQUFHLENBQUNqQixDQUFDLENBQUNrQixhQUFhLENBQUM5RSxDQUFDLEVBQUMrRCxDQUFDLENBQUNnQixJQUFJLENBQUMsSUFBRSxDQUFDbkIsQ0FBQyxDQUFDa0IsYUFBYSxDQUFDN0UsQ0FBQyxFQUFDOEQsQ0FBQyxDQUFDZ0IsSUFBSSxDQUFDLEVBQUMsTUFBTSxJQUFJckUsS0FBSyxDQUFDLDREQUE0RCxHQUFDcUQsQ0FBQyxDQUFDZ0IsSUFBSSxHQUFDLElBQUksR0FBQy9FLENBQUMsR0FBQyxJQUFJLEdBQUNDLENBQUMsR0FBQyxHQUFHLENBQUM7a0JBQUNDLENBQUMsR0FBQyxJQUFJMkQsQ0FBQyxDQUFDLElBQUlyRCxDQUFDLENBQUNJLENBQUMsQ0FBQyxDQUFDWixDQUFDLEVBQUNDLENBQUMsQ0FBQyxDQUFDO2tCQUFDO2dCQUFNLEtBQUksR0FBRztrQkFBQ0MsQ0FBQyxDQUFDc0QsS0FBSyxDQUFDbEQsQ0FBQyxDQUFDMEMsSUFBSSxDQUFDO2tCQUFDO2dCQUFNLEtBQUksR0FBRztrQkFBQzlDLENBQUMsSUFBRUEsQ0FBQyxDQUFDd0QsTUFBTSxDQUFDLENBQUMsRUFBQ3hELENBQUMsR0FBQyxJQUFJO2NBQUE7WUFBQztVQUFDLENBQUMsQ0FBQyxFQUFDNEQsQ0FBQyxDQUFDVCxXQUFXLENBQUMsR0FBRyxDQUFDO1FBQUEsQ0FBQztNQUFBLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxVQUFVLEVBQUMsQ0FBQztNQUFDLHdCQUF3QixFQUFDLEVBQUU7TUFBQyxZQUFZLEVBQUMsRUFBRTtNQUFDLGVBQWUsRUFBQyxFQUFFO01BQUMsZ0JBQWdCLEVBQUMsRUFBRTtNQUFDLGFBQWEsRUFBQyxFQUFFO01BQUMsT0FBTyxFQUFDLEtBQUs7SUFBQyxDQUFDLENBQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFTOUQsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDMEMsWUFBWTtRQUFDckIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDVSxDQUFDLEdBQUNWLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztRQUFDVyxDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztNQUFDLFNBQVNGLENBQUNBLENBQUNULENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUNJLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQztRQUFDLElBQUlELENBQUMsR0FBQyxJQUFJO1VBQUNaLENBQUMsR0FBQyxDQUFDLElBQUlzQyxJQUFJLENBQUQsQ0FBQztRQUFDLElBQUksQ0FBQzBDLEVBQUUsR0FBQyxJQUFJM0UsQ0FBQyxDQUFDLEtBQUssRUFBQ2QsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDeUYsRUFBRSxDQUFDekQsSUFBSSxDQUFDLFFBQVEsRUFBQyxVQUFTaEMsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7VUFBQyxJQUFJQyxDQUFDLEVBQUNHLENBQUM7VUFBQyxJQUFHLEdBQUcsS0FBR2xCLENBQUMsRUFBQztZQUFDLElBQUdrQixDQUFDLEdBQUMsQ0FBQyxJQUFJNkIsSUFBSSxDQUFELENBQUMsR0FBQ3RDLENBQUMsRUFBQ0ssQ0FBQyxFQUFDLElBQUc7Y0FBQ0MsQ0FBQyxHQUFDZ0QsSUFBSSxDQUFDcUIsS0FBSyxDQUFDdEUsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxRQUFNZCxDQUFDLEVBQUM7Y0FBQ1csQ0FBQyxDQUFDLFVBQVUsRUFBQ0csQ0FBQyxDQUFDO1lBQUE7WUFBQ0osQ0FBQyxDQUFDZ0YsUUFBUSxDQUFDM0UsQ0FBQyxDQUFDLEtBQUdBLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQztVQUFBO1VBQUNNLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLEVBQUN0QixDQUFDLEVBQUNHLENBQUMsQ0FBQyxFQUFDRyxDQUFDLENBQUNTLGtCQUFrQixDQUFDLENBQUM7UUFBQSxDQUFDLENBQUM7TUFBQTtNQUFDVCxDQUFDLENBQUNaLENBQUMsRUFBQ1MsQ0FBQyxDQUFDLEVBQUNULENBQUMsQ0FBQ29CLFNBQVMsQ0FBQ3VDLEtBQUssR0FBQyxZQUFVO1FBQUMsSUFBSSxDQUFDdEMsa0JBQWtCLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzJELEVBQUUsQ0FBQ3JCLEtBQUssQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDdEQsQ0FBQyxDQUFDYixPQUFPLEdBQUNRLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxnQkFBZ0IsRUFBQyxFQUFFO01BQUMsT0FBTyxFQUFDLEtBQUssQ0FBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU1QsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDMEMsWUFBWTtRQUFDakMsQ0FBQyxHQUFDVCxDQUFDLENBQUMsOEJBQThCLENBQUM7UUFBQ1UsQ0FBQyxHQUFDVixDQUFDLENBQUMsYUFBYSxDQUFDO01BQUMsU0FBU1csQ0FBQ0EsQ0FBQ1gsQ0FBQyxFQUFDO1FBQUMsSUFBSWUsQ0FBQyxHQUFDLElBQUk7UUFBQ00sQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDcUUsRUFBRSxHQUFDLElBQUlqRixDQUFDLENBQUNWLENBQUMsRUFBQ1MsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDa0YsRUFBRSxDQUFDM0QsSUFBSSxDQUFDLFFBQVEsRUFBQyxVQUFTaEMsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7VUFBQ0MsQ0FBQyxDQUFDNEUsRUFBRSxHQUFDLElBQUksRUFBQzVFLENBQUMsQ0FBQ3NCLElBQUksQ0FBQyxTQUFTLEVBQUMwQixJQUFJLENBQUNDLFNBQVMsQ0FBQyxDQUFDaEUsQ0FBQyxFQUFDYyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUEsQ0FBQyxDQUFDO01BQUE7TUFBQ0ksQ0FBQyxDQUFDUCxDQUFDLEVBQUNVLENBQUMsQ0FBQyxFQUFDVixDQUFDLENBQUNpRSxhQUFhLEdBQUMsc0JBQXNCLEVBQUNqRSxDQUFDLENBQUNrQixTQUFTLENBQUN1QyxLQUFLLEdBQUMsWUFBVTtRQUFDLElBQUksQ0FBQ3VCLEVBQUUsS0FBRyxJQUFJLENBQUNBLEVBQUUsQ0FBQ3ZCLEtBQUssQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDdUIsRUFBRSxHQUFDLElBQUksQ0FBQyxFQUFDLElBQUksQ0FBQzdELGtCQUFrQixDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUNoQixDQUFDLENBQUNiLE9BQU8sR0FBQ1UsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLGFBQWEsRUFBQyxDQUFDO01BQUMsOEJBQThCLEVBQUMsRUFBRTtNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0ksQ0FBQyxFQUFDTSxDQUFDLEVBQUNyQixDQUFDLEVBQUM7TUFBQyxDQUFDLFVBQVNhLENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSUssQ0FBQyxHQUFDSCxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMyQixZQUFZO1lBQUMxQyxDQUFDLEdBQUNlLENBQUMsQ0FBQyxVQUFVLENBQUM7WUFBQ04sQ0FBQyxHQUFDTSxDQUFDLENBQUMsZUFBZSxDQUFDO1lBQUNMLENBQUMsR0FBQ0ssQ0FBQyxDQUFDLG9CQUFvQixDQUFDO1lBQUNKLENBQUMsR0FBQ0ksQ0FBQyxDQUFDLHdCQUF3QixDQUFDO1lBQUNILENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO1VBQUMsU0FBU0UsQ0FBQ0EsQ0FBQ0EsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7WUFBQyxJQUFJTSxDQUFDLEdBQUMsSUFBSTtZQUFDSCxDQUFDLENBQUNJLElBQUksQ0FBQyxJQUFJLENBQUM7WUFBQyxTQUFTdEIsQ0FBQ0EsQ0FBQSxFQUFFO2NBQUMsSUFBSUEsQ0FBQyxHQUFDcUIsQ0FBQyxDQUFDdUUsR0FBRyxHQUFDLElBQUlsRixDQUFDLENBQUNDLENBQUMsQ0FBQ2lFLGFBQWEsRUFBQzdELENBQUMsRUFBQ0QsQ0FBQyxDQUFDO2NBQUNkLENBQUMsQ0FBQ2dDLElBQUksQ0FBQyxTQUFTLEVBQUMsVUFBU2xCLENBQUMsRUFBQztnQkFBQyxJQUFHQSxDQUFDLEVBQUM7a0JBQUMsSUFBSWQsQ0FBQztrQkFBQyxJQUFHO29CQUFDQSxDQUFDLEdBQUMrRCxJQUFJLENBQUNxQixLQUFLLENBQUN0RSxDQUFDLENBQUM7a0JBQUEsQ0FBQyxRQUFNZCxDQUFDLEVBQUM7b0JBQUMsT0FBT1ksQ0FBQyxDQUFDLFVBQVUsRUFBQ0UsQ0FBQyxDQUFDLEVBQUNPLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBQyxLQUFLaEIsQ0FBQyxDQUFDK0MsS0FBSyxDQUFDLENBQUM7a0JBQUE7a0JBQUMsSUFBSXJELENBQUMsR0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFBQ2tCLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7a0JBQUNxQixDQUFDLENBQUNnQixJQUFJLENBQUMsUUFBUSxFQUFDdEIsQ0FBQyxFQUFDRyxDQUFDLENBQUM7Z0JBQUE7Z0JBQUNHLENBQUMsQ0FBQytDLEtBQUssQ0FBQyxDQUFDO2NBQUEsQ0FBQyxDQUFDLEVBQUNwRSxDQUFDLENBQUNnQyxJQUFJLENBQUMsT0FBTyxFQUFDLFlBQVU7Z0JBQUNYLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBQ2hCLENBQUMsQ0FBQytDLEtBQUssQ0FBQyxDQUFDO2NBQUEsQ0FBQyxDQUFDO1lBQUE7WUFBQ3ZELENBQUMsQ0FBQ2dGLFFBQVEsQ0FBQ0MsSUFBSSxHQUFDOUYsQ0FBQyxDQUFDLENBQUMsR0FBQ1MsQ0FBQyxDQUFDdUUsV0FBVyxDQUFDLE1BQU0sRUFBQ2hGLENBQUMsQ0FBQztVQUFBO1VBQUNBLENBQUMsQ0FBQ2MsQ0FBQyxFQUFDSSxDQUFDLENBQUMsRUFBQ0osQ0FBQyxDQUFDaUYsT0FBTyxHQUFDLFlBQVU7WUFBQyxPQUFPckYsQ0FBQyxDQUFDcUYsT0FBTyxDQUFDLENBQUM7VUFBQSxDQUFDLEVBQUNqRixDQUFDLENBQUNlLFNBQVMsQ0FBQ3VDLEtBQUssR0FBQyxZQUFVO1lBQUMsSUFBSSxDQUFDd0IsR0FBRyxJQUFFLElBQUksQ0FBQ0EsR0FBRyxDQUFDeEIsS0FBSyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUN0QyxrQkFBa0IsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDOEQsR0FBRyxHQUFDLElBQUk7VUFBQSxDQUFDLEVBQUN2RSxDQUFDLENBQUNwQixPQUFPLEdBQUNhLENBQUM7UUFBQSxDQUFDLEVBQUVRLElBQUksQ0FBQyxJQUFJLENBQUM7TUFBQSxDQUFDLEVBQUVBLElBQUksQ0FBQyxJQUFJLEVBQUMsV0FBVyxJQUFFLE9BQU9oQixxQkFBTSxHQUFDQSxxQkFBTSxHQUFDLFdBQVcsSUFBRSxPQUFPQyxJQUFJLEdBQUNBLElBQUksR0FBQyxXQUFXLElBQUUsT0FBT0YsTUFBTSxHQUFDQSxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyx3QkFBd0IsRUFBQyxFQUFFO01BQUMsb0JBQW9CLEVBQUMsRUFBRTtNQUFDLGVBQWUsRUFBQyxFQUFFO01BQUMsT0FBTyxFQUFDLEtBQUssQ0FBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0wsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDMEMsWUFBWTtRQUFDckIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDUyxDQUFDLEdBQUNULENBQUMsQ0FBQyxhQUFhLENBQUM7UUFBQ1UsQ0FBQyxHQUFDVixDQUFDLENBQUMsd0JBQXdCLENBQUM7UUFBQ1csQ0FBQyxHQUFDWCxDQUFDLENBQUMsNkJBQTZCLENBQUM7UUFBQ1ksQ0FBQyxHQUFDWixDQUFDLENBQUMsOEJBQThCLENBQUM7UUFBQ2EsQ0FBQyxHQUFDYixDQUFDLENBQUMsNkJBQTZCLENBQUM7UUFBQ2lCLENBQUMsR0FBQ2pCLENBQUMsQ0FBQyxlQUFlLENBQUM7UUFBQ3FFLENBQUMsR0FBQ3JFLENBQUMsQ0FBQyxhQUFhLENBQUM7UUFBQ3NFLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0MsQ0FBQ0EsQ0FBQ3ZFLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUN3RCxDQUFDLENBQUN0RSxDQUFDLENBQUM7UUFBQyxJQUFJZSxDQUFDLEdBQUMsSUFBSTtRQUFDRyxDQUFDLENBQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQ0UsVUFBVSxDQUFDLFlBQVU7VUFBQ1QsQ0FBQyxDQUFDaUYsS0FBSyxDQUFDaEcsQ0FBQyxFQUFDYyxDQUFDLENBQUM7UUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUE7TUFBQ08sQ0FBQyxDQUFDa0QsQ0FBQyxFQUFDckQsQ0FBQyxDQUFDLEVBQUNxRCxDQUFDLENBQUMwQixZQUFZLEdBQUMsVUFBU2pHLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7UUFBQyxPQUFPQSxDQUFDLENBQUNtRixVQUFVLEdBQUMsSUFBSTdCLENBQUMsQ0FBQ3ZELENBQUMsRUFBQ0YsQ0FBQyxDQUFDLEdBQUNELENBQUMsQ0FBQ29GLE9BQU8sR0FBQyxJQUFJMUIsQ0FBQyxDQUFDdkQsQ0FBQyxFQUFDSCxDQUFDLENBQUMsR0FBQ0QsQ0FBQyxDQUFDcUYsT0FBTyxJQUFFaEYsQ0FBQyxDQUFDb0YsVUFBVSxHQUFDLElBQUk5QixDQUFDLENBQUN2RCxDQUFDLEVBQUNKLENBQUMsQ0FBQyxHQUFDTyxDQUFDLENBQUM4RSxPQUFPLENBQUMsQ0FBQyxHQUFDLElBQUk5RSxDQUFDLENBQUNqQixDQUFDLEVBQUNjLENBQUMsQ0FBQyxHQUFDLElBQUl1RCxDQUFDLENBQUN2RCxDQUFDLEVBQUNELENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQzBELENBQUMsQ0FBQzFDLFNBQVMsQ0FBQ21FLEtBQUssR0FBQyxVQUFTaEcsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7UUFBQyxJQUFJQyxDQUFDLEdBQUMsSUFBSTtVQUFDRyxDQUFDLEdBQUNULENBQUMsQ0FBQzJGLE9BQU8sQ0FBQ3BHLENBQUMsRUFBQyxPQUFPLENBQUM7UUFBQ3NFLENBQUMsQ0FBQyxPQUFPLEVBQUNwRCxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUN1RSxFQUFFLEdBQUNsQixDQUFDLENBQUMwQixZQUFZLENBQUNqRyxDQUFDLEVBQUNrQixDQUFDLEVBQUNKLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ3VGLFVBQVUsR0FBQzdFLFVBQVUsQ0FBQyxZQUFVO1VBQUM4QyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUN2RCxDQUFDLENBQUN1RixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQ3ZGLENBQUMsQ0FBQ3NCLElBQUksQ0FBQyxRQUFRLENBQUM7UUFBQSxDQUFDLEVBQUNrQyxDQUFDLENBQUNnQyxPQUFPLENBQUMsRUFBQyxJQUFJLENBQUNkLEVBQUUsQ0FBQ3pELElBQUksQ0FBQyxRQUFRLEVBQUMsVUFBU2hDLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1VBQUN3RCxDQUFDLENBQUMsUUFBUSxFQUFDdEUsQ0FBQyxFQUFDYyxDQUFDLENBQUMsRUFBQ0MsQ0FBQyxDQUFDdUYsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUN2RixDQUFDLENBQUNzQixJQUFJLENBQUMsUUFBUSxFQUFDckMsQ0FBQyxFQUFDYyxDQUFDLENBQUM7UUFBQSxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUN5RCxDQUFDLENBQUMxQyxTQUFTLENBQUN5RSxRQUFRLEdBQUMsVUFBU3RHLENBQUMsRUFBQztRQUFDc0UsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFDa0MsWUFBWSxDQUFDLElBQUksQ0FBQ0gsVUFBVSxDQUFDLEVBQUMsSUFBSSxDQUFDQSxVQUFVLEdBQUMsSUFBSSxFQUFDLENBQUNyRyxDQUFDLElBQUUsSUFBSSxDQUFDeUYsRUFBRSxJQUFFLElBQUksQ0FBQ0EsRUFBRSxDQUFDckIsS0FBSyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNxQixFQUFFLEdBQUMsSUFBSTtNQUFBLENBQUMsRUFBQ2xCLENBQUMsQ0FBQzFDLFNBQVMsQ0FBQ3VDLEtBQUssR0FBQyxZQUFVO1FBQUNFLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLENBQUN4QyxrQkFBa0IsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDd0UsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDL0IsQ0FBQyxDQUFDZ0MsT0FBTyxHQUFDLEdBQUcsRUFBQ3pGLENBQUMsQ0FBQ2IsT0FBTyxHQUFDc0UsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLGFBQWEsRUFBQyxDQUFDO01BQUMsZUFBZSxFQUFDLEVBQUU7TUFBQyx3QkFBd0IsRUFBQyxFQUFFO01BQUMsNkJBQTZCLEVBQUMsRUFBRTtNQUFDLDZCQUE2QixFQUFDLEVBQUU7TUFBQyw4QkFBOEIsRUFBQyxFQUFFO01BQUMsYUFBYSxFQUFDLEVBQUU7TUFBQyxPQUFPLEVBQUMsS0FBSyxDQUFDO01BQUMsUUFBUSxFQUFDLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTdkUsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLENBQUMsVUFBU2YsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxZQUFVO1VBQUMsWUFBWTs7VUFBQ2MsQ0FBQyxDQUFDYixPQUFPLEdBQUNELENBQUMsQ0FBQ3lHLFFBQVEsSUFBRTtZQUFDdEIsTUFBTSxFQUFDLHFCQUFxQjtZQUFDdUIsUUFBUSxFQUFDLE9BQU87WUFBQ0MsSUFBSSxFQUFDLFdBQVc7WUFBQ0MsSUFBSSxFQUFDLEVBQUU7WUFBQ3BCLElBQUksRUFBQyxtQkFBbUI7WUFBQ1QsSUFBSSxFQUFDO1VBQUUsQ0FBQztRQUFBLENBQUMsRUFBRXpELElBQUksQ0FBQyxJQUFJLENBQUM7TUFBQSxDQUFDLEVBQUVBLElBQUksQ0FBQyxJQUFJLEVBQUMsV0FBVyxJQUFFLE9BQU9oQixxQkFBTSxHQUFDQSxxQkFBTSxHQUFDLFdBQVcsSUFBRSxPQUFPQyxJQUFJLEdBQUNBLElBQUksR0FBQyxXQUFXLElBQUUsT0FBT0YsTUFBTSxHQUFDQSxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTd0csQ0FBQyxFQUFDQyxDQUFDLEVBQUM5RyxDQUFDLEVBQUM7TUFBQyxDQUFDLFVBQVMrRyxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDRixDQUFDLENBQUMsU0FBUyxDQUFDO1VBQUMsSUFBSTNGLENBQUM7WUFBQ04sQ0FBQyxHQUFDaUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQztZQUFDN0csQ0FBQyxHQUFDNkcsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUFDaEcsQ0FBQyxHQUFDZ0csQ0FBQyxDQUFDLGdCQUFnQixDQUFDO1lBQUMvRixDQUFDLEdBQUMrRixDQUFDLENBQUMsZ0JBQWdCLENBQUM7WUFBQzVGLENBQUMsR0FBQzRGLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFBQ3BHLENBQUMsR0FBQ29HLENBQUMsQ0FBQyxlQUFlLENBQUM7WUFBQzlGLENBQUMsR0FBQzhGLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztZQUFDeEYsQ0FBQyxHQUFDd0YsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO1lBQUN4QyxDQUFDLEdBQUN3QyxDQUFDLENBQUMsaUJBQWlCLENBQUM7WUFBQ3ZDLENBQUMsR0FBQ3VDLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFBQ25HLENBQUMsR0FBQ21HLENBQUMsQ0FBQyxlQUFlLENBQUM7WUFBQ3RDLENBQUMsR0FBQ3NDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztZQUFDckMsQ0FBQyxHQUFDcUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztZQUFDbEcsQ0FBQyxHQUFDa0csQ0FBQyxDQUFDLGVBQWUsQ0FBQztZQUFDcEMsQ0FBQyxHQUFDb0MsQ0FBQyxDQUFDLHVCQUF1QixDQUFDO1lBQUNHLENBQUMsR0FBQ0gsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO1lBQUNJLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO1VBQUMsU0FBU0MsQ0FBQ0EsQ0FBQ2xILENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7WUFBQyxJQUFHLEVBQUUsSUFBSSxZQUFZbUcsQ0FBQyxDQUFDLEVBQUMsT0FBTyxJQUFJQSxDQUFDLENBQUNsSCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO1lBQUMsSUFBR3FCLFNBQVMsQ0FBQ2IsTUFBTSxHQUFDLENBQUMsRUFBQyxNQUFNLElBQUk0RixTQUFTLENBQUMsc0VBQXNFLENBQUM7WUFBQzVDLENBQUMsQ0FBQ2pELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLENBQUM4RixVQUFVLEdBQUNGLENBQUMsQ0FBQ0csVUFBVSxFQUFDLElBQUksQ0FBQ0MsVUFBVSxHQUFDLEVBQUUsRUFBQyxJQUFJLENBQUNaLFFBQVEsR0FBQyxFQUFFLEVBQUMsQ0FBQzNGLENBQUMsR0FBQ0EsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFFd0csbUJBQW1CLElBQUVqRCxDQUFDLENBQUNrRCxJQUFJLENBQUMsZ0VBQWdFLENBQUMsRUFBQyxJQUFJLENBQUNDLG9CQUFvQixHQUFDMUcsQ0FBQyxDQUFDMkcsVUFBVSxFQUFDLElBQUksQ0FBQ0MsaUJBQWlCLEdBQUM1RyxDQUFDLENBQUM2RyxnQkFBZ0IsSUFBRSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNDLFFBQVEsR0FBQzlHLENBQUMsQ0FBQ3dGLE9BQU8sSUFBRSxDQUFDO1lBQUMsSUFBSXJGLENBQUMsR0FBQ0gsQ0FBQyxDQUFDK0csU0FBUyxJQUFFLENBQUM7WUFBQyxJQUFHLFVBQVUsSUFBRSxPQUFPNUcsQ0FBQyxFQUFDLElBQUksQ0FBQzZHLGtCQUFrQixHQUFDN0csQ0FBQyxDQUFDLEtBQUk7Y0FBQyxJQUFHLFFBQVEsSUFBRSxPQUFPQSxDQUFDLEVBQUMsTUFBTSxJQUFJaUcsU0FBUyxDQUFDLDZFQUE2RSxDQUFDO2NBQUMsSUFBSSxDQUFDWSxrQkFBa0IsR0FBQyxZQUFVO2dCQUFDLE9BQU9sSCxDQUFDLENBQUNtSCxNQUFNLENBQUM5RyxDQUFDLENBQUM7Y0FBQSxDQUFDO1lBQUE7WUFBQyxJQUFJLENBQUMrRyxPQUFPLEdBQUNsSCxDQUFDLENBQUNtSCxNQUFNLElBQUVySCxDQUFDLENBQUNzSCxZQUFZLENBQUMsR0FBRyxDQUFDO1lBQUMsSUFBSTlHLENBQUMsR0FBQyxJQUFJVCxDQUFDLENBQUNaLENBQUMsQ0FBQztZQUFDLElBQUcsQ0FBQ3FCLENBQUMsQ0FBQ3NGLElBQUksSUFBRSxDQUFDdEYsQ0FBQyxDQUFDcUYsUUFBUSxFQUFDLE1BQU0sSUFBSTBCLFdBQVcsQ0FBQyxXQUFXLEdBQUNwSSxDQUFDLEdBQUMsY0FBYyxDQUFDO1lBQUMsSUFBR3FCLENBQUMsQ0FBQzBELElBQUksRUFBQyxNQUFNLElBQUlxRCxXQUFXLENBQUMscUNBQXFDLENBQUM7WUFBQyxJQUFHLE9BQU8sS0FBRy9HLENBQUMsQ0FBQ3FGLFFBQVEsSUFBRSxRQUFRLEtBQUdyRixDQUFDLENBQUNxRixRQUFRLEVBQUMsTUFBTSxJQUFJMEIsV0FBVyxDQUFDLHdEQUF3RCxHQUFDL0csQ0FBQyxDQUFDcUYsUUFBUSxHQUFDLG1CQUFtQixDQUFDO1lBQUMsSUFBSWpHLENBQUMsR0FBQyxRQUFRLEtBQUdZLENBQUMsQ0FBQ3FGLFFBQVE7WUFBQyxJQUFHLFFBQVEsS0FBR2xDLENBQUMsQ0FBQ2tDLFFBQVEsSUFBRSxDQUFDakcsQ0FBQyxJQUFFLENBQUNRLENBQUMsQ0FBQ29ILGNBQWMsQ0FBQ2hILENBQUMsQ0FBQ2lILFFBQVEsQ0FBQyxFQUFDLE1BQU0sSUFBSW5ILEtBQUssQ0FBQyxpR0FBaUcsQ0FBQztZQUFDTCxDQUFDLEdBQUN3QixLQUFLLENBQUNpRyxPQUFPLENBQUN6SCxDQUFDLENBQUMsS0FBR0EsQ0FBQyxHQUFDLENBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUNBLENBQUMsR0FBQyxFQUFFO1lBQUMsSUFBSUosQ0FBQyxHQUFDSSxDQUFDLENBQUMwSCxJQUFJLENBQUMsQ0FBQztZQUFDOUgsQ0FBQyxDQUFDZ0UsT0FBTyxDQUFDLFVBQVMxRSxDQUFDLEVBQUNjLENBQUMsRUFBQztjQUFDLElBQUcsQ0FBQ2QsQ0FBQyxFQUFDLE1BQU0sSUFBSW9JLFdBQVcsQ0FBQyx1QkFBdUIsR0FBQ3BJLENBQUMsR0FBQyxlQUFlLENBQUM7Y0FBQyxJQUFHYyxDQUFDLEdBQUNKLENBQUMsQ0FBQ2EsTUFBTSxHQUFDLENBQUMsSUFBRXZCLENBQUMsS0FBR1UsQ0FBQyxDQUFDSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJc0gsV0FBVyxDQUFDLHVCQUF1QixHQUFDcEksQ0FBQyxHQUFDLGtCQUFrQixDQUFDO1lBQUEsQ0FBQyxDQUFDO1lBQUMsSUFBSVcsQ0FBQyxHQUFDTSxDQUFDLENBQUN3SCxTQUFTLENBQUNqRSxDQUFDLENBQUNnQixJQUFJLENBQUM7WUFBQyxJQUFJLENBQUNrRCxPQUFPLEdBQUMvSCxDQUFDLEdBQUNBLENBQUMsQ0FBQ2dJLFdBQVcsQ0FBQyxDQUFDLEdBQUMsSUFBSSxFQUFDdEgsQ0FBQyxDQUFDdUgsR0FBRyxDQUFDLFVBQVUsRUFBQ3ZILENBQUMsQ0FBQ3dILFFBQVEsQ0FBQ0MsT0FBTyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ0MsR0FBRyxHQUFDMUgsQ0FBQyxDQUFDbUUsSUFBSSxFQUFDeUIsQ0FBQyxDQUFDLFdBQVcsRUFBQyxJQUFJLENBQUM4QixHQUFHLENBQUMsRUFBQyxJQUFJLENBQUNDLFFBQVEsR0FBQztjQUFDQyxVQUFVLEVBQUMsQ0FBQzVFLENBQUMsQ0FBQzZFLFNBQVMsQ0FBQyxDQUFDO2NBQUNoRCxVQUFVLEVBQUNqRixDQUFDLENBQUNzRSxhQUFhLENBQUMsSUFBSSxDQUFDd0QsR0FBRyxFQUFDdkUsQ0FBQyxDQUFDZ0IsSUFBSSxDQUFDO2NBQUNXLFVBQVUsRUFBQ2xGLENBQUMsQ0FBQ2tJLGFBQWEsQ0FBQyxJQUFJLENBQUNKLEdBQUcsRUFBQ3ZFLENBQUMsQ0FBQ2dCLElBQUk7WUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDNEQsR0FBRyxHQUFDLElBQUlwQyxDQUFDLENBQUMsSUFBSSxDQUFDK0IsR0FBRyxFQUFDLElBQUksQ0FBQ0MsUUFBUSxDQUFDLEVBQUMsSUFBSSxDQUFDSSxHQUFHLENBQUNwSCxJQUFJLENBQUMsUUFBUSxFQUFDLElBQUksQ0FBQ3FILFlBQVksQ0FBQ3pGLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztVQUFBO1VBQUMsU0FBUzBGLENBQUNBLENBQUN0SixDQUFDLEVBQUM7WUFBQyxPQUFPLEdBQUcsS0FBR0EsQ0FBQyxJQUFFLEdBQUcsSUFBRUEsQ0FBQyxJQUFFQSxDQUFDLElBQUUsSUFBSTtVQUFBO1VBQUNBLENBQUMsQ0FBQ2tILENBQUMsRUFBQzNDLENBQUMsQ0FBQyxFQUFDMkMsQ0FBQyxDQUFDckYsU0FBUyxDQUFDdUMsS0FBSyxHQUFDLFVBQVNwRSxDQUFDLEVBQUNjLENBQUMsRUFBQztZQUFDLElBQUdkLENBQUMsSUFBRSxDQUFDc0osQ0FBQyxDQUFDdEosQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJbUIsS0FBSyxDQUFDLGtDQUFrQyxDQUFDO1lBQUMsSUFBR0wsQ0FBQyxJQUFFLEdBQUcsR0FBQ0EsQ0FBQyxDQUFDUyxNQUFNLEVBQUMsTUFBTSxJQUFJNkcsV0FBVyxDQUFDLHVDQUF1QyxDQUFDO1lBQUMsSUFBRyxJQUFJLENBQUNoQixVQUFVLEtBQUdGLENBQUMsQ0FBQ3FDLE9BQU8sSUFBRSxJQUFJLENBQUNuQyxVQUFVLEtBQUdGLENBQUMsQ0FBQ3NDLE1BQU0sRUFBQztjQUFDLElBQUksQ0FBQ3JGLE1BQU0sQ0FBQ25FLENBQUMsSUFBRSxHQUFHLEVBQUNjLENBQUMsSUFBRSxnQkFBZ0IsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUFBO1VBQUMsQ0FBQyxFQUFDb0csQ0FBQyxDQUFDckYsU0FBUyxDQUFDcUMsSUFBSSxHQUFDLFVBQVNsRSxDQUFDLEVBQUM7WUFBQyxJQUFHLFFBQVEsSUFBRSxPQUFPQSxDQUFDLEtBQUdBLENBQUMsR0FBQyxFQUFFLEdBQUNBLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ29ILFVBQVUsS0FBR0YsQ0FBQyxDQUFDRyxVQUFVLEVBQUMsTUFBTSxJQUFJbEcsS0FBSyxDQUFDLGdFQUFnRSxDQUFDO1lBQUMsSUFBSSxDQUFDaUcsVUFBVSxLQUFHRixDQUFDLENBQUN1QyxJQUFJLElBQUUsSUFBSSxDQUFDL0YsVUFBVSxDQUFDUSxJQUFJLENBQUNwRCxDQUFDLENBQUM0SSxLQUFLLENBQUMxSixDQUFDLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQ2tILENBQUMsQ0FBQzVCLE9BQU8sR0FBQ3VCLENBQUMsQ0FBQyxXQUFXLENBQUMsRUFBQ0ssQ0FBQyxDQUFDRyxVQUFVLEdBQUMsQ0FBQyxFQUFDSCxDQUFDLENBQUN1QyxJQUFJLEdBQUMsQ0FBQyxFQUFDdkMsQ0FBQyxDQUFDcUMsT0FBTyxHQUFDLENBQUMsRUFBQ3JDLENBQUMsQ0FBQ3NDLE1BQU0sR0FBQyxDQUFDLEVBQUN0QyxDQUFDLENBQUNyRixTQUFTLENBQUN3SCxZQUFZLEdBQUMsVUFBU3JKLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1lBQUMsSUFBR21HLENBQUMsQ0FBQyxjQUFjLEVBQUNuRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNzSSxHQUFHLEdBQUMsSUFBSSxFQUFDcEosQ0FBQyxFQUFDO2NBQUMsSUFBSSxDQUFDMkosSUFBSSxHQUFDLElBQUksQ0FBQ0MsUUFBUSxDQUFDOUksQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDK0ksU0FBUyxHQUFDN0osQ0FBQyxDQUFDOEosUUFBUSxHQUFDOUosQ0FBQyxDQUFDOEosUUFBUSxHQUFDLElBQUksQ0FBQ2YsR0FBRyxFQUFDL0ksQ0FBQyxHQUFDcUIsQ0FBQyxDQUFDMEksTUFBTSxDQUFDL0osQ0FBQyxFQUFDLElBQUksQ0FBQ2dKLFFBQVEsQ0FBQyxFQUFDL0IsQ0FBQyxDQUFDLE1BQU0sRUFBQ2pILENBQUMsQ0FBQztjQUFDLElBQUllLENBQUMsR0FBQ0csQ0FBQyxDQUFDOEksZUFBZSxDQUFDLElBQUksQ0FBQ3ZDLG9CQUFvQixFQUFDekgsQ0FBQyxDQUFDO2NBQUMsSUFBSSxDQUFDaUssV0FBVyxHQUFDbEosQ0FBQyxDQUFDbUosSUFBSSxFQUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQ2dELFdBQVcsQ0FBQzFJLE1BQU0sR0FBQyxxQkFBcUIsQ0FBQyxFQUFDLElBQUksQ0FBQzRJLFFBQVEsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxNQUFLLElBQUksQ0FBQ2hHLE1BQU0sQ0FBQyxJQUFJLEVBQUMsMEJBQTBCLENBQUM7VUFBQSxDQUFDLEVBQUMrQyxDQUFDLENBQUNyRixTQUFTLENBQUNzSSxRQUFRLEdBQUMsWUFBVTtZQUFDLEtBQUksSUFBSW5LLENBQUMsR0FBQyxJQUFJLENBQUNpSyxXQUFXLENBQUNHLEtBQUssQ0FBQyxDQUFDLEVBQUNwSyxDQUFDLEVBQUNBLENBQUMsR0FBQyxJQUFJLENBQUNpSyxXQUFXLENBQUNHLEtBQUssQ0FBQyxDQUFDLEVBQUM7Y0FBQyxJQUFHbkQsQ0FBQyxDQUFDLFNBQVMsRUFBQ2pILENBQUMsQ0FBQzRFLGFBQWEsQ0FBQyxFQUFDNUUsQ0FBQyxDQUFDcUssUUFBUSxLQUFHLENBQUN0RCxDQUFDLENBQUNsQixRQUFRLENBQUNDLElBQUksSUFBRSxLQUFLLENBQUMsS0FBR2lCLENBQUMsQ0FBQ2xCLFFBQVEsQ0FBQ3VCLFVBQVUsSUFBRSxVQUFVLEtBQUdMLENBQUMsQ0FBQ2xCLFFBQVEsQ0FBQ3VCLFVBQVUsSUFBRSxhQUFhLEtBQUdMLENBQUMsQ0FBQ2xCLFFBQVEsQ0FBQ3VCLFVBQVUsQ0FBQyxFQUFDLE9BQU9ILENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFDLElBQUksQ0FBQ2dELFdBQVcsQ0FBQ0ssT0FBTyxDQUFDdEssQ0FBQyxDQUFDLEVBQUMsS0FBS1MsQ0FBQyxDQUFDdUUsV0FBVyxDQUFDLE1BQU0sRUFBQyxJQUFJLENBQUNtRixRQUFRLENBQUN2RyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Y0FBQyxJQUFJOUMsQ0FBQyxHQUFDeUosSUFBSSxDQUFDQyxHQUFHLENBQUMsSUFBSSxDQUFDM0MsUUFBUSxFQUFDLElBQUksQ0FBQzhCLElBQUksR0FBQzNKLENBQUMsQ0FBQ3lLLFVBQVUsSUFBRSxHQUFHLENBQUM7Y0FBQyxJQUFJLENBQUNDLG1CQUFtQixHQUFDbEosVUFBVSxDQUFDLElBQUksQ0FBQ21KLGlCQUFpQixDQUFDL0csSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDOUMsQ0FBQyxDQUFDLEVBQUNtRyxDQUFDLENBQUMsZUFBZSxFQUFDbkcsQ0FBQyxDQUFDO2NBQUMsSUFBSUMsQ0FBQyxHQUFDRSxDQUFDLENBQUNtRixPQUFPLENBQUMsSUFBSSxDQUFDeUQsU0FBUyxFQUFDLEdBQUcsR0FBQyxJQUFJLENBQUM1QixPQUFPLEdBQUMsR0FBRyxHQUFDLElBQUksQ0FBQ0Ysa0JBQWtCLENBQUMsQ0FBQyxDQUFDO2dCQUFDN0csQ0FBQyxHQUFDLElBQUksQ0FBQ3lHLGlCQUFpQixDQUFDM0gsQ0FBQyxDQUFDNEUsYUFBYSxDQUFDO2NBQUNxQyxDQUFDLENBQUMsZUFBZSxFQUFDbEcsQ0FBQyxDQUFDO2NBQUMsSUFBSU0sQ0FBQyxHQUFDLElBQUlyQixDQUFDLENBQUNlLENBQUMsRUFBQyxJQUFJLENBQUM4SSxTQUFTLEVBQUMzSSxDQUFDLENBQUM7Y0FBQyxPQUFPRyxDQUFDLENBQUNZLEVBQUUsQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDMEIsaUJBQWlCLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDdkMsQ0FBQyxDQUFDVyxJQUFJLENBQUMsT0FBTyxFQUFDLElBQUksQ0FBQzZCLGVBQWUsQ0FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUN2QyxDQUFDLENBQUN1RCxhQUFhLEdBQUM1RSxDQUFDLENBQUM0RSxhQUFhLEVBQUMsTUFBSyxJQUFJLENBQUNsQixVQUFVLEdBQUNyQyxDQUFDLENBQUM7WUFBQTtZQUFDLElBQUksQ0FBQzhDLE1BQU0sQ0FBQyxHQUFHLEVBQUMsdUJBQXVCLEVBQUMsQ0FBQyxDQUFDLENBQUM7VUFBQSxDQUFDLEVBQUMrQyxDQUFDLENBQUNyRixTQUFTLENBQUM4SSxpQkFBaUIsR0FBQyxZQUFVO1lBQUMxRCxDQUFDLENBQUMsbUJBQW1CLENBQUMsRUFBQyxJQUFJLENBQUNHLFVBQVUsS0FBR0YsQ0FBQyxDQUFDRyxVQUFVLEtBQUcsSUFBSSxDQUFDM0QsVUFBVSxJQUFFLElBQUksQ0FBQ0EsVUFBVSxDQUFDVSxLQUFLLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ1AsZUFBZSxDQUFDLElBQUksRUFBQyxxQkFBcUIsQ0FBQyxDQUFDO1VBQUEsQ0FBQyxFQUFDcUQsQ0FBQyxDQUFDckYsU0FBUyxDQUFDOEIsaUJBQWlCLEdBQUMsVUFBUzNELENBQUMsRUFBQztZQUFDaUgsQ0FBQyxDQUFDLG1CQUFtQixFQUFDakgsQ0FBQyxDQUFDO1lBQUMsSUFBSWMsQ0FBQztjQUFDQyxDQUFDLEdBQUMsSUFBSTtjQUFDRyxDQUFDLEdBQUNsQixDQUFDLENBQUN1RCxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztjQUFDbEMsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDdUQsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUFDLFFBQU9yQyxDQUFDO2NBQUUsS0FBSSxHQUFHO2dCQUFDLE9BQU8sS0FBSyxJQUFJLENBQUMwSixLQUFLLENBQUMsQ0FBQztjQUFDLEtBQUksR0FBRztnQkFBQyxPQUFPLElBQUksQ0FBQ3BILGFBQWEsQ0FBQyxJQUFJOUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsS0FBS3VHLENBQUMsQ0FBQyxXQUFXLEVBQUMsSUFBSSxDQUFDNEQsU0FBUyxDQUFDO1lBQUE7WUFBQyxJQUFHeEosQ0FBQyxFQUFDLElBQUc7Y0FBQ1AsQ0FBQyxHQUFDaUQsSUFBSSxDQUFDcUIsS0FBSyxDQUFDL0QsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxRQUFNckIsQ0FBQyxFQUFDO2NBQUNpSCxDQUFDLENBQUMsVUFBVSxFQUFDNUYsQ0FBQyxDQUFDO1lBQUE7WUFBQyxJQUFHLEtBQUssQ0FBQyxLQUFHUCxDQUFDLEVBQUMsUUFBT0ksQ0FBQztjQUFFLEtBQUksR0FBRztnQkFBQ29CLEtBQUssQ0FBQ2lHLE9BQU8sQ0FBQ3pILENBQUMsQ0FBQyxJQUFFQSxDQUFDLENBQUM0RCxPQUFPLENBQUMsVUFBUzFFLENBQUMsRUFBQztrQkFBQ2lILENBQUMsQ0FBQyxTQUFTLEVBQUNsRyxDQUFDLENBQUM4SixTQUFTLEVBQUM3SyxDQUFDLENBQUMsRUFBQ2UsQ0FBQyxDQUFDeUMsYUFBYSxDQUFDLElBQUlpQixDQUFDLENBQUN6RSxDQUFDLENBQUMsQ0FBQztnQkFBQSxDQUFDLENBQUM7Z0JBQUM7Y0FBTSxLQUFJLEdBQUc7Z0JBQUNpSCxDQUFDLENBQUMsU0FBUyxFQUFDLElBQUksQ0FBQzRELFNBQVMsRUFBQy9KLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzBDLGFBQWEsQ0FBQyxJQUFJaUIsQ0FBQyxDQUFDM0QsQ0FBQyxDQUFDLENBQUM7Z0JBQUM7Y0FBTSxLQUFJLEdBQUc7Z0JBQUN3QixLQUFLLENBQUNpRyxPQUFPLENBQUN6SCxDQUFDLENBQUMsSUFBRSxDQUFDLEtBQUdBLENBQUMsQ0FBQ1MsTUFBTSxJQUFFLElBQUksQ0FBQzRDLE1BQU0sQ0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxNQUFLbUcsQ0FBQyxDQUFDLGVBQWUsRUFBQzVGLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQzZGLENBQUMsQ0FBQ3JGLFNBQVMsQ0FBQ2dDLGVBQWUsR0FBQyxVQUFTN0QsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7WUFBQ21HLENBQUMsQ0FBQyxpQkFBaUIsRUFBQyxJQUFJLENBQUM0RCxTQUFTLEVBQUM3SyxDQUFDLEVBQUNjLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzRDLFVBQVUsS0FBRyxJQUFJLENBQUNBLFVBQVUsQ0FBQzVCLGtCQUFrQixDQUFDLENBQUMsRUFBQyxJQUFJLENBQUM0QixVQUFVLEdBQUMsSUFBSSxFQUFDLElBQUksQ0FBQ21ILFNBQVMsR0FBQyxJQUFJLENBQUMsRUFBQ3ZCLENBQUMsQ0FBQ3RKLENBQUMsQ0FBQyxJQUFFLEdBQUcsS0FBR0EsQ0FBQyxJQUFFLElBQUksQ0FBQ29ILFVBQVUsS0FBR0YsQ0FBQyxDQUFDRyxVQUFVLEdBQUMsSUFBSSxDQUFDbEQsTUFBTSxDQUFDbkUsQ0FBQyxFQUFDYyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUNxSixRQUFRLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQ2pELENBQUMsQ0FBQ3JGLFNBQVMsQ0FBQytJLEtBQUssR0FBQyxZQUFVO1lBQUMzRCxDQUFDLENBQUMsT0FBTyxFQUFDLElBQUksQ0FBQ3ZELFVBQVUsSUFBRSxJQUFJLENBQUNBLFVBQVUsQ0FBQ2tCLGFBQWEsRUFBQyxJQUFJLENBQUN3QyxVQUFVLENBQUMsRUFBQyxJQUFJLENBQUNBLFVBQVUsS0FBR0YsQ0FBQyxDQUFDRyxVQUFVLElBQUUsSUFBSSxDQUFDcUQsbUJBQW1CLEtBQUdsRSxZQUFZLENBQUMsSUFBSSxDQUFDa0UsbUJBQW1CLENBQUMsRUFBQyxJQUFJLENBQUNBLG1CQUFtQixHQUFDLElBQUksQ0FBQyxFQUFDLElBQUksQ0FBQ3RELFVBQVUsR0FBQ0YsQ0FBQyxDQUFDdUMsSUFBSSxFQUFDLElBQUksQ0FBQ29CLFNBQVMsR0FBQyxJQUFJLENBQUNuSCxVQUFVLENBQUNrQixhQUFhLEVBQUMsSUFBSSxDQUFDcEIsYUFBYSxDQUFDLElBQUk5QyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQ3VHLENBQUMsQ0FBQyxXQUFXLEVBQUMsSUFBSSxDQUFDNEQsU0FBUyxDQUFDLElBQUUsSUFBSSxDQUFDMUcsTUFBTSxDQUFDLElBQUksRUFBQyxxQkFBcUIsQ0FBQztVQUFBLENBQUMsRUFBQytDLENBQUMsQ0FBQ3JGLFNBQVMsQ0FBQ3NDLE1BQU0sR0FBQyxVQUFTckQsQ0FBQyxFQUFDQyxDQUFDLEVBQUNHLENBQUMsRUFBQztZQUFDK0YsQ0FBQyxDQUFDLFFBQVEsRUFBQyxJQUFJLENBQUM0RCxTQUFTLEVBQUMvSixDQUFDLEVBQUNDLENBQUMsRUFBQ0csQ0FBQyxFQUFDLElBQUksQ0FBQ2tHLFVBQVUsQ0FBQztZQUFDLElBQUkvRixDQUFDLEdBQUMsQ0FBQyxDQUFDO1lBQUMsSUFBRyxJQUFJLENBQUMrSCxHQUFHLEtBQUcvSCxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDK0gsR0FBRyxDQUFDaEYsS0FBSyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNnRixHQUFHLEdBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDMUYsVUFBVSxLQUFHLElBQUksQ0FBQ0EsVUFBVSxDQUFDVSxLQUFLLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ1YsVUFBVSxHQUFDLElBQUksRUFBQyxJQUFJLENBQUNtSCxTQUFTLEdBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDekQsVUFBVSxLQUFHRixDQUFDLENBQUNzQyxNQUFNLEVBQUMsTUFBTSxJQUFJckksS0FBSyxDQUFDLG1EQUFtRCxDQUFDO1lBQUMsSUFBSSxDQUFDaUcsVUFBVSxHQUFDRixDQUFDLENBQUNxQyxPQUFPLEVBQUMvSCxVQUFVLENBQUMsWUFBVTtjQUFDLElBQUksQ0FBQzRGLFVBQVUsR0FBQ0YsQ0FBQyxDQUFDc0MsTUFBTSxFQUFDbkksQ0FBQyxJQUFFLElBQUksQ0FBQ21DLGFBQWEsQ0FBQyxJQUFJOUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2NBQUMsSUFBSVYsQ0FBQyxHQUFDLElBQUlXLENBQUMsQ0FBQyxPQUFPLENBQUM7Y0FBQ1gsQ0FBQyxDQUFDMkIsUUFBUSxHQUFDVCxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUNsQixDQUFDLENBQUNvQixJQUFJLEdBQUNOLENBQUMsSUFBRSxHQUFHLEVBQUNkLENBQUMsQ0FBQzRCLE1BQU0sR0FBQ2IsQ0FBQyxFQUFDLElBQUksQ0FBQ3lDLGFBQWEsQ0FBQ3hELENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzhLLFNBQVMsR0FBQyxJQUFJLENBQUNDLE9BQU8sR0FBQyxJQUFJLENBQUNDLE9BQU8sR0FBQyxJQUFJLEVBQUMvRCxDQUFDLENBQUMsY0FBYyxDQUFDO1lBQUEsQ0FBQyxDQUFDckQsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQ3NELENBQUMsQ0FBQ3JGLFNBQVMsQ0FBQytILFFBQVEsR0FBQyxVQUFTNUosQ0FBQyxFQUFDO1lBQUMsT0FBTyxHQUFHLEdBQUNBLENBQUMsR0FBQyxDQUFDLEdBQUNBLENBQUMsR0FBQyxHQUFHLEdBQUNBLENBQUM7VUFBQSxDQUFDLEVBQUM4RyxDQUFDLENBQUM3RyxPQUFPLEdBQUMsVUFBU0QsQ0FBQyxFQUFDO1lBQUMsT0FBT2tCLENBQUMsR0FBQ0gsQ0FBQyxDQUFDZixDQUFDLENBQUMsRUFBQzZHLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDSyxDQUFDLEVBQUNsSCxDQUFDLENBQUMsRUFBQ2tILENBQUM7VUFBQSxDQUFDO1FBQUEsQ0FBQyxFQUFFNUYsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLGVBQWUsRUFBQyxDQUFDO01BQUMsZUFBZSxFQUFDLENBQUM7TUFBQyxxQkFBcUIsRUFBQyxDQUFDO01BQUMsdUJBQXVCLEVBQUMsQ0FBQztNQUFDLG9CQUFvQixFQUFDLENBQUM7TUFBQyxpQkFBaUIsRUFBQyxFQUFFO01BQUMsWUFBWSxFQUFDLEVBQUU7TUFBQyxTQUFTLEVBQUMsRUFBRTtNQUFDLGlCQUFpQixFQUFDLEVBQUU7TUFBQyxnQkFBZ0IsRUFBQyxFQUFFO01BQUMsZUFBZSxFQUFDLEVBQUU7TUFBQyxhQUFhLEVBQUMsRUFBRTtNQUFDLGdCQUFnQixFQUFDLEVBQUU7TUFBQyxnQkFBZ0IsRUFBQyxFQUFFO01BQUMsbUJBQW1CLEVBQUMsRUFBRTtNQUFDLGFBQWEsRUFBQyxFQUFFO01BQUMsV0FBVyxFQUFDLEVBQUU7TUFBQyxPQUFPLEVBQUMsS0FBSyxDQUFDO01BQUMsVUFBVSxFQUFDLEVBQUU7TUFBQyxXQUFXLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTTCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxTQUFTSixDQUFDQSxDQUFDWCxDQUFDLEVBQUM7UUFBQyxPQUFNLG1CQUFtQixLQUFHUyxDQUFDLENBQUN3SyxRQUFRLENBQUMzSixJQUFJLENBQUN0QixDQUFDLENBQUM7TUFBQTtNQUFDLFNBQVNZLENBQUNBLENBQUNaLENBQUMsRUFBQztRQUFDLE9BQU0saUJBQWlCLEtBQUdxRSxDQUFDLENBQUMvQyxJQUFJLENBQUN0QixDQUFDLENBQUM7TUFBQTtNQUFDLElBQUlxQixDQUFDO1FBQUNKLENBQUMsR0FBQ3FCLEtBQUssQ0FBQ1QsU0FBUztRQUFDcEIsQ0FBQyxHQUFDeUssTUFBTSxDQUFDckosU0FBUztRQUFDWCxDQUFDLEdBQUNpSyxRQUFRLENBQUN0SixTQUFTO1FBQUNuQixDQUFDLEdBQUMwSyxNQUFNLENBQUN2SixTQUFTO1FBQUNoQixDQUFDLEdBQUNJLENBQUMsQ0FBQ3NDLEtBQUs7UUFBQ2MsQ0FBQyxHQUFDNUQsQ0FBQyxDQUFDd0ssUUFBUTtRQUFDM0csQ0FBQyxHQUFDNEcsTUFBTSxDQUFDRyxjQUFjLElBQUUsWUFBVTtVQUFDLElBQUc7WUFBQyxPQUFPSCxNQUFNLENBQUNHLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7VUFBQSxDQUFDLFFBQU1yTCxDQUFDLEVBQUM7WUFBQyxPQUFNLENBQUMsQ0FBQztVQUFBO1FBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQ3FCLENBQUMsR0FBQ2lELENBQUMsR0FBQyxVQUFTdEUsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQ0csQ0FBQyxFQUFDO1FBQUMsQ0FBQ0EsQ0FBQyxJQUFFSixDQUFDLElBQUlkLENBQUMsSUFBRWtMLE1BQU0sQ0FBQ0csY0FBYyxDQUFDckwsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7VUFBQ3dLLFlBQVksRUFBQyxDQUFDLENBQUM7VUFBQ0MsVUFBVSxFQUFDLENBQUMsQ0FBQztVQUFDQyxRQUFRLEVBQUMsQ0FBQyxDQUFDO1VBQUNDLEtBQUssRUFBQzFLO1FBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxHQUFDLFVBQVNmLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUNHLENBQUMsRUFBQztRQUFDLENBQUNBLENBQUMsSUFBRUosQ0FBQyxJQUFJZCxDQUFDLEtBQUdBLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDLEdBQUNDLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxTQUFTd0QsQ0FBQ0EsQ0FBQ3ZFLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7UUFBQyxLQUFJLElBQUlHLENBQUMsSUFBSUosQ0FBQyxFQUFDTCxDQUFDLENBQUNpTCxjQUFjLENBQUNwSyxJQUFJLENBQUNSLENBQUMsRUFBQ0ksQ0FBQyxDQUFDLElBQUVHLENBQUMsQ0FBQ3JCLENBQUMsRUFBQ2tCLENBQUMsRUFBQ0osQ0FBQyxDQUFDSSxDQUFDLENBQUMsRUFBQ0gsQ0FBQyxDQUFDO01BQUE7TUFBQyxTQUFTeUQsQ0FBQ0EsQ0FBQ3hFLENBQUMsRUFBQztRQUFDLElBQUcsSUFBSSxJQUFFQSxDQUFDLEVBQUMsTUFBTSxJQUFJbUgsU0FBUyxDQUFDLGdCQUFnQixHQUFDbkgsQ0FBQyxHQUFDLFlBQVksQ0FBQztRQUFDLE9BQU9rTCxNQUFNLENBQUNsTCxDQUFDLENBQUM7TUFBQTtNQUFDLFNBQVN5RSxDQUFDQSxDQUFBLEVBQUUsQ0FBQztNQUFDRixDQUFDLENBQUNyRCxDQUFDLEVBQUM7UUFBQzBDLElBQUksRUFBQyxTQUFBQSxDQUFTOUMsQ0FBQyxFQUFDO1VBQUMsSUFBSUMsQ0FBQyxHQUFDLElBQUk7VUFBQyxJQUFHLENBQUNKLENBQUMsQ0FBQ0ksQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJb0csU0FBUyxDQUFDLGlEQUFpRCxHQUFDcEcsQ0FBQyxDQUFDO1VBQUMsS0FBSSxJQUFJRyxDQUFDLEdBQUNMLENBQUMsQ0FBQ1MsSUFBSSxDQUFDYyxTQUFTLEVBQUMsQ0FBQyxDQUFDLEVBQUNwQyxDQUFDLEdBQUN1SyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUN6SixDQUFDLENBQUNRLE1BQU0sR0FBQ0wsQ0FBQyxDQUFDSyxNQUFNLENBQUMsRUFBQ0YsQ0FBQyxHQUFDLEVBQUUsRUFBQ1osQ0FBQyxHQUFDLENBQUMsRUFBQ0EsQ0FBQyxHQUFDVCxDQUFDLEVBQUNTLENBQUMsRUFBRSxFQUFDWSxDQUFDLENBQUNzSyxJQUFJLENBQUMsR0FBRyxHQUFDbEwsQ0FBQyxDQUFDO1VBQUMsSUFBSUMsQ0FBQyxHQUFDeUssUUFBUSxDQUFDLFFBQVEsRUFBQyxtQkFBbUIsR0FBQzlKLENBQUMsQ0FBQ3VLLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLFlBQVU7WUFBQyxJQUFHLElBQUksWUFBWWxMLENBQUMsRUFBQztjQUFDLElBQUlWLENBQUMsR0FBQ2UsQ0FBQyxDQUFDb0IsS0FBSyxDQUFDLElBQUksRUFBQ2pCLENBQUMsQ0FBQ29DLE1BQU0sQ0FBQ3pDLENBQUMsQ0FBQ1MsSUFBSSxDQUFDYyxTQUFTLENBQUMsQ0FBQyxDQUFDO2NBQUMsT0FBTzhJLE1BQU0sQ0FBQ2xMLENBQUMsQ0FBQyxLQUFHQSxDQUFDLEdBQUNBLENBQUMsR0FBQyxJQUFJO1lBQUE7WUFBQyxPQUFPZSxDQUFDLENBQUNvQixLQUFLLENBQUNyQixDQUFDLEVBQUNJLENBQUMsQ0FBQ29DLE1BQU0sQ0FBQ3pDLENBQUMsQ0FBQ1MsSUFBSSxDQUFDYyxTQUFTLENBQUMsQ0FBQyxDQUFDO1VBQUEsQ0FBQyxDQUFDO1VBQUMsT0FBT3JCLENBQUMsQ0FBQ2MsU0FBUyxLQUFHNEMsQ0FBQyxDQUFDNUMsU0FBUyxHQUFDZCxDQUFDLENBQUNjLFNBQVMsRUFBQ25CLENBQUMsQ0FBQ21CLFNBQVMsR0FBQyxJQUFJNEMsQ0FBQyxDQUFELENBQUMsRUFBQ0EsQ0FBQyxDQUFDNUMsU0FBUyxHQUFDLElBQUksQ0FBQyxFQUFDbkIsQ0FBQztRQUFBO01BQUMsQ0FBQyxDQUFDLEVBQUM2RCxDQUFDLENBQUNqQyxLQUFLLEVBQUM7UUFBQ2lHLE9BQU8sRUFBQyxTQUFBQSxDQUFTdkksQ0FBQyxFQUFDO1VBQUMsT0FBTSxnQkFBZ0IsS0FBR3FFLENBQUMsQ0FBQy9DLElBQUksQ0FBQ3RCLENBQUMsQ0FBQztRQUFBO01BQUMsQ0FBQyxDQUFDO01BQUMsSUFBSWdILENBQUM7UUFBQ0MsQ0FBQztRQUFDQyxDQUFDO1FBQUNvQyxDQUFDLEdBQUM0QixNQUFNLENBQUMsR0FBRyxDQUFDO1FBQUNuRSxDQUFDLEdBQUMsR0FBRyxLQUFHdUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxJQUFJQSxDQUFDLENBQUM7TUFBQy9FLENBQUMsQ0FBQ3RELENBQUMsRUFBQztRQUFDeUQsT0FBTyxFQUFDLFNBQUFBLENBQVMxRSxDQUFDLEVBQUNjLENBQUMsRUFBQztVQUFDLElBQUlDLENBQUMsR0FBQ3lELENBQUMsQ0FBQyxJQUFJLENBQUM7WUFBQ3RELENBQUMsR0FBQzZGLENBQUMsSUFBRW5HLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUNpTCxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUM5SyxDQUFDO1lBQUNNLENBQUMsR0FBQ1AsQ0FBQztZQUFDTCxDQUFDLEdBQUMsQ0FBQyxDQUFDO1lBQUNDLENBQUMsR0FBQ1EsQ0FBQyxDQUFDSyxNQUFNLEtBQUcsQ0FBQztVQUFDLElBQUcsQ0FBQ1osQ0FBQyxDQUFDWCxDQUFDLENBQUMsRUFBQyxNQUFNLElBQUltSCxTQUFTLENBQUQsQ0FBQztVQUFDLE9BQUssRUFBRTFHLENBQUMsR0FBQ0MsQ0FBQyxHQUFFRCxDQUFDLElBQUlTLENBQUMsSUFBRWxCLENBQUMsQ0FBQ3NCLElBQUksQ0FBQ0QsQ0FBQyxFQUFDSCxDQUFDLENBQUNULENBQUMsQ0FBQyxFQUFDQSxDQUFDLEVBQUNNLENBQUMsQ0FBQztRQUFBO01BQUMsQ0FBQyxHQUFFaUcsQ0FBQyxHQUFDL0YsQ0FBQyxDQUFDeUQsT0FBTyxFQUFDd0MsQ0FBQyxHQUFDRCxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUNELENBQUMsS0FBR0EsQ0FBQyxDQUFDMUYsSUFBSSxDQUFDLEtBQUssRUFBQyxVQUFTdEIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztRQUFDLFFBQVEsSUFBRSxPQUFPQSxDQUFDLEtBQUdrRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQSxDQUFDLENBQUMsRUFBQ0QsQ0FBQyxDQUFDMUYsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsWUFBVTtRQUFDNEYsQ0FBQyxHQUFDLFFBQVEsSUFBRSxPQUFPLElBQUk7TUFBQSxDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxFQUFFRixDQUFDLElBQUVDLENBQUMsSUFBRUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDLElBQUlMLENBQUMsR0FBQ3ZFLEtBQUssQ0FBQ1QsU0FBUyxDQUFDd0IsT0FBTyxJQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDQSxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFDa0IsQ0FBQyxDQUFDdEQsQ0FBQyxFQUFDO1FBQUNvQyxPQUFPLEVBQUMsU0FBQUEsQ0FBU3JELENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1VBQUMsSUFBSUMsQ0FBQyxHQUFDZ0csQ0FBQyxJQUFFbkcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFDLElBQUksQ0FBQ2lMLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBQ3JILENBQUMsQ0FBQyxJQUFJLENBQUM7WUFBQ3RELENBQUMsR0FBQ0gsQ0FBQyxDQUFDUSxNQUFNLEtBQUcsQ0FBQztVQUFDLElBQUcsQ0FBQ0wsQ0FBQyxFQUFDLE9BQU0sQ0FBQyxDQUFDO1VBQUMsSUFBSUcsQ0FBQyxHQUFDLENBQUM7VUFBQyxLQUFJLENBQUMsR0FBQ2UsU0FBUyxDQUFDYixNQUFNLEtBQUdGLENBQUMsR0FBQyxVQUFTckIsQ0FBQyxFQUFDO1lBQUMsSUFBSWMsQ0FBQyxHQUFDLENBQUNkLENBQUM7WUFBQyxPQUFPYyxDQUFDLElBQUVBLENBQUMsR0FBQ0EsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEtBQUdBLENBQUMsSUFBRUEsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLElBQUVBLENBQUMsS0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLEtBQUdBLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQ0EsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFFeUosSUFBSSxDQUFDdUIsS0FBSyxDQUFDdkIsSUFBSSxDQUFDd0IsR0FBRyxDQUFDakwsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDQSxDQUFDO1VBQUEsQ0FBQyxDQUFDQSxDQUFDLENBQUMsQ0FBQyxFQUFDTyxDQUFDLEdBQUMsQ0FBQyxJQUFFQSxDQUFDLEdBQUNBLENBQUMsR0FBQ2tKLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBQ3RKLENBQUMsR0FBQ0csQ0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ0gsQ0FBQyxFQUFDRyxDQUFDLEVBQUUsRUFBQyxJQUFHQSxDQUFDLElBQUlOLENBQUMsSUFBRUEsQ0FBQyxDQUFDTSxDQUFDLENBQUMsS0FBR3JCLENBQUMsRUFBQyxPQUFPcUIsQ0FBQztVQUFDLE9BQU0sQ0FBQyxDQUFDO1FBQUE7TUFBQyxDQUFDLEVBQUN3RixDQUFDLENBQUM7TUFBQyxJQUFJQyxDQUFDO1FBQUNrRixDQUFDLEdBQUN0TCxDQUFDLENBQUNtTCxLQUFLO01BQUMsQ0FBQyxLQUFHLElBQUksQ0FBQ0EsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDdEssTUFBTSxJQUFFLENBQUMsS0FBRyxHQUFHLENBQUNzSyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUN0SyxNQUFNLElBQUUsR0FBRyxLQUFHLE9BQU8sQ0FBQ3NLLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsTUFBTSxDQUFDQSxLQUFLLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUN0SyxNQUFNLElBQUUsRUFBRSxDQUFDc0ssS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDdEssTUFBTSxJQUFFLENBQUMsR0FBQyxHQUFHLENBQUNzSyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUN0SyxNQUFNLElBQUV1RixDQUFDLEdBQUMsS0FBSyxDQUFDLEtBQUcsTUFBTSxDQUFDbUYsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDdkwsQ0FBQyxDQUFDbUwsS0FBSyxHQUFDLFVBQVM3TCxDQUFDLEVBQUNjLENBQUMsRUFBQztRQUFDLElBQUlDLENBQUMsR0FBQyxJQUFJO1FBQUMsSUFBRyxLQUFLLENBQUMsS0FBR2YsQ0FBQyxJQUFFLENBQUMsS0FBR2MsQ0FBQyxFQUFDLE9BQU0sRUFBRTtRQUFDLElBQUcsaUJBQWlCLEtBQUd1RCxDQUFDLENBQUMvQyxJQUFJLENBQUN0QixDQUFDLENBQUMsRUFBQyxPQUFPZ00sQ0FBQyxDQUFDMUssSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQ2MsQ0FBQyxDQUFDO1FBQUMsSUFBSUksQ0FBQztVQUFDRyxDQUFDO1VBQUNaLENBQUM7VUFBQ0MsQ0FBQztVQUFDQyxDQUFDLEdBQUMsRUFBRTtVQUFDQyxDQUFDLEdBQUMsQ0FBQ1osQ0FBQyxDQUFDa00sVUFBVSxHQUFDLEdBQUcsR0FBQyxFQUFFLEtBQUdsTSxDQUFDLENBQUNtTSxTQUFTLEdBQUMsR0FBRyxHQUFDLEVBQUUsQ0FBQyxJQUFFbk0sQ0FBQyxDQUFDb00sUUFBUSxHQUFDLEdBQUcsR0FBQyxFQUFFLENBQUMsSUFBRXBNLENBQUMsQ0FBQ3FNLE1BQU0sR0FBQyxHQUFHLEdBQUMsRUFBRSxDQUFDO1VBQUN4TCxDQUFDLEdBQUMsQ0FBQztRQUFDLEtBQUliLENBQUMsR0FBQyxJQUFJc00sTUFBTSxDQUFDdE0sQ0FBQyxDQUFDaUYsTUFBTSxFQUFDckUsQ0FBQyxHQUFDLEdBQUcsQ0FBQyxFQUFDRyxDQUFDLElBQUUsRUFBRSxFQUFDK0YsQ0FBQyxLQUFHNUYsQ0FBQyxHQUFDLElBQUlvTCxNQUFNLENBQUMsR0FBRyxHQUFDdE0sQ0FBQyxDQUFDaUYsTUFBTSxHQUFDLFVBQVUsRUFBQ3JFLENBQUMsQ0FBQyxDQUFDLEVBQUNFLENBQUMsR0FBQyxLQUFLLENBQUMsS0FBR0EsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxVQUFTZCxDQUFDLEVBQUM7VUFBQyxPQUFPQSxDQUFDLEtBQUcsQ0FBQztRQUFBLENBQUMsQ0FBQ2MsQ0FBQyxDQUFDLEVBQUMsQ0FBQ08sQ0FBQyxHQUFDckIsQ0FBQyxDQUFDaU0sSUFBSSxDQUFDbEwsQ0FBQyxDQUFDLEtBQUcsRUFBRUYsQ0FBQyxJQUFFSixDQUFDLEdBQUNZLENBQUMsQ0FBQ2tMLEtBQUssR0FBQ2xMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsTUFBTSxDQUFDLEtBQUdaLENBQUMsQ0FBQ2dMLElBQUksQ0FBQzVLLENBQUMsQ0FBQ3dDLEtBQUssQ0FBQzFDLENBQUMsRUFBQ1EsQ0FBQyxDQUFDa0wsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDekYsQ0FBQyxJQUFFLENBQUMsR0FBQ3pGLENBQUMsQ0FBQ0UsTUFBTSxJQUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUN5SCxPQUFPLENBQUM1SCxDQUFDLEVBQUMsWUFBVTtVQUFDLEtBQUksSUFBSWxCLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ29DLFNBQVMsQ0FBQ2IsTUFBTSxHQUFDLENBQUMsRUFBQ3ZCLENBQUMsRUFBRSxFQUFDLEtBQUssQ0FBQyxLQUFHb0MsU0FBUyxDQUFDcEMsQ0FBQyxDQUFDLEtBQUdxQixDQUFDLENBQUNyQixDQUFDLENBQUMsR0FBQyxLQUFLLENBQUMsQ0FBQztRQUFBLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQ3FCLENBQUMsQ0FBQ0UsTUFBTSxJQUFFRixDQUFDLENBQUNrTCxLQUFLLEdBQUN4TCxDQUFDLENBQUNRLE1BQU0sSUFBRU4sQ0FBQyxDQUFDMEssSUFBSSxDQUFDeEosS0FBSyxDQUFDeEIsQ0FBQyxFQUFDVSxDQUFDLENBQUNrQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQzdDLENBQUMsR0FBQ1csQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxNQUFNLEVBQUNWLENBQUMsR0FBQ0osQ0FBQyxFQUFDRSxDQUFDLENBQUNZLE1BQU0sSUFBRVQsQ0FBQyxDQUFDLENBQUMsR0FBRWQsQ0FBQyxDQUFDd00sU0FBUyxLQUFHbkwsQ0FBQyxDQUFDa0wsS0FBSyxJQUFFdk0sQ0FBQyxDQUFDd00sU0FBUyxFQUFFO1FBQUMsT0FBTzNMLENBQUMsS0FBR0UsQ0FBQyxDQUFDUSxNQUFNLEdBQUMsQ0FBQ2IsQ0FBQyxJQUFFVixDQUFDLENBQUN5TSxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUU5TCxDQUFDLENBQUNnTCxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUNoTCxDQUFDLENBQUNnTCxJQUFJLENBQUM1SyxDQUFDLENBQUN3QyxLQUFLLENBQUMxQyxDQUFDLENBQUMsQ0FBQyxFQUFDRixDQUFDLENBQUNZLE1BQU0sR0FBQ1QsQ0FBQyxHQUFDSCxDQUFDLENBQUM0QyxLQUFLLENBQUMsQ0FBQyxFQUFDekMsQ0FBQyxDQUFDLEdBQUNILENBQUM7TUFBQSxDQUFDLElBQUUsR0FBRyxDQUFDa0wsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDdEssTUFBTSxLQUFHYixDQUFDLENBQUNtTCxLQUFLLEdBQUMsVUFBUzdMLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUMsT0FBTyxLQUFLLENBQUMsS0FBR2QsQ0FBQyxJQUFFLENBQUMsS0FBR2MsQ0FBQyxHQUFDLEVBQUUsR0FBQ2tMLENBQUMsQ0FBQzFLLElBQUksQ0FBQyxJQUFJLEVBQUN0QixDQUFDLEVBQUNjLENBQUMsQ0FBQztNQUFBLENBQUMsQ0FBQztNQUFDLElBQUk0TCxDQUFDLEdBQUNoTSxDQUFDLENBQUNpTSxNQUFNO1FBQUNDLENBQUMsR0FBQyxFQUFFLENBQUNELE1BQU0sSUFBRSxHQUFHLEtBQUcsSUFBSSxDQUFDQSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQ3BJLENBQUMsQ0FBQzdELENBQUMsRUFBQztRQUFDaU0sTUFBTSxFQUFDLFNBQUFBLENBQVMzTSxDQUFDLEVBQUNjLENBQUMsRUFBQztVQUFDLE9BQU80TCxDQUFDLENBQUNwTCxJQUFJLENBQUMsSUFBSSxFQUFDdEIsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDQSxDQUFDLEdBQUMsSUFBSSxDQUFDdUIsTUFBTSxHQUFDdkIsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUNBLENBQUMsRUFBQ2MsQ0FBQyxDQUFDO1FBQUE7TUFBQyxDQUFDLEVBQUM4TCxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTNU0sQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUNELENBQUMsQ0FBQ2IsT0FBTyxHQUFDLENBQUNELENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFDQSxDQUFDLENBQUMsMkJBQTJCLENBQUMsRUFBQ0EsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLEVBQUNBLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxFQUFDQSxDQUFDLENBQUMsNkJBQTZCLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsRUFBQ0EsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUNBLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDQSxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUFDQSxDQUFDLENBQUMseUJBQXlCLENBQUMsRUFBQ0EsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLEVBQUNBLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDQSxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxFQUFDQSxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLHlCQUF5QixFQUFDLEVBQUU7TUFBQyxzQkFBc0IsRUFBQyxFQUFFO01BQUMsMkJBQTJCLEVBQUMsRUFBRTtNQUFDLDZCQUE2QixFQUFDLEVBQUU7TUFBQyx1QkFBdUIsRUFBQyxFQUFFO01BQUMseUJBQXlCLEVBQUMsRUFBRTtNQUFDLDJCQUEyQixFQUFDLEVBQUU7TUFBQyx5QkFBeUIsRUFBQyxFQUFFO01BQUMsMkJBQTJCLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTcUIsQ0FBQyxFQUFDZ0QsQ0FBQyxFQUFDckUsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTa0IsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxZQUFVO1VBQUMsWUFBWTs7VUFBQyxJQUFJVCxDQUFDLEdBQUNZLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQ3FCLFlBQVk7WUFBQzFDLENBQUMsR0FBQ3FCLENBQUMsQ0FBQyxVQUFVLENBQUM7WUFBQ1gsQ0FBQyxHQUFDVyxDQUFDLENBQUMsbUJBQW1CLENBQUM7WUFBQ1YsQ0FBQyxHQUFDVSxDQUFDLENBQUMsaUJBQWlCLENBQUM7WUFBQ1QsQ0FBQyxHQUFDTSxDQUFDLENBQUMyTCxjQUFjO1lBQUNoTSxDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztVQUFDLFNBQVNJLENBQUNBLENBQUNqQixDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDRyxDQUFDLEVBQUM7WUFBQ0wsQ0FBQyxDQUFDYixDQUFDLEVBQUNjLENBQUMsQ0FBQztZQUFDLElBQUlPLENBQUMsR0FBQyxJQUFJO1lBQUNaLENBQUMsQ0FBQ2EsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDRSxVQUFVLENBQUMsWUFBVTtjQUFDSCxDQUFDLENBQUN5TCxNQUFNLENBQUM5TSxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDRyxDQUFDLENBQUM7WUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1VBQUE7VUFBQ2xCLENBQUMsQ0FBQ2lCLENBQUMsRUFBQ1IsQ0FBQyxDQUFDLEVBQUNRLENBQUMsQ0FBQ1ksU0FBUyxDQUFDaUwsTUFBTSxHQUFDLFVBQVM5TSxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDRyxDQUFDLEVBQUM7WUFBQyxJQUFJRyxDQUFDLEdBQUMsSUFBSTtZQUFDLElBQUc7Y0FBQyxJQUFJLENBQUMwTCxHQUFHLEdBQUMsSUFBSW5NLENBQUMsQ0FBRCxDQUFDO1lBQUEsQ0FBQyxRQUFNWixDQUFDLEVBQUMsQ0FBQztZQUFDLElBQUcsQ0FBQyxJQUFJLENBQUMrTSxHQUFHLEVBQUMsT0FBT2xNLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQyxJQUFJLENBQUN3QixJQUFJLENBQUMsUUFBUSxFQUFDLENBQUMsRUFBQyxnQkFBZ0IsQ0FBQyxFQUFDLEtBQUssSUFBSSxDQUFDaUUsUUFBUSxDQUFDLENBQUM7WUFBQ3hGLENBQUMsR0FBQ0gsQ0FBQyxDQUFDcU0sUUFBUSxDQUFDbE0sQ0FBQyxFQUFDLElBQUksR0FBRSxDQUFDLElBQUlpQyxJQUFJLENBQUQsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDa0ssU0FBUyxHQUFDdk0sQ0FBQyxDQUFDd00sU0FBUyxDQUFDLFlBQVU7Y0FBQ3JNLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFDUSxDQUFDLENBQUNpRixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQSxDQUFDLENBQUM7WUFBQyxJQUFHO2NBQUMsSUFBSSxDQUFDeUcsR0FBRyxDQUFDSSxJQUFJLENBQUNuTixDQUFDLEVBQUNjLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ3lGLE9BQU8sSUFBRSxTQUFTLElBQUcsSUFBSSxDQUFDd0csR0FBRyxLQUFHLElBQUksQ0FBQ0EsR0FBRyxDQUFDeEcsT0FBTyxHQUFDLElBQUksQ0FBQ0EsT0FBTyxFQUFDLElBQUksQ0FBQ3dHLEdBQUcsQ0FBQ0ssU0FBUyxHQUFDLFlBQVU7Z0JBQUN2TSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUNRLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLEVBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxFQUFDaEIsQ0FBQyxDQUFDaUYsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQUEsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxRQUFNdEcsQ0FBQyxFQUFDO2NBQUMsT0FBT2EsQ0FBQyxDQUFDLFdBQVcsRUFBQ2IsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDcUMsSUFBSSxDQUFDLFFBQVEsRUFBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMsS0FBSyxJQUFJLENBQUNpRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQTtZQUFDLElBQUdwRixDQUFDLElBQUVBLENBQUMsQ0FBQ21NLGFBQWEsSUFBRSxDQUFDcE0sQ0FBQyxDQUFDcU0sWUFBWSxLQUFHek0sQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEVBQUMsSUFBSSxDQUFDa00sR0FBRyxDQUFDUSxlQUFlLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQ3JNLENBQUMsSUFBRUEsQ0FBQyxDQUFDc00sT0FBTyxFQUFDLEtBQUksSUFBSS9NLENBQUMsSUFBSVMsQ0FBQyxDQUFDc00sT0FBTyxFQUFDLElBQUksQ0FBQ1QsR0FBRyxDQUFDVSxnQkFBZ0IsQ0FBQ2hOLENBQUMsRUFBQ1MsQ0FBQyxDQUFDc00sT0FBTyxDQUFDL00sQ0FBQyxDQUFDLENBQUM7WUFBQyxJQUFJLENBQUNzTSxHQUFHLENBQUNXLGtCQUFrQixHQUFDLFlBQVU7Y0FBQyxJQUFHck0sQ0FBQyxDQUFDMEwsR0FBRyxFQUFDO2dCQUFDLElBQUkvTSxDQUFDO2tCQUFDYyxDQUFDO2tCQUFDQyxDQUFDLEdBQUNNLENBQUMsQ0FBQzBMLEdBQUc7Z0JBQUMsUUFBT2xNLENBQUMsQ0FBQyxZQUFZLEVBQUNFLENBQUMsQ0FBQ3FHLFVBQVUsQ0FBQyxFQUFDckcsQ0FBQyxDQUFDcUcsVUFBVTtrQkFBRSxLQUFLLENBQUM7b0JBQUMsSUFBRztzQkFBQ3RHLENBQUMsR0FBQ0MsQ0FBQyxDQUFDNE0sTUFBTSxFQUFDM04sQ0FBQyxHQUFDZSxDQUFDLENBQUM2TSxZQUFZO29CQUFBLENBQUMsUUFBTTVOLENBQUMsRUFBQyxDQUFDO29CQUFDYSxDQUFDLENBQUMsUUFBUSxFQUFDQyxDQUFDLENBQUMsRUFBQyxJQUFJLEtBQUdBLENBQUMsS0FBR0EsQ0FBQyxHQUFDLEdBQUcsQ0FBQyxFQUFDLEdBQUcsS0FBR0EsQ0FBQyxJQUFFZCxDQUFDLElBQUUsQ0FBQyxHQUFDQSxDQUFDLENBQUN1QixNQUFNLEtBQUdWLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBQ1EsQ0FBQyxDQUFDZ0IsSUFBSSxDQUFDLE9BQU8sRUFBQ3ZCLENBQUMsRUFBQ2QsQ0FBQyxDQUFDLENBQUM7b0JBQUM7a0JBQU0sS0FBSyxDQUFDO29CQUFDYyxDQUFDLEdBQUNDLENBQUMsQ0FBQzRNLE1BQU0sRUFBQzlNLENBQUMsQ0FBQyxRQUFRLEVBQUNDLENBQUMsQ0FBQyxFQUFDLElBQUksS0FBR0EsQ0FBQyxLQUFHQSxDQUFDLEdBQUMsR0FBRyxDQUFDLEVBQUMsS0FBSyxLQUFHQSxDQUFDLElBQUUsS0FBSyxLQUFHQSxDQUFDLEtBQUdBLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQ0QsQ0FBQyxDQUFDLFFBQVEsRUFBQ0MsQ0FBQyxFQUFDQyxDQUFDLENBQUM2TSxZQUFZLENBQUMsRUFBQ3ZNLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLEVBQUN2QixDQUFDLEVBQUNDLENBQUMsQ0FBQzZNLFlBQVksQ0FBQyxFQUFDdk0sQ0FBQyxDQUFDaUYsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUFBO2NBQUM7WUFBQyxDQUFDO1lBQUMsSUFBRztjQUFDakYsQ0FBQyxDQUFDMEwsR0FBRyxDQUFDN0ksSUFBSSxDQUFDbkQsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxRQUFNZixDQUFDLEVBQUM7Y0FBQ3FCLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLEVBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxFQUFDaEIsQ0FBQyxDQUFDaUYsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUE7VUFBQyxDQUFDLEVBQUNyRixDQUFDLENBQUNZLFNBQVMsQ0FBQ3lFLFFBQVEsR0FBQyxVQUFTdEcsQ0FBQyxFQUFDO1lBQUMsSUFBR2EsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFDLElBQUksQ0FBQ2tNLEdBQUcsRUFBQztjQUFDLElBQUcsSUFBSSxDQUFDakwsa0JBQWtCLENBQUMsQ0FBQyxFQUFDcEIsQ0FBQyxDQUFDbU4sU0FBUyxDQUFDLElBQUksQ0FBQ1osU0FBUyxDQUFDLEVBQUMsSUFBSSxDQUFDRixHQUFHLENBQUNXLGtCQUFrQixHQUFDLFlBQVUsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDWCxHQUFHLENBQUNLLFNBQVMsS0FBRyxJQUFJLENBQUNMLEdBQUcsQ0FBQ0ssU0FBUyxHQUFDLElBQUksQ0FBQyxFQUFDcE4sQ0FBQyxFQUFDLElBQUc7Z0JBQUMsSUFBSSxDQUFDK00sR0FBRyxDQUFDZSxLQUFLLENBQUMsQ0FBQztjQUFBLENBQUMsUUFBTTlOLENBQUMsRUFBQyxDQUFDO2NBQUMsSUFBSSxDQUFDaU4sU0FBUyxHQUFDLElBQUksQ0FBQ0YsR0FBRyxHQUFDLElBQUk7WUFBQTtVQUFDLENBQUMsRUFBQzlMLENBQUMsQ0FBQ1ksU0FBUyxDQUFDdUMsS0FBSyxHQUFDLFlBQVU7WUFBQ3ZELENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLENBQUN5RixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFBQSxDQUFDLEVBQUNyRixDQUFDLENBQUM4RSxPQUFPLEdBQUMsQ0FBQyxDQUFDbkYsQ0FBQztVQUFDLElBQUlFLENBQUMsR0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDd0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDc0ksSUFBSSxDQUFDLEdBQUcsQ0FBQztVQUFDLENBQUMzSyxDQUFDLENBQUM4RSxPQUFPLElBQUVqRixDQUFDLElBQUlJLENBQUMsS0FBR0wsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLEVBQUNJLENBQUMsQ0FBQzhFLE9BQU8sR0FBQyxDQUFDLENBQUMsS0FBSW5GLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVU7WUFBQyxJQUFHO2NBQUMsT0FBTyxJQUFJTSxDQUFDLENBQUNKLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO1lBQUEsQ0FBQyxRQUFNZCxDQUFDLEVBQUM7Y0FBQyxPQUFPLElBQUk7WUFBQTtVQUFDLENBQUMsR0FBQyxDQUFDO1VBQUMsSUFBSWUsQ0FBQyxHQUFDLENBQUMsQ0FBQztVQUFDLElBQUc7WUFBQ0EsQ0FBQyxHQUFDLGlCQUFpQixJQUFHLElBQUlILENBQUMsQ0FBRCxDQUFDO1VBQUEsQ0FBQyxRQUFNWixDQUFDLEVBQUMsQ0FBQztVQUFDaUIsQ0FBQyxDQUFDcU0sWUFBWSxHQUFDdk0sQ0FBQyxFQUFDc0QsQ0FBQyxDQUFDcEUsT0FBTyxHQUFDZ0IsQ0FBQztRQUFBLENBQUMsRUFBRUssSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLG1CQUFtQixFQUFDLEVBQUU7TUFBQyxpQkFBaUIsRUFBQyxFQUFFO01BQUMsT0FBTyxFQUFDLEtBQUssQ0FBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0wsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLENBQUMsVUFBU2YsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxZQUFVO1VBQUNjLENBQUMsQ0FBQ2IsT0FBTyxHQUFDRCxDQUFDLENBQUMrTixXQUFXO1FBQUEsQ0FBQyxFQUFFek0sSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQ2UsQ0FBQyxFQUFDRCxDQUFDLEVBQUM7TUFBQyxDQUFDLFVBQVNkLENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSWMsQ0FBQyxHQUFDZCxDQUFDLENBQUNnTyxTQUFTLElBQUVoTyxDQUFDLENBQUNpTyxZQUFZO1VBQUNsTixDQUFDLENBQUNkLE9BQU8sR0FBQ2EsQ0FBQyxHQUFDLFVBQVNkLENBQUMsRUFBQztZQUFDLE9BQU8sSUFBSWMsQ0FBQyxDQUFDZCxDQUFDLENBQUM7VUFBQSxDQUFDLEdBQUMsS0FBSyxDQUFDO1FBQUEsQ0FBQyxFQUFFc0IsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQ3FCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztRQUFDUyxDQUFDLEdBQUNULENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztRQUFDVSxDQUFDLEdBQUNWLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztRQUFDVyxDQUFDLEdBQUNYLENBQUMsQ0FBQyxhQUFhLENBQUM7TUFBQyxTQUFTWSxDQUFDQSxDQUFDWixDQUFDLEVBQUM7UUFBQyxJQUFHLENBQUNZLENBQUMsQ0FBQ21GLE9BQU8sQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1FBQUNFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQyxjQUFjLEVBQUNTLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO01BQUE7TUFBQ1EsQ0FBQyxDQUFDTixDQUFDLEVBQUNTLENBQUMsQ0FBQyxFQUFDVCxDQUFDLENBQUNtRixPQUFPLEdBQUMsWUFBVTtRQUFDLE9BQU0sQ0FBQyxDQUFDcEYsQ0FBQztNQUFBLENBQUMsRUFBQ0MsQ0FBQyxDQUFDZ0UsYUFBYSxHQUFDLGFBQWEsRUFBQ2hFLENBQUMsQ0FBQzZKLFVBQVUsR0FBQyxDQUFDLEVBQUMzSixDQUFDLENBQUNiLE9BQU8sR0FBQ1csQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLGtCQUFrQixFQUFDLEVBQUU7TUFBQyx3QkFBd0IsRUFBQyxFQUFFO01BQUMsbUJBQW1CLEVBQUMsRUFBRTtNQUFDLGFBQWEsRUFBQyxFQUFFO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU1osQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1FBQUNTLENBQUMsR0FBQ1QsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO1FBQUNVLENBQUMsR0FBQ1YsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO01BQUMsU0FBU1csQ0FBQ0EsQ0FBQ1gsQ0FBQyxFQUFDO1FBQUMsSUFBRyxDQUFDcUIsQ0FBQyxDQUFDMEUsT0FBTyxFQUFDLE1BQU0sSUFBSTVFLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQztRQUFDVCxDQUFDLENBQUNZLElBQUksQ0FBQyxJQUFJLEVBQUN0QixDQUFDLEVBQUMsV0FBVyxFQUFDcUIsQ0FBQyxFQUFDWixDQUFDLENBQUM7TUFBQTtNQUFDUyxDQUFDLENBQUNQLENBQUMsRUFBQ0QsQ0FBQyxDQUFDLEVBQUNDLENBQUMsQ0FBQ29GLE9BQU8sR0FBQyxVQUFTL0YsQ0FBQyxFQUFDO1FBQUMsT0FBT3FCLENBQUMsQ0FBQzBFLE9BQU8sSUFBRS9GLENBQUMsQ0FBQ2tHLFVBQVU7TUFBQSxDQUFDLEVBQUN2RixDQUFDLENBQUNpRSxhQUFhLEdBQUMsVUFBVSxFQUFDakUsQ0FBQyxDQUFDOEosVUFBVSxHQUFDLENBQUMsRUFBQzNKLENBQUMsQ0FBQ2IsT0FBTyxHQUFDVSxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsa0JBQWtCLEVBQUMsRUFBRTtNQUFDLHFCQUFxQixFQUFDLEVBQUU7TUFBQyxvQkFBb0IsRUFBQyxFQUFFO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU1gsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDUyxDQUFDLEdBQUNULENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzBDLFlBQVk7UUFBQ3JCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyxZQUFZLENBQUM7UUFBQ1UsQ0FBQyxHQUFDVixDQUFDLENBQUMsY0FBYyxDQUFDO1FBQUNXLENBQUMsR0FBQ1gsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO1FBQUNZLENBQUMsR0FBQ1osQ0FBQyxDQUFDLGdCQUFnQixDQUFDO1FBQUNhLENBQUMsR0FBQ2IsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO1FBQUNpQixDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztNQUFDLFNBQVNvRCxDQUFDQSxDQUFDckUsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztRQUFDLElBQUcsQ0FBQ3NELENBQUMsQ0FBQzBCLE9BQU8sQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1FBQUNWLENBQUMsQ0FBQ2EsSUFBSSxDQUFDLElBQUksQ0FBQztRQUFDLElBQUlKLENBQUMsR0FBQyxJQUFJO1FBQUMsSUFBSSxDQUFDaUUsTUFBTSxHQUFDekUsQ0FBQyxDQUFDK0gsU0FBUyxDQUFDMUgsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDbU4sT0FBTyxHQUFDbk4sQ0FBQyxFQUFDLElBQUksQ0FBQ29OLFFBQVEsR0FBQ3JOLENBQUMsRUFBQyxJQUFJLENBQUMrSixTQUFTLEdBQUM3SyxDQUFDLEVBQUMsSUFBSSxDQUFDcUYsUUFBUSxHQUFDeEUsQ0FBQyxDQUFDbUgsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUFDLElBQUkzRyxDQUFDLEdBQUNYLENBQUMsQ0FBQzBGLE9BQU8sQ0FBQ3JGLENBQUMsRUFBQyxjQUFjLENBQUMsR0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDc0UsUUFBUTtRQUFDcEUsQ0FBQyxDQUFDakIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNPLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQytNLFNBQVMsR0FBQ3pOLENBQUMsQ0FBQzBOLFlBQVksQ0FBQ2hOLENBQUMsRUFBQyxVQUFTckIsQ0FBQyxFQUFDO1VBQUNpQixDQUFDLENBQUMsY0FBYyxDQUFDLEVBQUNDLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxPQUFPLEVBQUMsSUFBSSxFQUFDLDRCQUE0QixHQUFDckMsQ0FBQyxHQUFDLEdBQUcsQ0FBQyxFQUFDa0IsQ0FBQyxDQUFDa0QsS0FBSyxDQUFDLENBQUM7UUFBQSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNrSyxpQkFBaUIsR0FBQyxJQUFJLENBQUNDLFFBQVEsQ0FBQzNLLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQ2hELENBQUMsQ0FBQ29FLFdBQVcsQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDc0osaUJBQWlCLENBQUM7TUFBQTtNQUFDcE4sQ0FBQyxDQUFDbUQsQ0FBQyxFQUFDNUQsQ0FBQyxDQUFDLEVBQUM0RCxDQUFDLENBQUN4QyxTQUFTLENBQUN1QyxLQUFLLEdBQUMsWUFBVTtRQUFDLElBQUduRCxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUMsSUFBSSxDQUFDYSxrQkFBa0IsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDc00sU0FBUyxFQUFDO1VBQUN4TixDQUFDLENBQUM0TixXQUFXLENBQUMsU0FBUyxFQUFDLElBQUksQ0FBQ0YsaUJBQWlCLENBQUM7VUFBQyxJQUFHO1lBQUMsSUFBSSxDQUFDeEssV0FBVyxDQUFDLEdBQUcsQ0FBQztVQUFBLENBQUMsUUFBTTlELENBQUMsRUFBQyxDQUFDO1VBQUMsSUFBSSxDQUFDb08sU0FBUyxDQUFDSyxPQUFPLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ0wsU0FBUyxHQUFDLElBQUksRUFBQyxJQUFJLENBQUNFLGlCQUFpQixHQUFDLElBQUksQ0FBQ0YsU0FBUyxHQUFDLElBQUk7UUFBQTtNQUFDLENBQUMsRUFBQy9KLENBQUMsQ0FBQ3hDLFNBQVMsQ0FBQzBNLFFBQVEsR0FBQyxVQUFTek4sQ0FBQyxFQUFDO1FBQUMsSUFBR0csQ0FBQyxDQUFDLFNBQVMsRUFBQ0gsQ0FBQyxDQUFDMkMsSUFBSSxDQUFDLEVBQUMvQyxDQUFDLENBQUM2RSxhQUFhLENBQUN6RSxDQUFDLENBQUNxRSxNQUFNLEVBQUMsSUFBSSxDQUFDQSxNQUFNLENBQUMsRUFBQztVQUFDLElBQUlwRSxDQUFDO1VBQUMsSUFBRztZQUFDQSxDQUFDLEdBQUNnRCxJQUFJLENBQUNxQixLQUFLLENBQUN0RSxDQUFDLENBQUMyQyxJQUFJLENBQUM7VUFBQSxDQUFDLFFBQU16RCxDQUFDLEVBQUM7WUFBQyxPQUFPLEtBQUtpQixDQUFDLENBQUMsVUFBVSxFQUFDSCxDQUFDLENBQUMyQyxJQUFJLENBQUM7VUFBQTtVQUFDLElBQUcxQyxDQUFDLENBQUNzRSxRQUFRLEtBQUcsSUFBSSxDQUFDQSxRQUFRLEVBQUMsUUFBT3RFLENBQUMsQ0FBQzRCLElBQUk7WUFBRSxLQUFJLEdBQUc7Y0FBQyxJQUFJLENBQUN5TCxTQUFTLENBQUNNLE1BQU0sQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDNUssV0FBVyxDQUFDLEdBQUcsRUFBQ0MsSUFBSSxDQUFDQyxTQUFTLENBQUMsQ0FBQzNDLENBQUMsRUFBQyxJQUFJLENBQUN3SixTQUFTLEVBQUMsSUFBSSxDQUFDc0QsUUFBUSxFQUFDLElBQUksQ0FBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQztjQUFDO1lBQU0sS0FBSSxHQUFHO2NBQUMsSUFBSSxDQUFDN0wsSUFBSSxDQUFDLFNBQVMsRUFBQ3RCLENBQUMsQ0FBQzBDLElBQUksQ0FBQztjQUFDO1lBQU0sS0FBSSxHQUFHO2NBQUMsSUFBSXpELENBQUM7Y0FBQyxJQUFHO2dCQUFDQSxDQUFDLEdBQUMrRCxJQUFJLENBQUNxQixLQUFLLENBQUNyRSxDQUFDLENBQUMwQyxJQUFJLENBQUM7Y0FBQSxDQUFDLFFBQU16RCxDQUFDLEVBQUM7Z0JBQUMsT0FBTyxLQUFLaUIsQ0FBQyxDQUFDLFVBQVUsRUFBQ0YsQ0FBQyxDQUFDMEMsSUFBSSxDQUFDO2NBQUE7Y0FBQyxJQUFJLENBQUNwQixJQUFJLENBQUMsT0FBTyxFQUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNvRSxLQUFLLENBQUMsQ0FBQztVQUFBLENBQUMsTUFBS25ELENBQUMsQ0FBQyxzQkFBc0IsRUFBQ0YsQ0FBQyxDQUFDc0UsUUFBUSxFQUFDLElBQUksQ0FBQ0EsUUFBUSxDQUFDO1FBQUEsQ0FBQyxNQUFLcEUsQ0FBQyxDQUFDLGlCQUFpQixFQUFDSCxDQUFDLENBQUNxRSxNQUFNLEVBQUMsSUFBSSxDQUFDQSxNQUFNLENBQUM7TUFBQSxDQUFDLEVBQUNkLENBQUMsQ0FBQ3hDLFNBQVMsQ0FBQ2lDLFdBQVcsR0FBQyxVQUFTOUQsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7UUFBQ0csQ0FBQyxDQUFDLGFBQWEsRUFBQ2pCLENBQUMsRUFBQ2MsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDc04sU0FBUyxDQUFDTyxJQUFJLENBQUM1SyxJQUFJLENBQUNDLFNBQVMsQ0FBQztVQUFDcUIsUUFBUSxFQUFDLElBQUksQ0FBQ0EsUUFBUTtVQUFDMUMsSUFBSSxFQUFDM0MsQ0FBQztVQUFDeUQsSUFBSSxFQUFDM0MsQ0FBQyxJQUFFO1FBQUUsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDcUUsTUFBTSxDQUFDO01BQUEsQ0FBQyxFQUFDZCxDQUFDLENBQUN4QyxTQUFTLENBQUNxQyxJQUFJLEdBQUMsVUFBU2xFLENBQUMsRUFBQztRQUFDaUIsQ0FBQyxDQUFDLE1BQU0sRUFBQ2pCLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzhELFdBQVcsQ0FBQyxHQUFHLEVBQUM5RCxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUNxRSxDQUFDLENBQUMwQixPQUFPLEdBQUMsWUFBVTtRQUFDLE9BQU9wRixDQUFDLENBQUNpTyxhQUFhO01BQUEsQ0FBQyxFQUFDdkssQ0FBQyxDQUFDTyxhQUFhLEdBQUMsUUFBUSxFQUFDUCxDQUFDLENBQUNvRyxVQUFVLEdBQUMsQ0FBQyxFQUFDM0osQ0FBQyxDQUFDYixPQUFPLEdBQUNvRSxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsZ0JBQWdCLEVBQUMsRUFBRTtNQUFDLGlCQUFpQixFQUFDLEVBQUU7TUFBQyxpQkFBaUIsRUFBQyxFQUFFO01BQUMsY0FBYyxFQUFDLEVBQUU7TUFBQyxZQUFZLEVBQUMsRUFBRTtNQUFDLE9BQU8sRUFBQyxLQUFLLENBQUM7TUFBQyxRQUFRLEVBQUMsQ0FBQztNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVMzRCxDQUFDLEVBQUNDLENBQUMsRUFBQ1gsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTUyxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDLElBQUlULENBQUMsR0FBQ1UsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUFDSSxDQUFDLEdBQUNKLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQztZQUFDSyxDQUFDLEdBQUNMLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztZQUFDUSxDQUFDLEdBQUNSLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztVQUFDLFNBQVNXLENBQUNBLENBQUNyQixDQUFDLEVBQUM7WUFBQyxJQUFHLENBQUNxQixDQUFDLENBQUMwRSxPQUFPLENBQUMsQ0FBQyxFQUFDLE1BQU0sSUFBSTVFLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQztZQUFDTCxDQUFDLENBQUNRLElBQUksQ0FBQyxJQUFJLEVBQUN0QixDQUFDLEVBQUMsUUFBUSxFQUFDa0IsQ0FBQyxFQUFDSCxDQUFDLENBQUM7VUFBQTtVQUFDZixDQUFDLENBQUNxQixDQUFDLEVBQUNQLENBQUMsQ0FBQyxFQUFDTyxDQUFDLENBQUMwRSxPQUFPLEdBQUMsWUFBVTtZQUFDLE9BQU0sQ0FBQyxDQUFDdEYsQ0FBQyxDQUFDb0YsUUFBUTtVQUFBLENBQUMsRUFBQ3hFLENBQUMsQ0FBQ3VELGFBQWEsR0FBQyxlQUFlLEVBQUN2RCxDQUFDLENBQUNvSixVQUFVLEdBQUMsQ0FBQyxFQUFDcEosQ0FBQyxDQUFDZ0osUUFBUSxHQUFDLENBQUMsQ0FBQyxFQUFDMUosQ0FBQyxDQUFDVixPQUFPLEdBQUNvQixDQUFDO1FBQUEsQ0FBQyxFQUFFQyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsdUJBQXVCLEVBQUMsRUFBRTtNQUFDLGtCQUFrQixFQUFDLEVBQUU7TUFBQyxnQkFBZ0IsRUFBQyxFQUFFO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0wsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDVyxDQUFDLEdBQUNYLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO1FBQUNZLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0gsQ0FBQ0EsQ0FBQ1QsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQ0csQ0FBQyxFQUFDO1FBQUNHLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQ2MsQ0FBQyxFQUFDLFVBQVNKLENBQUMsRUFBQztVQUFDLE9BQU8sVUFBU1YsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztZQUFDSCxDQUFDLENBQUMsb0JBQW9CLEVBQUNaLENBQUMsRUFBQ2MsQ0FBQyxDQUFDO1lBQUMsSUFBSUksQ0FBQyxHQUFDLENBQUMsQ0FBQztZQUFDLFFBQVEsSUFBRSxPQUFPSixDQUFDLEtBQUdJLENBQUMsQ0FBQ3NNLE9BQU8sR0FBQztjQUFDLGNBQWMsRUFBQztZQUFZLENBQUMsQ0FBQztZQUFDLElBQUluTSxDQUFDLEdBQUNWLENBQUMsQ0FBQ3lGLE9BQU8sQ0FBQ3BHLENBQUMsRUFBQyxXQUFXLENBQUM7Y0FBQ1MsQ0FBQyxHQUFDLElBQUlDLENBQUMsQ0FBQyxNQUFNLEVBQUNXLENBQUMsRUFBQ1AsQ0FBQyxFQUFDSSxDQUFDLENBQUM7WUFBQyxPQUFPVCxDQUFDLENBQUN1QixJQUFJLENBQUMsUUFBUSxFQUFDLFVBQVNoQyxDQUFDLEVBQUM7Y0FBQyxJQUFHWSxDQUFDLENBQUMsUUFBUSxFQUFDWixDQUFDLENBQUMsRUFBQ1MsQ0FBQyxHQUFDLElBQUksRUFBQyxHQUFHLEtBQUdULENBQUMsSUFBRSxHQUFHLEtBQUdBLENBQUMsRUFBQyxPQUFPZSxDQUFDLENBQUMsSUFBSUksS0FBSyxDQUFDLGNBQWMsR0FBQ25CLENBQUMsQ0FBQyxDQUFDO2NBQUNlLENBQUMsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxDQUFDLEVBQUMsWUFBVTtjQUFDSCxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUNILENBQUMsQ0FBQzJELEtBQUssQ0FBQyxDQUFDLEVBQUMzRCxDQUFDLEdBQUMsSUFBSTtjQUFDLElBQUlULENBQUMsR0FBQyxJQUFJbUIsS0FBSyxDQUFDLFNBQVMsQ0FBQztjQUFDbkIsQ0FBQyxDQUFDb0IsSUFBSSxHQUFDLEdBQUcsRUFBQ0wsQ0FBQyxDQUFDZixDQUFDLENBQUM7WUFBQSxDQUFDO1VBQUEsQ0FBQztRQUFBLENBQUMsQ0FBQ2tCLENBQUMsQ0FBQyxFQUFDSCxDQUFDLEVBQUNHLENBQUMsQ0FBQztNQUFBO01BQUNBLENBQUMsQ0FBQ1QsQ0FBQyxFQUFDWSxDQUFDLENBQUMsRUFBQ1AsQ0FBQyxDQUFDYixPQUFPLEdBQUNRLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxpQkFBaUIsRUFBQyxFQUFFO01BQUMsbUJBQW1CLEVBQUMsRUFBRTtNQUFDLE9BQU8sRUFBQyxLQUFLLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTVCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJRyxDQUFDLEdBQUNsQixDQUFDLENBQUMsVUFBVSxDQUFDO1FBQUNxQixDQUFDLEdBQUNyQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMwQyxZQUFZO1FBQUNqQyxDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztNQUFDLFNBQVNDLENBQUNBLENBQUNWLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUNMLENBQUMsQ0FBQ1QsQ0FBQyxDQUFDLEVBQUNxQixDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLENBQUN1TixVQUFVLEdBQUMsRUFBRSxFQUFDLElBQUksQ0FBQ0MsTUFBTSxHQUFDaE8sQ0FBQyxFQUFDLElBQUksQ0FBQ2lJLEdBQUcsR0FBQy9JLENBQUM7TUFBQTtNQUFDa0IsQ0FBQyxDQUFDUixDQUFDLEVBQUNXLENBQUMsQ0FBQyxFQUFDWCxDQUFDLENBQUNtQixTQUFTLENBQUNxQyxJQUFJLEdBQUMsVUFBU2xFLENBQUMsRUFBQztRQUFDUyxDQUFDLENBQUMsTUFBTSxFQUFDVCxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUM2TyxVQUFVLENBQUNsRCxJQUFJLENBQUMzTCxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMrTyxRQUFRLElBQUUsSUFBSSxDQUFDQyxZQUFZLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQ3RPLENBQUMsQ0FBQ21CLFNBQVMsQ0FBQ29OLGdCQUFnQixHQUFDLFlBQVU7UUFBQ3hPLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztRQUFDLElBQUlULENBQUM7VUFBQ2MsQ0FBQyxHQUFDLElBQUk7UUFBQyxJQUFJLENBQUNpTyxRQUFRLEdBQUMsWUFBVTtVQUFDdE8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFDSyxDQUFDLENBQUNpTyxRQUFRLEdBQUMsSUFBSSxFQUFDdkksWUFBWSxDQUFDeEcsQ0FBQyxDQUFDO1FBQUEsQ0FBQyxFQUFDQSxDQUFDLEdBQUN3QixVQUFVLENBQUMsWUFBVTtVQUFDZixDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUNLLENBQUMsQ0FBQ2lPLFFBQVEsR0FBQyxJQUFJLEVBQUNqTyxDQUFDLENBQUNrTyxZQUFZLENBQUMsQ0FBQztRQUFBLENBQUMsRUFBQyxFQUFFLENBQUM7TUFBQSxDQUFDLEVBQUN0TyxDQUFDLENBQUNtQixTQUFTLENBQUNtTixZQUFZLEdBQUMsWUFBVTtRQUFDdk8sQ0FBQyxDQUFDLGNBQWMsRUFBQyxJQUFJLENBQUNvTyxVQUFVLENBQUN0TixNQUFNLENBQUM7UUFBQyxJQUFJVCxDQUFDLEdBQUMsSUFBSTtRQUFDLElBQUcsQ0FBQyxHQUFDLElBQUksQ0FBQytOLFVBQVUsQ0FBQ3ROLE1BQU0sRUFBQztVQUFDLElBQUl2QixDQUFDLEdBQUMsR0FBRyxHQUFDLElBQUksQ0FBQzZPLFVBQVUsQ0FBQ2pELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyxHQUFHO1VBQUMsSUFBSSxDQUFDbUQsUUFBUSxHQUFDLElBQUksQ0FBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQy9GLEdBQUcsRUFBQy9JLENBQUMsRUFBQyxVQUFTQSxDQUFDLEVBQUM7WUFBQ2MsQ0FBQyxDQUFDaU8sUUFBUSxHQUFDLElBQUksRUFBQy9PLENBQUMsSUFBRVMsQ0FBQyxDQUFDLE9BQU8sRUFBQ1QsQ0FBQyxDQUFDLEVBQUNjLENBQUMsQ0FBQ3VCLElBQUksQ0FBQyxPQUFPLEVBQUNyQyxDQUFDLENBQUNvQixJQUFJLElBQUUsSUFBSSxFQUFDLGlCQUFpQixHQUFDcEIsQ0FBQyxDQUFDLEVBQUNjLENBQUMsQ0FBQ3NELEtBQUssQ0FBQyxDQUFDLElBQUV0RCxDQUFDLENBQUNtTyxnQkFBZ0IsQ0FBQyxDQUFDO1VBQUEsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDSixVQUFVLEdBQUMsRUFBRTtRQUFBO01BQUMsQ0FBQyxFQUFDbk8sQ0FBQyxDQUFDbUIsU0FBUyxDQUFDeUUsUUFBUSxHQUFDLFlBQVU7UUFBQzdGLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQyxJQUFJLENBQUNxQixrQkFBa0IsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDcEIsQ0FBQyxDQUFDbUIsU0FBUyxDQUFDdUMsS0FBSyxHQUFDLFlBQVU7UUFBQzNELENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLENBQUM2RixRQUFRLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ3lJLFFBQVEsS0FBRyxJQUFJLENBQUNBLFFBQVEsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDQSxRQUFRLEdBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFDak8sQ0FBQyxDQUFDYixPQUFPLEdBQUNTLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxPQUFPLEVBQUMsS0FBSyxDQUFDO01BQUMsUUFBUSxFQUFDLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTVixDQUFDLEVBQUNlLENBQUMsRUFBQ0QsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTSixDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDLElBQUlJLENBQUMsR0FBQ2QsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLFdBQVcsQ0FBQztZQUFDUyxDQUFDLEdBQUNULENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztVQUFDZSxDQUFDLENBQUNkLE9BQU8sR0FBQyxVQUFTaUIsQ0FBQyxFQUFDO1lBQUMsU0FBU2xCLENBQUNBLENBQUNBLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO2NBQUNPLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ0osQ0FBQyxDQUFDMEQsYUFBYSxFQUFDNUUsQ0FBQyxFQUFDYyxDQUFDLENBQUM7WUFBQTtZQUFDLE9BQU9BLENBQUMsQ0FBQ2QsQ0FBQyxFQUFDcUIsQ0FBQyxDQUFDLEVBQUNyQixDQUFDLENBQUMrRixPQUFPLEdBQUMsVUFBUy9GLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO2NBQUMsSUFBRyxDQUFDSixDQUFDLENBQUNtRixRQUFRLEVBQUMsT0FBTSxDQUFDLENBQUM7Y0FBQyxJQUFJOUUsQ0FBQyxHQUFDTixDQUFDLENBQUNzSixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUNqSixDQUFDLENBQUM7Y0FBQyxPQUFPQyxDQUFDLENBQUNtRixVQUFVLEdBQUMsQ0FBQyxDQUFDLEVBQUNoRixDQUFDLENBQUM2RSxPQUFPLENBQUNoRixDQUFDLENBQUMsSUFBRU0sQ0FBQyxDQUFDMEUsT0FBTyxDQUFDLENBQUM7WUFBQSxDQUFDLEVBQUMvRixDQUFDLENBQUM0RSxhQUFhLEdBQUMsU0FBUyxHQUFDMUQsQ0FBQyxDQUFDMEQsYUFBYSxFQUFDNUUsQ0FBQyxDQUFDcUssUUFBUSxHQUFDLENBQUMsQ0FBQyxFQUFDckssQ0FBQyxDQUFDeUssVUFBVSxHQUFDcEosQ0FBQyxDQUFDb0osVUFBVSxHQUFDdkosQ0FBQyxDQUFDdUosVUFBVSxHQUFDLENBQUMsRUFBQ3pLLENBQUMsQ0FBQzJFLGVBQWUsR0FBQ3pELENBQUMsRUFBQ2xCLENBQUM7VUFBQSxDQUFDO1FBQUEsQ0FBQyxFQUFFc0IsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLG9CQUFvQixFQUFDLEVBQUU7TUFBQyxXQUFXLEVBQUMsRUFBRTtNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQ3FCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzBDLFlBQVk7UUFBQ2pDLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0MsQ0FBQ0EsQ0FBQ1YsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztRQUFDTixDQUFDLENBQUNLLENBQUMsQ0FBQyxFQUFDTyxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLENBQUM0TixRQUFRLEdBQUNsUCxDQUFDLEVBQUMsSUFBSSxDQUFDbVAsVUFBVSxHQUFDck8sQ0FBQyxFQUFDLElBQUksQ0FBQ3NPLFVBQVUsR0FBQ3JPLENBQUMsRUFBQyxJQUFJLENBQUNzTyxpQkFBaUIsQ0FBQyxDQUFDO01BQUE7TUFBQ25PLENBQUMsQ0FBQ1IsQ0FBQyxFQUFDVyxDQUFDLENBQUMsRUFBQ1gsQ0FBQyxDQUFDbUIsU0FBUyxDQUFDd04saUJBQWlCLEdBQUMsWUFBVTtRQUFDNU8sQ0FBQyxDQUFDLG1CQUFtQixDQUFDO1FBQUMsSUFBSU0sQ0FBQyxHQUFDLElBQUk7VUFBQ0csQ0FBQyxHQUFDLElBQUksQ0FBQ29PLElBQUksR0FBQyxJQUFJLElBQUksQ0FBQ0osUUFBUSxDQUFDLElBQUksQ0FBQ0MsVUFBVSxFQUFDLElBQUksQ0FBQ0MsVUFBVSxDQUFDO1FBQUNsTyxDQUFDLENBQUNlLEVBQUUsQ0FBQyxTQUFTLEVBQUMsVUFBU2pDLENBQUMsRUFBQztVQUFDUyxDQUFDLENBQUMsU0FBUyxFQUFDVCxDQUFDLENBQUMsRUFBQ2UsQ0FBQyxDQUFDc0IsSUFBSSxDQUFDLFNBQVMsRUFBQ3JDLENBQUMsQ0FBQztRQUFBLENBQUMsQ0FBQyxFQUFDa0IsQ0FBQyxDQUFDYyxJQUFJLENBQUMsT0FBTyxFQUFDLFVBQVNoQyxDQUFDLEVBQUNjLENBQUMsRUFBQztVQUFDTCxDQUFDLENBQUMsT0FBTyxFQUFDVCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxDQUFDd08sYUFBYSxDQUFDLEVBQUN4TyxDQUFDLENBQUN1TyxJQUFJLEdBQUNwTyxDQUFDLEdBQUMsSUFBSSxFQUFDSCxDQUFDLENBQUN3TyxhQUFhLEtBQUcsU0FBUyxLQUFHek8sQ0FBQyxHQUFDQyxDQUFDLENBQUNzTyxpQkFBaUIsQ0FBQyxDQUFDLElBQUV0TyxDQUFDLENBQUNzQixJQUFJLENBQUMsT0FBTyxFQUFDckMsQ0FBQyxJQUFFLElBQUksRUFBQ2MsQ0FBQyxDQUFDLEVBQUNDLENBQUMsQ0FBQ2Usa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQSxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUNwQixDQUFDLENBQUNtQixTQUFTLENBQUNpTSxLQUFLLEdBQUMsWUFBVTtRQUFDck4sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFDLElBQUksQ0FBQ3FCLGtCQUFrQixDQUFDLENBQUMsRUFBQyxJQUFJLENBQUN5TixhQUFhLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDRCxJQUFJLElBQUUsSUFBSSxDQUFDQSxJQUFJLENBQUN4QixLQUFLLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQ2hOLENBQUMsQ0FBQ2IsT0FBTyxHQUFDUyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsT0FBTyxFQUFDLEtBQUssQ0FBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU1YsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDVyxDQUFDLEdBQUNYLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztRQUFDWSxDQUFDLEdBQUNaLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztRQUFDYSxDQUFDLEdBQUNiLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFBQ2lCLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0ksQ0FBQ0EsQ0FBQ3JCLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUNHLENBQUMsRUFBQ0csQ0FBQyxFQUFDO1FBQUMsSUFBSVosQ0FBQyxHQUFDRSxDQUFDLENBQUN5RixPQUFPLENBQUNwRyxDQUFDLEVBQUNjLENBQUMsQ0FBQztRQUFDRyxDQUFDLENBQUNSLENBQUMsQ0FBQztRQUFDLElBQUlDLENBQUMsR0FBQyxJQUFJO1FBQUNFLENBQUMsQ0FBQ1UsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQ2UsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDdU8sSUFBSSxHQUFDLElBQUl6TyxDQUFDLENBQUNLLENBQUMsRUFBQ1QsQ0FBQyxFQUFDWSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNpTyxJQUFJLENBQUNyTixFQUFFLENBQUMsU0FBUyxFQUFDLFVBQVNqQyxDQUFDLEVBQUM7VUFBQ2lCLENBQUMsQ0FBQyxjQUFjLEVBQUNqQixDQUFDLENBQUMsRUFBQ1UsQ0FBQyxDQUFDMkIsSUFBSSxDQUFDLFNBQVMsRUFBQ3JDLENBQUMsQ0FBQztRQUFBLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ3NQLElBQUksQ0FBQ3ROLElBQUksQ0FBQyxPQUFPLEVBQUMsVUFBU2hDLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1VBQUNHLENBQUMsQ0FBQyxZQUFZLEVBQUNqQixDQUFDLEVBQUNjLENBQUMsQ0FBQyxFQUFDSixDQUFDLENBQUM0TyxJQUFJLEdBQUMsSUFBSSxFQUFDNU8sQ0FBQyxDQUFDMkIsSUFBSSxDQUFDLE9BQU8sRUFBQ3JDLENBQUMsRUFBQ2MsQ0FBQyxDQUFDLEVBQUNKLENBQUMsQ0FBQzBELEtBQUssQ0FBQyxDQUFDO1FBQUEsQ0FBQyxDQUFDO01BQUE7TUFBQ2xELENBQUMsQ0FBQ0csQ0FBQyxFQUFDVCxDQUFDLENBQUMsRUFBQ1MsQ0FBQyxDQUFDUSxTQUFTLENBQUN1QyxLQUFLLEdBQUMsWUFBVTtRQUFDeEQsQ0FBQyxDQUFDaUIsU0FBUyxDQUFDdUMsS0FBSyxDQUFDOUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDTCxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUMsSUFBSSxDQUFDYSxrQkFBa0IsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDd04sSUFBSSxLQUFHLElBQUksQ0FBQ0EsSUFBSSxDQUFDeEIsS0FBSyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUN3QixJQUFJLEdBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFDeE8sQ0FBQyxDQUFDYixPQUFPLEdBQUNvQixDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsaUJBQWlCLEVBQUMsRUFBRTtNQUFDLG1CQUFtQixFQUFDLEVBQUU7TUFBQyxXQUFXLEVBQUMsRUFBRTtNQUFDLE9BQU8sRUFBQyxLQUFLLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTckIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDMEMsWUFBWTtRQUFDakMsQ0FBQyxHQUFDVCxDQUFDLENBQUMsYUFBYSxDQUFDO1FBQUNVLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0MsQ0FBQ0EsQ0FBQ1gsQ0FBQyxFQUFDO1FBQUNVLENBQUMsQ0FBQ1YsQ0FBQyxDQUFDLEVBQUNxQixDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFBQyxJQUFJUCxDQUFDLEdBQUMsSUFBSTtVQUFDRyxDQUFDLEdBQUMsSUFBSSxDQUFDc08sRUFBRSxHQUFDLElBQUkvTyxDQUFDLENBQUNULENBQUMsQ0FBQztRQUFDa0IsQ0FBQyxDQUFDNEosU0FBUyxHQUFDLFVBQVM5SyxDQUFDLEVBQUM7VUFBQ1UsQ0FBQyxDQUFDLFNBQVMsRUFBQ1YsQ0FBQyxDQUFDeUQsSUFBSSxDQUFDLEVBQUMxQyxDQUFDLENBQUNzQixJQUFJLENBQUMsU0FBUyxFQUFDb04sU0FBUyxDQUFDelAsQ0FBQyxDQUFDeUQsSUFBSSxDQUFDLENBQUM7UUFBQSxDQUFDLEVBQUN2QyxDQUFDLENBQUM4SixPQUFPLEdBQUMsVUFBU2hMLENBQUMsRUFBQztVQUFDVSxDQUFDLENBQUMsT0FBTyxFQUFDUSxDQUFDLENBQUNrRyxVQUFVLEVBQUNwSCxDQUFDLENBQUM7VUFBQyxJQUFJYyxDQUFDLEdBQUMsQ0FBQyxLQUFHSSxDQUFDLENBQUNrRyxVQUFVLEdBQUMsU0FBUyxHQUFDLFdBQVc7VUFBQ3JHLENBQUMsQ0FBQ3VGLFFBQVEsQ0FBQyxDQUFDLEVBQUN2RixDQUFDLENBQUNvRCxNQUFNLENBQUNyRCxDQUFDLENBQUM7UUFBQSxDQUFDO01BQUE7TUFBQ0ksQ0FBQyxDQUFDUCxDQUFDLEVBQUNVLENBQUMsQ0FBQyxFQUFDVixDQUFDLENBQUNrQixTQUFTLENBQUNpTSxLQUFLLEdBQUMsWUFBVTtRQUFDcE4sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFDLElBQUksQ0FBQzRGLFFBQVEsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQztNQUFBLENBQUMsRUFBQ3hELENBQUMsQ0FBQ2tCLFNBQVMsQ0FBQ3lFLFFBQVEsR0FBQyxZQUFVO1FBQUM1RixDQUFDLENBQUMsU0FBUyxDQUFDO1FBQUMsSUFBSVYsQ0FBQyxHQUFDLElBQUksQ0FBQ3dQLEVBQUU7UUFBQ3hQLENBQUMsS0FBR0EsQ0FBQyxDQUFDOEssU0FBUyxHQUFDOUssQ0FBQyxDQUFDZ0wsT0FBTyxHQUFDLElBQUksRUFBQ2hMLENBQUMsQ0FBQ29FLEtBQUssQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDb0wsRUFBRSxHQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBQzdPLENBQUMsQ0FBQ2tCLFNBQVMsQ0FBQ3NDLE1BQU0sR0FBQyxVQUFTbkUsQ0FBQyxFQUFDO1FBQUNVLENBQUMsQ0FBQyxPQUFPLEVBQUNWLENBQUMsQ0FBQztRQUFDLElBQUljLENBQUMsR0FBQyxJQUFJO1FBQUNVLFVBQVUsQ0FBQyxZQUFVO1VBQUNWLENBQUMsQ0FBQ3VCLElBQUksQ0FBQyxPQUFPLEVBQUMsSUFBSSxFQUFDckMsQ0FBQyxDQUFDLEVBQUNjLENBQUMsQ0FBQ2dCLGtCQUFrQixDQUFDLENBQUM7UUFBQSxDQUFDLEVBQUMsR0FBRyxDQUFDO01BQUEsQ0FBQyxFQUFDaEIsQ0FBQyxDQUFDYixPQUFPLEdBQUNVLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxPQUFPLEVBQUMsS0FBSyxDQUFDO01BQUMsUUFBUSxFQUFDLENBQUM7TUFBQyxhQUFhLEVBQUMsRUFBRTtNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNJLENBQUMsRUFBQ0UsQ0FBQyxFQUFDakIsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTYSxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDLElBQUliLENBQUMsR0FBQ2UsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUFDRyxDQUFDLEdBQUNILENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztZQUFDTSxDQUFDLEdBQUNOLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztZQUFDTixDQUFDLEdBQUNNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzJCLFlBQVk7WUFBQ2hDLENBQUMsR0FBQ0ssQ0FBQyxDQUFDLG9CQUFvQixDQUFDO1lBQUNKLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO1VBQUMsU0FBU0MsQ0FBQ0EsQ0FBQ1osQ0FBQyxFQUFDO1lBQUNXLENBQUMsQ0FBQ1gsQ0FBQyxDQUFDLEVBQUNTLENBQUMsQ0FBQ2EsSUFBSSxDQUFDLElBQUksQ0FBQztZQUFDLElBQUlSLENBQUMsR0FBQyxJQUFJO1lBQUNJLENBQUMsQ0FBQ3dPLHNCQUFzQixDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNDLEVBQUUsR0FBQyxHQUFHLEdBQUNqUCxDQUFDLENBQUNzSCxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUNoSSxDQUFDLEdBQUNxQixDQUFDLENBQUMyTCxRQUFRLENBQUNoTixDQUFDLEVBQUMsSUFBSSxHQUFDNFAsa0JBQWtCLENBQUMxTyxDQUFDLENBQUMyTyxPQUFPLEdBQUMsR0FBRyxHQUFDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLENBQUMsRUFBQ2hQLENBQUMsQ0FBQyxnQkFBZ0IsRUFBQ0MsQ0FBQyxDQUFDa1AsZUFBZSxDQUFDO1lBQUMsSUFBSS9PLENBQUMsR0FBQ0gsQ0FBQyxDQUFDa1AsZUFBZSxHQUFDNU8sQ0FBQyxDQUFDNk8sY0FBYyxHQUFDN08sQ0FBQyxDQUFDbU4sWUFBWTtZQUFDeE4sQ0FBQyxDQUFDSyxDQUFDLENBQUMyTyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUNGLEVBQUUsQ0FBQyxHQUFDO2NBQUNLLEtBQUssRUFBQyxTQUFBQSxDQUFBLEVBQVU7Z0JBQUNyUCxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUNHLENBQUMsQ0FBQ3NOLFNBQVMsQ0FBQ00sTUFBTSxDQUFDLENBQUM7Y0FBQSxDQUFDO2NBQUN1QixPQUFPLEVBQUMsU0FBQUEsQ0FBU2pRLENBQUMsRUFBQztnQkFBQ1csQ0FBQyxDQUFDLFNBQVMsRUFBQ1gsQ0FBQyxDQUFDLEVBQUNjLENBQUMsQ0FBQ3VCLElBQUksQ0FBQyxTQUFTLEVBQUNyQyxDQUFDLENBQUM7Y0FBQSxDQUFDO2NBQUNrUSxJQUFJLEVBQUMsU0FBQUEsQ0FBQSxFQUFVO2dCQUFDdlAsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFDRyxDQUFDLENBQUN3RixRQUFRLENBQUMsQ0FBQyxFQUFDeEYsQ0FBQyxDQUFDcUQsTUFBTSxDQUFDLFNBQVMsQ0FBQztjQUFBO1lBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ2lLLFNBQVMsR0FBQ3JOLENBQUMsQ0FBQ2YsQ0FBQyxFQUFDLFlBQVU7Y0FBQ1csQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFDRyxDQUFDLENBQUN3RixRQUFRLENBQUMsQ0FBQyxFQUFDeEYsQ0FBQyxDQUFDcUQsTUFBTSxDQUFDLFdBQVcsQ0FBQztZQUFBLENBQUMsQ0FBQztVQUFBO1VBQUNuRSxDQUFDLENBQUNZLENBQUMsRUFBQ0gsQ0FBQyxDQUFDLEVBQUNHLENBQUMsQ0FBQ2lCLFNBQVMsQ0FBQ2lNLEtBQUssR0FBQyxZQUFVO1lBQUNuTixDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUMsSUFBSSxDQUFDMkYsUUFBUSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNuQyxNQUFNLENBQUMsTUFBTSxDQUFDO1VBQUEsQ0FBQyxFQUFDdkQsQ0FBQyxDQUFDaUIsU0FBUyxDQUFDeUUsUUFBUSxHQUFDLFlBQVU7WUFBQzNGLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQyxJQUFJLENBQUN5TixTQUFTLEtBQUcsSUFBSSxDQUFDQSxTQUFTLENBQUNLLE9BQU8sQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDTCxTQUFTLEdBQUMsSUFBSSxDQUFDLEVBQUMsT0FBT3ZOLENBQUMsQ0FBQ0ssQ0FBQyxDQUFDMk8sT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDRixFQUFFLENBQUM7VUFBQSxDQUFDLEVBQUMvTyxDQUFDLENBQUNpQixTQUFTLENBQUNzQyxNQUFNLEdBQUMsVUFBU25FLENBQUMsRUFBQztZQUFDVyxDQUFDLENBQUMsUUFBUSxFQUFDWCxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNxQyxJQUFJLENBQUMsT0FBTyxFQUFDLElBQUksRUFBQ3JDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzhCLGtCQUFrQixDQUFDLENBQUM7VUFBQSxDQUFDLEVBQUNsQixDQUFDLENBQUNrUCxlQUFlLEdBQUMsQ0FBQyxDQUFDO1VBQUMsSUFBSWhQLENBQUMsR0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDd0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDc0ksSUFBSSxDQUFDLEdBQUcsQ0FBQztVQUFDLElBQUc5SyxDQUFDLElBQUlELENBQUMsRUFBQyxJQUFHO1lBQUNELENBQUMsQ0FBQ2tQLGVBQWUsR0FBQyxDQUFDLENBQUMsSUFBSWpQLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO1VBQUEsQ0FBQyxRQUFNZCxDQUFDLEVBQUMsQ0FBQztVQUFDWSxDQUFDLENBQUNtRixPQUFPLEdBQUNuRixDQUFDLENBQUNrUCxlQUFlLElBQUU1TyxDQUFDLENBQUMwTixhQUFhLEVBQUMzTixDQUFDLENBQUNoQixPQUFPLEdBQUNXLENBQUM7UUFBQSxDQUFDLEVBQUVVLElBQUksQ0FBQyxJQUFJLENBQUM7TUFBQSxDQUFDLEVBQUVBLElBQUksQ0FBQyxJQUFJLEVBQUMsV0FBVyxJQUFFLE9BQU9oQixxQkFBTSxHQUFDQSxxQkFBTSxHQUFDLFdBQVcsSUFBRSxPQUFPQyxJQUFJLEdBQUNBLElBQUksR0FBQyxXQUFXLElBQUUsT0FBT0YsTUFBTSxHQUFDQSxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxvQkFBb0IsRUFBQyxFQUFFO01BQUMsb0JBQW9CLEVBQUMsRUFBRTtNQUFDLGlCQUFpQixFQUFDLEVBQUU7TUFBQyxPQUFPLEVBQUMsS0FBSyxDQUFDO01BQUMsUUFBUSxFQUFDLENBQUM7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTUyxDQUFDLEVBQUNDLENBQUMsRUFBQ2YsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTaUIsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxZQUFVO1VBQUMsWUFBWTs7VUFBQyxJQUFJQyxDQUFDLEdBQUNKLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztZQUFDTCxDQUFDLEdBQUNLLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztZQUFDSixDQUFDLEdBQUNJLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztZQUFDTyxDQUFDLEdBQUNQLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztZQUFDZCxDQUFDLEdBQUNjLENBQUMsQ0FBQyxVQUFVLENBQUM7WUFBQ0gsQ0FBQyxHQUFDRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM0QixZQUFZO1lBQUM5QixDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztVQUFDLFNBQVNDLENBQUNBLENBQUNiLENBQUMsRUFBQztZQUFDWSxDQUFDLENBQUNaLENBQUMsQ0FBQztZQUFDLElBQUljLENBQUMsR0FBQyxJQUFJO1lBQUNILENBQUMsQ0FBQ1csSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDSixDQUFDLENBQUN3TyxzQkFBc0IsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDQyxFQUFFLEdBQUMsR0FBRyxHQUFDbFAsQ0FBQyxDQUFDdUgsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUFDLElBQUlqSCxDQUFDLEdBQUNNLENBQUMsQ0FBQzJMLFFBQVEsQ0FBQ2hOLENBQUMsRUFBQyxJQUFJLEdBQUNtUSxrQkFBa0IsQ0FBQ2pQLENBQUMsQ0FBQzJPLE9BQU8sR0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDRixFQUFFLENBQUMsQ0FBQztZQUFDMU8sQ0FBQyxDQUFDQyxDQUFDLENBQUMyTyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUNGLEVBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQ1MsU0FBUyxDQUFDeE0sSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLElBQUksQ0FBQ3lNLGFBQWEsQ0FBQ3RQLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ3VQLFNBQVMsR0FBQzlPLFVBQVUsQ0FBQyxZQUFVO2NBQUNaLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBQ0UsQ0FBQyxDQUFDeVAsTUFBTSxDQUFDLElBQUlwUCxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQztZQUFBLENBQUMsRUFBQ04sQ0FBQyxDQUFDMEYsT0FBTyxDQUFDO1VBQUE7VUFBQ3ZHLENBQUMsQ0FBQ2EsQ0FBQyxFQUFDRixDQUFDLENBQUMsRUFBQ0UsQ0FBQyxDQUFDZ0IsU0FBUyxDQUFDaU0sS0FBSyxHQUFDLFlBQVU7WUFBQyxJQUFHbE4sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFDSyxDQUFDLENBQUNDLENBQUMsQ0FBQzJPLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLEVBQUM7Y0FBQyxJQUFJM1AsQ0FBQyxHQUFDLElBQUltQixLQUFLLENBQUMseUJBQXlCLENBQUM7Y0FBQ25CLENBQUMsQ0FBQ29CLElBQUksR0FBQyxHQUFHLEVBQUMsSUFBSSxDQUFDbVAsTUFBTSxDQUFDdlEsQ0FBQyxDQUFDO1lBQUE7VUFBQyxDQUFDLEVBQUNhLENBQUMsQ0FBQzBGLE9BQU8sR0FBQyxJQUFJLEVBQUMxRixDQUFDLENBQUMyUCxrQkFBa0IsR0FBQyxHQUFHLEVBQUMzUCxDQUFDLENBQUNnQixTQUFTLENBQUN1TyxTQUFTLEdBQUMsVUFBU3BRLENBQUMsRUFBQztZQUFDWSxDQUFDLENBQUMsV0FBVyxFQUFDWixDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNzRyxRQUFRLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ21LLFFBQVEsS0FBR3pRLENBQUMsS0FBR1ksQ0FBQyxDQUFDLFNBQVMsRUFBQ1osQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDcUMsSUFBSSxDQUFDLFNBQVMsRUFBQ3JDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDcUMsSUFBSSxDQUFDLE9BQU8sRUFBQyxJQUFJLEVBQUMsU0FBUyxDQUFDLEVBQUMsSUFBSSxDQUFDUCxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7VUFBQSxDQUFDLEVBQUNqQixDQUFDLENBQUNnQixTQUFTLENBQUMwTyxNQUFNLEdBQUMsVUFBU3ZRLENBQUMsRUFBQztZQUFDWSxDQUFDLENBQUMsUUFBUSxFQUFDWixDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNzRyxRQUFRLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQ21LLFFBQVEsR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNwTyxJQUFJLENBQUMsT0FBTyxFQUFDckMsQ0FBQyxDQUFDb0IsSUFBSSxFQUFDcEIsQ0FBQyxDQUFDaVEsT0FBTyxDQUFDLEVBQUMsSUFBSSxDQUFDbk8sa0JBQWtCLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQ2pCLENBQUMsQ0FBQ2dCLFNBQVMsQ0FBQ3lFLFFBQVEsR0FBQyxZQUFVO1lBQUMsSUFBRzFGLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQzRGLFlBQVksQ0FBQyxJQUFJLENBQUM4SixTQUFTLENBQUMsRUFBQyxJQUFJLENBQUNJLE9BQU8sS0FBRyxJQUFJLENBQUNBLE9BQU8sQ0FBQ0MsVUFBVSxDQUFDQyxXQUFXLENBQUMsSUFBSSxDQUFDRixPQUFPLENBQUMsRUFBQyxJQUFJLENBQUNBLE9BQU8sR0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLENBQUNHLE1BQU0sRUFBQztjQUFDLElBQUk3USxDQUFDLEdBQUMsSUFBSSxDQUFDNlEsTUFBTTtjQUFDN1EsQ0FBQyxDQUFDMlEsVUFBVSxDQUFDQyxXQUFXLENBQUM1USxDQUFDLENBQUMsRUFBQ0EsQ0FBQyxDQUFDME4sa0JBQWtCLEdBQUMxTixDQUFDLENBQUNnTCxPQUFPLEdBQUNoTCxDQUFDLENBQUM4USxNQUFNLEdBQUM5USxDQUFDLENBQUMrUSxPQUFPLEdBQUMsSUFBSSxFQUFDLElBQUksQ0FBQ0YsTUFBTSxHQUFDLElBQUk7WUFBQTtZQUFDLE9BQU81UCxDQUFDLENBQUNDLENBQUMsQ0FBQzJPLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQ0YsRUFBRSxDQUFDO1VBQUEsQ0FBQyxFQUFDOU8sQ0FBQyxDQUFDZ0IsU0FBUyxDQUFDbVAsWUFBWSxHQUFDLFlBQVU7WUFBQ3BRLENBQUMsQ0FBQyxjQUFjLENBQUM7WUFBQyxJQUFJWixDQUFDLEdBQUMsSUFBSTtZQUFDLElBQUksQ0FBQ2lSLFVBQVUsS0FBRyxJQUFJLENBQUNBLFVBQVUsR0FBQ3pQLFVBQVUsQ0FBQyxZQUFVO2NBQUN4QixDQUFDLENBQUNrUixVQUFVLElBQUVsUixDQUFDLENBQUN1USxNQUFNLENBQUMsSUFBSXBQLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxFQUFDTixDQUFDLENBQUMyUCxrQkFBa0IsQ0FBQyxDQUFDO1VBQUEsQ0FBQyxFQUFDM1AsQ0FBQyxDQUFDZ0IsU0FBUyxDQUFDd08sYUFBYSxHQUFDLFVBQVNyUSxDQUFDLEVBQUM7WUFBQ1ksQ0FBQyxDQUFDLGVBQWUsRUFBQ1osQ0FBQyxDQUFDO1lBQUMsSUFBSWMsQ0FBQztjQUFDQyxDQUFDLEdBQUMsSUFBSTtjQUFDRyxDQUFDLEdBQUMsSUFBSSxDQUFDMlAsTUFBTSxHQUFDNVAsQ0FBQyxDQUFDNEUsUUFBUSxDQUFDc0wsYUFBYSxDQUFDLFFBQVEsQ0FBQztZQUFDLElBQUdqUSxDQUFDLENBQUN5TyxFQUFFLEdBQUMsR0FBRyxHQUFDbFAsQ0FBQyxDQUFDdUgsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDOUcsQ0FBQyxDQUFDa1EsR0FBRyxHQUFDcFIsQ0FBQyxFQUFDa0IsQ0FBQyxDQUFDeUIsSUFBSSxHQUFDLGlCQUFpQixFQUFDekIsQ0FBQyxDQUFDbVEsT0FBTyxHQUFDLE9BQU8sRUFBQ25RLENBQUMsQ0FBQzhKLE9BQU8sR0FBQyxJQUFJLENBQUNnRyxZQUFZLENBQUNwTixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMxQyxDQUFDLENBQUM0UCxNQUFNLEdBQUMsWUFBVTtjQUFDbFEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDRyxDQUFDLENBQUN3UCxNQUFNLENBQUMsSUFBSXBQLEtBQUssQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxFQUFDRCxDQUFDLENBQUN3TSxrQkFBa0IsR0FBQyxZQUFVO2NBQUMsSUFBRzlNLENBQUMsQ0FBQyxvQkFBb0IsRUFBQ00sQ0FBQyxDQUFDa0csVUFBVSxDQUFDLEVBQUMsZUFBZSxDQUFDcUYsSUFBSSxDQUFDdkwsQ0FBQyxDQUFDa0csVUFBVSxDQUFDLEVBQUM7Z0JBQUMsSUFBR2xHLENBQUMsSUFBRUEsQ0FBQyxDQUFDb1EsT0FBTyxJQUFFcFEsQ0FBQyxDQUFDNlAsT0FBTyxFQUFDO2tCQUFDaFEsQ0FBQyxDQUFDbVEsVUFBVSxHQUFDLENBQUMsQ0FBQztrQkFBQyxJQUFHO29CQUFDaFEsQ0FBQyxDQUFDNlAsT0FBTyxDQUFDLENBQUM7a0JBQUEsQ0FBQyxRQUFNL1EsQ0FBQyxFQUFDLENBQUM7Z0JBQUM7Z0JBQUNrQixDQUFDLElBQUVILENBQUMsQ0FBQ3dQLE1BQU0sQ0FBQyxJQUFJcFAsS0FBSyxDQUFDLHFEQUFxRCxDQUFDLENBQUM7Y0FBQTtZQUFDLENBQUMsRUFBQyxLQUFLLENBQUMsS0FBR0QsQ0FBQyxDQUFDcVEsS0FBSyxJQUFFdFEsQ0FBQyxDQUFDNEUsUUFBUSxDQUFDYixXQUFXLEVBQUMsSUFBR3RFLENBQUMsQ0FBQzhRLE9BQU8sQ0FBQyxDQUFDLEVBQUMsQ0FBQzFRLENBQUMsR0FBQyxJQUFJLENBQUM0UCxPQUFPLEdBQUN6UCxDQUFDLENBQUM0RSxRQUFRLENBQUNzTCxhQUFhLENBQUMsUUFBUSxDQUFDLEVBQUVNLElBQUksR0FBQyx1Q0FBdUMsR0FBQ3ZRLENBQUMsQ0FBQ3lPLEVBQUUsR0FBQyxtQ0FBbUMsRUFBQ3pPLENBQUMsQ0FBQ3FRLEtBQUssR0FBQ3pRLENBQUMsQ0FBQ3lRLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJO2NBQUMsSUFBRztnQkFBQ3JRLENBQUMsQ0FBQ29RLE9BQU8sR0FBQ3BRLENBQUMsQ0FBQ3lPLEVBQUUsRUFBQ3pPLENBQUMsQ0FBQ3dRLEtBQUssR0FBQyxTQUFTO2NBQUEsQ0FBQyxRQUFNMVIsQ0FBQyxFQUFDLENBQUM7Y0FBQ2tCLENBQUMsQ0FBQ3FRLEtBQUssR0FBQyxDQUFDLENBQUM7WUFBQTtZQUFDLEtBQUssQ0FBQyxLQUFHclEsQ0FBQyxDQUFDcVEsS0FBSyxLQUFHclEsQ0FBQyxDQUFDcVEsS0FBSyxHQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUMsSUFBSWxRLENBQUMsR0FBQ0osQ0FBQyxDQUFDNEUsUUFBUSxDQUFDOEwsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUN0USxDQUFDLENBQUN1USxZQUFZLENBQUMxUSxDQUFDLEVBQUNHLENBQUMsQ0FBQ3dRLFVBQVUsQ0FBQyxFQUFDL1EsQ0FBQyxJQUFFTyxDQUFDLENBQUN1USxZQUFZLENBQUM5USxDQUFDLEVBQUNPLENBQUMsQ0FBQ3dRLFVBQVUsQ0FBQztVQUFBLENBQUMsRUFBQzlRLENBQUMsQ0FBQ2QsT0FBTyxHQUFDWSxDQUFDO1FBQUEsQ0FBQyxFQUFFUyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMscUJBQXFCLEVBQUMsRUFBRTtNQUFDLG9CQUFvQixFQUFDLEVBQUU7TUFBQyxvQkFBb0IsRUFBQyxFQUFFO01BQUMsaUJBQWlCLEVBQUMsRUFBRTtNQUFDLE9BQU8sRUFBQyxLQUFLLENBQUM7TUFBQyxRQUFRLEVBQUMsQ0FBQztNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQ3FCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzBDLFlBQVk7UUFBQ2pDLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0MsQ0FBQ0EsQ0FBQ1YsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7UUFBQ0wsQ0FBQyxDQUFDVCxDQUFDLENBQUMsRUFBQ3FCLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztRQUFDLElBQUlKLENBQUMsR0FBQyxJQUFJO1FBQUMsSUFBSSxDQUFDNFEsY0FBYyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUNyTSxFQUFFLEdBQUMsSUFBSTNFLENBQUMsQ0FBQyxNQUFNLEVBQUNkLENBQUMsRUFBQyxJQUFJLENBQUMsRUFBQyxJQUFJLENBQUN5RixFQUFFLENBQUN4RCxFQUFFLENBQUMsT0FBTyxFQUFDLElBQUksQ0FBQzhQLGFBQWEsQ0FBQ25PLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQzZCLEVBQUUsQ0FBQ3pELElBQUksQ0FBQyxRQUFRLEVBQUMsVUFBU2hDLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1VBQUNMLENBQUMsQ0FBQyxRQUFRLEVBQUNULENBQUMsRUFBQ2MsQ0FBQyxDQUFDLEVBQUNJLENBQUMsQ0FBQzZRLGFBQWEsQ0FBQy9SLENBQUMsRUFBQ2MsQ0FBQyxDQUFDLEVBQUNJLENBQUMsQ0FBQ3VFLEVBQUUsR0FBQyxJQUFJO1VBQUMsSUFBSTFFLENBQUMsR0FBQyxHQUFHLEtBQUdmLENBQUMsR0FBQyxTQUFTLEdBQUMsV0FBVztVQUFDUyxDQUFDLENBQUMsT0FBTyxFQUFDTSxDQUFDLENBQUMsRUFBQ0csQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLE9BQU8sRUFBQyxJQUFJLEVBQUN0QixDQUFDLENBQUMsRUFBQ0csQ0FBQyxDQUFDb0YsUUFBUSxDQUFDLENBQUM7UUFBQSxDQUFDLENBQUM7TUFBQTtNQUFDcEYsQ0FBQyxDQUFDUixDQUFDLEVBQUNXLENBQUMsQ0FBQyxFQUFDWCxDQUFDLENBQUNtQixTQUFTLENBQUNrUSxhQUFhLEdBQUMsVUFBUy9SLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUMsSUFBR0wsQ0FBQyxDQUFDLGVBQWUsRUFBQ1QsQ0FBQyxDQUFDLEVBQUMsR0FBRyxLQUFHQSxDQUFDLElBQUVjLENBQUMsRUFBQyxLQUFJLElBQUlDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxJQUFJLENBQUMrUSxjQUFjLElBQUUvUSxDQUFDLEdBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBSUcsQ0FBQyxHQUFDSixDQUFDLENBQUN5QyxLQUFLLENBQUMsSUFBSSxDQUFDdU8sY0FBYyxDQUFDO1VBQUMsSUFBRyxDQUFDLENBQUMsTUFBSS9RLENBQUMsR0FBQ0csQ0FBQyxDQUFDbUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUM7VUFBTSxJQUFJaEMsQ0FBQyxHQUFDSCxDQUFDLENBQUNxQyxLQUFLLENBQUMsQ0FBQyxFQUFDeEMsQ0FBQyxDQUFDO1VBQUNNLENBQUMsS0FBR1osQ0FBQyxDQUFDLFNBQVMsRUFBQ1ksQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDZ0IsSUFBSSxDQUFDLFNBQVMsRUFBQ2hCLENBQUMsQ0FBQyxDQUFDO1FBQUE7TUFBQyxDQUFDLEVBQUNYLENBQUMsQ0FBQ21CLFNBQVMsQ0FBQ3lFLFFBQVEsR0FBQyxZQUFVO1FBQUM3RixDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUMsSUFBSSxDQUFDcUIsa0JBQWtCLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQ3BCLENBQUMsQ0FBQ21CLFNBQVMsQ0FBQ2lNLEtBQUssR0FBQyxZQUFVO1FBQUNyTixDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUMsSUFBSSxDQUFDZ0YsRUFBRSxLQUFHLElBQUksQ0FBQ0EsRUFBRSxDQUFDckIsS0FBSyxDQUFDLENBQUMsRUFBQzNELENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLENBQUM0QixJQUFJLENBQUMsT0FBTyxFQUFDLElBQUksRUFBQyxNQUFNLENBQUMsRUFBQyxJQUFJLENBQUNvRCxFQUFFLEdBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDYSxRQUFRLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQ3hGLENBQUMsQ0FBQ2IsT0FBTyxHQUFDUyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsT0FBTyxFQUFDLEtBQUssQ0FBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU1YsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLENBQUMsVUFBU3NELENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSTNELENBQUM7WUFBQ0MsQ0FBQztZQUFDQyxDQUFDLEdBQUNaLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztZQUFDYSxDQUFDLEdBQUNiLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztZQUFDaUIsQ0FBQyxHQUFDLFNBQUFBLENBQUEsRUFBVSxDQUFDLENBQUM7VUFBQ0gsQ0FBQyxDQUFDYixPQUFPLEdBQUMsVUFBU0QsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztZQUFDRSxDQUFDLENBQUNqQixDQUFDLEVBQUNjLENBQUMsQ0FBQyxFQUFDSixDQUFDLEtBQUdPLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDUCxDQUFDLEdBQUMyRCxDQUFDLENBQUN3QixRQUFRLENBQUNzTCxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQUVhLEtBQUssQ0FBQ0MsT0FBTyxHQUFDLE1BQU0sRUFBQ3ZSLENBQUMsQ0FBQ3NSLEtBQUssQ0FBQ0UsUUFBUSxHQUFDLFVBQVUsRUFBQ3hSLENBQUMsQ0FBQ3lSLE1BQU0sR0FBQyxNQUFNLEVBQUN6UixDQUFDLENBQUMwUixPQUFPLEdBQUMsbUNBQW1DLEVBQUMxUixDQUFDLENBQUMyUixhQUFhLEdBQUMsT0FBTyxFQUFDLENBQUMxUixDQUFDLEdBQUMwRCxDQUFDLENBQUN3QixRQUFRLENBQUNzTCxhQUFhLENBQUMsVUFBVSxDQUFDLEVBQUVtQixJQUFJLEdBQUMsR0FBRyxFQUFDNVIsQ0FBQyxDQUFDNlIsV0FBVyxDQUFDNVIsQ0FBQyxDQUFDLEVBQUMwRCxDQUFDLENBQUN3QixRQUFRLENBQUNDLElBQUksQ0FBQ3lNLFdBQVcsQ0FBQzdSLENBQUMsQ0FBQyxDQUFDO1lBQUMsSUFBSVEsQ0FBQyxHQUFDLEdBQUcsR0FBQ04sQ0FBQyxDQUFDb0gsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUFDdEgsQ0FBQyxDQUFDOFIsTUFBTSxHQUFDdFIsQ0FBQyxFQUFDUixDQUFDLENBQUMrUixNQUFNLEdBQUM1UixDQUFDLENBQUNtTSxRQUFRLENBQUNuTSxDQUFDLENBQUN1RixPQUFPLENBQUNwRyxDQUFDLEVBQUMsYUFBYSxDQUFDLEVBQUMsSUFBSSxHQUFDa0IsQ0FBQyxDQUFDO1lBQUMsSUFBSUcsQ0FBQyxHQUFDLFVBQVNQLENBQUMsRUFBQztjQUFDRyxDQUFDLENBQUMsY0FBYyxFQUFDSCxDQUFDLENBQUM7Y0FBQyxJQUFHO2dCQUFDLE9BQU91RCxDQUFDLENBQUN3QixRQUFRLENBQUNzTCxhQUFhLENBQUMsZ0JBQWdCLEdBQUNyUSxDQUFDLEdBQUMsSUFBSSxDQUFDO2NBQUEsQ0FBQyxRQUFNZCxDQUFDLEVBQUM7Z0JBQUMsSUFBSWUsQ0FBQyxHQUFDc0QsQ0FBQyxDQUFDd0IsUUFBUSxDQUFDc0wsYUFBYSxDQUFDLFFBQVEsQ0FBQztnQkFBQyxPQUFPcFEsQ0FBQyxDQUFDdVIsSUFBSSxHQUFDeFIsQ0FBQyxFQUFDQyxDQUFDO2NBQUE7WUFBQyxDQUFDLENBQUNHLENBQUMsQ0FBQztZQUFDRyxDQUFDLENBQUNzTyxFQUFFLEdBQUN6TyxDQUFDLEVBQUNHLENBQUMsQ0FBQzJRLEtBQUssQ0FBQ0MsT0FBTyxHQUFDLE1BQU0sRUFBQ3ZSLENBQUMsQ0FBQzZSLFdBQVcsQ0FBQ2xSLENBQUMsQ0FBQztZQUFDLElBQUc7Y0FBQ1YsQ0FBQyxDQUFDOEssS0FBSyxHQUFDM0ssQ0FBQztZQUFBLENBQUMsUUFBTWQsQ0FBQyxFQUFDLENBQUM7WUFBQ1UsQ0FBQyxDQUFDZ1MsTUFBTSxDQUFDLENBQUM7WUFBQyxTQUFTalMsQ0FBQ0EsQ0FBQ1QsQ0FBQyxFQUFDO2NBQUNpQixDQUFDLENBQUMsV0FBVyxFQUFDQyxDQUFDLEVBQUNsQixDQUFDLENBQUMsRUFBQ3FCLENBQUMsQ0FBQzJKLE9BQU8sS0FBRzNKLENBQUMsQ0FBQ3FNLGtCQUFrQixHQUFDck0sQ0FBQyxDQUFDMkosT0FBTyxHQUFDM0osQ0FBQyxDQUFDeVAsTUFBTSxHQUFDLElBQUksRUFBQ3RQLFVBQVUsQ0FBQyxZQUFVO2dCQUFDUCxDQUFDLENBQUMsYUFBYSxFQUFDQyxDQUFDLENBQUMsRUFBQ0csQ0FBQyxDQUFDc1AsVUFBVSxDQUFDQyxXQUFXLENBQUN2UCxDQUFDLENBQUMsRUFBQ0EsQ0FBQyxHQUFDLElBQUk7Y0FBQSxDQUFDLEVBQUMsR0FBRyxDQUFDLEVBQUNWLENBQUMsQ0FBQzhLLEtBQUssR0FBQyxFQUFFLEVBQUMxSyxDQUFDLENBQUNmLENBQUMsQ0FBQyxDQUFDO1lBQUE7WUFBQyxPQUFPcUIsQ0FBQyxDQUFDMkosT0FBTyxHQUFDLFlBQVU7Y0FBQy9KLENBQUMsQ0FBQyxTQUFTLEVBQUNDLENBQUMsQ0FBQyxFQUFDVCxDQUFDLENBQUMsQ0FBQztZQUFBLENBQUMsRUFBQ1ksQ0FBQyxDQUFDeVAsTUFBTSxHQUFDLFlBQVU7Y0FBQzdQLENBQUMsQ0FBQyxRQUFRLEVBQUNDLENBQUMsQ0FBQyxFQUFDVCxDQUFDLENBQUMsQ0FBQztZQUFBLENBQUMsRUFBQ1ksQ0FBQyxDQUFDcU0sa0JBQWtCLEdBQUMsVUFBUzFOLENBQUMsRUFBQztjQUFDaUIsQ0FBQyxDQUFDLG9CQUFvQixFQUFDQyxDQUFDLEVBQUNHLENBQUMsQ0FBQytGLFVBQVUsRUFBQ3BILENBQUMsQ0FBQyxFQUFDLFVBQVUsS0FBR3FCLENBQUMsQ0FBQytGLFVBQVUsSUFBRTNHLENBQUMsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxFQUFDLFlBQVU7Y0FBQ1EsQ0FBQyxDQUFDLFNBQVMsRUFBQ0MsQ0FBQyxDQUFDLEVBQUNULENBQUMsQ0FBQyxJQUFJVSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7WUFBQSxDQUFDO1VBQUEsQ0FBQztRQUFBLENBQUMsRUFBRUcsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLG9CQUFvQixFQUFDLEVBQUU7TUFBQyxpQkFBaUIsRUFBQyxFQUFFO01BQUMsT0FBTyxFQUFDLEtBQUs7SUFBQyxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTYSxDQUFDLEVBQUNMLENBQUMsRUFBQ2IsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTWSxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDLElBQUlTLENBQUMsR0FBQ0gsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDd0IsWUFBWTtZQUFDMUMsQ0FBQyxHQUFDa0IsQ0FBQyxDQUFDLFVBQVUsQ0FBQztZQUFDVCxDQUFDLEdBQUNTLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztZQUFDSixDQUFDLEdBQUNJLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztZQUFDUixDQUFDLEdBQUNRLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztZQUFDUCxDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztVQUFDLFNBQVNJLENBQUNBLENBQUNmLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7WUFBQ0osQ0FBQyxDQUFDWCxDQUFDLEVBQUNjLENBQUMsQ0FBQztZQUFDLElBQUlJLENBQUMsR0FBQyxJQUFJO1lBQUNHLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDRSxVQUFVLENBQUMsWUFBVTtjQUFDTixDQUFDLENBQUM0TCxNQUFNLENBQUM5TSxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQztVQUFBO1VBQUNmLENBQUMsQ0FBQ2UsQ0FBQyxFQUFDTSxDQUFDLENBQUMsRUFBQ04sQ0FBQyxDQUFDYyxTQUFTLENBQUNpTCxNQUFNLEdBQUMsVUFBUzlNLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7WUFBQ0osQ0FBQyxDQUFDLFFBQVEsQ0FBQztZQUFDLElBQUlPLENBQUMsR0FBQyxJQUFJO2NBQUNHLENBQUMsR0FBQyxJQUFJVCxDQUFDLENBQUMrUixjQUFjLENBQUQsQ0FBQztZQUFDN1IsQ0FBQyxHQUFDSixDQUFDLENBQUNzTSxRQUFRLENBQUNsTSxDQUFDLEVBQUMsSUFBSSxHQUFFLENBQUMsSUFBSWlDLElBQUksQ0FBRCxDQUFDLENBQUMsRUFBQzFCLENBQUMsQ0FBQzJKLE9BQU8sR0FBQyxZQUFVO2NBQUNySyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUNPLENBQUMsQ0FBQzBSLE1BQU0sQ0FBQyxDQUFDO1lBQUEsQ0FBQyxFQUFDdlIsQ0FBQyxDQUFDK0wsU0FBUyxHQUFDLFlBQVU7Y0FBQ3pNLENBQUMsQ0FBQyxXQUFXLENBQUMsRUFBQ08sQ0FBQyxDQUFDMFIsTUFBTSxDQUFDLENBQUM7WUFBQSxDQUFDLEVBQUN2UixDQUFDLENBQUN3UixVQUFVLEdBQUMsWUFBVTtjQUFDbFMsQ0FBQyxDQUFDLFVBQVUsRUFBQ1UsQ0FBQyxDQUFDdU0sWUFBWSxDQUFDLEVBQUMxTSxDQUFDLENBQUNtQixJQUFJLENBQUMsT0FBTyxFQUFDLEdBQUcsRUFBQ2hCLENBQUMsQ0FBQ3VNLFlBQVksQ0FBQztZQUFBLENBQUMsRUFBQ3ZNLENBQUMsQ0FBQ3lQLE1BQU0sR0FBQyxZQUFVO2NBQUNuUSxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUNPLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxRQUFRLEVBQUMsR0FBRyxFQUFDaEIsQ0FBQyxDQUFDdU0sWUFBWSxDQUFDLEVBQUMxTSxDQUFDLENBQUNvRixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQSxDQUFDLEVBQUMsSUFBSSxDQUFDd00sR0FBRyxHQUFDelIsQ0FBQyxFQUFDLElBQUksQ0FBQzRMLFNBQVMsR0FBQ3hNLENBQUMsQ0FBQ3lNLFNBQVMsQ0FBQyxZQUFVO2NBQUNoTSxDQUFDLENBQUNvRixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQSxDQUFDLENBQUM7WUFBQyxJQUFHO2NBQUMsSUFBSSxDQUFDd00sR0FBRyxDQUFDM0YsSUFBSSxDQUFDbk4sQ0FBQyxFQUFDYyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUN5RixPQUFPLEtBQUcsSUFBSSxDQUFDdU0sR0FBRyxDQUFDdk0sT0FBTyxHQUFDLElBQUksQ0FBQ0EsT0FBTyxDQUFDLEVBQUMsSUFBSSxDQUFDdU0sR0FBRyxDQUFDNU8sSUFBSSxDQUFDbkQsQ0FBQyxDQUFDO1lBQUEsQ0FBQyxRQUFNZixDQUFDLEVBQUM7Y0FBQyxJQUFJLENBQUM0UyxNQUFNLENBQUMsQ0FBQztZQUFBO1VBQUMsQ0FBQyxFQUFDN1IsQ0FBQyxDQUFDYyxTQUFTLENBQUMrUSxNQUFNLEdBQUMsWUFBVTtZQUFDLElBQUksQ0FBQ3ZRLElBQUksQ0FBQyxRQUFRLEVBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxFQUFDLElBQUksQ0FBQ2lFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQ3ZGLENBQUMsQ0FBQ2MsU0FBUyxDQUFDeUUsUUFBUSxHQUFDLFVBQVN0RyxDQUFDLEVBQUM7WUFBQyxJQUFHVyxDQUFDLENBQUMsU0FBUyxFQUFDWCxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUM4UyxHQUFHLEVBQUM7Y0FBQyxJQUFHLElBQUksQ0FBQ2hSLGtCQUFrQixDQUFDLENBQUMsRUFBQ3JCLENBQUMsQ0FBQ29OLFNBQVMsQ0FBQyxJQUFJLENBQUNaLFNBQVMsQ0FBQyxFQUFDLElBQUksQ0FBQzZGLEdBQUcsQ0FBQzFGLFNBQVMsR0FBQyxJQUFJLENBQUMwRixHQUFHLENBQUM5SCxPQUFPLEdBQUMsSUFBSSxDQUFDOEgsR0FBRyxDQUFDRCxVQUFVLEdBQUMsSUFBSSxDQUFDQyxHQUFHLENBQUNoQyxNQUFNLEdBQUMsSUFBSSxFQUFDOVEsQ0FBQyxFQUFDLElBQUc7Z0JBQUMsSUFBSSxDQUFDOFMsR0FBRyxDQUFDaEYsS0FBSyxDQUFDLENBQUM7Y0FBQSxDQUFDLFFBQU05TixDQUFDLEVBQUMsQ0FBQztjQUFDLElBQUksQ0FBQ2lOLFNBQVMsR0FBQyxJQUFJLENBQUM2RixHQUFHLEdBQUMsSUFBSTtZQUFBO1VBQUMsQ0FBQyxFQUFDL1IsQ0FBQyxDQUFDYyxTQUFTLENBQUN1QyxLQUFLLEdBQUMsWUFBVTtZQUFDekQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFDLElBQUksQ0FBQzJGLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUFBLENBQUMsRUFBQ3ZGLENBQUMsQ0FBQ2dGLE9BQU8sR0FBQyxFQUFFLENBQUNuRixDQUFDLENBQUMrUixjQUFjLElBQUUsQ0FBQzdSLENBQUMsQ0FBQ29JLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBQ3JJLENBQUMsQ0FBQ1osT0FBTyxHQUFDYyxDQUFDO1FBQUEsQ0FBQyxFQUFFTyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMscUJBQXFCLEVBQUMsRUFBRTtNQUFDLG1CQUFtQixFQUFDLEVBQUU7TUFBQyxpQkFBaUIsRUFBQyxFQUFFO01BQUMsT0FBTyxFQUFDLEtBQUssQ0FBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0wsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSUcsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDcUIsQ0FBQyxHQUFDckIsQ0FBQyxDQUFDLGVBQWUsQ0FBQztNQUFDLFNBQVNTLENBQUNBLENBQUNULENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUNHLENBQUMsRUFBQztRQUFDRyxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUN0QixDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDRyxDQUFDLENBQUM7TUFBQTtNQUFDQSxDQUFDLENBQUNULENBQUMsRUFBQ1ksQ0FBQyxDQUFDLEVBQUNaLENBQUMsQ0FBQ3NGLE9BQU8sR0FBQzFFLENBQUMsQ0FBQzBFLE9BQU8sSUFBRTFFLENBQUMsQ0FBQ2lNLFlBQVksRUFBQ3hNLENBQUMsQ0FBQ2IsT0FBTyxHQUFDUSxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsZUFBZSxFQUFDLEVBQUU7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTVCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJRyxDQUFDLEdBQUNsQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMwQyxZQUFZO01BQUMsU0FBU3JCLENBQUNBLENBQUEsRUFBRTtRQUFDLElBQUlyQixDQUFDLEdBQUMsSUFBSTtRQUFDa0IsQ0FBQyxDQUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDeVIsRUFBRSxHQUFDdlIsVUFBVSxDQUFDLFlBQVU7VUFBQ3hCLENBQUMsQ0FBQ3FDLElBQUksQ0FBQyxRQUFRLEVBQUMsR0FBRyxFQUFDLElBQUksQ0FBQztRQUFBLENBQUMsRUFBQ2hCLENBQUMsQ0FBQ2tGLE9BQU8sQ0FBQztNQUFBO01BQUN2RyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUNxQixDQUFDLEVBQUNILENBQUMsQ0FBQyxFQUFDRyxDQUFDLENBQUNRLFNBQVMsQ0FBQ3VDLEtBQUssR0FBQyxZQUFVO1FBQUNvQyxZQUFZLENBQUMsSUFBSSxDQUFDdU0sRUFBRSxDQUFDO01BQUEsQ0FBQyxFQUFDMVIsQ0FBQyxDQUFDa0YsT0FBTyxHQUFDLEdBQUcsRUFBQ3pGLENBQUMsQ0FBQ2IsT0FBTyxHQUFDb0IsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLFFBQVEsRUFBQyxDQUFDO01BQUMsVUFBVSxFQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU3JCLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQ3FCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyxlQUFlLENBQUM7TUFBQyxTQUFTUyxDQUFDQSxDQUFDVCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO1FBQUNNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7VUFBQ3NNLGFBQWEsRUFBQyxDQUFDO1FBQUMsQ0FBQyxDQUFDO01BQUE7TUFBQ25NLENBQUMsQ0FBQ1QsQ0FBQyxFQUFDWSxDQUFDLENBQUMsRUFBQ1osQ0FBQyxDQUFDc0YsT0FBTyxHQUFDMUUsQ0FBQyxDQUFDMEUsT0FBTyxFQUFDakYsQ0FBQyxDQUFDYixPQUFPLEdBQUNRLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxlQUFlLEVBQUMsRUFBRTtNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNULENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlOLENBQUMsR0FBQ1QsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO1FBQUNVLENBQUMsR0FBQ1YsQ0FBQyxDQUFDLGNBQWMsQ0FBQztRQUFDa0IsQ0FBQyxHQUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUFDVyxDQUFDLEdBQUNYLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzBDLFlBQVk7UUFBQzlCLENBQUMsR0FBQ1osQ0FBQyxDQUFDLG9CQUFvQixDQUFDO1FBQUNhLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUMsU0FBU0ksQ0FBQ0EsQ0FBQ2pCLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7UUFBQyxJQUFHLENBQUNFLENBQUMsQ0FBQzhFLE9BQU8sQ0FBQyxDQUFDLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1FBQUNSLENBQUMsQ0FBQ1csSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDVCxDQUFDLENBQUMsYUFBYSxFQUFDYixDQUFDLENBQUM7UUFBQyxJQUFJa0IsQ0FBQyxHQUFDLElBQUk7VUFBQ0csQ0FBQyxHQUFDWCxDQUFDLENBQUMwRixPQUFPLENBQUNwRyxDQUFDLEVBQUMsWUFBWSxDQUFDO1FBQUNxQixDQUFDLEdBQUMsT0FBTyxLQUFHQSxDQUFDLENBQUNrQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFDLEtBQUssR0FBQ2xDLENBQUMsQ0FBQ2tDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLEdBQUNsQyxDQUFDLENBQUNrQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDd0YsR0FBRyxHQUFDMUgsQ0FBQyxFQUFDLElBQUksQ0FBQzJSLEVBQUUsR0FBQyxJQUFJcFMsQ0FBQyxDQUFDLElBQUksQ0FBQ21JLEdBQUcsRUFBQyxFQUFFLEVBQUNoSSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUNpUyxFQUFFLENBQUNsSSxTQUFTLEdBQUMsVUFBUzlLLENBQUMsRUFBQztVQUFDYSxDQUFDLENBQUMsZUFBZSxFQUFDYixDQUFDLENBQUN5RCxJQUFJLENBQUMsRUFBQ3ZDLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxTQUFTLEVBQUNyQyxDQUFDLENBQUN5RCxJQUFJLENBQUM7UUFBQSxDQUFDLEVBQUMsSUFBSSxDQUFDd0osU0FBUyxHQUFDeE0sQ0FBQyxDQUFDeU0sU0FBUyxDQUFDLFlBQVU7VUFBQ3JNLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQ0ssQ0FBQyxDQUFDOFIsRUFBRSxDQUFDNU8sS0FBSyxDQUFDLENBQUM7UUFBQSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUM0TyxFQUFFLENBQUNqSSxPQUFPLEdBQUMsVUFBUy9LLENBQUMsRUFBQztVQUFDYSxDQUFDLENBQUMsYUFBYSxFQUFDYixDQUFDLENBQUNvQixJQUFJLEVBQUNwQixDQUFDLENBQUM0QixNQUFNLENBQUMsRUFBQ1YsQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLE9BQU8sRUFBQ3JDLENBQUMsQ0FBQ29CLElBQUksRUFBQ3BCLENBQUMsQ0FBQzRCLE1BQU0sQ0FBQyxFQUFDVixDQUFDLENBQUNvRixRQUFRLENBQUMsQ0FBQztRQUFBLENBQUMsRUFBQyxJQUFJLENBQUMwTSxFQUFFLENBQUNoSSxPQUFPLEdBQUMsVUFBU2hMLENBQUMsRUFBQztVQUFDYSxDQUFDLENBQUMsYUFBYSxFQUFDYixDQUFDLENBQUMsRUFBQ2tCLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxPQUFPLEVBQUMsSUFBSSxFQUFDLDZCQUE2QixDQUFDLEVBQUNuQixDQUFDLENBQUNvRixRQUFRLENBQUMsQ0FBQztRQUFBLENBQUM7TUFBQTtNQUFDcEYsQ0FBQyxDQUFDRCxDQUFDLEVBQUNOLENBQUMsQ0FBQyxFQUFDTSxDQUFDLENBQUNZLFNBQVMsQ0FBQ3FDLElBQUksR0FBQyxVQUFTbEUsQ0FBQyxFQUFDO1FBQUMsSUFBSWMsQ0FBQyxHQUFDLEdBQUcsR0FBQ2QsQ0FBQyxHQUFDLEdBQUc7UUFBQ2EsQ0FBQyxDQUFDLE1BQU0sRUFBQ0MsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDa1MsRUFBRSxDQUFDOU8sSUFBSSxDQUFDcEQsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDRyxDQUFDLENBQUNZLFNBQVMsQ0FBQ3VDLEtBQUssR0FBQyxZQUFVO1FBQUN2RCxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQUMsSUFBSWIsQ0FBQyxHQUFDLElBQUksQ0FBQ2dULEVBQUU7UUFBQyxJQUFJLENBQUMxTSxRQUFRLENBQUMsQ0FBQyxFQUFDdEcsQ0FBQyxJQUFFQSxDQUFDLENBQUNvRSxLQUFLLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQ25ELENBQUMsQ0FBQ1ksU0FBUyxDQUFDeUUsUUFBUSxHQUFDLFlBQVU7UUFBQ3pGLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQyxJQUFJYixDQUFDLEdBQUMsSUFBSSxDQUFDZ1QsRUFBRTtRQUFDaFQsQ0FBQyxLQUFHQSxDQUFDLENBQUM4SyxTQUFTLEdBQUM5SyxDQUFDLENBQUMrSyxPQUFPLEdBQUMvSyxDQUFDLENBQUNnTCxPQUFPLEdBQUMsSUFBSSxDQUFDLEVBQUN2SyxDQUFDLENBQUNvTixTQUFTLENBQUMsSUFBSSxDQUFDWixTQUFTLENBQUMsRUFBQyxJQUFJLENBQUNBLFNBQVMsR0FBQyxJQUFJLENBQUMrRixFQUFFLEdBQUMsSUFBSSxFQUFDLElBQUksQ0FBQ2xSLGtCQUFrQixDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUNiLENBQUMsQ0FBQzhFLE9BQU8sR0FBQyxZQUFVO1FBQUMsT0FBT2xGLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBQyxDQUFDLENBQUNELENBQUM7TUFBQSxDQUFDLEVBQUNLLENBQUMsQ0FBQzJELGFBQWEsR0FBQyxXQUFXLEVBQUMzRCxDQUFDLENBQUN3SixVQUFVLEdBQUMsQ0FBQyxFQUFDM0osQ0FBQyxDQUFDYixPQUFPLEdBQUNnQixDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsZ0JBQWdCLEVBQUMsRUFBRTtNQUFDLGNBQWMsRUFBQyxFQUFFO01BQUMsb0JBQW9CLEVBQUMsRUFBRTtNQUFDLE9BQU8sRUFBQyxLQUFLLENBQUM7TUFBQyxRQUFRLEVBQUMsQ0FBQztNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNqQixDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJRyxDQUFDLEdBQUNsQixDQUFDLENBQUMsVUFBVSxDQUFDO1FBQUNxQixDQUFDLEdBQUNyQixDQUFDLENBQUMsa0JBQWtCLENBQUM7UUFBQ1MsQ0FBQyxHQUFDVCxDQUFDLENBQUMsaUJBQWlCLENBQUM7UUFBQ1UsQ0FBQyxHQUFDVixDQUFDLENBQUMsZ0JBQWdCLENBQUM7UUFBQ1csQ0FBQyxHQUFDWCxDQUFDLENBQUMsY0FBYyxDQUFDO01BQUMsU0FBU1ksQ0FBQ0EsQ0FBQ1osQ0FBQyxFQUFDO1FBQUMsSUFBRyxDQUFDVyxDQUFDLENBQUNvRixPQUFPLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1FBQUNFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQyxNQUFNLEVBQUNVLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO01BQUE7TUFBQ08sQ0FBQyxDQUFDTixDQUFDLEVBQUNTLENBQUMsQ0FBQyxFQUFDVCxDQUFDLENBQUNtRixPQUFPLEdBQUN0RixDQUFDLENBQUNzRixPQUFPLEVBQUNuRixDQUFDLENBQUNnRSxhQUFhLEdBQUMsYUFBYSxFQUFDaEUsQ0FBQyxDQUFDNkosVUFBVSxHQUFDLENBQUMsRUFBQzNKLENBQUMsQ0FBQ2IsT0FBTyxHQUFDVyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsa0JBQWtCLEVBQUMsRUFBRTtNQUFDLGdCQUFnQixFQUFDLEVBQUU7TUFBQyxjQUFjLEVBQUMsRUFBRTtNQUFDLGlCQUFpQixFQUFDLEVBQUU7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTWixDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJRyxDQUFDLEdBQUNsQixDQUFDLENBQUMsVUFBVSxDQUFDO1FBQUNxQixDQUFDLEdBQUNyQixDQUFDLENBQUMsa0JBQWtCLENBQUM7UUFBQ1MsQ0FBQyxHQUFDVCxDQUFDLENBQUMsZ0JBQWdCLENBQUM7UUFBQ1UsQ0FBQyxHQUFDVixDQUFDLENBQUMsY0FBYyxDQUFDO01BQUMsU0FBU1csQ0FBQ0EsQ0FBQ1gsQ0FBQyxFQUFDO1FBQUMsSUFBRyxDQUFDVSxDQUFDLENBQUNxRixPQUFPLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1FBQUNFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQyxnQkFBZ0IsRUFBQ1MsQ0FBQyxFQUFDQyxDQUFDLENBQUM7TUFBQTtNQUFDUSxDQUFDLENBQUNQLENBQUMsRUFBQ1UsQ0FBQyxDQUFDLEVBQUNWLENBQUMsQ0FBQ29GLE9BQU8sR0FBQyxVQUFTL0YsQ0FBQyxFQUFDO1FBQUMsT0FBTSxDQUFDQSxDQUFDLENBQUNpVCxhQUFhLElBQUUsQ0FBQ2pULENBQUMsQ0FBQ2lKLFVBQVUsSUFBR3ZJLENBQUMsQ0FBQ3FGLE9BQU8sSUFBRS9GLENBQUMsQ0FBQ21HLFVBQVc7TUFBQSxDQUFDLEVBQUN4RixDQUFDLENBQUNpRSxhQUFhLEdBQUMsZUFBZSxFQUFDakUsQ0FBQyxDQUFDOEosVUFBVSxHQUFDLENBQUMsRUFBQzNKLENBQUMsQ0FBQ2IsT0FBTyxHQUFDVSxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsa0JBQWtCLEVBQUMsRUFBRTtNQUFDLGdCQUFnQixFQUFDLEVBQUU7TUFBQyxjQUFjLEVBQUMsRUFBRTtNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNYLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFBQ3FCLENBQUMsR0FBQ3JCLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztRQUFDUyxDQUFDLEdBQUNULENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztRQUFDVSxDQUFDLEdBQUNWLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztRQUFDVyxDQUFDLEdBQUNYLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztNQUFDLFNBQVNZLENBQUNBLENBQUNaLENBQUMsRUFBQztRQUFDLElBQUcsQ0FBQ1csQ0FBQyxDQUFDb0YsT0FBTyxJQUFFLENBQUNyRixDQUFDLENBQUNxRixPQUFPLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1FBQUNFLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQyxNQUFNLEVBQUNTLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO01BQUE7TUFBQ1EsQ0FBQyxDQUFDTixDQUFDLEVBQUNTLENBQUMsQ0FBQyxFQUFDVCxDQUFDLENBQUNtRixPQUFPLEdBQUMsVUFBUy9GLENBQUMsRUFBQztRQUFDLE9BQU0sQ0FBQ0EsQ0FBQyxDQUFDaUosVUFBVSxLQUFHLEVBQUUsQ0FBQ3RJLENBQUMsQ0FBQ29GLE9BQU8sSUFBRSxDQUFDL0YsQ0FBQyxDQUFDa0csVUFBVSxDQUFDLElBQUV4RixDQUFDLENBQUNxRixPQUFPLENBQUM7TUFBQSxDQUFDLEVBQUNuRixDQUFDLENBQUNnRSxhQUFhLEdBQUMsYUFBYSxFQUFDaEUsQ0FBQyxDQUFDNkosVUFBVSxHQUFDLENBQUMsRUFBQzNKLENBQUMsQ0FBQ2IsT0FBTyxHQUFDVyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsa0JBQWtCLEVBQUMsRUFBRTtNQUFDLGdCQUFnQixFQUFDLEVBQUU7TUFBQyxtQkFBbUIsRUFBQyxFQUFFO01BQUMsb0JBQW9CLEVBQUMsRUFBRTtNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNBLENBQUMsRUFBQ0MsQ0FBQyxFQUFDYixDQUFDLEVBQUM7TUFBQyxDQUFDLFVBQVNXLENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSVgsQ0FBQyxHQUFDWSxDQUFDLENBQUMsVUFBVSxDQUFDO1lBQUNFLENBQUMsR0FBQ0YsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO1lBQUNHLENBQUMsR0FBQ0gsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO1lBQUNNLENBQUMsR0FBQ04sQ0FBQyxDQUFDLG1CQUFtQixDQUFDO1lBQUNTLENBQUMsR0FBQ1QsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO1lBQUNILENBQUMsR0FBQ0csQ0FBQyxDQUFDLGtCQUFrQixDQUFDO1VBQUMsU0FBU0YsQ0FBQ0EsQ0FBQ1YsQ0FBQyxFQUFDO1lBQUMsSUFBRyxDQUFDcUIsQ0FBQyxDQUFDMEUsT0FBTyxJQUFFLENBQUM3RSxDQUFDLENBQUM2RSxPQUFPLEVBQUMsTUFBTSxJQUFJNUUsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1lBQUNMLENBQUMsQ0FBQ1EsSUFBSSxDQUFDLElBQUksRUFBQ3RCLENBQUMsRUFBQyxnQkFBZ0IsRUFBQ2UsQ0FBQyxFQUFDRyxDQUFDLENBQUM7VUFBQTtVQUFDbEIsQ0FBQyxDQUFDVSxDQUFDLEVBQUNJLENBQUMsQ0FBQyxFQUFDSixDQUFDLENBQUNxRixPQUFPLEdBQUMsVUFBUy9GLENBQUMsRUFBQztZQUFDLE9BQU0sQ0FBQ0EsQ0FBQyxDQUFDaUosVUFBVSxJQUFHLENBQUN4SSxDQUFDLENBQUMrUSxPQUFPLENBQUMsQ0FBQyxJQUFFdFEsQ0FBQyxDQUFDNkUsT0FBUTtVQUFBLENBQUMsRUFBQ3JGLENBQUMsQ0FBQ2tFLGFBQWEsR0FBQyxlQUFlLEVBQUNsRSxDQUFDLENBQUMrSixVQUFVLEdBQUMsQ0FBQyxFQUFDL0osQ0FBQyxDQUFDMkosUUFBUSxHQUFDLENBQUMsQ0FBQzFKLENBQUMsQ0FBQ2tGLFFBQVEsRUFBQ2hGLENBQUMsQ0FBQ1osT0FBTyxHQUFDUyxDQUFDO1FBQUEsQ0FBQyxFQUFFWSxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsa0JBQWtCLEVBQUMsRUFBRTtNQUFDLGtCQUFrQixFQUFDLEVBQUU7TUFBQyxnQkFBZ0IsRUFBQyxFQUFFO01BQUMsbUJBQW1CLEVBQUMsRUFBRTtNQUFDLG9CQUFvQixFQUFDLEVBQUU7TUFBQyxVQUFVLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTTCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTQSxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDQSxDQUFDLENBQUNtUyxNQUFNLElBQUVuUyxDQUFDLENBQUNtUyxNQUFNLENBQUNDLGVBQWUsR0FBQ3JTLENBQUMsQ0FBQ2IsT0FBTyxDQUFDbVQsV0FBVyxHQUFDLFVBQVNwVCxDQUFDLEVBQUM7WUFBQyxJQUFJYyxDQUFDLEdBQUMsSUFBSXVTLFVBQVUsQ0FBQ3JULENBQUMsQ0FBQztZQUFDLE9BQU9lLENBQUMsQ0FBQ21TLE1BQU0sQ0FBQ0MsZUFBZSxDQUFDclMsQ0FBQyxDQUFDLEVBQUNBLENBQUM7VUFBQSxDQUFDLEdBQUNBLENBQUMsQ0FBQ2IsT0FBTyxDQUFDbVQsV0FBVyxHQUFDLFVBQVNwVCxDQUFDLEVBQUM7WUFBQyxLQUFJLElBQUljLENBQUMsR0FBQyxJQUFJd0IsS0FBSyxDQUFDdEMsQ0FBQyxDQUFDLEVBQUNlLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ2YsQ0FBQyxFQUFDZSxDQUFDLEVBQUUsRUFBQ0QsQ0FBQyxDQUFDQyxDQUFDLENBQUMsR0FBQ3dKLElBQUksQ0FBQ3VCLEtBQUssQ0FBQyxHQUFHLEdBQUN2QixJQUFJLENBQUMrSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQUMsT0FBT3hTLENBQUM7VUFBQSxDQUFDO1FBQUEsQ0FBQyxFQUFFUSxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0wsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLENBQUMsVUFBU2YsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxZQUFVO1VBQUMsWUFBWTs7VUFBQ2MsQ0FBQyxDQUFDYixPQUFPLEdBQUM7WUFBQ3VSLE9BQU8sRUFBQyxTQUFBQSxDQUFBLEVBQVU7Y0FBQyxPQUFPeFIsQ0FBQyxDQUFDdVQsU0FBUyxJQUFFLFFBQVEsQ0FBQzlHLElBQUksQ0FBQ3pNLENBQUMsQ0FBQ3VULFNBQVMsQ0FBQ0MsU0FBUyxDQUFDO1lBQUEsQ0FBQztZQUFDQyxXQUFXLEVBQUMsU0FBQUEsQ0FBQSxFQUFVO2NBQUMsT0FBT3pULENBQUMsQ0FBQ3VULFNBQVMsSUFBRSxZQUFZLENBQUM5RyxJQUFJLENBQUN6TSxDQUFDLENBQUN1VCxTQUFTLENBQUNDLFNBQVMsQ0FBQztZQUFBLENBQUM7WUFBQ3RLLFNBQVMsRUFBQyxTQUFBQSxDQUFBLEVBQVU7Y0FBQyxJQUFHLENBQUNsSixDQUFDLENBQUM2RixRQUFRLEVBQUMsT0FBTSxDQUFDLENBQUM7Y0FBQyxJQUFHO2dCQUFDLE9BQU0sQ0FBQyxDQUFDN0YsQ0FBQyxDQUFDNkYsUUFBUSxDQUFDNk4sTUFBTTtjQUFBLENBQUMsUUFBTTFULENBQUMsRUFBQztnQkFBQyxPQUFNLENBQUMsQ0FBQztjQUFBO1lBQUM7VUFBQyxDQUFDO1FBQUEsQ0FBQyxFQUFFc0IsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUM7UUFBQ0csQ0FBQyxHQUFDLHkvQkFBeS9CO01BQUNQLENBQUMsQ0FBQ2IsT0FBTyxHQUFDO1FBQUN5SixLQUFLLEVBQUMsU0FBQUEsQ0FBUzFKLENBQUMsRUFBQztVQUFDLElBQUljLENBQUMsR0FBQ2lELElBQUksQ0FBQ0MsU0FBUyxDQUFDaEUsQ0FBQyxDQUFDO1VBQUMsT0FBT3FCLENBQUMsQ0FBQ21MLFNBQVMsR0FBQyxDQUFDLEVBQUNuTCxDQUFDLENBQUNvTCxJQUFJLENBQUMzTCxDQUFDLENBQUMsSUFBRUksQ0FBQyxHQUFDQSxDQUFDLElBQUUsVUFBU2xCLENBQUMsRUFBQztZQUFDLElBQUljLENBQUM7Y0FBQ0MsQ0FBQyxHQUFDLENBQUMsQ0FBQztjQUFDRyxDQUFDLEdBQUMsRUFBRTtZQUFDLEtBQUlKLENBQUMsR0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQyxLQUFLLEVBQUNBLENBQUMsRUFBRSxFQUFDSSxDQUFDLENBQUN5SyxJQUFJLENBQUNQLE1BQU0sQ0FBQ3VJLFlBQVksQ0FBQzdTLENBQUMsQ0FBQyxDQUFDO1lBQUMsT0FBT2QsQ0FBQyxDQUFDd00sU0FBUyxHQUFDLENBQUMsRUFBQ3RMLENBQUMsQ0FBQzBLLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzlDLE9BQU8sQ0FBQzlJLENBQUMsRUFBQyxVQUFTQSxDQUFDLEVBQUM7Y0FBQyxPQUFPZSxDQUFDLENBQUNmLENBQUMsQ0FBQyxHQUFDLEtBQUssR0FBQyxDQUFDLE1BQU0sR0FBQ0EsQ0FBQyxDQUFDNFQsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDM0ksUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFFMUgsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRTtZQUFBLENBQUMsQ0FBQyxFQUFDdkQsQ0FBQyxDQUFDd00sU0FBUyxHQUFDLENBQUMsRUFBQ3pMLENBQUM7VUFBQSxDQUFDLENBQUNNLENBQUMsQ0FBQyxFQUFDUCxDQUFDLENBQUNnSSxPQUFPLENBQUN6SCxDQUFDLEVBQUMsVUFBU3JCLENBQUMsRUFBQztZQUFDLE9BQU9rQixDQUFDLENBQUNsQixDQUFDLENBQUM7VUFBQSxDQUFDLENBQUMsSUFBRWMsQ0FBQztRQUFBO01BQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNkLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSUssQ0FBQyxHQUFDZixDQUFDLENBQUMsVUFBVSxDQUFDO1lBQUNrQixDQUFDLEdBQUMsQ0FBQyxDQUFDO1lBQUNHLENBQUMsR0FBQyxDQUFDLENBQUM7WUFBQ1osQ0FBQyxHQUFDQyxDQUFDLENBQUNtVCxNQUFNLElBQUVuVCxDQUFDLENBQUNtVCxNQUFNLENBQUNDLEdBQUcsSUFBRXBULENBQUMsQ0FBQ21ULE1BQU0sQ0FBQ0MsR0FBRyxDQUFDQyxPQUFPO1VBQUNqVCxDQUFDLENBQUNiLE9BQU8sR0FBQztZQUFDK0UsV0FBVyxFQUFDLFNBQUFBLENBQVNoRixDQUFDLEVBQUNjLENBQUMsRUFBQztjQUFDLEtBQUssQ0FBQyxLQUFHSixDQUFDLENBQUM4QixnQkFBZ0IsR0FBQzlCLENBQUMsQ0FBQzhCLGdCQUFnQixDQUFDeEMsQ0FBQyxFQUFDYyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ0osQ0FBQyxDQUFDbUYsUUFBUSxJQUFFbkYsQ0FBQyxDQUFDc0UsV0FBVyxLQUFHdEUsQ0FBQyxDQUFDbUYsUUFBUSxDQUFDYixXQUFXLENBQUMsSUFBSSxHQUFDaEYsQ0FBQyxFQUFDYyxDQUFDLENBQUMsRUFBQ0osQ0FBQyxDQUFDc0UsV0FBVyxDQUFDLElBQUksR0FBQ2hGLENBQUMsRUFBQ2MsQ0FBQyxDQUFDLENBQUM7WUFBQSxDQUFDO1lBQUMwTixXQUFXLEVBQUMsU0FBQUEsQ0FBU3hPLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO2NBQUMsS0FBSyxDQUFDLEtBQUdKLENBQUMsQ0FBQzhCLGdCQUFnQixHQUFDOUIsQ0FBQyxDQUFDK0IsbUJBQW1CLENBQUN6QyxDQUFDLEVBQUNjLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDSixDQUFDLENBQUNtRixRQUFRLElBQUVuRixDQUFDLENBQUM4TixXQUFXLEtBQUc5TixDQUFDLENBQUNtRixRQUFRLENBQUMySSxXQUFXLENBQUMsSUFBSSxHQUFDeE8sQ0FBQyxFQUFDYyxDQUFDLENBQUMsRUFBQ0osQ0FBQyxDQUFDOE4sV0FBVyxDQUFDLElBQUksR0FBQ3hPLENBQUMsRUFBQ2MsQ0FBQyxDQUFDLENBQUM7WUFBQSxDQUFDO1lBQUNvTSxTQUFTLEVBQUMsU0FBQUEsQ0FBU2xOLENBQUMsRUFBQztjQUFDLElBQUdTLENBQUMsRUFBQyxPQUFPLElBQUk7Y0FBQyxJQUFJSyxDQUFDLEdBQUNDLENBQUMsQ0FBQ2lILE1BQU0sQ0FBQyxDQUFDLENBQUM7Y0FBQyxPQUFPOUcsQ0FBQyxDQUFDSixDQUFDLENBQUMsR0FBQ2QsQ0FBQyxFQUFDcUIsQ0FBQyxJQUFFRyxVQUFVLENBQUMsSUFBSSxDQUFDd1Msc0JBQXNCLEVBQUMsQ0FBQyxDQUFDLEVBQUNsVCxDQUFDO1lBQUEsQ0FBQztZQUFDK00sU0FBUyxFQUFDLFNBQUFBLENBQVM3TixDQUFDLEVBQUM7Y0FBQ0EsQ0FBQyxJQUFJa0IsQ0FBQyxJQUFFLE9BQU9BLENBQUMsQ0FBQ2xCLENBQUMsQ0FBQztZQUFBLENBQUM7WUFBQ2dVLHNCQUFzQixFQUFDLFNBQUFBLENBQUEsRUFBVTtjQUFDLEtBQUksSUFBSWhVLENBQUMsSUFBSWtCLENBQUMsRUFBQ0EsQ0FBQyxDQUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLE9BQU9rQixDQUFDLENBQUNsQixDQUFDLENBQUM7WUFBQTtVQUFDLENBQUM7VUFBQ1MsQ0FBQyxJQUFFSyxDQUFDLENBQUNiLE9BQU8sQ0FBQytFLFdBQVcsQ0FBQyxRQUFRLEVBQUMsWUFBVTtZQUFDM0QsQ0FBQyxLQUFHQSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUNQLENBQUMsQ0FBQ2IsT0FBTyxDQUFDK1Qsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1VBQUEsQ0FBQyxDQUFDO1FBQUEsQ0FBQyxFQUFFMVMsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLFVBQVUsRUFBQztJQUFFLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNTLENBQUMsRUFBQzBELENBQUMsRUFBQ3hFLENBQUMsRUFBQztNQUFDLENBQUMsVUFBU3VFLENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSUYsQ0FBQyxHQUFDdkQsQ0FBQyxDQUFDLFNBQVMsQ0FBQztZQUFDZCxDQUFDLEdBQUNjLENBQUMsQ0FBQyxXQUFXLENBQUM7WUFBQ3dELENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO1VBQUNFLENBQUMsQ0FBQ3ZFLE9BQU8sR0FBQztZQUFDNFAsT0FBTyxFQUFDLEtBQUs7WUFBQy9LLGVBQWUsRUFBQyxJQUFJO1lBQUM0SyxzQkFBc0IsRUFBQyxTQUFBQSxDQUFBLEVBQVU7Y0FBQ2xMLENBQUMsQ0FBQ3ZFLE9BQU8sQ0FBQzRQLE9BQU8sSUFBSXRMLENBQUMsS0FBR0EsQ0FBQyxDQUFDQyxDQUFDLENBQUN2RSxPQUFPLENBQUM0UCxPQUFPLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQztZQUFBLENBQUM7WUFBQy9MLFdBQVcsRUFBQyxTQUFBQSxDQUFTOUQsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7Y0FBQ3lELENBQUMsQ0FBQ1csTUFBTSxLQUFHWCxDQUFDLEdBQUNBLENBQUMsQ0FBQ1csTUFBTSxDQUFDcEIsV0FBVyxDQUFDQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztnQkFBQ3FCLFFBQVEsRUFBQ2IsQ0FBQyxDQUFDdkUsT0FBTyxDQUFDNkUsZUFBZTtnQkFBQ25DLElBQUksRUFBQzNDLENBQUM7Z0JBQUN5RCxJQUFJLEVBQUMzQyxDQUFDLElBQUU7Y0FBRSxDQUFDLENBQUMsRUFBQyxHQUFHLENBQUMsR0FBQ3dELENBQUMsQ0FBQyx1Q0FBdUMsRUFBQ3RFLENBQUMsRUFBQ2MsQ0FBQyxDQUFDO1lBQUEsQ0FBQztZQUFDdU4sWUFBWSxFQUFDLFNBQUFBLENBQVNyTyxDQUFDLEVBQUNjLENBQUMsRUFBQztjQUFDLFNBQVNDLENBQUNBLENBQUEsRUFBRTtnQkFBQ3VELENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQ2tDLFlBQVksQ0FBQy9GLENBQUMsQ0FBQztnQkFBQyxJQUFHO2tCQUFDRSxDQUFDLENBQUNtUSxNQUFNLEdBQUMsSUFBSTtnQkFBQSxDQUFDLFFBQU05USxDQUFDLEVBQUMsQ0FBQztnQkFBQ1csQ0FBQyxDQUFDcUssT0FBTyxHQUFDLElBQUk7Y0FBQTtjQUFDLFNBQVM5SixDQUFDQSxDQUFBLEVBQUU7Z0JBQUNvRCxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUMzRCxDQUFDLEtBQUdJLENBQUMsQ0FBQyxDQUFDLEVBQUNTLFVBQVUsQ0FBQyxZQUFVO2tCQUFDYixDQUFDLElBQUVBLENBQUMsQ0FBQ2dRLFVBQVUsQ0FBQ0MsV0FBVyxDQUFDalEsQ0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQyxJQUFJO2dCQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQzBELENBQUMsQ0FBQ3dKLFNBQVMsQ0FBQ25OLENBQUMsQ0FBQyxDQUFDO2NBQUE7Y0FBQyxTQUFTVyxDQUFDQSxDQUFDckIsQ0FBQyxFQUFDO2dCQUFDc0UsQ0FBQyxDQUFDLFNBQVMsRUFBQ3RFLENBQUMsQ0FBQyxFQUFDVyxDQUFDLEtBQUdPLENBQUMsQ0FBQyxDQUFDLEVBQUNKLENBQUMsQ0FBQ2QsQ0FBQyxDQUFDLENBQUM7Y0FBQTtjQUFDLElBQUlTLENBQUM7Z0JBQUNDLENBQUM7Z0JBQUNDLENBQUMsR0FBQzRELENBQUMsQ0FBQ3NCLFFBQVEsQ0FBQ3NMLGFBQWEsQ0FBQyxRQUFRLENBQUM7Y0FBQyxPQUFPeFEsQ0FBQyxDQUFDeVEsR0FBRyxHQUFDcFIsQ0FBQyxFQUFDVyxDQUFDLENBQUNxUixLQUFLLENBQUNDLE9BQU8sR0FBQyxNQUFNLEVBQUN0UixDQUFDLENBQUNxUixLQUFLLENBQUNFLFFBQVEsR0FBQyxVQUFVLEVBQUN2UixDQUFDLENBQUNxSyxPQUFPLEdBQUMsWUFBVTtnQkFBQzNKLENBQUMsQ0FBQyxTQUFTLENBQUM7Y0FBQSxDQUFDLEVBQUNWLENBQUMsQ0FBQ21RLE1BQU0sR0FBQyxZQUFVO2dCQUFDeE0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDa0MsWUFBWSxDQUFDL0YsQ0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ2UsVUFBVSxDQUFDLFlBQVU7a0JBQUNILENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFBQSxDQUFDLEVBQUMsR0FBRyxDQUFDO2NBQUEsQ0FBQyxFQUFDa0QsQ0FBQyxDQUFDc0IsUUFBUSxDQUFDQyxJQUFJLENBQUN5TSxXQUFXLENBQUM1UixDQUFDLENBQUMsRUFBQ0YsQ0FBQyxHQUFDZSxVQUFVLENBQUMsWUFBVTtnQkFBQ0gsQ0FBQyxDQUFDLFNBQVMsQ0FBQztjQUFBLENBQUMsRUFBQyxJQUFJLENBQUMsRUFBQ1gsQ0FBQyxHQUFDMkQsQ0FBQyxDQUFDNkksU0FBUyxDQUFDaE0sQ0FBQyxDQUFDLEVBQUM7Z0JBQUN5TixJQUFJLEVBQUMsU0FBQUEsQ0FBUzNPLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO2tCQUFDd0QsQ0FBQyxDQUFDLE1BQU0sRUFBQ3RFLENBQUMsRUFBQ2MsQ0FBQyxDQUFDLEVBQUNVLFVBQVUsQ0FBQyxZQUFVO29CQUFDLElBQUc7c0JBQUNiLENBQUMsSUFBRUEsQ0FBQyxDQUFDc1QsYUFBYSxJQUFFdFQsQ0FBQyxDQUFDc1QsYUFBYSxDQUFDblEsV0FBVyxDQUFDOUQsQ0FBQyxFQUFDYyxDQUFDLENBQUM7b0JBQUEsQ0FBQyxRQUFNZCxDQUFDLEVBQUMsQ0FBQztrQkFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO2dCQUFBLENBQUM7Z0JBQUN5TyxPQUFPLEVBQUN2TixDQUFDO2dCQUFDd04sTUFBTSxFQUFDM047Y0FBQyxDQUFDO1lBQUEsQ0FBQztZQUFDZ1AsY0FBYyxFQUFDLFNBQUFBLENBQVMvUCxDQUFDLEVBQUNjLENBQUMsRUFBQztjQUFDLFNBQVNDLENBQUNBLENBQUEsRUFBRTtnQkFBQ3lGLFlBQVksQ0FBQy9GLENBQUMsQ0FBQyxFQUFDRSxDQUFDLENBQUNxSyxPQUFPLEdBQUMsSUFBSTtjQUFBO2NBQUMsU0FBUzlKLENBQUNBLENBQUEsRUFBRTtnQkFBQ0wsQ0FBQyxLQUFHRSxDQUFDLENBQUMsQ0FBQyxFQUFDc0QsQ0FBQyxDQUFDd0osU0FBUyxDQUFDbk4sQ0FBQyxDQUFDLEVBQUNDLENBQUMsQ0FBQ2dRLFVBQVUsQ0FBQ0MsV0FBVyxDQUFDalEsQ0FBQyxDQUFDLEVBQUNBLENBQUMsR0FBQ0UsQ0FBQyxHQUFDLElBQUksRUFBQ3FULGNBQWMsQ0FBQyxDQUFDLENBQUM7Y0FBQTtjQUFDLFNBQVM3UyxDQUFDQSxDQUFDckIsQ0FBQyxFQUFDO2dCQUFDc0UsQ0FBQyxDQUFDLFNBQVMsRUFBQ3RFLENBQUMsQ0FBQyxFQUFDYSxDQUFDLEtBQUdLLENBQUMsQ0FBQyxDQUFDLEVBQUNKLENBQUMsQ0FBQ2QsQ0FBQyxDQUFDLENBQUM7Y0FBQTtjQUFDLElBQUlTLENBQUM7Z0JBQUNDLENBQUM7Z0JBQUNDLENBQUM7Z0JBQUNDLENBQUMsR0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDMEMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDc0ksSUFBSSxDQUFDLEdBQUcsQ0FBQztnQkFBQy9LLENBQUMsR0FBQyxJQUFJMEQsQ0FBQyxDQUFDM0QsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO2NBQUNDLENBQUMsQ0FBQ3NNLElBQUksQ0FBQyxDQUFDLEVBQUN0TSxDQUFDLENBQUNzVCxLQUFLLENBQUMsaUNBQWlDLEdBQUM1UCxDQUFDLENBQUNzQixRQUFRLENBQUM2TixNQUFNLEdBQUMscUJBQXFCLENBQUMsRUFBQzdTLENBQUMsQ0FBQ3VELEtBQUssQ0FBQyxDQUFDLEVBQUN2RCxDQUFDLENBQUN1VCxZQUFZLENBQUM1UCxDQUFDLENBQUN2RSxPQUFPLENBQUM0UCxPQUFPLENBQUMsR0FBQ3RMLENBQUMsQ0FBQ0MsQ0FBQyxDQUFDdkUsT0FBTyxDQUFDNFAsT0FBTyxDQUFDO2NBQUMsSUFBSTVPLENBQUMsR0FBQ0osQ0FBQyxDQUFDc1EsYUFBYSxDQUFDLEtBQUssQ0FBQztjQUFDLE9BQU90USxDQUFDLENBQUNpRixJQUFJLENBQUN5TSxXQUFXLENBQUN0UixDQUFDLENBQUMsRUFBQ04sQ0FBQyxHQUFDRSxDQUFDLENBQUNzUSxhQUFhLENBQUMsUUFBUSxDQUFDLEVBQUNsUSxDQUFDLENBQUNzUixXQUFXLENBQUM1UixDQUFDLENBQUMsRUFBQ0EsQ0FBQyxDQUFDeVEsR0FBRyxHQUFDcFIsQ0FBQyxFQUFDVyxDQUFDLENBQUNxSyxPQUFPLEdBQUMsWUFBVTtnQkFBQzNKLENBQUMsQ0FBQyxTQUFTLENBQUM7Y0FBQSxDQUFDLEVBQUNaLENBQUMsR0FBQ2UsVUFBVSxDQUFDLFlBQVU7Z0JBQUNILENBQUMsQ0FBQyxTQUFTLENBQUM7Y0FBQSxDQUFDLEVBQUMsSUFBSSxDQUFDLEVBQUNYLENBQUMsR0FBQzJELENBQUMsQ0FBQzZJLFNBQVMsQ0FBQ2hNLENBQUMsQ0FBQyxFQUFDO2dCQUFDeU4sSUFBSSxFQUFDLFNBQUFBLENBQVMzTyxDQUFDLEVBQUNjLENBQUMsRUFBQztrQkFBQyxJQUFHO29CQUFDVSxVQUFVLENBQUMsWUFBVTtzQkFBQ2IsQ0FBQyxJQUFFQSxDQUFDLENBQUNzVCxhQUFhLElBQUV0VCxDQUFDLENBQUNzVCxhQUFhLENBQUNuUSxXQUFXLENBQUM5RCxDQUFDLEVBQUNjLENBQUMsQ0FBQztvQkFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDO2tCQUFBLENBQUMsUUFBTWQsQ0FBQyxFQUFDLENBQUM7Z0JBQUMsQ0FBQztnQkFBQ3lPLE9BQU8sRUFBQ3ZOLENBQUM7Z0JBQUN3TixNQUFNLEVBQUMzTjtjQUFDLENBQUM7WUFBQTtVQUFDLENBQUMsRUFBQ3lELENBQUMsQ0FBQ3ZFLE9BQU8sQ0FBQzJPLGFBQWEsR0FBQyxDQUFDLENBQUMsRUFBQ3JLLENBQUMsQ0FBQ3NCLFFBQVEsS0FBR3JCLENBQUMsQ0FBQ3ZFLE9BQU8sQ0FBQzJPLGFBQWEsR0FBQyxDQUFDLFVBQVUsSUFBRSxPQUFPckssQ0FBQyxDQUFDVCxXQUFXLElBQUUsUUFBUSxJQUFFLE9BQU9TLENBQUMsQ0FBQ1QsV0FBVyxLQUFHLENBQUM5RCxDQUFDLENBQUN5VCxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQUEsQ0FBQyxFQUFFblMsSUFBSSxDQUFDLElBQUksQ0FBQztNQUFBLENBQUMsRUFBRUEsSUFBSSxDQUFDLElBQUksRUFBQyxXQUFXLElBQUUsT0FBT2hCLHFCQUFNLEdBQUNBLHFCQUFNLEdBQUMsV0FBVyxJQUFFLE9BQU9DLElBQUksR0FBQ0EsSUFBSSxHQUFDLFdBQVcsSUFBRSxPQUFPRixNQUFNLEdBQUNBLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLFdBQVcsRUFBQyxFQUFFO01BQUMsU0FBUyxFQUFDLEVBQUU7TUFBQyxPQUFPLEVBQUMsS0FBSztJQUFDLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNMLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxDQUFDLFVBQVNHLENBQUMsRUFBQztRQUFDLENBQUMsWUFBVTtVQUFDLFlBQVk7O1VBQUMsSUFBSUgsQ0FBQyxHQUFDLENBQUMsQ0FBQztVQUFDLENBQUMsS0FBSyxFQUFDLE9BQU8sRUFBQyxNQUFNLENBQUMsQ0FBQzJELE9BQU8sQ0FBQyxVQUFTMUUsQ0FBQyxFQUFDO1lBQUMsSUFBSWMsQ0FBQztZQUFDLElBQUc7Y0FBQ0EsQ0FBQyxHQUFDSSxDQUFDLENBQUNtVCxPQUFPLElBQUVuVCxDQUFDLENBQUNtVCxPQUFPLENBQUNyVSxDQUFDLENBQUMsSUFBRWtCLENBQUMsQ0FBQ21ULE9BQU8sQ0FBQ3JVLENBQUMsQ0FBQyxDQUFDbUMsS0FBSztZQUFBLENBQUMsUUFBTW5DLENBQUMsRUFBQyxDQUFDO1lBQUNlLENBQUMsQ0FBQ2YsQ0FBQyxDQUFDLEdBQUNjLENBQUMsR0FBQyxZQUFVO2NBQUMsT0FBT0ksQ0FBQyxDQUFDbVQsT0FBTyxDQUFDclUsQ0FBQyxDQUFDLENBQUNtQyxLQUFLLENBQUNqQixDQUFDLENBQUNtVCxPQUFPLEVBQUNqUyxTQUFTLENBQUM7WUFBQSxDQUFDLEdBQUMsS0FBSyxLQUFHcEMsQ0FBQyxHQUFDLFlBQVUsQ0FBQyxDQUFDLEdBQUNlLENBQUMsQ0FBQ3VULEdBQUc7VUFBQSxDQUFDLENBQUMsRUFBQ3hULENBQUMsQ0FBQ2IsT0FBTyxHQUFDYyxDQUFDO1FBQUEsQ0FBQyxFQUFFTyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0wsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUNELENBQUMsQ0FBQ2IsT0FBTyxHQUFDO1FBQUN5RixRQUFRLEVBQUMsU0FBQUEsQ0FBUzFGLENBQUMsRUFBQztVQUFDLElBQUljLENBQUMsR0FBQyxPQUFPZCxDQUFDO1VBQUMsT0FBTSxVQUFVLElBQUVjLENBQUMsSUFBRSxRQUFRLElBQUVBLENBQUMsSUFBRSxDQUFDLENBQUNkLENBQUM7UUFBQSxDQUFDO1FBQUMrSixNQUFNLEVBQUMsU0FBQUEsQ0FBUy9KLENBQUMsRUFBQztVQUFDLElBQUcsQ0FBQyxJQUFJLENBQUMwRixRQUFRLENBQUMxRixDQUFDLENBQUMsRUFBQyxPQUFPQSxDQUFDO1VBQUMsS0FBSSxJQUFJYyxDQUFDLEVBQUNDLENBQUMsRUFBQ0csQ0FBQyxHQUFDLENBQUMsRUFBQ0csQ0FBQyxHQUFDZSxTQUFTLENBQUNiLE1BQU0sRUFBQ0wsQ0FBQyxHQUFDRyxDQUFDLEVBQUNILENBQUMsRUFBRSxFQUFDLEtBQUlILENBQUMsSUFBSUQsQ0FBQyxHQUFDc0IsU0FBUyxDQUFDbEIsQ0FBQyxDQUFDLEVBQUNnSyxNQUFNLENBQUNySixTQUFTLENBQUM2SixjQUFjLENBQUNwSyxJQUFJLENBQUNSLENBQUMsRUFBQ0MsQ0FBQyxDQUFDLEtBQUdmLENBQUMsQ0FBQ2UsQ0FBQyxDQUFDLEdBQUNELENBQUMsQ0FBQ0MsQ0FBQyxDQUFDLENBQUM7VUFBQyxPQUFPZixDQUFDO1FBQUE7TUFBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU0EsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUMsSUFBSU4sQ0FBQyxHQUFDVCxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQUNVLENBQUMsR0FBQyxrQ0FBa0M7TUFBQ0ksQ0FBQyxDQUFDYixPQUFPLEdBQUM7UUFBQytILE1BQU0sRUFBQyxTQUFBQSxDQUFTaEksQ0FBQyxFQUFDO1VBQUMsS0FBSSxJQUFJYyxDQUFDLEdBQUNKLENBQUMsQ0FBQ2EsTUFBTSxFQUFDUixDQUFDLEdBQUNOLENBQUMsQ0FBQzJTLFdBQVcsQ0FBQ3BULENBQUMsQ0FBQyxFQUFDa0IsQ0FBQyxHQUFDLEVBQUUsRUFBQ0csQ0FBQyxHQUFDLENBQUMsRUFBQ0EsQ0FBQyxHQUFDckIsQ0FBQyxFQUFDcUIsQ0FBQyxFQUFFLEVBQUNILENBQUMsQ0FBQ3lLLElBQUksQ0FBQ2pMLENBQUMsQ0FBQ2lNLE1BQU0sQ0FBQzVMLENBQUMsQ0FBQ00sQ0FBQyxDQUFDLEdBQUNQLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztVQUFDLE9BQU9JLENBQUMsQ0FBQzBLLElBQUksQ0FBQyxFQUFFLENBQUM7UUFBQSxDQUFDO1FBQUMySSxNQUFNLEVBQUMsU0FBQUEsQ0FBU3ZVLENBQUMsRUFBQztVQUFDLE9BQU91SyxJQUFJLENBQUN1QixLQUFLLENBQUN2QixJQUFJLENBQUMrSSxNQUFNLENBQUMsQ0FBQyxHQUFDdFQsQ0FBQyxDQUFDO1FBQUEsQ0FBQztRQUFDbUksWUFBWSxFQUFDLFNBQUFBLENBQVNuSSxDQUFDLEVBQUM7VUFBQyxJQUFJYyxDQUFDLEdBQUMsQ0FBQyxFQUFFLElBQUVkLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRXVCLE1BQU07VUFBQyxPQUFNLENBQUMsSUFBSWUsS0FBSyxDQUFDeEIsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDOEssSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFDLElBQUksQ0FBQzJJLE1BQU0sQ0FBQ3ZVLENBQUMsQ0FBQyxFQUFFdUQsS0FBSyxDQUFDLENBQUN6QyxDQUFDLENBQUM7UUFBQTtNQUFDLENBQUM7SUFBQSxDQUFDLEVBQUM7TUFBQyxRQUFRLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTZCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsWUFBWTs7TUFBQyxJQUFJTSxDQUFDLEdBQUMsU0FBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztNQUFDUCxDQUFDLENBQUNiLE9BQU8sR0FBQyxVQUFTRCxDQUFDLEVBQUM7UUFBQyxPQUFNO1VBQUNnSyxlQUFlLEVBQUMsU0FBQUEsQ0FBU2xKLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO1lBQUMsSUFBSUcsQ0FBQyxHQUFDO2NBQUNnSixJQUFJLEVBQUMsRUFBRTtjQUFDc0ssTUFBTSxFQUFDO1lBQUUsQ0FBQztZQUFDLE9BQU8xVCxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU9BLENBQUMsS0FBR0EsQ0FBQyxHQUFDLENBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUNBLENBQUMsR0FBQyxFQUFFLEVBQUNkLENBQUMsQ0FBQzBFLE9BQU8sQ0FBQyxVQUFTMUUsQ0FBQyxFQUFDO2NBQUNBLENBQUMsS0FBRyxXQUFXLEtBQUdBLENBQUMsQ0FBQzRFLGFBQWEsSUFBRSxDQUFDLENBQUMsS0FBRzdELENBQUMsQ0FBQzBULFNBQVMsR0FBQzNULENBQUMsQ0FBQ1MsTUFBTSxJQUFFLENBQUMsQ0FBQyxLQUFHVCxDQUFDLENBQUN1QyxPQUFPLENBQUNyRCxDQUFDLENBQUM0RSxhQUFhLENBQUMsR0FBQ3ZELENBQUMsQ0FBQyxrQkFBa0IsRUFBQ3JCLENBQUMsQ0FBQzRFLGFBQWEsQ0FBQyxHQUFDNUUsQ0FBQyxDQUFDK0YsT0FBTyxDQUFDaEYsQ0FBQyxDQUFDLElBQUVNLENBQUMsQ0FBQyxTQUFTLEVBQUNyQixDQUFDLENBQUM0RSxhQUFhLENBQUMsRUFBQzFELENBQUMsQ0FBQ2dKLElBQUksQ0FBQ3lCLElBQUksQ0FBQzNMLENBQUMsQ0FBQyxFQUFDQSxDQUFDLENBQUMyRSxlQUFlLElBQUV6RCxDQUFDLENBQUNzVCxNQUFNLENBQUM3SSxJQUFJLENBQUMzTCxDQUFDLENBQUMyRSxlQUFlLENBQUMsSUFBRXRELENBQUMsQ0FBQyxVQUFVLEVBQUNyQixDQUFDLENBQUM0RSxhQUFhLENBQUMsR0FBQ3ZELENBQUMsQ0FBQyxzQkFBc0IsRUFBQyxXQUFXLENBQUMsQ0FBQztZQUFBLENBQUMsQ0FBQyxFQUFDSCxDQUFDO1VBQUE7UUFBQyxDQUFDO01BQUEsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLE9BQU8sRUFBQyxLQUFLO0lBQUMsQ0FBQyxDQUFDO0lBQUMsRUFBRSxFQUFDLENBQUMsVUFBU2xCLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlHLENBQUMsR0FBQ2xCLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFBQ3FCLENBQUMsR0FBQyxTQUFBQSxDQUFBLEVBQVUsQ0FBQyxDQUFDO01BQUNQLENBQUMsQ0FBQ2IsT0FBTyxHQUFDO1FBQUN3SSxTQUFTLEVBQUMsU0FBQUEsQ0FBU3pJLENBQUMsRUFBQztVQUFDLElBQUcsQ0FBQ0EsQ0FBQyxFQUFDLE9BQU8sSUFBSTtVQUFDLElBQUljLENBQUMsR0FBQyxJQUFJSSxDQUFDLENBQUNsQixDQUFDLENBQUM7VUFBQyxJQUFHLE9BQU8sS0FBR2MsQ0FBQyxDQUFDNEYsUUFBUSxFQUFDLE9BQU8sSUFBSTtVQUFDLElBQUkzRixDQUFDLEdBQUNELENBQUMsQ0FBQzhGLElBQUk7VUFBQyxPQUFPN0YsQ0FBQyxHQUFDQSxDQUFDLEtBQUcsUUFBUSxLQUFHRCxDQUFDLENBQUM0RixRQUFRLEdBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxFQUFDNUYsQ0FBQyxDQUFDNEYsUUFBUSxHQUFDLElBQUksR0FBQzVGLENBQUMsQ0FBQ3dILFFBQVEsR0FBQyxHQUFHLEdBQUN2SCxDQUFDO1FBQUEsQ0FBQztRQUFDd0UsYUFBYSxFQUFDLFNBQUFBLENBQVN2RixDQUFDLEVBQUNjLENBQUMsRUFBQztVQUFDLElBQUlDLENBQUMsR0FBQyxJQUFJLENBQUMwSCxTQUFTLENBQUN6SSxDQUFDLENBQUMsS0FBRyxJQUFJLENBQUN5SSxTQUFTLENBQUMzSCxDQUFDLENBQUM7VUFBQyxPQUFPTyxDQUFDLENBQUMsTUFBTSxFQUFDckIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsQ0FBQyxFQUFDQSxDQUFDO1FBQUEsQ0FBQztRQUFDb0ksYUFBYSxFQUFDLFNBQUFBLENBQVNuSixDQUFDLEVBQUNjLENBQUMsRUFBQztVQUFDLE9BQU9kLENBQUMsQ0FBQzZMLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRy9LLENBQUMsQ0FBQytLLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQSxDQUFDO1FBQUN6RixPQUFPLEVBQUMsU0FBQUEsQ0FBU3BHLENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1VBQUMsSUFBSUMsQ0FBQyxHQUFDZixDQUFDLENBQUM2TCxLQUFLLENBQUMsR0FBRyxDQUFDO1VBQUMsT0FBTzlLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ0QsQ0FBQyxJQUFFQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxHQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDO1FBQUEsQ0FBQztRQUFDaU0sUUFBUSxFQUFDLFNBQUFBLENBQVNoTixDQUFDLEVBQUNjLENBQUMsRUFBQztVQUFDLE9BQU9kLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBR0EsQ0FBQyxDQUFDcUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFDLEdBQUcsR0FBQ3ZDLENBQUMsR0FBQyxHQUFHLEdBQUNBLENBQUMsQ0FBQztRQUFBLENBQUM7UUFBQ3VILGNBQWMsRUFBQyxTQUFBQSxDQUFTckksQ0FBQyxFQUFDO1VBQUMsT0FBTSxrREFBa0QsQ0FBQ3lNLElBQUksQ0FBQ3pNLENBQUMsQ0FBQyxJQUFFLFdBQVcsQ0FBQ3lNLElBQUksQ0FBQ3pNLENBQUMsQ0FBQztRQUFBO01BQUMsQ0FBQztJQUFBLENBQUMsRUFBQztNQUFDLE9BQU8sRUFBQyxLQUFLLENBQUM7TUFBQyxXQUFXLEVBQUM7SUFBRSxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTQSxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUNELENBQUMsQ0FBQ2IsT0FBTyxHQUFDLE9BQU87SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTRCxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO01BQUMsVUFBVSxJQUFFLE9BQU9tSyxNQUFNLENBQUN3SixNQUFNLEdBQUM1VCxDQUFDLENBQUNiLE9BQU8sR0FBQyxVQUFTRCxDQUFDLEVBQUNjLENBQUMsRUFBQztRQUFDQSxDQUFDLEtBQUdkLENBQUMsQ0FBQzJVLE1BQU0sR0FBQzdULENBQUMsRUFBQ2QsQ0FBQyxDQUFDNkIsU0FBUyxHQUFDcUosTUFBTSxDQUFDd0osTUFBTSxDQUFDNVQsQ0FBQyxDQUFDZSxTQUFTLEVBQUM7VUFBQytTLFdBQVcsRUFBQztZQUFDbkosS0FBSyxFQUFDekwsQ0FBQztZQUFDdUwsVUFBVSxFQUFDLENBQUMsQ0FBQztZQUFDQyxRQUFRLEVBQUMsQ0FBQyxDQUFDO1lBQUNGLFlBQVksRUFBQyxDQUFDO1VBQUM7UUFBQyxDQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsR0FBQ3hLLENBQUMsQ0FBQ2IsT0FBTyxHQUFDLFVBQVNELENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUMsSUFBR0EsQ0FBQyxFQUFDO1VBQUNkLENBQUMsQ0FBQzJVLE1BQU0sR0FBQzdULENBQUM7VUFBQyxTQUFTQyxDQUFDQSxDQUFBLEVBQUUsQ0FBQztVQUFDQSxDQUFDLENBQUNjLFNBQVMsR0FBQ2YsQ0FBQyxDQUFDZSxTQUFTLEVBQUM3QixDQUFDLENBQUM2QixTQUFTLEdBQUMsSUFBSWQsQ0FBQyxDQUFELENBQUMsRUFBQ2YsQ0FBQyxDQUFDNkIsU0FBUyxDQUFDK1MsV0FBVyxHQUFDNVUsQ0FBQztRQUFBO01BQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFDLEVBQUUsRUFBQyxDQUFDLFVBQVNBLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7TUFBQyxZQUFZOztNQUFDLElBQUlOLENBQUMsR0FBQ3lLLE1BQU0sQ0FBQ3JKLFNBQVMsQ0FBQzZKLGNBQWM7TUFBQyxTQUFTaEwsQ0FBQ0EsQ0FBQ1YsQ0FBQyxFQUFDO1FBQUMsSUFBRztVQUFDLE9BQU80UCxrQkFBa0IsQ0FBQzVQLENBQUMsQ0FBQzhJLE9BQU8sQ0FBQyxLQUFLLEVBQUMsR0FBRyxDQUFDLENBQUM7UUFBQSxDQUFDLFFBQU05SSxDQUFDLEVBQUM7VUFBQyxPQUFPLElBQUk7UUFBQTtNQUFDO01BQUNlLENBQUMsQ0FBQ2lELFNBQVMsR0FBQyxVQUFTaEUsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7UUFBQ0EsQ0FBQyxHQUFDQSxDQUFDLElBQUUsRUFBRTtRQUFDLElBQUlDLENBQUM7VUFBQ0csQ0FBQztVQUFDRyxDQUFDLEdBQUMsRUFBRTtRQUFDLEtBQUlILENBQUMsSUFBRyxRQUFRLElBQUUsT0FBT0osQ0FBQyxLQUFHQSxDQUFDLEdBQUMsR0FBRyxDQUFDLEVBQUNkLENBQUMsRUFBQyxJQUFHUyxDQUFDLENBQUNhLElBQUksQ0FBQ3RCLENBQUMsRUFBQ2tCLENBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBRyxDQUFDSCxDQUFDLEdBQUNmLENBQUMsQ0FBQ2tCLENBQUMsQ0FBQyxLQUFHLElBQUksSUFBRUgsQ0FBQyxJQUFFLENBQUM4VCxLQUFLLENBQUM5VCxDQUFDLENBQUMsS0FBR0EsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFDRyxDQUFDLEdBQUNpUCxrQkFBa0IsQ0FBQ2pQLENBQUMsQ0FBQyxFQUFDSCxDQUFDLEdBQUNvUCxrQkFBa0IsQ0FBQ3BQLENBQUMsQ0FBQyxFQUFDLElBQUksS0FBR0csQ0FBQyxJQUFFLElBQUksS0FBR0gsQ0FBQyxFQUFDO1VBQVNNLENBQUMsQ0FBQ3NLLElBQUksQ0FBQ3pLLENBQUMsR0FBQyxHQUFHLEdBQUNILENBQUMsQ0FBQztRQUFBO1FBQUMsT0FBT00sQ0FBQyxDQUFDRSxNQUFNLEdBQUNULENBQUMsR0FBQ08sQ0FBQyxDQUFDdUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFDLEVBQUU7TUFBQSxDQUFDLEVBQUM3SyxDQUFDLENBQUNxRSxLQUFLLEdBQUMsVUFBU3BGLENBQUMsRUFBQztRQUFDLEtBQUksSUFBSWMsQ0FBQyxFQUFDQyxDQUFDLEdBQUMscUJBQXFCLEVBQUNHLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQ0osQ0FBQyxHQUFDQyxDQUFDLENBQUNrTCxJQUFJLENBQUNqTSxDQUFDLENBQUMsR0FBRTtVQUFDLElBQUlxQixDQUFDLEdBQUNYLENBQUMsQ0FBQ0ksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUNMLENBQUMsR0FBQ0MsQ0FBQyxDQUFDSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFBQyxJQUFJLEtBQUdPLENBQUMsSUFBRSxJQUFJLEtBQUdaLENBQUMsSUFBRVksQ0FBQyxJQUFJSCxDQUFDLEtBQUdBLENBQUMsQ0FBQ0csQ0FBQyxDQUFDLEdBQUNaLENBQUMsQ0FBQztRQUFBO1FBQUMsT0FBT1MsQ0FBQztNQUFBLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTbEIsQ0FBQyxFQUFDYyxDQUFDLEVBQUNDLENBQUMsRUFBQztNQUFDLFlBQVk7O01BQUNELENBQUMsQ0FBQ2IsT0FBTyxHQUFDLFVBQVNELENBQUMsRUFBQ2MsQ0FBQyxFQUFDO1FBQUMsSUFBR0EsQ0FBQyxHQUFDQSxDQUFDLENBQUMrSyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRTdMLENBQUMsR0FBQyxDQUFDQSxDQUFDLENBQUMsRUFBQyxPQUFNLENBQUMsQ0FBQztRQUFDLFFBQU9jLENBQUM7VUFBRSxLQUFJLE1BQU07VUFBQyxLQUFJLElBQUk7WUFBQyxPQUFPLEVBQUUsS0FBR2QsQ0FBQztVQUFDLEtBQUksT0FBTztVQUFDLEtBQUksS0FBSztZQUFDLE9BQU8sR0FBRyxLQUFHQSxDQUFDO1VBQUMsS0FBSSxLQUFLO1lBQUMsT0FBTyxFQUFFLEtBQUdBLENBQUM7VUFBQyxLQUFJLFFBQVE7WUFBQyxPQUFPLEVBQUUsS0FBR0EsQ0FBQztVQUFDLEtBQUksTUFBTTtZQUFDLE9BQU0sQ0FBQyxDQUFDO1FBQUE7UUFBQyxPQUFPLENBQUMsS0FBR0EsQ0FBQztNQUFBLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxFQUFFLEVBQUMsQ0FBQyxVQUFTQSxDQUFDLEVBQUNlLENBQUMsRUFBQ0QsQ0FBQyxFQUFDO01BQUMsQ0FBQyxVQUFTSCxDQUFDLEVBQUM7UUFBQyxDQUFDLFlBQVU7VUFBQyxZQUFZOztVQUFDLElBQUk0RCxDQUFDLEdBQUN2RSxDQUFDLENBQUMsZUFBZSxDQUFDO1lBQUN3RSxDQUFDLEdBQUN4RSxDQUFDLENBQUMsZ0JBQWdCLENBQUM7WUFBQ2MsQ0FBQyxHQUFDLDRFQUE0RTtZQUFDMkQsQ0FBQyxHQUFDLFdBQVc7WUFBQ2hFLENBQUMsR0FBQywrQkFBK0I7WUFBQ0csQ0FBQyxHQUFDLE9BQU87WUFBQ0MsQ0FBQyxHQUFDLGtEQUFrRDtZQUFDbUcsQ0FBQyxHQUFDLFlBQVk7VUFBQyxTQUFTQyxDQUFDQSxDQUFDakgsQ0FBQyxFQUFDO1lBQUMsT0FBTSxDQUFDQSxDQUFDLElBQUUsRUFBRSxFQUFFaUwsUUFBUSxDQUFDLENBQUMsQ0FBQ25DLE9BQU8sQ0FBQ2hJLENBQUMsRUFBQyxFQUFFLENBQUM7VUFBQTtVQUFDLElBQUlvRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBQyxNQUFNLENBQUMsRUFBQyxDQUFDLEdBQUcsRUFBQyxPQUFPLENBQUMsRUFBQyxVQUFTbEgsQ0FBQyxFQUFDYyxDQUFDLEVBQUM7Y0FBQyxPQUFPaUcsQ0FBQyxDQUFDakcsQ0FBQyxDQUFDNEYsUUFBUSxDQUFDLEdBQUMxRyxDQUFDLENBQUM4SSxPQUFPLENBQUMsS0FBSyxFQUFDLEdBQUcsQ0FBQyxHQUFDOUksQ0FBQztZQUFBLENBQUMsRUFBQyxDQUFDLEdBQUcsRUFBQyxVQUFVLENBQUMsRUFBQyxDQUFDLEdBQUcsRUFBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQzhVLEdBQUcsRUFBQyxNQUFNLEVBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsU0FBUyxFQUFDLE1BQU0sRUFBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDQSxHQUFHLEVBQUMsVUFBVSxFQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztZQUFDcFUsQ0FBQyxHQUFDO2NBQUNxRSxJQUFJLEVBQUMsQ0FBQztjQUFDZ1EsS0FBSyxFQUFDO1lBQUMsQ0FBQztVQUFDLFNBQVN6TCxDQUFDQSxDQUFDdEosQ0FBQyxFQUFDO1lBQUMsSUFBSWMsQ0FBQztjQUFDQyxDQUFDLEdBQUMsQ0FBQyxXQUFXLElBQUUsT0FBT1YsTUFBTSxHQUFDQSxNQUFNLEdBQUMsS0FBSyxDQUFDLEtBQUdNLENBQUMsR0FBQ0EsQ0FBQyxHQUFDLFdBQVcsSUFBRSxPQUFPSixJQUFJLEdBQUNBLElBQUksR0FBQyxDQUFDLENBQUMsRUFBRWtHLFFBQVEsSUFBRSxDQUFDLENBQUM7Y0FBQ3ZGLENBQUMsR0FBQyxDQUFDLENBQUM7Y0FBQ0csQ0FBQyxHQUFDLFFBQU9yQixDQUFDLEdBQUNBLENBQUMsSUFBRWUsQ0FBQyxDQUFDO1lBQUMsSUFBRyxPQUFPLEtBQUdmLENBQUMsQ0FBQzBHLFFBQVEsRUFBQ3hGLENBQUMsR0FBQyxJQUFJNEYsQ0FBQyxDQUFDa08sUUFBUSxDQUFDaFYsQ0FBQyxDQUFDNkksUUFBUSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUcsUUFBUSxJQUFFeEgsQ0FBQyxFQUFDLEtBQUlQLENBQUMsSUFBSUksQ0FBQyxHQUFDLElBQUk0RixDQUFDLENBQUM5RyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQ1UsQ0FBQyxFQUFDLE9BQU9RLENBQUMsQ0FBQ0osQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFHLFFBQVEsSUFBRU8sQ0FBQyxFQUFDO2NBQUMsS0FBSVAsQ0FBQyxJQUFJZCxDQUFDLEVBQUNjLENBQUMsSUFBSUosQ0FBQyxLQUFHUSxDQUFDLENBQUNKLENBQUMsQ0FBQyxHQUFDZCxDQUFDLENBQUNjLENBQUMsQ0FBQyxDQUFDO2NBQUMsS0FBSyxDQUFDLEtBQUdJLENBQUMsQ0FBQytULE9BQU8sS0FBRy9ULENBQUMsQ0FBQytULE9BQU8sR0FBQ3hVLENBQUMsQ0FBQ2dNLElBQUksQ0FBQ3pNLENBQUMsQ0FBQ3dGLElBQUksQ0FBQyxDQUFDO1lBQUE7WUFBQyxPQUFPdEUsQ0FBQztVQUFBO1VBQUMsU0FBUzZGLENBQUNBLENBQUMvRyxDQUFDLEVBQUM7WUFBQyxPQUFNLE9BQU8sS0FBR0EsQ0FBQyxJQUFFLE1BQU0sS0FBR0EsQ0FBQyxJQUFFLE9BQU8sS0FBR0EsQ0FBQyxJQUFFLFFBQVEsS0FBR0EsQ0FBQyxJQUFFLEtBQUssS0FBR0EsQ0FBQyxJQUFFLE1BQU0sS0FBR0EsQ0FBQztVQUFBO1VBQUMsU0FBUzZHLENBQUNBLENBQUM3RyxDQUFDLEVBQUNjLENBQUMsRUFBQztZQUFDZCxDQUFDLEdBQUMsQ0FBQ0EsQ0FBQyxHQUFDaUgsQ0FBQyxDQUFDakgsQ0FBQyxDQUFDLEVBQUU4SSxPQUFPLENBQUNyRSxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMzRCxDQUFDLEdBQUNBLENBQUMsSUFBRSxDQUFDLENBQUM7WUFBQyxJQUFJQyxDQUFDO2NBQUNHLENBQUMsR0FBQ0wsQ0FBQyxDQUFDb0wsSUFBSSxDQUFDak0sQ0FBQyxDQUFDO2NBQUNxQixDQUFDLEdBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDeUgsV0FBVyxDQUFDLENBQUMsR0FBQyxFQUFFO2NBQUNsSSxDQUFDLEdBQUMsQ0FBQyxDQUFDUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQUNSLENBQUMsR0FBQyxDQUFDLENBQUNRLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FBQ1AsQ0FBQyxHQUFDLENBQUM7WUFBQyxPQUFPRixDQUFDLEdBQUNFLENBQUMsR0FBQ0QsQ0FBQyxJQUFFSyxDQUFDLEdBQUNHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ssTUFBTSxHQUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNLLE1BQU0sS0FBR1IsQ0FBQyxHQUFDRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDSyxNQUFNLENBQUMsR0FBQ2IsQ0FBQyxJQUFFSyxDQUFDLEdBQUNHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDUCxDQUFDLEdBQUNPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0ssTUFBTSxJQUFFUixDQUFDLEdBQUNHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxPQUFPLEtBQUdHLENBQUMsR0FBQyxDQUFDLElBQUVWLENBQUMsS0FBR0ksQ0FBQyxHQUFDQSxDQUFDLENBQUN3QyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ3dELENBQUMsQ0FBQzFGLENBQUMsQ0FBQyxHQUFDTixDQUFDLEdBQUNHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQ0csQ0FBQyxHQUFDWixDQUFDLEtBQUdNLENBQUMsR0FBQ0EsQ0FBQyxDQUFDd0MsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFNUMsQ0FBQyxJQUFFb0csQ0FBQyxDQUFDakcsQ0FBQyxDQUFDNEYsUUFBUSxDQUFDLEtBQUczRixDQUFDLEdBQUNHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO2NBQUN3RixRQUFRLEVBQUNyRixDQUFDO2NBQUM0VCxPQUFPLEVBQUN4VSxDQUFDLElBQUVzRyxDQUFDLENBQUMxRixDQUFDLENBQUM7Y0FBQzZULFlBQVksRUFBQ3ZVLENBQUM7Y0FBQ3dVLElBQUksRUFBQ3BVO1lBQUMsQ0FBQztVQUFBO1VBQUMsU0FBUytGLENBQUNBLENBQUM5RyxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxFQUFDO1lBQUMsSUFBR2YsQ0FBQyxHQUFDLENBQUNBLENBQUMsR0FBQ2lILENBQUMsQ0FBQ2pILENBQUMsQ0FBQyxFQUFFOEksT0FBTyxDQUFDckUsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxFQUFDLEVBQUUsSUFBSSxZQUFZcUMsQ0FBQyxDQUFDLEVBQUMsT0FBTyxJQUFJQSxDQUFDLENBQUM5RyxDQUFDLEVBQUNjLENBQUMsRUFBQ0MsQ0FBQyxDQUFDO1lBQUMsSUFBSUcsQ0FBQztjQUFDRyxDQUFDO2NBQUNaLENBQUM7Y0FBQ0MsQ0FBQztjQUFDQyxDQUFDO2NBQUNDLENBQUM7Y0FBQ0MsQ0FBQyxHQUFDcUcsQ0FBQyxDQUFDM0QsS0FBSyxDQUFDLENBQUM7Y0FBQ3RDLENBQUMsR0FBQyxPQUFPSCxDQUFDO2NBQUN1RCxDQUFDLEdBQUMsSUFBSTtjQUFDQyxDQUFDLEdBQUMsQ0FBQztZQUFDLEtBQUksUUFBUSxJQUFFckQsQ0FBQyxJQUFFLFFBQVEsSUFBRUEsQ0FBQyxLQUFHRixDQUFDLEdBQUNELENBQUMsRUFBQ0EsQ0FBQyxHQUFDLElBQUksQ0FBQyxFQUFDQyxDQUFDLElBQUUsVUFBVSxJQUFFLE9BQU9BLENBQUMsS0FBR0EsQ0FBQyxHQUFDeUQsQ0FBQyxDQUFDWSxLQUFLLENBQUMsRUFBQ2xFLENBQUMsR0FBQyxDQUFDLENBQUNHLENBQUMsR0FBQ3dGLENBQUMsQ0FBQzdHLENBQUMsSUFBRSxFQUFFLEVBQUNjLENBQUMsR0FBQ3dJLENBQUMsQ0FBQ3hJLENBQUMsQ0FBQyxDQUFDLEVBQUU0RixRQUFRLElBQUUsQ0FBQ3JGLENBQUMsQ0FBQzRULE9BQU8sRUFBQzVRLENBQUMsQ0FBQzRRLE9BQU8sR0FBQzVULENBQUMsQ0FBQzRULE9BQU8sSUFBRS9ULENBQUMsSUFBRUosQ0FBQyxDQUFDbVUsT0FBTyxFQUFDNVEsQ0FBQyxDQUFDcUMsUUFBUSxHQUFDckYsQ0FBQyxDQUFDcUYsUUFBUSxJQUFFNUYsQ0FBQyxDQUFDNEYsUUFBUSxJQUFFLEVBQUUsRUFBQzFHLENBQUMsR0FBQ3FCLENBQUMsQ0FBQzhULElBQUksRUFBQyxDQUFDLE9BQU8sS0FBRzlULENBQUMsQ0FBQ3FGLFFBQVEsS0FBRyxDQUFDLEtBQUdyRixDQUFDLENBQUM2VCxZQUFZLElBQUVsTyxDQUFDLENBQUN5RixJQUFJLENBQUN6TSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUNxQixDQUFDLENBQUM0VCxPQUFPLEtBQUc1VCxDQUFDLENBQUNxRixRQUFRLElBQUVyRixDQUFDLENBQUM2VCxZQUFZLEdBQUMsQ0FBQyxJQUFFLENBQUNuTyxDQUFDLENBQUMxQyxDQUFDLENBQUNxQyxRQUFRLENBQUMsQ0FBQyxNQUFJN0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsTUFBTSxFQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUN5RCxDQUFDLEdBQUN6RCxDQUFDLENBQUNVLE1BQU0sRUFBQytDLENBQUMsRUFBRSxFQUFDLFVBQVUsSUFBRSxRQUFPNUQsQ0FBQyxHQUFDRyxDQUFDLENBQUN5RCxDQUFDLENBQUMsQ0FBQyxJQUFFN0QsQ0FBQyxHQUFDQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUNFLENBQUMsR0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDRCxDQUFDLElBQUVBLENBQUMsR0FBQzRELENBQUMsQ0FBQ3pELENBQUMsQ0FBQyxHQUFDWixDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU9TLENBQUMsR0FBQyxFQUFFRSxDQUFDLEdBQUMsR0FBRyxLQUFHRixDQUFDLEdBQUNULENBQUMsQ0FBQ29WLFdBQVcsQ0FBQzNVLENBQUMsQ0FBQyxHQUFDVCxDQUFDLENBQUNxRCxPQUFPLENBQUM1QyxDQUFDLENBQUMsQ0FBQyxLQUFHVCxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU9VLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRTJELENBQUMsQ0FBQ3pELENBQUMsQ0FBQyxHQUFDWixDQUFDLENBQUN1RCxLQUFLLENBQUMsQ0FBQyxFQUFDNUMsQ0FBQyxDQUFDLEVBQUNYLENBQUMsQ0FBQ3VELEtBQUssQ0FBQzVDLENBQUMsR0FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcyRCxDQUFDLENBQUN6RCxDQUFDLENBQUMsR0FBQ1osQ0FBQyxDQUFDdUQsS0FBSyxDQUFDNUMsQ0FBQyxDQUFDLEVBQUNYLENBQUMsQ0FBQ3VELEtBQUssQ0FBQyxDQUFDLEVBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQ0EsQ0FBQyxHQUFDRixDQUFDLENBQUN3TCxJQUFJLENBQUNqTSxDQUFDLENBQUMsTUFBSXFFLENBQUMsQ0FBQ3pELENBQUMsQ0FBQyxHQUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUNYLENBQUMsR0FBQ0EsQ0FBQyxDQUFDdUQsS0FBSyxDQUFDLENBQUMsRUFBQzVDLENBQUMsQ0FBQzRMLEtBQUssQ0FBQyxDQUFDLEVBQUNsSSxDQUFDLENBQUN6RCxDQUFDLENBQUMsR0FBQ3lELENBQUMsQ0FBQ3pELENBQUMsQ0FBQyxJQUFFTSxDQUFDLElBQUVSLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRUksQ0FBQyxDQUFDRixDQUFDLENBQUMsSUFBRSxFQUFFLEVBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRzJELENBQUMsQ0FBQ3pELENBQUMsQ0FBQyxHQUFDeUQsQ0FBQyxDQUFDekQsQ0FBQyxDQUFDLENBQUMrSCxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUUzSSxDQUFDLEdBQUNVLENBQUMsQ0FBQ1YsQ0FBQyxFQUFDcUUsQ0FBQyxDQUFDO1lBQUN0RCxDQUFDLEtBQUdzRCxDQUFDLENBQUMwUSxLQUFLLEdBQUNoVSxDQUFDLENBQUNzRCxDQUFDLENBQUMwUSxLQUFLLENBQUMsQ0FBQyxFQUFDN1QsQ0FBQyxJQUFFSixDQUFDLENBQUNtVSxPQUFPLElBQUUsR0FBRyxLQUFHNVEsQ0FBQyxDQUFDd0UsUUFBUSxDQUFDd00sTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFHLEVBQUUsS0FBR2hSLENBQUMsQ0FBQ3dFLFFBQVEsSUFBRSxFQUFFLEtBQUcvSCxDQUFDLENBQUMrSCxRQUFRLENBQUMsS0FBR3hFLENBQUMsQ0FBQ3dFLFFBQVEsR0FBQyxVQUFTN0ksQ0FBQyxFQUFDYyxDQUFDLEVBQUM7Y0FBQyxJQUFHLEVBQUUsS0FBR2QsQ0FBQyxFQUFDLE9BQU9jLENBQUM7Y0FBQyxLQUFJLElBQUlDLENBQUMsR0FBQyxDQUFDRCxDQUFDLElBQUUsR0FBRyxFQUFFK0ssS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDdEksS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRCxNQUFNLENBQUN0RCxDQUFDLENBQUM2TCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQzNLLENBQUMsR0FBQ0gsQ0FBQyxDQUFDUSxNQUFNLEVBQUNGLENBQUMsR0FBQ04sQ0FBQyxDQUFDRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUNULENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQ0MsQ0FBQyxHQUFDLENBQUMsRUFBQ1EsQ0FBQyxFQUFFLEdBQUUsR0FBRyxLQUFHSCxDQUFDLENBQUNHLENBQUMsQ0FBQyxHQUFDSCxDQUFDLENBQUN1VSxNQUFNLENBQUNwVSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxLQUFHSCxDQUFDLENBQUNHLENBQUMsQ0FBQyxJQUFFSCxDQUFDLENBQUN1VSxNQUFNLENBQUNwVSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUNSLENBQUMsRUFBRSxJQUFFQSxDQUFDLEtBQUcsQ0FBQyxLQUFHUSxDQUFDLEtBQUdULENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDTSxDQUFDLENBQUN1VSxNQUFNLENBQUNwVSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUNSLENBQUMsRUFBRSxDQUFDO2NBQUMsT0FBT0QsQ0FBQyxJQUFFTSxDQUFDLENBQUN1SixPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUMsR0FBRyxLQUFHakosQ0FBQyxJQUFFLElBQUksS0FBR0EsQ0FBQyxJQUFFTixDQUFDLENBQUM0SyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUM1SyxDQUFDLENBQUM2SyxJQUFJLENBQUMsR0FBRyxDQUFDO1lBQUEsQ0FBQyxDQUFDdkgsQ0FBQyxDQUFDd0UsUUFBUSxFQUFDL0gsQ0FBQyxDQUFDK0gsUUFBUSxDQUFDLENBQUMsRUFBQyxHQUFHLEtBQUd4RSxDQUFDLENBQUN3RSxRQUFRLENBQUN3TSxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUV0TyxDQUFDLENBQUMxQyxDQUFDLENBQUNxQyxRQUFRLENBQUMsS0FBR3JDLENBQUMsQ0FBQ3dFLFFBQVEsR0FBQyxHQUFHLEdBQUN4RSxDQUFDLENBQUN3RSxRQUFRLENBQUMsRUFBQ3RFLENBQUMsQ0FBQ0YsQ0FBQyxDQUFDdUMsSUFBSSxFQUFDdkMsQ0FBQyxDQUFDcUMsUUFBUSxDQUFDLEtBQUdyQyxDQUFDLENBQUNzQyxJQUFJLEdBQUN0QyxDQUFDLENBQUNpRSxRQUFRLEVBQUNqRSxDQUFDLENBQUN1QyxJQUFJLEdBQUMsRUFBRSxDQUFDLEVBQUN2QyxDQUFDLENBQUNrUixRQUFRLEdBQUNsUixDQUFDLENBQUNtUixRQUFRLEdBQUMsRUFBRSxFQUFDblIsQ0FBQyxDQUFDb1IsSUFBSSxLQUFHLEVBQUU5VSxDQUFDLEdBQUMwRCxDQUFDLENBQUNvUixJQUFJLENBQUNwUyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBRWdCLENBQUMsQ0FBQ2tSLFFBQVEsR0FBQ2xSLENBQUMsQ0FBQ29SLElBQUksQ0FBQ2xTLEtBQUssQ0FBQyxDQUFDLEVBQUM1QyxDQUFDLENBQUMsRUFBQzBELENBQUMsQ0FBQ2tSLFFBQVEsR0FBQ3BGLGtCQUFrQixDQUFDUCxrQkFBa0IsQ0FBQ3ZMLENBQUMsQ0FBQ2tSLFFBQVEsQ0FBQyxDQUFDLEVBQUNsUixDQUFDLENBQUNtUixRQUFRLEdBQUNuUixDQUFDLENBQUNvUixJQUFJLENBQUNsUyxLQUFLLENBQUM1QyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMwRCxDQUFDLENBQUNtUixRQUFRLEdBQUNyRixrQkFBa0IsQ0FBQ1Asa0JBQWtCLENBQUN2TCxDQUFDLENBQUNtUixRQUFRLENBQUMsQ0FBQyxJQUFFblIsQ0FBQyxDQUFDa1IsUUFBUSxHQUFDcEYsa0JBQWtCLENBQUNQLGtCQUFrQixDQUFDdkwsQ0FBQyxDQUFDb1IsSUFBSSxDQUFDLENBQUMsRUFBQ3BSLENBQUMsQ0FBQ29SLElBQUksR0FBQ3BSLENBQUMsQ0FBQ21SLFFBQVEsR0FBQ25SLENBQUMsQ0FBQ2tSLFFBQVEsR0FBQyxHQUFHLEdBQUNsUixDQUFDLENBQUNtUixRQUFRLEdBQUNuUixDQUFDLENBQUNrUixRQUFRLENBQUMsRUFBQ2xSLENBQUMsQ0FBQ2MsTUFBTSxHQUFDLE9BQU8sS0FBR2QsQ0FBQyxDQUFDcUMsUUFBUSxJQUFFSyxDQUFDLENBQUMxQyxDQUFDLENBQUNxQyxRQUFRLENBQUMsSUFBRXJDLENBQUMsQ0FBQ3NDLElBQUksR0FBQ3RDLENBQUMsQ0FBQ3FDLFFBQVEsR0FBQyxJQUFJLEdBQUNyQyxDQUFDLENBQUNzQyxJQUFJLEdBQUMsTUFBTSxFQUFDdEMsQ0FBQyxDQUFDbUIsSUFBSSxHQUFDbkIsQ0FBQyxDQUFDNEcsUUFBUSxDQUFDLENBQUM7VUFBQTtVQUFDbkUsQ0FBQyxDQUFDakYsU0FBUyxHQUFDO1lBQUMrRyxHQUFHLEVBQUMsU0FBQUEsQ0FBUzVJLENBQUMsRUFBQ2MsQ0FBQyxFQUFDQyxDQUFDLEVBQUM7Y0FBQyxJQUFJRyxDQUFDLEdBQUMsSUFBSTtjQUFDLFFBQU9sQixDQUFDO2dCQUFFLEtBQUksT0FBTztrQkFBQyxRQUFRLElBQUUsT0FBT2MsQ0FBQyxJQUFFQSxDQUFDLENBQUNTLE1BQU0sS0FBR1QsQ0FBQyxHQUFDLENBQUNDLENBQUMsSUFBRXlELENBQUMsQ0FBQ1ksS0FBSyxFQUFFdEUsQ0FBQyxDQUFDLENBQUMsRUFBQ0ksQ0FBQyxDQUFDbEIsQ0FBQyxDQUFDLEdBQUNjLENBQUM7a0JBQUM7Z0JBQU0sS0FBSSxNQUFNO2tCQUFDSSxDQUFDLENBQUNsQixDQUFDLENBQUMsR0FBQ2MsQ0FBQyxFQUFDeUQsQ0FBQyxDQUFDekQsQ0FBQyxFQUFDSSxDQUFDLENBQUN3RixRQUFRLENBQUMsR0FBQzVGLENBQUMsS0FBR0ksQ0FBQyxDQUFDeUYsSUFBSSxHQUFDekYsQ0FBQyxDQUFDb0gsUUFBUSxHQUFDLEdBQUcsR0FBQ3hILENBQUMsQ0FBQyxJQUFFSSxDQUFDLENBQUN5RixJQUFJLEdBQUN6RixDQUFDLENBQUNvSCxRQUFRLEVBQUNwSCxDQUFDLENBQUNsQixDQUFDLENBQUMsR0FBQyxFQUFFLENBQUM7a0JBQUM7Z0JBQU0sS0FBSSxVQUFVO2tCQUFDa0IsQ0FBQyxDQUFDbEIsQ0FBQyxDQUFDLEdBQUNjLENBQUMsRUFBQ0ksQ0FBQyxDQUFDMEYsSUFBSSxLQUFHOUYsQ0FBQyxJQUFFLEdBQUcsR0FBQ0ksQ0FBQyxDQUFDMEYsSUFBSSxDQUFDLEVBQUMxRixDQUFDLENBQUN5RixJQUFJLEdBQUM3RixDQUFDO2tCQUFDO2dCQUFNLEtBQUksTUFBTTtrQkFBQ0ksQ0FBQyxDQUFDbEIsQ0FBQyxDQUFDLEdBQUNjLENBQUMsRUFBQ0YsQ0FBQyxDQUFDNkwsSUFBSSxDQUFDM0wsQ0FBQyxDQUFDLElBQUVBLENBQUMsR0FBQ0EsQ0FBQyxDQUFDK0ssS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDM0ssQ0FBQyxDQUFDMEYsSUFBSSxHQUFDOUYsQ0FBQyxDQUFDNFUsR0FBRyxDQUFDLENBQUMsRUFBQ3hVLENBQUMsQ0FBQ29ILFFBQVEsR0FBQ3hILENBQUMsQ0FBQzhLLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBRzFLLENBQUMsQ0FBQ29ILFFBQVEsR0FBQ3hILENBQUMsRUFBQ0ksQ0FBQyxDQUFDMEYsSUFBSSxHQUFDLEVBQUUsQ0FBQztrQkFBQztnQkFBTSxLQUFJLFVBQVU7a0JBQUMxRixDQUFDLENBQUN3RixRQUFRLEdBQUM1RixDQUFDLENBQUM2SCxXQUFXLENBQUMsQ0FBQyxFQUFDekgsQ0FBQyxDQUFDK1QsT0FBTyxHQUFDLENBQUNsVSxDQUFDO2tCQUFDO2dCQUFNLEtBQUksVUFBVTtnQkFBQyxLQUFJLE1BQU07a0JBQUMsSUFBR0QsQ0FBQyxFQUFDO29CQUFDLElBQUlPLENBQUMsR0FBQyxVQUFVLEtBQUdyQixDQUFDLEdBQUMsR0FBRyxHQUFDLEdBQUc7b0JBQUNrQixDQUFDLENBQUNsQixDQUFDLENBQUMsR0FBQ2MsQ0FBQyxDQUFDdVUsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFHaFUsQ0FBQyxHQUFDQSxDQUFDLEdBQUNQLENBQUMsR0FBQ0EsQ0FBQztrQkFBQSxDQUFDLE1BQUtJLENBQUMsQ0FBQ2xCLENBQUMsQ0FBQyxHQUFDYyxDQUFDO2tCQUFDO2dCQUFNLEtBQUksVUFBVTtnQkFBQyxLQUFJLFVBQVU7a0JBQUNJLENBQUMsQ0FBQ2xCLENBQUMsQ0FBQyxHQUFDbVEsa0JBQWtCLENBQUNyUCxDQUFDLENBQUM7a0JBQUM7Z0JBQU0sS0FBSSxNQUFNO2tCQUFDLElBQUlMLENBQUMsR0FBQ0ssQ0FBQyxDQUFDdUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztrQkFBQyxDQUFDNUMsQ0FBQyxJQUFFUyxDQUFDLENBQUNxVSxRQUFRLEdBQUN6VSxDQUFDLENBQUN5QyxLQUFLLENBQUMsQ0FBQyxFQUFDOUMsQ0FBQyxDQUFDLEVBQUNTLENBQUMsQ0FBQ3FVLFFBQVEsR0FBQ3BGLGtCQUFrQixDQUFDUCxrQkFBa0IsQ0FBQzFPLENBQUMsQ0FBQ3FVLFFBQVEsQ0FBQyxDQUFDLEVBQUNyVSxDQUFDLENBQUNzVSxRQUFRLEdBQUMxVSxDQUFDLENBQUN5QyxLQUFLLENBQUM5QyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUNTLENBQUMsQ0FBQ3NVLFFBQVEsR0FBQ3JGLGtCQUFrQixDQUFDUCxrQkFBa0IsQ0FBQzFPLENBQUMsQ0FBQ3NVLFFBQVEsQ0FBQyxDQUFDLElBQUV0VSxDQUFDLENBQUNxVSxRQUFRLEdBQUNwRixrQkFBa0IsQ0FBQ1Asa0JBQWtCLENBQUM5TyxDQUFDLENBQUMsQ0FBQztjQUFBO2NBQUMsS0FBSSxJQUFJSixDQUFDLEdBQUMsQ0FBQyxFQUFDQSxDQUFDLEdBQUN3RyxDQUFDLENBQUMzRixNQUFNLEVBQUNiLENBQUMsRUFBRSxFQUFDO2dCQUFDLElBQUlDLENBQUMsR0FBQ3VHLENBQUMsQ0FBQ3hHLENBQUMsQ0FBQztnQkFBQ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHTyxDQUFDLENBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDTyxDQUFDLENBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDZ0ksV0FBVyxDQUFDLENBQUMsQ0FBQztjQUFBO2NBQUMsT0FBT3pILENBQUMsQ0FBQ3VVLElBQUksR0FBQ3ZVLENBQUMsQ0FBQ3NVLFFBQVEsR0FBQ3RVLENBQUMsQ0FBQ3FVLFFBQVEsR0FBQyxHQUFHLEdBQUNyVSxDQUFDLENBQUNzVSxRQUFRLEdBQUN0VSxDQUFDLENBQUNxVSxRQUFRLEVBQUNyVSxDQUFDLENBQUNpRSxNQUFNLEdBQUMsT0FBTyxLQUFHakUsQ0FBQyxDQUFDd0YsUUFBUSxJQUFFSyxDQUFDLENBQUM3RixDQUFDLENBQUN3RixRQUFRLENBQUMsSUFBRXhGLENBQUMsQ0FBQ3lGLElBQUksR0FBQ3pGLENBQUMsQ0FBQ3dGLFFBQVEsR0FBQyxJQUFJLEdBQUN4RixDQUFDLENBQUN5RixJQUFJLEdBQUMsTUFBTSxFQUFDekYsQ0FBQyxDQUFDc0UsSUFBSSxHQUFDdEUsQ0FBQyxDQUFDK0osUUFBUSxDQUFDLENBQUMsRUFBQy9KLENBQUM7WUFBQSxDQUFDO1lBQUMrSixRQUFRLEVBQUMsU0FBQUEsQ0FBU2pMLENBQUMsRUFBQztjQUFDQSxDQUFDLElBQUUsVUFBVSxJQUFFLE9BQU9BLENBQUMsS0FBR0EsQ0FBQyxHQUFDd0UsQ0FBQyxDQUFDUixTQUFTLENBQUM7Y0FBQyxJQUFJbEQsQ0FBQztnQkFBQ0MsQ0FBQyxHQUFDLElBQUk7Z0JBQUNHLENBQUMsR0FBQ0gsQ0FBQyxDQUFDNEYsSUFBSTtnQkFBQ3RGLENBQUMsR0FBQ04sQ0FBQyxDQUFDMkYsUUFBUTtjQUFDckYsQ0FBQyxJQUFFLEdBQUcsS0FBR0EsQ0FBQyxDQUFDZ1UsTUFBTSxDQUFDaFUsQ0FBQyxDQUFDRSxNQUFNLEdBQUMsQ0FBQyxDQUFDLEtBQUdGLENBQUMsSUFBRSxHQUFHLENBQUM7Y0FBQyxJQUFJWixDQUFDLEdBQUNZLENBQUMsSUFBRU4sQ0FBQyxDQUFDMkYsUUFBUSxJQUFFM0YsQ0FBQyxDQUFDa1UsT0FBTyxJQUFFbE8sQ0FBQyxDQUFDaEcsQ0FBQyxDQUFDMkYsUUFBUSxDQUFDLEdBQUMsSUFBSSxHQUFDLEVBQUUsQ0FBQztjQUFDLE9BQU8zRixDQUFDLENBQUN3VSxRQUFRLElBQUU5VSxDQUFDLElBQUVNLENBQUMsQ0FBQ3dVLFFBQVEsRUFBQ3hVLENBQUMsQ0FBQ3lVLFFBQVEsS0FBRy9VLENBQUMsSUFBRSxHQUFHLEdBQUNNLENBQUMsQ0FBQ3lVLFFBQVEsQ0FBQyxFQUFDL1UsQ0FBQyxJQUFFLEdBQUcsSUFBRU0sQ0FBQyxDQUFDeVUsUUFBUSxJQUFFL1UsQ0FBQyxJQUFFLEdBQUcsR0FBQ00sQ0FBQyxDQUFDeVUsUUFBUSxFQUFDL1UsQ0FBQyxJQUFFLEdBQUcsSUFBRSxPQUFPLEtBQUdNLENBQUMsQ0FBQzJGLFFBQVEsSUFBRUssQ0FBQyxDQUFDaEcsQ0FBQyxDQUFDMkYsUUFBUSxDQUFDLElBQUUsQ0FBQ3hGLENBQUMsSUFBRSxHQUFHLEtBQUdILENBQUMsQ0FBQzhILFFBQVEsS0FBR3BJLENBQUMsSUFBRSxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUcsS0FBR1MsQ0FBQyxDQUFDQSxDQUFDLENBQUNLLE1BQU0sR0FBQyxDQUFDLENBQUMsSUFBRVgsQ0FBQyxDQUFDNkwsSUFBSSxDQUFDMUwsQ0FBQyxDQUFDdUgsUUFBUSxDQUFDLElBQUUsQ0FBQ3ZILENBQUMsQ0FBQzZGLElBQUksTUFBSTFGLENBQUMsSUFBRSxHQUFHLENBQUMsRUFBQ1QsQ0FBQyxJQUFFUyxDQUFDLEdBQUNILENBQUMsQ0FBQzhILFFBQVEsRUFBQyxDQUFDL0gsQ0FBQyxHQUFDLFFBQVEsSUFBRSxPQUFPQyxDQUFDLENBQUNnVSxLQUFLLEdBQUMvVSxDQUFDLENBQUNlLENBQUMsQ0FBQ2dVLEtBQUssQ0FBQyxHQUFDaFUsQ0FBQyxDQUFDZ1UsS0FBSyxNQUFJdFUsQ0FBQyxJQUFFLEdBQUcsS0FBR0ssQ0FBQyxDQUFDdVUsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQ3ZVLENBQUMsR0FBQ0EsQ0FBQyxDQUFDLEVBQUNDLENBQUMsQ0FBQ2dFLElBQUksS0FBR3RFLENBQUMsSUFBRU0sQ0FBQyxDQUFDZ0UsSUFBSSxDQUFDLEVBQUN0RSxDQUFDO1lBQUE7VUFBQyxDQUFDLEVBQUNxRyxDQUFDLENBQUM2TyxlQUFlLEdBQUM5TyxDQUFDLEVBQUNDLENBQUMsQ0FBQ0wsUUFBUSxHQUFDNkMsQ0FBQyxFQUFDeEMsQ0FBQyxDQUFDOE8sUUFBUSxHQUFDM08sQ0FBQyxFQUFDSCxDQUFDLENBQUMrTyxFQUFFLEdBQUNyUixDQUFDLEVBQUN6RCxDQUFDLENBQUNkLE9BQU8sR0FBQzZHLENBQUM7UUFBQSxDQUFDLEVBQUV4RixJQUFJLENBQUMsSUFBSSxDQUFDO01BQUEsQ0FBQyxFQUFFQSxJQUFJLENBQUMsSUFBSSxFQUFDLFdBQVcsSUFBRSxPQUFPaEIscUJBQU0sR0FBQ0EscUJBQU0sR0FBQyxXQUFXLElBQUUsT0FBT0MsSUFBSSxHQUFDQSxJQUFJLEdBQUMsV0FBVyxJQUFFLE9BQU9GLE1BQU0sR0FBQ0EsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDO01BQUMsZ0JBQWdCLEVBQUMsRUFBRTtNQUFDLGVBQWUsRUFBQztJQUFFLENBQUM7RUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUFBLENBQUMsQ0FBQyxDOzs7Ozs7VUNENzl2RDtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLEdBQUc7V0FDSDtXQUNBO1dBQ0EsQ0FBQyxJOzs7Ozs7Ozs7QUNOMkIsSUFBSUcsTUFBTSxHQUFHUSxtQkFBTyxDQUFDLG9EQUFxQixDQUFDO0FBQzNDLElBQUk4VSxJQUFJLEdBQUcsSUFBSXRWLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztBQUM5Q3NWLElBQUksQ0FBQ2hMLFNBQVMsR0FBRyxVQUFTNEcsS0FBSyxFQUFFO0VBQzdCLE1BQU16QixPQUFPLEdBQUdsTSxJQUFJLENBQUNxQixLQUFLLENBQUNzTSxLQUFLLENBQUNqTyxJQUFJLENBQUM7RUFDdEM0USxPQUFPLENBQUNDLEdBQUcsQ0FBQ3JFLE9BQU8sRUFBQyxJQUFJLENBQUM7RUFDekIsUUFBUUEsT0FBTyxDQUFDdE4sSUFBSTtJQUNoQixLQUFLLGNBQWM7TUFDZjBSLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLFlBQVksR0FBR3JFLE9BQU8sQ0FBQ3hNLElBQUksQ0FBQ3NTLElBQUksR0FBRyxJQUFJLENBQUM7TUFDcEQsSUFBSTlGLE9BQU8sQ0FBQ3hNLElBQUksQ0FBQ3VTLE9BQU8sRUFBRTtRQUN0Qm5DLE1BQU0sQ0FBQ0UsT0FBTyxDQUFDa0MsTUFBTSxDQUFDLENBQUM7UUFDdkI1QixPQUFPLENBQUNDLEdBQUcsQ0FBQyxhQUFhLENBQUM7TUFDOUIsQ0FBQyxNQUFNO1FBQ0hELE9BQU8sQ0FBQzZCLEtBQUssQ0FBQyxjQUFjLEdBQUdqRyxPQUFPLENBQUN4TSxJQUFJLENBQUMwUyxNQUFNLENBQUM7TUFDdkQ7TUFDQTtJQUNKO01BQ0k5QixPQUFPLENBQUNDLEdBQUcsQ0FBQyxPQUFPLEVBQUVyRSxPQUFPLENBQUM7RUFDckM7QUFDSixDQUFDOztBQUU3QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTRELE1BQU0sQ0FBQ3BCLE1BQU0sQ0FBQzJELFNBQVMsQ0FBQzdULFdBQVcsQ0FBQyxNQUFPOFQsR0FBRyxJQUFLO0VBQ2pEeEMsTUFBTSxDQUFDeUMsSUFBSSxDQUFDNUIsTUFBTSxDQUFDO0lBQ2pCM0wsR0FBRyxFQUFFOEssTUFBTSxDQUFDRSxPQUFPLENBQUN3QyxNQUFNLENBQUMsWUFBWSxDQUFDO0lBQ3hDQyxNQUFNLEVBQUU7RUFDVixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NoYXJlLWNocm9tZS1leHRlbnNpb25zLWJ5LWx3aC8uL3NyYy9qcy9saWJzL3NvY2tqcy5qcyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoL3dlYnBhY2svcnVudGltZS9nbG9iYWwiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL2JhY2tncm91bmQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogc29ja2pzLWNsaWVudCB2MS42LjEgfCBodHRwOi8vc29ja2pzLm9yZyB8IE1JVCBsaWNlbnNlICovXHJcbiFmdW5jdGlvbihlKXtpZihcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZSltb2R1bGUuZXhwb3J0cz1lKCk7ZWxzZSBpZihcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQpZGVmaW5lKFtdLGUpO2Vsc2V7KFwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93OlwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6dGhpcykuU29ja0pTPWUoKX19KGZ1bmN0aW9uKCl7cmV0dXJuIGZ1bmN0aW9uIGkocyxhLGwpe2Z1bmN0aW9uIHUodCxlKXtpZighYVt0XSl7aWYoIXNbdF0pe3ZhciBuPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWUmJm4pcmV0dXJuIG4odCwhMCk7aWYoYylyZXR1cm4gYyh0LCEwKTt2YXIgcj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK3QrXCInXCIpO3Rocm93IHIuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixyfXZhciBvPWFbdF09e2V4cG9ydHM6e319O3NbdF1bMF0uY2FsbChvLmV4cG9ydHMsZnVuY3Rpb24oZSl7cmV0dXJuIHUoc1t0XVsxXVtlXXx8ZSl9LG8sby5leHBvcnRzLGkscyxhLGwpfXJldHVybiBhW3RdLmV4cG9ydHN9Zm9yKHZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmUsZT0wO2U8bC5sZW5ndGg7ZSsrKXUobFtlXSk7cmV0dXJuIHV9KHsxOltmdW5jdGlvbihuLHIsZSl7KGZ1bmN0aW9uKHQpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBlPW4oXCIuL3RyYW5zcG9ydC1saXN0XCIpO3IuZXhwb3J0cz1uKFwiLi9tYWluXCIpKGUpLFwiX3NvY2tqc19vbmxvYWRcImluIHQmJnNldFRpbWVvdXQodC5fc29ja2pzX29ubG9hZCwxKX0pLmNhbGwodGhpcyl9KS5jYWxsKHRoaXMsXCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbD9nbG9iYWw6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHNlbGY/c2VsZjpcInVuZGVmaW5lZFwiIT10eXBlb2Ygd2luZG93P3dpbmRvdzp7fSl9LHtcIi4vbWFpblwiOjE0LFwiLi90cmFuc3BvcnQtbGlzdFwiOjE2fV0sMjpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciByPWUoXCJpbmhlcml0c1wiKSxvPWUoXCIuL2V2ZW50XCIpO2Z1bmN0aW9uIGkoKXtvLmNhbGwodGhpcyksdGhpcy5pbml0RXZlbnQoXCJjbG9zZVwiLCExLCExKSx0aGlzLndhc0NsZWFuPSExLHRoaXMuY29kZT0wLHRoaXMucmVhc29uPVwiXCJ9cihpLG8pLHQuZXhwb3J0cz1pfSx7XCIuL2V2ZW50XCI6NCxcImluaGVyaXRzXCI6NTR9XSwzOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcIi4vZXZlbnR0YXJnZXRcIik7ZnVuY3Rpb24gaSgpe28uY2FsbCh0aGlzKX1yKGksbyksaS5wcm90b3R5cGUucmVtb3ZlQWxsTGlzdGVuZXJzPWZ1bmN0aW9uKGUpe2U/ZGVsZXRlIHRoaXMuX2xpc3RlbmVyc1tlXTp0aGlzLl9saXN0ZW5lcnM9e319LGkucHJvdG90eXBlLm9uY2U9ZnVuY3Rpb24odCxuKXt2YXIgcj10aGlzLG89ITE7dGhpcy5vbih0LGZ1bmN0aW9uIGUoKXtyLnJlbW92ZUxpc3RlbmVyKHQsZSksb3x8KG89ITAsbi5hcHBseSh0aGlzLGFyZ3VtZW50cykpfSl9LGkucHJvdG90eXBlLmVtaXQ9ZnVuY3Rpb24oKXt2YXIgZT1hcmd1bWVudHNbMF0sdD10aGlzLl9saXN0ZW5lcnNbZV07aWYodCl7Zm9yKHZhciBuPWFyZ3VtZW50cy5sZW5ndGgscj1uZXcgQXJyYXkobi0xKSxvPTE7bzxuO28rKylyW28tMV09YXJndW1lbnRzW29dO2Zvcih2YXIgaT0wO2k8dC5sZW5ndGg7aSsrKXRbaV0uYXBwbHkodGhpcyxyKX19LGkucHJvdG90eXBlLm9uPWkucHJvdG90eXBlLmFkZExpc3RlbmVyPW8ucHJvdG90eXBlLmFkZEV2ZW50TGlzdGVuZXIsaS5wcm90b3R5cGUucmVtb3ZlTGlzdGVuZXI9by5wcm90b3R5cGUucmVtb3ZlRXZlbnRMaXN0ZW5lcix0LmV4cG9ydHMuRXZlbnRFbWl0dGVyPWl9LHtcIi4vZXZlbnR0YXJnZXRcIjo1LFwiaW5oZXJpdHNcIjo1NH1dLDQ6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjtmdW5jdGlvbiByKGUpe3RoaXMudHlwZT1lfXIucHJvdG90eXBlLmluaXRFdmVudD1mdW5jdGlvbihlLHQsbil7cmV0dXJuIHRoaXMudHlwZT1lLHRoaXMuYnViYmxlcz10LHRoaXMuY2FuY2VsYWJsZT1uLHRoaXMudGltZVN0YW1wPStuZXcgRGF0ZSx0aGlzfSxyLnByb3RvdHlwZS5zdG9wUHJvcGFnYXRpb249ZnVuY3Rpb24oKXt9LHIucHJvdG90eXBlLnByZXZlbnREZWZhdWx0PWZ1bmN0aW9uKCl7fSxyLkNBUFRVUklOR19QSEFTRT0xLHIuQVRfVEFSR0VUPTIsci5CVUJCTElOR19QSEFTRT0zLHQuZXhwb3J0cz1yfSx7fV0sNTpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO2Z1bmN0aW9uIHIoKXt0aGlzLl9saXN0ZW5lcnM9e319ci5wcm90b3R5cGUuYWRkRXZlbnRMaXN0ZW5lcj1mdW5jdGlvbihlLHQpe2UgaW4gdGhpcy5fbGlzdGVuZXJzfHwodGhpcy5fbGlzdGVuZXJzW2VdPVtdKTt2YXIgbj10aGlzLl9saXN0ZW5lcnNbZV07LTE9PT1uLmluZGV4T2YodCkmJihuPW4uY29uY2F0KFt0XSkpLHRoaXMuX2xpc3RlbmVyc1tlXT1ufSxyLnByb3RvdHlwZS5yZW1vdmVFdmVudExpc3RlbmVyPWZ1bmN0aW9uKGUsdCl7dmFyIG49dGhpcy5fbGlzdGVuZXJzW2VdO2lmKG4pe3ZhciByPW4uaW5kZXhPZih0KTstMT09PXJ8fCgxPG4ubGVuZ3RoP3RoaXMuX2xpc3RlbmVyc1tlXT1uLnNsaWNlKDAscikuY29uY2F0KG4uc2xpY2UocisxKSk6ZGVsZXRlIHRoaXMuX2xpc3RlbmVyc1tlXSl9fSxyLnByb3RvdHlwZS5kaXNwYXRjaEV2ZW50PWZ1bmN0aW9uKCl7dmFyIGU9YXJndW1lbnRzWzBdLHQ9ZS50eXBlLG49MT09PWFyZ3VtZW50cy5sZW5ndGg/W2VdOkFycmF5LmFwcGx5KG51bGwsYXJndW1lbnRzKTtpZih0aGlzW1wib25cIit0XSYmdGhpc1tcIm9uXCIrdF0uYXBwbHkodGhpcyxuKSx0IGluIHRoaXMuX2xpc3RlbmVycylmb3IodmFyIHI9dGhpcy5fbGlzdGVuZXJzW3RdLG89MDtvPHIubGVuZ3RoO28rKylyW29dLmFwcGx5KHRoaXMsbil9LHQuZXhwb3J0cz1yfSx7fV0sNjpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciByPWUoXCJpbmhlcml0c1wiKSxvPWUoXCIuL2V2ZW50XCIpO2Z1bmN0aW9uIGkoZSl7by5jYWxsKHRoaXMpLHRoaXMuaW5pdEV2ZW50KFwibWVzc2FnZVwiLCExLCExKSx0aGlzLmRhdGE9ZX1yKGksbyksdC5leHBvcnRzPWl9LHtcIi4vZXZlbnRcIjo0LFwiaW5oZXJpdHNcIjo1NH1dLDc6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiLi91dGlscy9pZnJhbWVcIik7ZnVuY3Rpb24gbyhlKXsodGhpcy5fdHJhbnNwb3J0PWUpLm9uKFwibWVzc2FnZVwiLHRoaXMuX3RyYW5zcG9ydE1lc3NhZ2UuYmluZCh0aGlzKSksZS5vbihcImNsb3NlXCIsdGhpcy5fdHJhbnNwb3J0Q2xvc2UuYmluZCh0aGlzKSl9by5wcm90b3R5cGUuX3RyYW5zcG9ydENsb3NlPWZ1bmN0aW9uKGUsdCl7ci5wb3N0TWVzc2FnZShcImNcIixKU09OLnN0cmluZ2lmeShbZSx0XSkpfSxvLnByb3RvdHlwZS5fdHJhbnNwb3J0TWVzc2FnZT1mdW5jdGlvbihlKXtyLnBvc3RNZXNzYWdlKFwidFwiLGUpfSxvLnByb3RvdHlwZS5fc2VuZD1mdW5jdGlvbihlKXt0aGlzLl90cmFuc3BvcnQuc2VuZChlKX0sby5wcm90b3R5cGUuX2Nsb3NlPWZ1bmN0aW9uKCl7dGhpcy5fdHJhbnNwb3J0LmNsb3NlKCksdGhpcy5fdHJhbnNwb3J0LnJlbW92ZUFsbExpc3RlbmVycygpfSx0LmV4cG9ydHM9b30se1wiLi91dGlscy9pZnJhbWVcIjo0N31dLDg6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgZj1lKFwiLi91dGlscy91cmxcIikscj1lKFwiLi91dGlscy9ldmVudFwiKSxoPWUoXCIuL2ZhY2FkZVwiKSxvPWUoXCIuL2luZm8taWZyYW1lLXJlY2VpdmVyXCIpLGQ9ZShcIi4vdXRpbHMvaWZyYW1lXCIpLHA9ZShcIi4vbG9jYXRpb25cIiksbT1mdW5jdGlvbigpe307dC5leHBvcnRzPWZ1bmN0aW9uKGwsZSl7dmFyIHUsYz17fTtlLmZvckVhY2goZnVuY3Rpb24oZSl7ZS5mYWNhZGVUcmFuc3BvcnQmJihjW2UuZmFjYWRlVHJhbnNwb3J0LnRyYW5zcG9ydE5hbWVdPWUuZmFjYWRlVHJhbnNwb3J0KX0pLGNbby50cmFuc3BvcnROYW1lXT1vLGwuYm9vdHN0cmFwX2lmcmFtZT1mdW5jdGlvbigpe3ZhciBhO2QuY3VycmVudFdpbmRvd0lkPXAuaGFzaC5zbGljZSgxKTtyLmF0dGFjaEV2ZW50KFwibWVzc2FnZVwiLGZ1bmN0aW9uKHQpe2lmKHQuc291cmNlPT09cGFyZW50JiYodm9pZCAwPT09dSYmKHU9dC5vcmlnaW4pLHQub3JpZ2luPT09dSkpe3ZhciBuO3RyeXtuPUpTT04ucGFyc2UodC5kYXRhKX1jYXRjaChlKXtyZXR1cm4gdm9pZCBtKFwiYmFkIGpzb25cIix0LmRhdGEpfWlmKG4ud2luZG93SWQ9PT1kLmN1cnJlbnRXaW5kb3dJZClzd2l0Y2gobi50eXBlKXtjYXNlXCJzXCI6dmFyIGU7dHJ5e2U9SlNPTi5wYXJzZShuLmRhdGEpfWNhdGNoKGUpe20oXCJiYWQganNvblwiLG4uZGF0YSk7YnJlYWt9dmFyIHI9ZVswXSxvPWVbMV0saT1lWzJdLHM9ZVszXTtpZihtKHIsbyxpLHMpLHIhPT1sLnZlcnNpb24pdGhyb3cgbmV3IEVycm9yKCdJbmNvbXBhdGlibGUgU29ja0pTISBNYWluIHNpdGUgdXNlczogXCInK3IrJ1wiLCB0aGUgaWZyYW1lOiBcIicrbC52ZXJzaW9uKydcIi4nKTtpZighZi5pc09yaWdpbkVxdWFsKGkscC5ocmVmKXx8IWYuaXNPcmlnaW5FcXVhbChzLHAuaHJlZikpdGhyb3cgbmV3IEVycm9yKFwiQ2FuJ3QgY29ubmVjdCB0byBkaWZmZXJlbnQgZG9tYWluIGZyb20gd2l0aGluIGFuIGlmcmFtZS4gKFwiK3AuaHJlZitcIiwgXCIraStcIiwgXCIrcytcIilcIik7YT1uZXcgaChuZXcgY1tvXShpLHMpKTticmVhaztjYXNlXCJtXCI6YS5fc2VuZChuLmRhdGEpO2JyZWFrO2Nhc2VcImNcIjphJiZhLl9jbG9zZSgpLGE9bnVsbH19fSksZC5wb3N0TWVzc2FnZShcInNcIil9fX0se1wiLi9mYWNhZGVcIjo3LFwiLi9pbmZvLWlmcmFtZS1yZWNlaXZlclwiOjEwLFwiLi9sb2NhdGlvblwiOjEzLFwiLi91dGlscy9ldmVudFwiOjQ2LFwiLi91dGlscy9pZnJhbWVcIjo0NyxcIi4vdXRpbHMvdXJsXCI6NTIsXCJkZWJ1Z1wiOnZvaWQgMH1dLDk6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlcixvPWUoXCJpbmhlcml0c1wiKSxzPWUoXCIuL3V0aWxzL29iamVjdFwiKSxhPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBpKGUsdCl7ci5jYWxsKHRoaXMpO3ZhciBvPXRoaXMsaT0rbmV3IERhdGU7dGhpcy54bz1uZXcgdChcIkdFVFwiLGUpLHRoaXMueG8ub25jZShcImZpbmlzaFwiLGZ1bmN0aW9uKGUsdCl7dmFyIG4scjtpZigyMDA9PT1lKXtpZihyPStuZXcgRGF0ZS1pLHQpdHJ5e249SlNPTi5wYXJzZSh0KX1jYXRjaChlKXthKFwiYmFkIGpzb25cIix0KX1zLmlzT2JqZWN0KG4pfHwobj17fSl9by5lbWl0KFwiZmluaXNoXCIsbixyKSxvLnJlbW92ZUFsbExpc3RlbmVycygpfSl9byhpLHIpLGkucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKCl7dGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKSx0aGlzLnhvLmNsb3NlKCl9LHQuZXhwb3J0cz1pfSx7XCIuL3V0aWxzL29iamVjdFwiOjQ5LFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDEwOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcImV2ZW50c1wiKS5FdmVudEVtaXR0ZXIsaT1lKFwiLi90cmFuc3BvcnQvc2VuZGVyL3hoci1sb2NhbFwiKSxzPWUoXCIuL2luZm8tYWpheFwiKTtmdW5jdGlvbiBhKGUpe3ZhciBuPXRoaXM7by5jYWxsKHRoaXMpLHRoaXMuaXI9bmV3IHMoZSxpKSx0aGlzLmlyLm9uY2UoXCJmaW5pc2hcIixmdW5jdGlvbihlLHQpe24uaXI9bnVsbCxuLmVtaXQoXCJtZXNzYWdlXCIsSlNPTi5zdHJpbmdpZnkoW2UsdF0pKX0pfXIoYSxvKSxhLnRyYW5zcG9ydE5hbWU9XCJpZnJhbWUtaW5mby1yZWNlaXZlclwiLGEucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKCl7dGhpcy5pciYmKHRoaXMuaXIuY2xvc2UoKSx0aGlzLmlyPW51bGwpLHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCl9LHQuZXhwb3J0cz1hfSx7XCIuL2luZm8tYWpheFwiOjksXCIuL3RyYW5zcG9ydC9zZW5kZXIveGhyLWxvY2FsXCI6MzcsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDExOltmdW5jdGlvbihuLG8sZSl7KGZ1bmN0aW9uKHUpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciByPW4oXCJldmVudHNcIikuRXZlbnRFbWl0dGVyLGU9bihcImluaGVyaXRzXCIpLGk9bihcIi4vdXRpbHMvZXZlbnRcIikscz1uKFwiLi90cmFuc3BvcnQvaWZyYW1lXCIpLGE9bihcIi4vaW5mby1pZnJhbWUtcmVjZWl2ZXJcIiksbD1mdW5jdGlvbigpe307ZnVuY3Rpb24gdCh0LG4pe3ZhciBvPXRoaXM7ci5jYWxsKHRoaXMpO2Z1bmN0aW9uIGUoKXt2YXIgZT1vLmlmcj1uZXcgcyhhLnRyYW5zcG9ydE5hbWUsbix0KTtlLm9uY2UoXCJtZXNzYWdlXCIsZnVuY3Rpb24odCl7aWYodCl7dmFyIGU7dHJ5e2U9SlNPTi5wYXJzZSh0KX1jYXRjaChlKXtyZXR1cm4gbChcImJhZCBqc29uXCIsdCksby5lbWl0KFwiZmluaXNoXCIpLHZvaWQgby5jbG9zZSgpfXZhciBuPWVbMF0scj1lWzFdO28uZW1pdChcImZpbmlzaFwiLG4scil9by5jbG9zZSgpfSksZS5vbmNlKFwiY2xvc2VcIixmdW5jdGlvbigpe28uZW1pdChcImZpbmlzaFwiKSxvLmNsb3NlKCl9KX11LmRvY3VtZW50LmJvZHk/ZSgpOmkuYXR0YWNoRXZlbnQoXCJsb2FkXCIsZSl9ZSh0LHIpLHQuZW5hYmxlZD1mdW5jdGlvbigpe3JldHVybiBzLmVuYWJsZWQoKX0sdC5wcm90b3R5cGUuY2xvc2U9ZnVuY3Rpb24oKXt0aGlzLmlmciYmdGhpcy5pZnIuY2xvc2UoKSx0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpLHRoaXMuaWZyPW51bGx9LG8uZXhwb3J0cz10fSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi9pbmZvLWlmcmFtZS1yZWNlaXZlclwiOjEwLFwiLi90cmFuc3BvcnQvaWZyYW1lXCI6MjIsXCIuL3V0aWxzL2V2ZW50XCI6NDYsXCJkZWJ1Z1wiOnZvaWQgMCxcImV2ZW50c1wiOjMsXCJpbmhlcml0c1wiOjU0fV0sMTI6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlcixvPWUoXCJpbmhlcml0c1wiKSxpPWUoXCIuL3V0aWxzL3VybFwiKSxzPWUoXCIuL3RyYW5zcG9ydC9zZW5kZXIveGRyXCIpLGE9ZShcIi4vdHJhbnNwb3J0L3NlbmRlci94aHItY29yc1wiKSxsPWUoXCIuL3RyYW5zcG9ydC9zZW5kZXIveGhyLWxvY2FsXCIpLHU9ZShcIi4vdHJhbnNwb3J0L3NlbmRlci94aHItZmFrZVwiKSxjPWUoXCIuL2luZm8taWZyYW1lXCIpLGY9ZShcIi4vaW5mby1hamF4XCIpLGg9ZnVuY3Rpb24oKXt9O2Z1bmN0aW9uIGQoZSx0KXtoKGUpO3ZhciBuPXRoaXM7ci5jYWxsKHRoaXMpLHNldFRpbWVvdXQoZnVuY3Rpb24oKXtuLmRvWGhyKGUsdCl9LDApfW8oZCxyKSxkLl9nZXRSZWNlaXZlcj1mdW5jdGlvbihlLHQsbil7cmV0dXJuIG4uc2FtZU9yaWdpbj9uZXcgZih0LGwpOmEuZW5hYmxlZD9uZXcgZih0LGEpOnMuZW5hYmxlZCYmbi5zYW1lU2NoZW1lP25ldyBmKHQscyk6Yy5lbmFibGVkKCk/bmV3IGMoZSx0KTpuZXcgZih0LHUpfSxkLnByb3RvdHlwZS5kb1hocj1mdW5jdGlvbihlLHQpe3ZhciBuPXRoaXMscj1pLmFkZFBhdGgoZSxcIi9pbmZvXCIpO2goXCJkb1hoclwiLHIpLHRoaXMueG89ZC5fZ2V0UmVjZWl2ZXIoZSxyLHQpLHRoaXMudGltZW91dFJlZj1zZXRUaW1lb3V0KGZ1bmN0aW9uKCl7aChcInRpbWVvdXRcIiksbi5fY2xlYW51cCghMSksbi5lbWl0KFwiZmluaXNoXCIpfSxkLnRpbWVvdXQpLHRoaXMueG8ub25jZShcImZpbmlzaFwiLGZ1bmN0aW9uKGUsdCl7aChcImZpbmlzaFwiLGUsdCksbi5fY2xlYW51cCghMCksbi5lbWl0KFwiZmluaXNoXCIsZSx0KX0pfSxkLnByb3RvdHlwZS5fY2xlYW51cD1mdW5jdGlvbihlKXtoKFwiX2NsZWFudXBcIiksY2xlYXJUaW1lb3V0KHRoaXMudGltZW91dFJlZiksdGhpcy50aW1lb3V0UmVmPW51bGwsIWUmJnRoaXMueG8mJnRoaXMueG8uY2xvc2UoKSx0aGlzLnhvPW51bGx9LGQucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKCl7aChcImNsb3NlXCIpLHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCksdGhpcy5fY2xlYW51cCghMSl9LGQudGltZW91dD04ZTMsdC5leHBvcnRzPWR9LHtcIi4vaW5mby1hamF4XCI6OSxcIi4vaW5mby1pZnJhbWVcIjoxMSxcIi4vdHJhbnNwb3J0L3NlbmRlci94ZHJcIjozNCxcIi4vdHJhbnNwb3J0L3NlbmRlci94aHItY29yc1wiOjM1LFwiLi90cmFuc3BvcnQvc2VuZGVyL3hoci1mYWtlXCI6MzYsXCIuL3RyYW5zcG9ydC9zZW5kZXIveGhyLWxvY2FsXCI6MzcsXCIuL3V0aWxzL3VybFwiOjUyLFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDEzOltmdW5jdGlvbihlLHQsbil7KGZ1bmN0aW9uKGUpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3QuZXhwb3J0cz1lLmxvY2F0aW9ufHx7b3JpZ2luOlwiaHR0cDovL2xvY2FsaG9zdDo4MFwiLHByb3RvY29sOlwiaHR0cDpcIixob3N0OlwibG9jYWxob3N0XCIscG9ydDo4MCxocmVmOlwiaHR0cDovL2xvY2FsaG9zdC9cIixoYXNoOlwiXCJ9fSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se31dLDE0OltmdW5jdGlvbih4LF8sZSl7KGZ1bmN0aW9uKHcpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3goXCIuL3NoaW1zXCIpO3ZhciByLGw9eChcInVybC1wYXJzZVwiKSxlPXgoXCJpbmhlcml0c1wiKSx1PXgoXCIuL3V0aWxzL3JhbmRvbVwiKSx0PXgoXCIuL3V0aWxzL2VzY2FwZVwiKSxjPXgoXCIuL3V0aWxzL3VybFwiKSxpPXgoXCIuL3V0aWxzL2V2ZW50XCIpLG49eChcIi4vdXRpbHMvdHJhbnNwb3J0XCIpLG89eChcIi4vdXRpbHMvb2JqZWN0XCIpLGY9eChcIi4vdXRpbHMvYnJvd3NlclwiKSxoPXgoXCIuL3V0aWxzL2xvZ1wiKSxzPXgoXCIuL2V2ZW50L2V2ZW50XCIpLGQ9eChcIi4vZXZlbnQvZXZlbnR0YXJnZXRcIikscD14KFwiLi9sb2NhdGlvblwiKSxhPXgoXCIuL2V2ZW50L2Nsb3NlXCIpLG09eChcIi4vZXZlbnQvdHJhbnMtbWVzc2FnZVwiKSx2PXgoXCIuL2luZm8tcmVjZWl2ZXJcIiksYj1mdW5jdGlvbigpe307ZnVuY3Rpb24geShlLHQsbil7aWYoISh0aGlzIGluc3RhbmNlb2YgeSkpcmV0dXJuIG5ldyB5KGUsdCxuKTtpZihhcmd1bWVudHMubGVuZ3RoPDEpdGhyb3cgbmV3IFR5cGVFcnJvcihcIkZhaWxlZCB0byBjb25zdHJ1Y3QgJ1NvY2tKUzogMSBhcmd1bWVudCByZXF1aXJlZCwgYnV0IG9ubHkgMCBwcmVzZW50XCIpO2QuY2FsbCh0aGlzKSx0aGlzLnJlYWR5U3RhdGU9eS5DT05ORUNUSU5HLHRoaXMuZXh0ZW5zaW9ucz1cIlwiLHRoaXMucHJvdG9jb2w9XCJcIiwobj1ufHx7fSkucHJvdG9jb2xzX3doaXRlbGlzdCYmaC53YXJuKFwiJ3Byb3RvY29sc193aGl0ZWxpc3QnIGlzIERFUFJFQ0FURUQuIFVzZSAndHJhbnNwb3J0cycgaW5zdGVhZC5cIiksdGhpcy5fdHJhbnNwb3J0c1doaXRlbGlzdD1uLnRyYW5zcG9ydHMsdGhpcy5fdHJhbnNwb3J0T3B0aW9ucz1uLnRyYW5zcG9ydE9wdGlvbnN8fHt9LHRoaXMuX3RpbWVvdXQ9bi50aW1lb3V0fHwwO3ZhciByPW4uc2Vzc2lvbklkfHw4O2lmKFwiZnVuY3Rpb25cIj09dHlwZW9mIHIpdGhpcy5fZ2VuZXJhdGVTZXNzaW9uSWQ9cjtlbHNle2lmKFwibnVtYmVyXCIhPXR5cGVvZiByKXRocm93IG5ldyBUeXBlRXJyb3IoXCJJZiBzZXNzaW9uSWQgaXMgdXNlZCBpbiB0aGUgb3B0aW9ucywgaXQgbmVlZHMgdG8gYmUgYSBudW1iZXIgb3IgYSBmdW5jdGlvbi5cIik7dGhpcy5fZ2VuZXJhdGVTZXNzaW9uSWQ9ZnVuY3Rpb24oKXtyZXR1cm4gdS5zdHJpbmcocil9fXRoaXMuX3NlcnZlcj1uLnNlcnZlcnx8dS5udW1iZXJTdHJpbmcoMWUzKTt2YXIgbz1uZXcgbChlKTtpZighby5ob3N0fHwhby5wcm90b2NvbCl0aHJvdyBuZXcgU3ludGF4RXJyb3IoXCJUaGUgVVJMICdcIitlK1wiJyBpcyBpbnZhbGlkXCIpO2lmKG8uaGFzaCl0aHJvdyBuZXcgU3ludGF4RXJyb3IoXCJUaGUgVVJMIG11c3Qgbm90IGNvbnRhaW4gYSBmcmFnbWVudFwiKTtpZihcImh0dHA6XCIhPT1vLnByb3RvY29sJiZcImh0dHBzOlwiIT09by5wcm90b2NvbCl0aHJvdyBuZXcgU3ludGF4RXJyb3IoXCJUaGUgVVJMJ3Mgc2NoZW1lIG11c3QgYmUgZWl0aGVyICdodHRwOicgb3IgJ2h0dHBzOicuICdcIitvLnByb3RvY29sK1wiJyBpcyBub3QgYWxsb3dlZC5cIik7dmFyIGk9XCJodHRwczpcIj09PW8ucHJvdG9jb2w7aWYoXCJodHRwczpcIj09PXAucHJvdG9jb2wmJiFpJiYhYy5pc0xvb3BiYWNrQWRkcihvLmhvc3RuYW1lKSl0aHJvdyBuZXcgRXJyb3IoXCJTZWN1cml0eUVycm9yOiBBbiBpbnNlY3VyZSBTb2NrSlMgY29ubmVjdGlvbiBtYXkgbm90IGJlIGluaXRpYXRlZCBmcm9tIGEgcGFnZSBsb2FkZWQgb3ZlciBIVFRQU1wiKTt0P0FycmF5LmlzQXJyYXkodCl8fCh0PVt0XSk6dD1bXTt2YXIgcz10LnNvcnQoKTtzLmZvckVhY2goZnVuY3Rpb24oZSx0KXtpZighZSl0aHJvdyBuZXcgU3ludGF4RXJyb3IoXCJUaGUgcHJvdG9jb2xzIGVudHJ5ICdcIitlK1wiJyBpcyBpbnZhbGlkLlwiKTtpZih0PHMubGVuZ3RoLTEmJmU9PT1zW3QrMV0pdGhyb3cgbmV3IFN5bnRheEVycm9yKFwiVGhlIHByb3RvY29scyBlbnRyeSAnXCIrZStcIicgaXMgZHVwbGljYXRlZC5cIil9KTt2YXIgYT1jLmdldE9yaWdpbihwLmhyZWYpO3RoaXMuX29yaWdpbj1hP2EudG9Mb3dlckNhc2UoKTpudWxsLG8uc2V0KFwicGF0aG5hbWVcIixvLnBhdGhuYW1lLnJlcGxhY2UoL1xcLyskLyxcIlwiKSksdGhpcy51cmw9by5ocmVmLGIoXCJ1c2luZyB1cmxcIix0aGlzLnVybCksdGhpcy5fdXJsSW5mbz17bnVsbE9yaWdpbjohZi5oYXNEb21haW4oKSxzYW1lT3JpZ2luOmMuaXNPcmlnaW5FcXVhbCh0aGlzLnVybCxwLmhyZWYpLHNhbWVTY2hlbWU6Yy5pc1NjaGVtZUVxdWFsKHRoaXMudXJsLHAuaHJlZil9LHRoaXMuX2lyPW5ldyB2KHRoaXMudXJsLHRoaXMuX3VybEluZm8pLHRoaXMuX2lyLm9uY2UoXCJmaW5pc2hcIix0aGlzLl9yZWNlaXZlSW5mby5iaW5kKHRoaXMpKX1mdW5jdGlvbiBnKGUpe3JldHVybiAxZTM9PT1lfHwzZTM8PWUmJmU8PTQ5OTl9ZSh5LGQpLHkucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKGUsdCl7aWYoZSYmIWcoZSkpdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZEFjY2Vzc0Vycm9yOiBJbnZhbGlkIGNvZGVcIik7aWYodCYmMTIzPHQubGVuZ3RoKXRocm93IG5ldyBTeW50YXhFcnJvcihcInJlYXNvbiBhcmd1bWVudCBoYXMgYW4gaW52YWxpZCBsZW5ndGhcIik7aWYodGhpcy5yZWFkeVN0YXRlIT09eS5DTE9TSU5HJiZ0aGlzLnJlYWR5U3RhdGUhPT15LkNMT1NFRCl7dGhpcy5fY2xvc2UoZXx8MWUzLHR8fFwiTm9ybWFsIGNsb3N1cmVcIiwhMCl9fSx5LnByb3RvdHlwZS5zZW5kPWZ1bmN0aW9uKGUpe2lmKFwic3RyaW5nXCIhPXR5cGVvZiBlJiYoZT1cIlwiK2UpLHRoaXMucmVhZHlTdGF0ZT09PXkuQ09OTkVDVElORyl0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkU3RhdGVFcnJvcjogVGhlIGNvbm5lY3Rpb24gaGFzIG5vdCBiZWVuIGVzdGFibGlzaGVkIHlldFwiKTt0aGlzLnJlYWR5U3RhdGU9PT15Lk9QRU4mJnRoaXMuX3RyYW5zcG9ydC5zZW5kKHQucXVvdGUoZSkpfSx5LnZlcnNpb249eChcIi4vdmVyc2lvblwiKSx5LkNPTk5FQ1RJTkc9MCx5Lk9QRU49MSx5LkNMT1NJTkc9Mix5LkNMT1NFRD0zLHkucHJvdG90eXBlLl9yZWNlaXZlSW5mbz1mdW5jdGlvbihlLHQpe2lmKGIoXCJfcmVjZWl2ZUluZm9cIix0KSx0aGlzLl9pcj1udWxsLGUpe3RoaXMuX3J0bz10aGlzLmNvdW50UlRPKHQpLHRoaXMuX3RyYW5zVXJsPWUuYmFzZV91cmw/ZS5iYXNlX3VybDp0aGlzLnVybCxlPW8uZXh0ZW5kKGUsdGhpcy5fdXJsSW5mbyksYihcImluZm9cIixlKTt2YXIgbj1yLmZpbHRlclRvRW5hYmxlZCh0aGlzLl90cmFuc3BvcnRzV2hpdGVsaXN0LGUpO3RoaXMuX3RyYW5zcG9ydHM9bi5tYWluLGIodGhpcy5fdHJhbnNwb3J0cy5sZW5ndGgrXCIgZW5hYmxlZCB0cmFuc3BvcnRzXCIpLHRoaXMuX2Nvbm5lY3QoKX1lbHNlIHRoaXMuX2Nsb3NlKDEwMDIsXCJDYW5ub3QgY29ubmVjdCB0byBzZXJ2ZXJcIil9LHkucHJvdG90eXBlLl9jb25uZWN0PWZ1bmN0aW9uKCl7Zm9yKHZhciBlPXRoaXMuX3RyYW5zcG9ydHMuc2hpZnQoKTtlO2U9dGhpcy5fdHJhbnNwb3J0cy5zaGlmdCgpKXtpZihiKFwiYXR0ZW1wdFwiLGUudHJhbnNwb3J0TmFtZSksZS5uZWVkQm9keSYmKCF3LmRvY3VtZW50LmJvZHl8fHZvaWQgMCE9PXcuZG9jdW1lbnQucmVhZHlTdGF0ZSYmXCJjb21wbGV0ZVwiIT09dy5kb2N1bWVudC5yZWFkeVN0YXRlJiZcImludGVyYWN0aXZlXCIhPT13LmRvY3VtZW50LnJlYWR5U3RhdGUpKXJldHVybiBiKFwid2FpdGluZyBmb3IgYm9keVwiKSx0aGlzLl90cmFuc3BvcnRzLnVuc2hpZnQoZSksdm9pZCBpLmF0dGFjaEV2ZW50KFwibG9hZFwiLHRoaXMuX2Nvbm5lY3QuYmluZCh0aGlzKSk7dmFyIHQ9TWF0aC5tYXgodGhpcy5fdGltZW91dCx0aGlzLl9ydG8qZS5yb3VuZFRyaXBzfHw1ZTMpO3RoaXMuX3RyYW5zcG9ydFRpbWVvdXRJZD1zZXRUaW1lb3V0KHRoaXMuX3RyYW5zcG9ydFRpbWVvdXQuYmluZCh0aGlzKSx0KSxiKFwidXNpbmcgdGltZW91dFwiLHQpO3ZhciBuPWMuYWRkUGF0aCh0aGlzLl90cmFuc1VybCxcIi9cIit0aGlzLl9zZXJ2ZXIrXCIvXCIrdGhpcy5fZ2VuZXJhdGVTZXNzaW9uSWQoKSkscj10aGlzLl90cmFuc3BvcnRPcHRpb25zW2UudHJhbnNwb3J0TmFtZV07YihcInRyYW5zcG9ydCB1cmxcIixuKTt2YXIgbz1uZXcgZShuLHRoaXMuX3RyYW5zVXJsLHIpO3JldHVybiBvLm9uKFwibWVzc2FnZVwiLHRoaXMuX3RyYW5zcG9ydE1lc3NhZ2UuYmluZCh0aGlzKSksby5vbmNlKFwiY2xvc2VcIix0aGlzLl90cmFuc3BvcnRDbG9zZS5iaW5kKHRoaXMpKSxvLnRyYW5zcG9ydE5hbWU9ZS50cmFuc3BvcnROYW1lLHZvaWQodGhpcy5fdHJhbnNwb3J0PW8pfXRoaXMuX2Nsb3NlKDJlMyxcIkFsbCB0cmFuc3BvcnRzIGZhaWxlZFwiLCExKX0seS5wcm90b3R5cGUuX3RyYW5zcG9ydFRpbWVvdXQ9ZnVuY3Rpb24oKXtiKFwiX3RyYW5zcG9ydFRpbWVvdXRcIiksdGhpcy5yZWFkeVN0YXRlPT09eS5DT05ORUNUSU5HJiYodGhpcy5fdHJhbnNwb3J0JiZ0aGlzLl90cmFuc3BvcnQuY2xvc2UoKSx0aGlzLl90cmFuc3BvcnRDbG9zZSgyMDA3LFwiVHJhbnNwb3J0IHRpbWVkIG91dFwiKSl9LHkucHJvdG90eXBlLl90cmFuc3BvcnRNZXNzYWdlPWZ1bmN0aW9uKGUpe2IoXCJfdHJhbnNwb3J0TWVzc2FnZVwiLGUpO3ZhciB0LG49dGhpcyxyPWUuc2xpY2UoMCwxKSxvPWUuc2xpY2UoMSk7c3dpdGNoKHIpe2Nhc2VcIm9cIjpyZXR1cm4gdm9pZCB0aGlzLl9vcGVuKCk7Y2FzZVwiaFwiOnJldHVybiB0aGlzLmRpc3BhdGNoRXZlbnQobmV3IHMoXCJoZWFydGJlYXRcIikpLHZvaWQgYihcImhlYXJ0YmVhdFwiLHRoaXMudHJhbnNwb3J0KX1pZihvKXRyeXt0PUpTT04ucGFyc2Uobyl9Y2F0Y2goZSl7YihcImJhZCBqc29uXCIsbyl9aWYodm9pZCAwIT09dClzd2l0Y2gocil7Y2FzZVwiYVwiOkFycmF5LmlzQXJyYXkodCkmJnQuZm9yRWFjaChmdW5jdGlvbihlKXtiKFwibWVzc2FnZVwiLG4udHJhbnNwb3J0LGUpLG4uZGlzcGF0Y2hFdmVudChuZXcgbShlKSl9KTticmVhaztjYXNlXCJtXCI6YihcIm1lc3NhZ2VcIix0aGlzLnRyYW5zcG9ydCx0KSx0aGlzLmRpc3BhdGNoRXZlbnQobmV3IG0odCkpO2JyZWFrO2Nhc2VcImNcIjpBcnJheS5pc0FycmF5KHQpJiYyPT09dC5sZW5ndGgmJnRoaXMuX2Nsb3NlKHRbMF0sdFsxXSwhMCl9ZWxzZSBiKFwiZW1wdHkgcGF5bG9hZFwiLG8pfSx5LnByb3RvdHlwZS5fdHJhbnNwb3J0Q2xvc2U9ZnVuY3Rpb24oZSx0KXtiKFwiX3RyYW5zcG9ydENsb3NlXCIsdGhpcy50cmFuc3BvcnQsZSx0KSx0aGlzLl90cmFuc3BvcnQmJih0aGlzLl90cmFuc3BvcnQucmVtb3ZlQWxsTGlzdGVuZXJzKCksdGhpcy5fdHJhbnNwb3J0PW51bGwsdGhpcy50cmFuc3BvcnQ9bnVsbCksZyhlKXx8MmUzPT09ZXx8dGhpcy5yZWFkeVN0YXRlIT09eS5DT05ORUNUSU5HP3RoaXMuX2Nsb3NlKGUsdCk6dGhpcy5fY29ubmVjdCgpfSx5LnByb3RvdHlwZS5fb3Blbj1mdW5jdGlvbigpe2IoXCJfb3BlblwiLHRoaXMuX3RyYW5zcG9ydCYmdGhpcy5fdHJhbnNwb3J0LnRyYW5zcG9ydE5hbWUsdGhpcy5yZWFkeVN0YXRlKSx0aGlzLnJlYWR5U3RhdGU9PT15LkNPTk5FQ1RJTkc/KHRoaXMuX3RyYW5zcG9ydFRpbWVvdXRJZCYmKGNsZWFyVGltZW91dCh0aGlzLl90cmFuc3BvcnRUaW1lb3V0SWQpLHRoaXMuX3RyYW5zcG9ydFRpbWVvdXRJZD1udWxsKSx0aGlzLnJlYWR5U3RhdGU9eS5PUEVOLHRoaXMudHJhbnNwb3J0PXRoaXMuX3RyYW5zcG9ydC50cmFuc3BvcnROYW1lLHRoaXMuZGlzcGF0Y2hFdmVudChuZXcgcyhcIm9wZW5cIikpLGIoXCJjb25uZWN0ZWRcIix0aGlzLnRyYW5zcG9ydCkpOnRoaXMuX2Nsb3NlKDEwMDYsXCJTZXJ2ZXIgbG9zdCBzZXNzaW9uXCIpfSx5LnByb3RvdHlwZS5fY2xvc2U9ZnVuY3Rpb24odCxuLHIpe2IoXCJfY2xvc2VcIix0aGlzLnRyYW5zcG9ydCx0LG4scix0aGlzLnJlYWR5U3RhdGUpO3ZhciBvPSExO2lmKHRoaXMuX2lyJiYobz0hMCx0aGlzLl9pci5jbG9zZSgpLHRoaXMuX2lyPW51bGwpLHRoaXMuX3RyYW5zcG9ydCYmKHRoaXMuX3RyYW5zcG9ydC5jbG9zZSgpLHRoaXMuX3RyYW5zcG9ydD1udWxsLHRoaXMudHJhbnNwb3J0PW51bGwpLHRoaXMucmVhZHlTdGF0ZT09PXkuQ0xPU0VEKXRocm93IG5ldyBFcnJvcihcIkludmFsaWRTdGF0ZUVycm9yOiBTb2NrSlMgaGFzIGFscmVhZHkgYmVlbiBjbG9zZWRcIik7dGhpcy5yZWFkeVN0YXRlPXkuQ0xPU0lORyxzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7dGhpcy5yZWFkeVN0YXRlPXkuQ0xPU0VELG8mJnRoaXMuZGlzcGF0Y2hFdmVudChuZXcgcyhcImVycm9yXCIpKTt2YXIgZT1uZXcgYShcImNsb3NlXCIpO2Uud2FzQ2xlYW49cnx8ITEsZS5jb2RlPXR8fDFlMyxlLnJlYXNvbj1uLHRoaXMuZGlzcGF0Y2hFdmVudChlKSx0aGlzLm9ubWVzc2FnZT10aGlzLm9uY2xvc2U9dGhpcy5vbmVycm9yPW51bGwsYihcImRpc2Nvbm5lY3RlZFwiKX0uYmluZCh0aGlzKSwwKX0seS5wcm90b3R5cGUuY291bnRSVE89ZnVuY3Rpb24oZSl7cmV0dXJuIDEwMDxlPzQqZTozMDArZX0sXy5leHBvcnRzPWZ1bmN0aW9uKGUpe3JldHVybiByPW4oZSkseChcIi4vaWZyYW1lLWJvb3RzdHJhcFwiKSh5LGUpLHl9fSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi9ldmVudC9jbG9zZVwiOjIsXCIuL2V2ZW50L2V2ZW50XCI6NCxcIi4vZXZlbnQvZXZlbnR0YXJnZXRcIjo1LFwiLi9ldmVudC90cmFucy1tZXNzYWdlXCI6NixcIi4vaWZyYW1lLWJvb3RzdHJhcFwiOjgsXCIuL2luZm8tcmVjZWl2ZXJcIjoxMixcIi4vbG9jYXRpb25cIjoxMyxcIi4vc2hpbXNcIjoxNSxcIi4vdXRpbHMvYnJvd3NlclwiOjQ0LFwiLi91dGlscy9lc2NhcGVcIjo0NSxcIi4vdXRpbHMvZXZlbnRcIjo0NixcIi4vdXRpbHMvbG9nXCI6NDgsXCIuL3V0aWxzL29iamVjdFwiOjQ5LFwiLi91dGlscy9yYW5kb21cIjo1MCxcIi4vdXRpbHMvdHJhbnNwb3J0XCI6NTEsXCIuL3V0aWxzL3VybFwiOjUyLFwiLi92ZXJzaW9uXCI6NTMsXCJkZWJ1Z1wiOnZvaWQgMCxcImluaGVyaXRzXCI6NTQsXCJ1cmwtcGFyc2VcIjo1N31dLDE1OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7ZnVuY3Rpb24gYShlKXtyZXR1cm5cIltvYmplY3QgRnVuY3Rpb25dXCI9PT1pLnRvU3RyaW5nLmNhbGwoZSl9ZnVuY3Rpb24gbChlKXtyZXR1cm5cIltvYmplY3QgU3RyaW5nXVwiPT09Zi5jYWxsKGUpfXZhciBvLGM9QXJyYXkucHJvdG90eXBlLGk9T2JqZWN0LnByb3RvdHlwZSxyPUZ1bmN0aW9uLnByb3RvdHlwZSxzPVN0cmluZy5wcm90b3R5cGUsdT1jLnNsaWNlLGY9aS50b1N0cmluZyxoPU9iamVjdC5kZWZpbmVQcm9wZXJ0eSYmZnVuY3Rpb24oKXt0cnl7cmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7fSxcInhcIix7fSksITB9Y2F0Y2goZSl7cmV0dXJuITF9fSgpO289aD9mdW5jdGlvbihlLHQsbixyKXshciYmdCBpbiBlfHxPYmplY3QuZGVmaW5lUHJvcGVydHkoZSx0LHtjb25maWd1cmFibGU6ITAsZW51bWVyYWJsZTohMSx3cml0YWJsZTohMCx2YWx1ZTpufSl9OmZ1bmN0aW9uKGUsdCxuLHIpeyFyJiZ0IGluIGV8fChlW3RdPW4pfTtmdW5jdGlvbiBkKGUsdCxuKXtmb3IodmFyIHIgaW4gdClpLmhhc093blByb3BlcnR5LmNhbGwodCxyKSYmbyhlLHIsdFtyXSxuKX1mdW5jdGlvbiBwKGUpe2lmKG51bGw9PWUpdGhyb3cgbmV3IFR5cGVFcnJvcihcImNhbid0IGNvbnZlcnQgXCIrZStcIiB0byBvYmplY3RcIik7cmV0dXJuIE9iamVjdChlKX1mdW5jdGlvbiBtKCl7fWQocix7YmluZDpmdW5jdGlvbih0KXt2YXIgbj10aGlzO2lmKCFhKG4pKXRocm93IG5ldyBUeXBlRXJyb3IoXCJGdW5jdGlvbi5wcm90b3R5cGUuYmluZCBjYWxsZWQgb24gaW5jb21wYXRpYmxlIFwiK24pO2Zvcih2YXIgcj11LmNhbGwoYXJndW1lbnRzLDEpLGU9TWF0aC5tYXgoMCxuLmxlbmd0aC1yLmxlbmd0aCksbz1bXSxpPTA7aTxlO2krKylvLnB1c2goXCIkXCIraSk7dmFyIHM9RnVuY3Rpb24oXCJiaW5kZXJcIixcInJldHVybiBmdW5jdGlvbiAoXCIrby5qb2luKFwiLFwiKStcIil7IHJldHVybiBiaW5kZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTsgfVwiKShmdW5jdGlvbigpe2lmKHRoaXMgaW5zdGFuY2VvZiBzKXt2YXIgZT1uLmFwcGx5KHRoaXMsci5jb25jYXQodS5jYWxsKGFyZ3VtZW50cykpKTtyZXR1cm4gT2JqZWN0KGUpPT09ZT9lOnRoaXN9cmV0dXJuIG4uYXBwbHkodCxyLmNvbmNhdCh1LmNhbGwoYXJndW1lbnRzKSkpfSk7cmV0dXJuIG4ucHJvdG90eXBlJiYobS5wcm90b3R5cGU9bi5wcm90b3R5cGUscy5wcm90b3R5cGU9bmV3IG0sbS5wcm90b3R5cGU9bnVsbCksc319KSxkKEFycmF5LHtpc0FycmF5OmZ1bmN0aW9uKGUpe3JldHVyblwiW29iamVjdCBBcnJheV1cIj09PWYuY2FsbChlKX19KTt2YXIgdixiLHksZz1PYmplY3QoXCJhXCIpLHc9XCJhXCIhPT1nWzBdfHwhKDAgaW4gZyk7ZChjLHtmb3JFYWNoOmZ1bmN0aW9uKGUsdCl7dmFyIG49cCh0aGlzKSxyPXcmJmwodGhpcyk/dGhpcy5zcGxpdChcIlwiKTpuLG89dCxpPS0xLHM9ci5sZW5ndGg+Pj4wO2lmKCFhKGUpKXRocm93IG5ldyBUeXBlRXJyb3I7Zm9yKDsrK2k8czspaSBpbiByJiZlLmNhbGwobyxyW2ldLGksbil9fSwodj1jLmZvckVhY2gseT1iPSEwLHYmJih2LmNhbGwoXCJmb29cIixmdW5jdGlvbihlLHQsbil7XCJvYmplY3RcIiE9dHlwZW9mIG4mJihiPSExKX0pLHYuY2FsbChbMV0sZnVuY3Rpb24oKXt5PVwic3RyaW5nXCI9PXR5cGVvZiB0aGlzfSxcInhcIikpLCEodiYmYiYmeSkpKTt2YXIgeD1BcnJheS5wcm90b3R5cGUuaW5kZXhPZiYmLTEhPT1bMCwxXS5pbmRleE9mKDEsMik7ZChjLHtpbmRleE9mOmZ1bmN0aW9uKGUsdCl7dmFyIG49dyYmbCh0aGlzKT90aGlzLnNwbGl0KFwiXCIpOnAodGhpcykscj1uLmxlbmd0aD4+PjA7aWYoIXIpcmV0dXJuLTE7dmFyIG89MDtmb3IoMTxhcmd1bWVudHMubGVuZ3RoJiYobz1mdW5jdGlvbihlKXt2YXIgdD0rZTtyZXR1cm4gdCE9dD90PTA6MCE9PXQmJnQhPT0xLzAmJnQhPT0tMS8wJiYodD0oMDx0fHwtMSkqTWF0aC5mbG9vcihNYXRoLmFicyh0KSkpLHR9KHQpKSxvPTA8PW8/bzpNYXRoLm1heCgwLHIrbyk7bzxyO28rKylpZihvIGluIG4mJm5bb109PT1lKXJldHVybiBvO3JldHVybi0xfX0seCk7dmFyIF8sRT1zLnNwbGl0OzIhPT1cImFiXCIuc3BsaXQoLyg/OmFiKSovKS5sZW5ndGh8fDQhPT1cIi5cIi5zcGxpdCgvKC4/KSguPykvKS5sZW5ndGh8fFwidFwiPT09XCJ0ZXNzdFwiLnNwbGl0KC8ocykqLylbMV18fDQhPT1cInRlc3RcIi5zcGxpdCgvKD86KS8sLTEpLmxlbmd0aHx8XCJcIi5zcGxpdCgvLj8vKS5sZW5ndGh8fDE8XCIuXCIuc3BsaXQoLygpKCkvKS5sZW5ndGg/KF89dm9pZCAwPT09LygpPz8vLmV4ZWMoXCJcIilbMV0scy5zcGxpdD1mdW5jdGlvbihlLHQpe3ZhciBuPXRoaXM7aWYodm9pZCAwPT09ZSYmMD09PXQpcmV0dXJuW107aWYoXCJbb2JqZWN0IFJlZ0V4cF1cIiE9PWYuY2FsbChlKSlyZXR1cm4gRS5jYWxsKHRoaXMsZSx0KTt2YXIgcixvLGkscyxhPVtdLGw9KGUuaWdub3JlQ2FzZT9cImlcIjpcIlwiKSsoZS5tdWx0aWxpbmU/XCJtXCI6XCJcIikrKGUuZXh0ZW5kZWQ/XCJ4XCI6XCJcIikrKGUuc3RpY2t5P1wieVwiOlwiXCIpLHU9MDtmb3IoZT1uZXcgUmVnRXhwKGUuc291cmNlLGwrXCJnXCIpLG4rPVwiXCIsX3x8KHI9bmV3IFJlZ0V4cChcIl5cIitlLnNvdXJjZStcIiQoPyFcXFxccylcIixsKSksdD12b2lkIDA9PT10Py0xPj4+MDpmdW5jdGlvbihlKXtyZXR1cm4gZT4+PjB9KHQpOyhvPWUuZXhlYyhuKSkmJiEodTwoaT1vLmluZGV4K29bMF0ubGVuZ3RoKSYmKGEucHVzaChuLnNsaWNlKHUsby5pbmRleCkpLCFfJiYxPG8ubGVuZ3RoJiZvWzBdLnJlcGxhY2UocixmdW5jdGlvbigpe2Zvcih2YXIgZT0xO2U8YXJndW1lbnRzLmxlbmd0aC0yO2UrKyl2b2lkIDA9PT1hcmd1bWVudHNbZV0mJihvW2VdPXZvaWQgMCl9KSwxPG8ubGVuZ3RoJiZvLmluZGV4PG4ubGVuZ3RoJiZjLnB1c2guYXBwbHkoYSxvLnNsaWNlKDEpKSxzPW9bMF0ubGVuZ3RoLHU9aSxhLmxlbmd0aD49dCkpOyllLmxhc3RJbmRleD09PW8uaW5kZXgmJmUubGFzdEluZGV4Kys7cmV0dXJuIHU9PT1uLmxlbmd0aD8hcyYmZS50ZXN0KFwiXCIpfHxhLnB1c2goXCJcIik6YS5wdXNoKG4uc2xpY2UodSkpLGEubGVuZ3RoPnQ/YS5zbGljZSgwLHQpOmF9KTpcIjBcIi5zcGxpdCh2b2lkIDAsMCkubGVuZ3RoJiYocy5zcGxpdD1mdW5jdGlvbihlLHQpe3JldHVybiB2b2lkIDA9PT1lJiYwPT09dD9bXTpFLmNhbGwodGhpcyxlLHQpfSk7dmFyIFM9cy5zdWJzdHIsTz1cIlwiLnN1YnN0ciYmXCJiXCIhPT1cIjBiXCIuc3Vic3RyKC0xKTtkKHMse3N1YnN0cjpmdW5jdGlvbihlLHQpe3JldHVybiBTLmNhbGwodGhpcyxlPDAmJihlPXRoaXMubGVuZ3RoK2UpPDA/MDplLHQpfX0sTyl9LHt9XSwxNjpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3QuZXhwb3J0cz1bZShcIi4vdHJhbnNwb3J0L3dlYnNvY2tldFwiKSxlKFwiLi90cmFuc3BvcnQveGhyLXN0cmVhbWluZ1wiKSxlKFwiLi90cmFuc3BvcnQveGRyLXN0cmVhbWluZ1wiKSxlKFwiLi90cmFuc3BvcnQvZXZlbnRzb3VyY2VcIiksZShcIi4vdHJhbnNwb3J0L2xpYi9pZnJhbWUtd3JhcFwiKShlKFwiLi90cmFuc3BvcnQvZXZlbnRzb3VyY2VcIikpLGUoXCIuL3RyYW5zcG9ydC9odG1sZmlsZVwiKSxlKFwiLi90cmFuc3BvcnQvbGliL2lmcmFtZS13cmFwXCIpKGUoXCIuL3RyYW5zcG9ydC9odG1sZmlsZVwiKSksZShcIi4vdHJhbnNwb3J0L3hoci1wb2xsaW5nXCIpLGUoXCIuL3RyYW5zcG9ydC94ZHItcG9sbGluZ1wiKSxlKFwiLi90cmFuc3BvcnQvbGliL2lmcmFtZS13cmFwXCIpKGUoXCIuL3RyYW5zcG9ydC94aHItcG9sbGluZ1wiKSksZShcIi4vdHJhbnNwb3J0L2pzb25wLXBvbGxpbmdcIildfSx7XCIuL3RyYW5zcG9ydC9ldmVudHNvdXJjZVwiOjIwLFwiLi90cmFuc3BvcnQvaHRtbGZpbGVcIjoyMSxcIi4vdHJhbnNwb3J0L2pzb25wLXBvbGxpbmdcIjoyMyxcIi4vdHJhbnNwb3J0L2xpYi9pZnJhbWUtd3JhcFwiOjI2LFwiLi90cmFuc3BvcnQvd2Vic29ja2V0XCI6MzgsXCIuL3RyYW5zcG9ydC94ZHItcG9sbGluZ1wiOjM5LFwiLi90cmFuc3BvcnQveGRyLXN0cmVhbWluZ1wiOjQwLFwiLi90cmFuc3BvcnQveGhyLXBvbGxpbmdcIjo0MSxcIi4vdHJhbnNwb3J0L3hoci1zdHJlYW1pbmdcIjo0Mn1dLDE3OltmdW5jdGlvbihvLGYsZSl7KGZ1bmN0aW9uKHIpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBpPW8oXCJldmVudHNcIikuRXZlbnRFbWl0dGVyLGU9byhcImluaGVyaXRzXCIpLHM9byhcIi4uLy4uL3V0aWxzL2V2ZW50XCIpLGE9byhcIi4uLy4uL3V0aWxzL3VybFwiKSxsPXIuWE1MSHR0cFJlcXVlc3QsdT1mdW5jdGlvbigpe307ZnVuY3Rpb24gYyhlLHQsbixyKXt1KGUsdCk7dmFyIG89dGhpcztpLmNhbGwodGhpcyksc2V0VGltZW91dChmdW5jdGlvbigpe28uX3N0YXJ0KGUsdCxuLHIpfSwwKX1lKGMsaSksYy5wcm90b3R5cGUuX3N0YXJ0PWZ1bmN0aW9uKGUsdCxuLHIpe3ZhciBvPXRoaXM7dHJ5e3RoaXMueGhyPW5ldyBsfWNhdGNoKGUpe31pZighdGhpcy54aHIpcmV0dXJuIHUoXCJubyB4aHJcIiksdGhpcy5lbWl0KFwiZmluaXNoXCIsMCxcIm5vIHhociBzdXBwb3J0XCIpLHZvaWQgdGhpcy5fY2xlYW51cCgpO3Q9YS5hZGRRdWVyeSh0LFwidD1cIisgK25ldyBEYXRlKSx0aGlzLnVubG9hZFJlZj1zLnVubG9hZEFkZChmdW5jdGlvbigpe3UoXCJ1bmxvYWQgY2xlYW51cFwiKSxvLl9jbGVhbnVwKCEwKX0pO3RyeXt0aGlzLnhoci5vcGVuKGUsdCwhMCksdGhpcy50aW1lb3V0JiZcInRpbWVvdXRcImluIHRoaXMueGhyJiYodGhpcy54aHIudGltZW91dD10aGlzLnRpbWVvdXQsdGhpcy54aHIub250aW1lb3V0PWZ1bmN0aW9uKCl7dShcInhociB0aW1lb3V0XCIpLG8uZW1pdChcImZpbmlzaFwiLDAsXCJcIiksby5fY2xlYW51cCghMSl9KX1jYXRjaChlKXtyZXR1cm4gdShcImV4Y2VwdGlvblwiLGUpLHRoaXMuZW1pdChcImZpbmlzaFwiLDAsXCJcIiksdm9pZCB0aGlzLl9jbGVhbnVwKCExKX1pZihyJiZyLm5vQ3JlZGVudGlhbHN8fCFjLnN1cHBvcnRzQ09SU3x8KHUoXCJ3aXRoQ3JlZGVudGlhbHNcIiksdGhpcy54aHIud2l0aENyZWRlbnRpYWxzPSEwKSxyJiZyLmhlYWRlcnMpZm9yKHZhciBpIGluIHIuaGVhZGVycyl0aGlzLnhoci5zZXRSZXF1ZXN0SGVhZGVyKGksci5oZWFkZXJzW2ldKTt0aGlzLnhoci5vbnJlYWR5c3RhdGVjaGFuZ2U9ZnVuY3Rpb24oKXtpZihvLnhocil7dmFyIGUsdCxuPW8ueGhyO3N3aXRjaCh1KFwicmVhZHlTdGF0ZVwiLG4ucmVhZHlTdGF0ZSksbi5yZWFkeVN0YXRlKXtjYXNlIDM6dHJ5e3Q9bi5zdGF0dXMsZT1uLnJlc3BvbnNlVGV4dH1jYXRjaChlKXt9dShcInN0YXR1c1wiLHQpLDEyMjM9PT10JiYodD0yMDQpLDIwMD09PXQmJmUmJjA8ZS5sZW5ndGgmJih1KFwiY2h1bmtcIiksby5lbWl0KFwiY2h1bmtcIix0LGUpKTticmVhaztjYXNlIDQ6dD1uLnN0YXR1cyx1KFwic3RhdHVzXCIsdCksMTIyMz09PXQmJih0PTIwNCksMTIwMDUhPT10JiYxMjAyOSE9PXR8fCh0PTApLHUoXCJmaW5pc2hcIix0LG4ucmVzcG9uc2VUZXh0KSxvLmVtaXQoXCJmaW5pc2hcIix0LG4ucmVzcG9uc2VUZXh0KSxvLl9jbGVhbnVwKCExKX19fTt0cnl7by54aHIuc2VuZChuKX1jYXRjaChlKXtvLmVtaXQoXCJmaW5pc2hcIiwwLFwiXCIpLG8uX2NsZWFudXAoITEpfX0sYy5wcm90b3R5cGUuX2NsZWFudXA9ZnVuY3Rpb24oZSl7aWYodShcImNsZWFudXBcIiksdGhpcy54aHIpe2lmKHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCkscy51bmxvYWREZWwodGhpcy51bmxvYWRSZWYpLHRoaXMueGhyLm9ucmVhZHlzdGF0ZWNoYW5nZT1mdW5jdGlvbigpe30sdGhpcy54aHIub250aW1lb3V0JiYodGhpcy54aHIub250aW1lb3V0PW51bGwpLGUpdHJ5e3RoaXMueGhyLmFib3J0KCl9Y2F0Y2goZSl7fXRoaXMudW5sb2FkUmVmPXRoaXMueGhyPW51bGx9fSxjLnByb3RvdHlwZS5jbG9zZT1mdW5jdGlvbigpe3UoXCJjbG9zZVwiKSx0aGlzLl9jbGVhbnVwKCEwKX0sYy5lbmFibGVkPSEhbDt2YXIgdD1bXCJBY3RpdmVcIl0uY29uY2F0KFwiT2JqZWN0XCIpLmpvaW4oXCJYXCIpOyFjLmVuYWJsZWQmJnQgaW4gciYmKHUoXCJvdmVycmlkaW5nIHhtbGh0dHByZXF1ZXN0XCIpLGMuZW5hYmxlZD0hIW5ldyhsPWZ1bmN0aW9uKCl7dHJ5e3JldHVybiBuZXcgclt0XShcIk1pY3Jvc29mdC5YTUxIVFRQXCIpfWNhdGNoKGUpe3JldHVybiBudWxsfX0pKTt2YXIgbj0hMTt0cnl7bj1cIndpdGhDcmVkZW50aWFsc1wiaW4gbmV3IGx9Y2F0Y2goZSl7fWMuc3VwcG9ydHNDT1JTPW4sZi5leHBvcnRzPWN9KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7XCIuLi8uLi91dGlscy9ldmVudFwiOjQ2LFwiLi4vLi4vdXRpbHMvdXJsXCI6NTIsXCJkZWJ1Z1wiOnZvaWQgMCxcImV2ZW50c1wiOjMsXCJpbmhlcml0c1wiOjU0fV0sMTg6W2Z1bmN0aW9uKGUsdCxuKXsoZnVuY3Rpb24oZSl7KGZ1bmN0aW9uKCl7dC5leHBvcnRzPWUuRXZlbnRTb3VyY2V9KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7fV0sMTk6W2Z1bmN0aW9uKGUsbix0KXsoZnVuY3Rpb24oZSl7KGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9ZS5XZWJTb2NrZXR8fGUuTW96V2ViU29ja2V0O24uZXhwb3J0cz10P2Z1bmN0aW9uKGUpe3JldHVybiBuZXcgdChlKX06dm9pZCAwfSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se31dLDIwOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcIi4vbGliL2FqYXgtYmFzZWRcIiksaT1lKFwiLi9yZWNlaXZlci9ldmVudHNvdXJjZVwiKSxzPWUoXCIuL3NlbmRlci94aHItY29yc1wiKSxhPWUoXCJldmVudHNvdXJjZVwiKTtmdW5jdGlvbiBsKGUpe2lmKCFsLmVuYWJsZWQoKSl0aHJvdyBuZXcgRXJyb3IoXCJUcmFuc3BvcnQgY3JlYXRlZCB3aGVuIGRpc2FibGVkXCIpO28uY2FsbCh0aGlzLGUsXCIvZXZlbnRzb3VyY2VcIixpLHMpfXIobCxvKSxsLmVuYWJsZWQ9ZnVuY3Rpb24oKXtyZXR1cm4hIWF9LGwudHJhbnNwb3J0TmFtZT1cImV2ZW50c291cmNlXCIsbC5yb3VuZFRyaXBzPTIsdC5leHBvcnRzPWx9LHtcIi4vbGliL2FqYXgtYmFzZWRcIjoyNCxcIi4vcmVjZWl2ZXIvZXZlbnRzb3VyY2VcIjoyOSxcIi4vc2VuZGVyL3hoci1jb3JzXCI6MzUsXCJldmVudHNvdXJjZVwiOjE4LFwiaW5oZXJpdHNcIjo1NH1dLDIxOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcIi4vcmVjZWl2ZXIvaHRtbGZpbGVcIiksaT1lKFwiLi9zZW5kZXIveGhyLWxvY2FsXCIpLHM9ZShcIi4vbGliL2FqYXgtYmFzZWRcIik7ZnVuY3Rpb24gYShlKXtpZighby5lbmFibGVkKXRocm93IG5ldyBFcnJvcihcIlRyYW5zcG9ydCBjcmVhdGVkIHdoZW4gZGlzYWJsZWRcIik7cy5jYWxsKHRoaXMsZSxcIi9odG1sZmlsZVwiLG8saSl9cihhLHMpLGEuZW5hYmxlZD1mdW5jdGlvbihlKXtyZXR1cm4gby5lbmFibGVkJiZlLnNhbWVPcmlnaW59LGEudHJhbnNwb3J0TmFtZT1cImh0bWxmaWxlXCIsYS5yb3VuZFRyaXBzPTIsdC5leHBvcnRzPWF9LHtcIi4vbGliL2FqYXgtYmFzZWRcIjoyNCxcIi4vcmVjZWl2ZXIvaHRtbGZpbGVcIjozMCxcIi4vc2VuZGVyL3hoci1sb2NhbFwiOjM3LFwiaW5oZXJpdHNcIjo1NH1dLDIyOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLGk9ZShcImV2ZW50c1wiKS5FdmVudEVtaXR0ZXIsbz1lKFwiLi4vdmVyc2lvblwiKSxzPWUoXCIuLi91dGlscy91cmxcIiksYT1lKFwiLi4vdXRpbHMvaWZyYW1lXCIpLGw9ZShcIi4uL3V0aWxzL2V2ZW50XCIpLHU9ZShcIi4uL3V0aWxzL3JhbmRvbVwiKSxjPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBmKGUsdCxuKXtpZighZi5lbmFibGVkKCkpdGhyb3cgbmV3IEVycm9yKFwiVHJhbnNwb3J0IGNyZWF0ZWQgd2hlbiBkaXNhYmxlZFwiKTtpLmNhbGwodGhpcyk7dmFyIHI9dGhpczt0aGlzLm9yaWdpbj1zLmdldE9yaWdpbihuKSx0aGlzLmJhc2VVcmw9bix0aGlzLnRyYW5zVXJsPXQsdGhpcy50cmFuc3BvcnQ9ZSx0aGlzLndpbmRvd0lkPXUuc3RyaW5nKDgpO3ZhciBvPXMuYWRkUGF0aChuLFwiL2lmcmFtZS5odG1sXCIpK1wiI1wiK3RoaXMud2luZG93SWQ7YyhlLHQsbyksdGhpcy5pZnJhbWVPYmo9YS5jcmVhdGVJZnJhbWUobyxmdW5jdGlvbihlKXtjKFwiZXJyIGNhbGxiYWNrXCIpLHIuZW1pdChcImNsb3NlXCIsMTAwNixcIlVuYWJsZSB0byBsb2FkIGFuIGlmcmFtZSAoXCIrZStcIilcIiksci5jbG9zZSgpfSksdGhpcy5vbm1lc3NhZ2VDYWxsYmFjaz10aGlzLl9tZXNzYWdlLmJpbmQodGhpcyksbC5hdHRhY2hFdmVudChcIm1lc3NhZ2VcIix0aGlzLm9ubWVzc2FnZUNhbGxiYWNrKX1yKGYsaSksZi5wcm90b3R5cGUuY2xvc2U9ZnVuY3Rpb24oKXtpZihjKFwiY2xvc2VcIiksdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKSx0aGlzLmlmcmFtZU9iail7bC5kZXRhY2hFdmVudChcIm1lc3NhZ2VcIix0aGlzLm9ubWVzc2FnZUNhbGxiYWNrKTt0cnl7dGhpcy5wb3N0TWVzc2FnZShcImNcIil9Y2F0Y2goZSl7fXRoaXMuaWZyYW1lT2JqLmNsZWFudXAoKSx0aGlzLmlmcmFtZU9iaj1udWxsLHRoaXMub25tZXNzYWdlQ2FsbGJhY2s9dGhpcy5pZnJhbWVPYmo9bnVsbH19LGYucHJvdG90eXBlLl9tZXNzYWdlPWZ1bmN0aW9uKHQpe2lmKGMoXCJtZXNzYWdlXCIsdC5kYXRhKSxzLmlzT3JpZ2luRXF1YWwodC5vcmlnaW4sdGhpcy5vcmlnaW4pKXt2YXIgbjt0cnl7bj1KU09OLnBhcnNlKHQuZGF0YSl9Y2F0Y2goZSl7cmV0dXJuIHZvaWQgYyhcImJhZCBqc29uXCIsdC5kYXRhKX1pZihuLndpbmRvd0lkPT09dGhpcy53aW5kb3dJZClzd2l0Y2gobi50eXBlKXtjYXNlXCJzXCI6dGhpcy5pZnJhbWVPYmoubG9hZGVkKCksdGhpcy5wb3N0TWVzc2FnZShcInNcIixKU09OLnN0cmluZ2lmeShbbyx0aGlzLnRyYW5zcG9ydCx0aGlzLnRyYW5zVXJsLHRoaXMuYmFzZVVybF0pKTticmVhaztjYXNlXCJ0XCI6dGhpcy5lbWl0KFwibWVzc2FnZVwiLG4uZGF0YSk7YnJlYWs7Y2FzZVwiY1wiOnZhciBlO3RyeXtlPUpTT04ucGFyc2Uobi5kYXRhKX1jYXRjaChlKXtyZXR1cm4gdm9pZCBjKFwiYmFkIGpzb25cIixuLmRhdGEpfXRoaXMuZW1pdChcImNsb3NlXCIsZVswXSxlWzFdKSx0aGlzLmNsb3NlKCl9ZWxzZSBjKFwibWlzbWF0Y2hlZCB3aW5kb3cgaWRcIixuLndpbmRvd0lkLHRoaXMud2luZG93SWQpfWVsc2UgYyhcIm5vdCBzYW1lIG9yaWdpblwiLHQub3JpZ2luLHRoaXMub3JpZ2luKX0sZi5wcm90b3R5cGUucG9zdE1lc3NhZ2U9ZnVuY3Rpb24oZSx0KXtjKFwicG9zdE1lc3NhZ2VcIixlLHQpLHRoaXMuaWZyYW1lT2JqLnBvc3QoSlNPTi5zdHJpbmdpZnkoe3dpbmRvd0lkOnRoaXMud2luZG93SWQsdHlwZTplLGRhdGE6dHx8XCJcIn0pLHRoaXMub3JpZ2luKX0sZi5wcm90b3R5cGUuc2VuZD1mdW5jdGlvbihlKXtjKFwic2VuZFwiLGUpLHRoaXMucG9zdE1lc3NhZ2UoXCJtXCIsZSl9LGYuZW5hYmxlZD1mdW5jdGlvbigpe3JldHVybiBhLmlmcmFtZUVuYWJsZWR9LGYudHJhbnNwb3J0TmFtZT1cImlmcmFtZVwiLGYucm91bmRUcmlwcz0yLHQuZXhwb3J0cz1mfSx7XCIuLi91dGlscy9ldmVudFwiOjQ2LFwiLi4vdXRpbHMvaWZyYW1lXCI6NDcsXCIuLi91dGlscy9yYW5kb21cIjo1MCxcIi4uL3V0aWxzL3VybFwiOjUyLFwiLi4vdmVyc2lvblwiOjUzLFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDIzOltmdW5jdGlvbihzLGEsZSl7KGZ1bmN0aW9uKGkpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBlPXMoXCJpbmhlcml0c1wiKSx0PXMoXCIuL2xpYi9zZW5kZXItcmVjZWl2ZXJcIiksbj1zKFwiLi9yZWNlaXZlci9qc29ucFwiKSxyPXMoXCIuL3NlbmRlci9qc29ucFwiKTtmdW5jdGlvbiBvKGUpe2lmKCFvLmVuYWJsZWQoKSl0aHJvdyBuZXcgRXJyb3IoXCJUcmFuc3BvcnQgY3JlYXRlZCB3aGVuIGRpc2FibGVkXCIpO3QuY2FsbCh0aGlzLGUsXCIvanNvbnBcIixyLG4pfWUobyx0KSxvLmVuYWJsZWQ9ZnVuY3Rpb24oKXtyZXR1cm4hIWkuZG9jdW1lbnR9LG8udHJhbnNwb3J0TmFtZT1cImpzb25wLXBvbGxpbmdcIixvLnJvdW5kVHJpcHM9MSxvLm5lZWRCb2R5PSEwLGEuZXhwb3J0cz1vfSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi9saWIvc2VuZGVyLXJlY2VpdmVyXCI6MjgsXCIuL3JlY2VpdmVyL2pzb25wXCI6MzEsXCIuL3NlbmRlci9qc29ucFwiOjMzLFwiaW5oZXJpdHNcIjo1NH1dLDI0OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLGE9ZShcIi4uLy4uL3V0aWxzL3VybFwiKSxvPWUoXCIuL3NlbmRlci1yZWNlaXZlclwiKSxsPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBpKGUsdCxuLHIpe28uY2FsbCh0aGlzLGUsdCxmdW5jdGlvbihzKXtyZXR1cm4gZnVuY3Rpb24oZSx0LG4pe2woXCJjcmVhdGUgYWpheCBzZW5kZXJcIixlLHQpO3ZhciByPXt9O1wic3RyaW5nXCI9PXR5cGVvZiB0JiYoci5oZWFkZXJzPXtcIkNvbnRlbnQtdHlwZVwiOlwidGV4dC9wbGFpblwifSk7dmFyIG89YS5hZGRQYXRoKGUsXCIveGhyX3NlbmRcIiksaT1uZXcgcyhcIlBPU1RcIixvLHQscik7cmV0dXJuIGkub25jZShcImZpbmlzaFwiLGZ1bmN0aW9uKGUpe2lmKGwoXCJmaW5pc2hcIixlKSxpPW51bGwsMjAwIT09ZSYmMjA0IT09ZSlyZXR1cm4gbihuZXcgRXJyb3IoXCJodHRwIHN0YXR1cyBcIitlKSk7bigpfSksZnVuY3Rpb24oKXtsKFwiYWJvcnRcIiksaS5jbG9zZSgpLGk9bnVsbDt2YXIgZT1uZXcgRXJyb3IoXCJBYm9ydGVkXCIpO2UuY29kZT0xZTMsbihlKX19fShyKSxuLHIpfXIoaSxvKSx0LmV4cG9ydHM9aX0se1wiLi4vLi4vdXRpbHMvdXJsXCI6NTIsXCIuL3NlbmRlci1yZWNlaXZlclwiOjI4LFwiZGVidWdcIjp2b2lkIDAsXCJpbmhlcml0c1wiOjU0fV0sMjU6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiaW5oZXJpdHNcIiksbz1lKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlcixpPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBzKGUsdCl7aShlKSxvLmNhbGwodGhpcyksdGhpcy5zZW5kQnVmZmVyPVtdLHRoaXMuc2VuZGVyPXQsdGhpcy51cmw9ZX1yKHMsbykscy5wcm90b3R5cGUuc2VuZD1mdW5jdGlvbihlKXtpKFwic2VuZFwiLGUpLHRoaXMuc2VuZEJ1ZmZlci5wdXNoKGUpLHRoaXMuc2VuZFN0b3B8fHRoaXMuc2VuZFNjaGVkdWxlKCl9LHMucHJvdG90eXBlLnNlbmRTY2hlZHVsZVdhaXQ9ZnVuY3Rpb24oKXtpKFwic2VuZFNjaGVkdWxlV2FpdFwiKTt2YXIgZSx0PXRoaXM7dGhpcy5zZW5kU3RvcD1mdW5jdGlvbigpe2koXCJzZW5kU3RvcFwiKSx0LnNlbmRTdG9wPW51bGwsY2xlYXJUaW1lb3V0KGUpfSxlPXNldFRpbWVvdXQoZnVuY3Rpb24oKXtpKFwidGltZW91dFwiKSx0LnNlbmRTdG9wPW51bGwsdC5zZW5kU2NoZWR1bGUoKX0sMjUpfSxzLnByb3RvdHlwZS5zZW5kU2NoZWR1bGU9ZnVuY3Rpb24oKXtpKFwic2VuZFNjaGVkdWxlXCIsdGhpcy5zZW5kQnVmZmVyLmxlbmd0aCk7dmFyIHQ9dGhpcztpZigwPHRoaXMuc2VuZEJ1ZmZlci5sZW5ndGgpe3ZhciBlPVwiW1wiK3RoaXMuc2VuZEJ1ZmZlci5qb2luKFwiLFwiKStcIl1cIjt0aGlzLnNlbmRTdG9wPXRoaXMuc2VuZGVyKHRoaXMudXJsLGUsZnVuY3Rpb24oZSl7dC5zZW5kU3RvcD1udWxsLGU/KGkoXCJlcnJvclwiLGUpLHQuZW1pdChcImNsb3NlXCIsZS5jb2RlfHwxMDA2LFwiU2VuZGluZyBlcnJvcjogXCIrZSksdC5jbG9zZSgpKTp0LnNlbmRTY2hlZHVsZVdhaXQoKX0pLHRoaXMuc2VuZEJ1ZmZlcj1bXX19LHMucHJvdG90eXBlLl9jbGVhbnVwPWZ1bmN0aW9uKCl7aShcIl9jbGVhbnVwXCIpLHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCl9LHMucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKCl7aShcImNsb3NlXCIpLHRoaXMuX2NsZWFudXAoKSx0aGlzLnNlbmRTdG9wJiYodGhpcy5zZW5kU3RvcCgpLHRoaXMuc2VuZFN0b3A9bnVsbCl9LHQuZXhwb3J0cz1zfSx7XCJkZWJ1Z1wiOnZvaWQgMCxcImV2ZW50c1wiOjMsXCJpbmhlcml0c1wiOjU0fV0sMjY6W2Z1bmN0aW9uKGUsbix0KXsoZnVuY3Rpb24ocyl7KGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9ZShcImluaGVyaXRzXCIpLG89ZShcIi4uL2lmcmFtZVwiKSxpPWUoXCIuLi8uLi91dGlscy9vYmplY3RcIik7bi5leHBvcnRzPWZ1bmN0aW9uKHIpe2Z1bmN0aW9uIGUoZSx0KXtvLmNhbGwodGhpcyxyLnRyYW5zcG9ydE5hbWUsZSx0KX1yZXR1cm4gdChlLG8pLGUuZW5hYmxlZD1mdW5jdGlvbihlLHQpe2lmKCFzLmRvY3VtZW50KXJldHVybiExO3ZhciBuPWkuZXh0ZW5kKHt9LHQpO3JldHVybiBuLnNhbWVPcmlnaW49ITAsci5lbmFibGVkKG4pJiZvLmVuYWJsZWQoKX0sZS50cmFuc3BvcnROYW1lPVwiaWZyYW1lLVwiK3IudHJhbnNwb3J0TmFtZSxlLm5lZWRCb2R5PSEwLGUucm91bmRUcmlwcz1vLnJvdW5kVHJpcHMrci5yb3VuZFRyaXBzLTEsZS5mYWNhZGVUcmFuc3BvcnQ9cixlfX0pLmNhbGwodGhpcyl9KS5jYWxsKHRoaXMsXCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbD9nbG9iYWw6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHNlbGY/c2VsZjpcInVuZGVmaW5lZFwiIT10eXBlb2Ygd2luZG93P3dpbmRvdzp7fSl9LHtcIi4uLy4uL3V0aWxzL29iamVjdFwiOjQ5LFwiLi4vaWZyYW1lXCI6MjIsXCJpbmhlcml0c1wiOjU0fV0sMjc6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiaW5oZXJpdHNcIiksbz1lKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlcixpPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBzKGUsdCxuKXtpKHQpLG8uY2FsbCh0aGlzKSx0aGlzLlJlY2VpdmVyPWUsdGhpcy5yZWNlaXZlVXJsPXQsdGhpcy5BamF4T2JqZWN0PW4sdGhpcy5fc2NoZWR1bGVSZWNlaXZlcigpfXIocyxvKSxzLnByb3RvdHlwZS5fc2NoZWR1bGVSZWNlaXZlcj1mdW5jdGlvbigpe2koXCJfc2NoZWR1bGVSZWNlaXZlclwiKTt2YXIgbj10aGlzLHI9dGhpcy5wb2xsPW5ldyB0aGlzLlJlY2VpdmVyKHRoaXMucmVjZWl2ZVVybCx0aGlzLkFqYXhPYmplY3QpO3Iub24oXCJtZXNzYWdlXCIsZnVuY3Rpb24oZSl7aShcIm1lc3NhZ2VcIixlKSxuLmVtaXQoXCJtZXNzYWdlXCIsZSl9KSxyLm9uY2UoXCJjbG9zZVwiLGZ1bmN0aW9uKGUsdCl7aShcImNsb3NlXCIsZSx0LG4ucG9sbElzQ2xvc2luZyksbi5wb2xsPXI9bnVsbCxuLnBvbGxJc0Nsb3Npbmd8fChcIm5ldHdvcmtcIj09PXQ/bi5fc2NoZWR1bGVSZWNlaXZlcigpOihuLmVtaXQoXCJjbG9zZVwiLGV8fDEwMDYsdCksbi5yZW1vdmVBbGxMaXN0ZW5lcnMoKSkpfSl9LHMucHJvdG90eXBlLmFib3J0PWZ1bmN0aW9uKCl7aShcImFib3J0XCIpLHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCksdGhpcy5wb2xsSXNDbG9zaW5nPSEwLHRoaXMucG9sbCYmdGhpcy5wb2xsLmFib3J0KCl9LHQuZXhwb3J0cz1zfSx7XCJkZWJ1Z1wiOnZvaWQgMCxcImV2ZW50c1wiOjMsXCJpbmhlcml0c1wiOjU0fV0sMjg6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiaW5oZXJpdHNcIiksYT1lKFwiLi4vLi4vdXRpbHMvdXJsXCIpLGw9ZShcIi4vYnVmZmVyZWQtc2VuZGVyXCIpLHU9ZShcIi4vcG9sbGluZ1wiKSxjPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBvKGUsdCxuLHIsbyl7dmFyIGk9YS5hZGRQYXRoKGUsdCk7YyhpKTt2YXIgcz10aGlzO2wuY2FsbCh0aGlzLGUsbiksdGhpcy5wb2xsPW5ldyB1KHIsaSxvKSx0aGlzLnBvbGwub24oXCJtZXNzYWdlXCIsZnVuY3Rpb24oZSl7YyhcInBvbGwgbWVzc2FnZVwiLGUpLHMuZW1pdChcIm1lc3NhZ2VcIixlKX0pLHRoaXMucG9sbC5vbmNlKFwiY2xvc2VcIixmdW5jdGlvbihlLHQpe2MoXCJwb2xsIGNsb3NlXCIsZSx0KSxzLnBvbGw9bnVsbCxzLmVtaXQoXCJjbG9zZVwiLGUsdCkscy5jbG9zZSgpfSl9cihvLGwpLG8ucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKCl7bC5wcm90b3R5cGUuY2xvc2UuY2FsbCh0aGlzKSxjKFwiY2xvc2VcIiksdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKSx0aGlzLnBvbGwmJih0aGlzLnBvbGwuYWJvcnQoKSx0aGlzLnBvbGw9bnVsbCl9LHQuZXhwb3J0cz1vfSx7XCIuLi8uLi91dGlscy91cmxcIjo1MixcIi4vYnVmZmVyZWQtc2VuZGVyXCI6MjUsXCIuL3BvbGxpbmdcIjoyNyxcImRlYnVnXCI6dm9pZCAwLFwiaW5oZXJpdHNcIjo1NH1dLDI5OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcImV2ZW50c1wiKS5FdmVudEVtaXR0ZXIsaT1lKFwiZXZlbnRzb3VyY2VcIikscz1mdW5jdGlvbigpe307ZnVuY3Rpb24gYShlKXtzKGUpLG8uY2FsbCh0aGlzKTt2YXIgbj10aGlzLHI9dGhpcy5lcz1uZXcgaShlKTtyLm9ubWVzc2FnZT1mdW5jdGlvbihlKXtzKFwibWVzc2FnZVwiLGUuZGF0YSksbi5lbWl0KFwibWVzc2FnZVwiLGRlY29kZVVSSShlLmRhdGEpKX0sci5vbmVycm9yPWZ1bmN0aW9uKGUpe3MoXCJlcnJvclwiLHIucmVhZHlTdGF0ZSxlKTt2YXIgdD0yIT09ci5yZWFkeVN0YXRlP1wibmV0d29ya1wiOlwicGVybWFuZW50XCI7bi5fY2xlYW51cCgpLG4uX2Nsb3NlKHQpfX1yKGEsbyksYS5wcm90b3R5cGUuYWJvcnQ9ZnVuY3Rpb24oKXtzKFwiYWJvcnRcIiksdGhpcy5fY2xlYW51cCgpLHRoaXMuX2Nsb3NlKFwidXNlclwiKX0sYS5wcm90b3R5cGUuX2NsZWFudXA9ZnVuY3Rpb24oKXtzKFwiY2xlYW51cFwiKTt2YXIgZT10aGlzLmVzO2UmJihlLm9ubWVzc2FnZT1lLm9uZXJyb3I9bnVsbCxlLmNsb3NlKCksdGhpcy5lcz1udWxsKX0sYS5wcm90b3R5cGUuX2Nsb3NlPWZ1bmN0aW9uKGUpe3MoXCJjbG9zZVwiLGUpO3ZhciB0PXRoaXM7c2V0VGltZW91dChmdW5jdGlvbigpe3QuZW1pdChcImNsb3NlXCIsbnVsbCxlKSx0LnJlbW92ZUFsbExpc3RlbmVycygpfSwyMDApfSx0LmV4cG9ydHM9YX0se1wiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiZXZlbnRzb3VyY2VcIjoxOCxcImluaGVyaXRzXCI6NTR9XSwzMDpbZnVuY3Rpb24obixjLGUpeyhmdW5jdGlvbih1KXsoZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjt2YXIgZT1uKFwiaW5oZXJpdHNcIikscj1uKFwiLi4vLi4vdXRpbHMvaWZyYW1lXCIpLG89bihcIi4uLy4uL3V0aWxzL3VybFwiKSxpPW4oXCJldmVudHNcIikuRXZlbnRFbWl0dGVyLHM9bihcIi4uLy4uL3V0aWxzL3JhbmRvbVwiKSxhPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBsKGUpe2EoZSksaS5jYWxsKHRoaXMpO3ZhciB0PXRoaXM7ci5wb2xsdXRlR2xvYmFsTmFtZXNwYWNlKCksdGhpcy5pZD1cImFcIitzLnN0cmluZyg2KSxlPW8uYWRkUXVlcnkoZSxcImM9XCIrZGVjb2RlVVJJQ29tcG9uZW50KHIuV1ByZWZpeCtcIi5cIit0aGlzLmlkKSksYShcInVzaW5nIGh0bWxmaWxlXCIsbC5odG1sZmlsZUVuYWJsZWQpO3ZhciBuPWwuaHRtbGZpbGVFbmFibGVkP3IuY3JlYXRlSHRtbGZpbGU6ci5jcmVhdGVJZnJhbWU7dVtyLldQcmVmaXhdW3RoaXMuaWRdPXtzdGFydDpmdW5jdGlvbigpe2EoXCJzdGFydFwiKSx0LmlmcmFtZU9iai5sb2FkZWQoKX0sbWVzc2FnZTpmdW5jdGlvbihlKXthKFwibWVzc2FnZVwiLGUpLHQuZW1pdChcIm1lc3NhZ2VcIixlKX0sc3RvcDpmdW5jdGlvbigpe2EoXCJzdG9wXCIpLHQuX2NsZWFudXAoKSx0Ll9jbG9zZShcIm5ldHdvcmtcIil9fSx0aGlzLmlmcmFtZU9iaj1uKGUsZnVuY3Rpb24oKXthKFwiY2FsbGJhY2tcIiksdC5fY2xlYW51cCgpLHQuX2Nsb3NlKFwicGVybWFuZW50XCIpfSl9ZShsLGkpLGwucHJvdG90eXBlLmFib3J0PWZ1bmN0aW9uKCl7YShcImFib3J0XCIpLHRoaXMuX2NsZWFudXAoKSx0aGlzLl9jbG9zZShcInVzZXJcIil9LGwucHJvdG90eXBlLl9jbGVhbnVwPWZ1bmN0aW9uKCl7YShcIl9jbGVhbnVwXCIpLHRoaXMuaWZyYW1lT2JqJiYodGhpcy5pZnJhbWVPYmouY2xlYW51cCgpLHRoaXMuaWZyYW1lT2JqPW51bGwpLGRlbGV0ZSB1W3IuV1ByZWZpeF1bdGhpcy5pZF19LGwucHJvdG90eXBlLl9jbG9zZT1mdW5jdGlvbihlKXthKFwiX2Nsb3NlXCIsZSksdGhpcy5lbWl0KFwiY2xvc2VcIixudWxsLGUpLHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCl9LGwuaHRtbGZpbGVFbmFibGVkPSExO3ZhciB0PVtcIkFjdGl2ZVwiXS5jb25jYXQoXCJPYmplY3RcIikuam9pbihcIlhcIik7aWYodCBpbiB1KXRyeXtsLmh0bWxmaWxlRW5hYmxlZD0hIW5ldyB1W3RdKFwiaHRtbGZpbGVcIil9Y2F0Y2goZSl7fWwuZW5hYmxlZD1sLmh0bWxmaWxlRW5hYmxlZHx8ci5pZnJhbWVFbmFibGVkLGMuZXhwb3J0cz1sfSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi4vLi4vdXRpbHMvaWZyYW1lXCI6NDcsXCIuLi8uLi91dGlscy9yYW5kb21cIjo1MCxcIi4uLy4uL3V0aWxzL3VybFwiOjUyLFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDMxOltmdW5jdGlvbih0LG4sZSl7KGZ1bmN0aW9uKGMpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciByPXQoXCIuLi8uLi91dGlscy9pZnJhbWVcIiksaT10KFwiLi4vLi4vdXRpbHMvcmFuZG9tXCIpLHM9dChcIi4uLy4uL3V0aWxzL2Jyb3dzZXJcIiksbz10KFwiLi4vLi4vdXRpbHMvdXJsXCIpLGU9dChcImluaGVyaXRzXCIpLGE9dChcImV2ZW50c1wiKS5FdmVudEVtaXR0ZXIsbD1mdW5jdGlvbigpe307ZnVuY3Rpb24gdShlKXtsKGUpO3ZhciB0PXRoaXM7YS5jYWxsKHRoaXMpLHIucG9sbHV0ZUdsb2JhbE5hbWVzcGFjZSgpLHRoaXMuaWQ9XCJhXCIraS5zdHJpbmcoNik7dmFyIG49by5hZGRRdWVyeShlLFwiYz1cIitlbmNvZGVVUklDb21wb25lbnQoci5XUHJlZml4K1wiLlwiK3RoaXMuaWQpKTtjW3IuV1ByZWZpeF1bdGhpcy5pZF09dGhpcy5fY2FsbGJhY2suYmluZCh0aGlzKSx0aGlzLl9jcmVhdGVTY3JpcHQobiksdGhpcy50aW1lb3V0SWQ9c2V0VGltZW91dChmdW5jdGlvbigpe2woXCJ0aW1lb3V0XCIpLHQuX2Fib3J0KG5ldyBFcnJvcihcIkpTT05QIHNjcmlwdCBsb2FkZWQgYWJub3JtYWxseSAodGltZW91dClcIikpfSx1LnRpbWVvdXQpfWUodSxhKSx1LnByb3RvdHlwZS5hYm9ydD1mdW5jdGlvbigpe2lmKGwoXCJhYm9ydFwiKSxjW3IuV1ByZWZpeF1bdGhpcy5pZF0pe3ZhciBlPW5ldyBFcnJvcihcIkpTT05QIHVzZXIgYWJvcnRlZCByZWFkXCIpO2UuY29kZT0xZTMsdGhpcy5fYWJvcnQoZSl9fSx1LnRpbWVvdXQ9MzVlMyx1LnNjcmlwdEVycm9yVGltZW91dD0xZTMsdS5wcm90b3R5cGUuX2NhbGxiYWNrPWZ1bmN0aW9uKGUpe2woXCJfY2FsbGJhY2tcIixlKSx0aGlzLl9jbGVhbnVwKCksdGhpcy5hYm9ydGluZ3x8KGUmJihsKFwibWVzc2FnZVwiLGUpLHRoaXMuZW1pdChcIm1lc3NhZ2VcIixlKSksdGhpcy5lbWl0KFwiY2xvc2VcIixudWxsLFwibmV0d29ya1wiKSx0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpKX0sdS5wcm90b3R5cGUuX2Fib3J0PWZ1bmN0aW9uKGUpe2woXCJfYWJvcnRcIixlKSx0aGlzLl9jbGVhbnVwKCksdGhpcy5hYm9ydGluZz0hMCx0aGlzLmVtaXQoXCJjbG9zZVwiLGUuY29kZSxlLm1lc3NhZ2UpLHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCl9LHUucHJvdG90eXBlLl9jbGVhbnVwPWZ1bmN0aW9uKCl7aWYobChcIl9jbGVhbnVwXCIpLGNsZWFyVGltZW91dCh0aGlzLnRpbWVvdXRJZCksdGhpcy5zY3JpcHQyJiYodGhpcy5zY3JpcHQyLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQodGhpcy5zY3JpcHQyKSx0aGlzLnNjcmlwdDI9bnVsbCksdGhpcy5zY3JpcHQpe3ZhciBlPXRoaXMuc2NyaXB0O2UucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChlKSxlLm9ucmVhZHlzdGF0ZWNoYW5nZT1lLm9uZXJyb3I9ZS5vbmxvYWQ9ZS5vbmNsaWNrPW51bGwsdGhpcy5zY3JpcHQ9bnVsbH1kZWxldGUgY1tyLldQcmVmaXhdW3RoaXMuaWRdfSx1LnByb3RvdHlwZS5fc2NyaXB0RXJyb3I9ZnVuY3Rpb24oKXtsKFwiX3NjcmlwdEVycm9yXCIpO3ZhciBlPXRoaXM7dGhpcy5lcnJvclRpbWVyfHwodGhpcy5lcnJvclRpbWVyPXNldFRpbWVvdXQoZnVuY3Rpb24oKXtlLmxvYWRlZE9rYXl8fGUuX2Fib3J0KG5ldyBFcnJvcihcIkpTT05QIHNjcmlwdCBsb2FkZWQgYWJub3JtYWxseSAob25lcnJvcilcIikpfSx1LnNjcmlwdEVycm9yVGltZW91dCkpfSx1LnByb3RvdHlwZS5fY3JlYXRlU2NyaXB0PWZ1bmN0aW9uKGUpe2woXCJfY3JlYXRlU2NyaXB0XCIsZSk7dmFyIHQsbj10aGlzLHI9dGhpcy5zY3JpcHQ9Yy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO2lmKHIuaWQ9XCJhXCIraS5zdHJpbmcoOCksci5zcmM9ZSxyLnR5cGU9XCJ0ZXh0L2phdmFzY3JpcHRcIixyLmNoYXJzZXQ9XCJVVEYtOFwiLHIub25lcnJvcj10aGlzLl9zY3JpcHRFcnJvci5iaW5kKHRoaXMpLHIub25sb2FkPWZ1bmN0aW9uKCl7bChcIm9ubG9hZFwiKSxuLl9hYm9ydChuZXcgRXJyb3IoXCJKU09OUCBzY3JpcHQgbG9hZGVkIGFibm9ybWFsbHkgKG9ubG9hZClcIikpfSxyLm9ucmVhZHlzdGF0ZWNoYW5nZT1mdW5jdGlvbigpe2lmKGwoXCJvbnJlYWR5c3RhdGVjaGFuZ2VcIixyLnJlYWR5U3RhdGUpLC9sb2FkZWR8Y2xvc2VkLy50ZXN0KHIucmVhZHlTdGF0ZSkpe2lmKHImJnIuaHRtbEZvciYmci5vbmNsaWNrKXtuLmxvYWRlZE9rYXk9ITA7dHJ5e3Iub25jbGljaygpfWNhdGNoKGUpe319ciYmbi5fYWJvcnQobmV3IEVycm9yKFwiSlNPTlAgc2NyaXB0IGxvYWRlZCBhYm5vcm1hbGx5IChvbnJlYWR5c3RhdGVjaGFuZ2UpXCIpKX19LHZvaWQgMD09PXIuYXN5bmMmJmMuZG9jdW1lbnQuYXR0YWNoRXZlbnQpaWYocy5pc09wZXJhKCkpKHQ9dGhpcy5zY3JpcHQyPWMuZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKSkudGV4dD1cInRyeXt2YXIgYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdcIityLmlkK1wiJyk7IGlmKGEpYS5vbmVycm9yKCk7fWNhdGNoKHgpe307XCIsci5hc3luYz10LmFzeW5jPSExO2Vsc2V7dHJ5e3IuaHRtbEZvcj1yLmlkLHIuZXZlbnQ9XCJvbmNsaWNrXCJ9Y2F0Y2goZSl7fXIuYXN5bmM9ITB9dm9pZCAwIT09ci5hc3luYyYmKHIuYXN5bmM9ITApO3ZhciBvPWMuZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJoZWFkXCIpWzBdO28uaW5zZXJ0QmVmb3JlKHIsby5maXJzdENoaWxkKSx0JiZvLmluc2VydEJlZm9yZSh0LG8uZmlyc3RDaGlsZCl9LG4uZXhwb3J0cz11fSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi4vLi4vdXRpbHMvYnJvd3NlclwiOjQ0LFwiLi4vLi4vdXRpbHMvaWZyYW1lXCI6NDcsXCIuLi8uLi91dGlscy9yYW5kb21cIjo1MCxcIi4uLy4uL3V0aWxzL3VybFwiOjUyLFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDMyOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcImV2ZW50c1wiKS5FdmVudEVtaXR0ZXIsaT1mdW5jdGlvbigpe307ZnVuY3Rpb24gcyhlLHQpe2koZSksby5jYWxsKHRoaXMpO3ZhciByPXRoaXM7dGhpcy5idWZmZXJQb3NpdGlvbj0wLHRoaXMueG89bmV3IHQoXCJQT1NUXCIsZSxudWxsKSx0aGlzLnhvLm9uKFwiY2h1bmtcIix0aGlzLl9jaHVua0hhbmRsZXIuYmluZCh0aGlzKSksdGhpcy54by5vbmNlKFwiZmluaXNoXCIsZnVuY3Rpb24oZSx0KXtpKFwiZmluaXNoXCIsZSx0KSxyLl9jaHVua0hhbmRsZXIoZSx0KSxyLnhvPW51bGw7dmFyIG49MjAwPT09ZT9cIm5ldHdvcmtcIjpcInBlcm1hbmVudFwiO2koXCJjbG9zZVwiLG4pLHIuZW1pdChcImNsb3NlXCIsbnVsbCxuKSxyLl9jbGVhbnVwKCl9KX1yKHMsbykscy5wcm90b3R5cGUuX2NodW5rSGFuZGxlcj1mdW5jdGlvbihlLHQpe2lmKGkoXCJfY2h1bmtIYW5kbGVyXCIsZSksMjAwPT09ZSYmdClmb3IodmFyIG49LTE7O3RoaXMuYnVmZmVyUG9zaXRpb24rPW4rMSl7dmFyIHI9dC5zbGljZSh0aGlzLmJ1ZmZlclBvc2l0aW9uKTtpZigtMT09PShuPXIuaW5kZXhPZihcIlxcblwiKSkpYnJlYWs7dmFyIG89ci5zbGljZSgwLG4pO28mJihpKFwibWVzc2FnZVwiLG8pLHRoaXMuZW1pdChcIm1lc3NhZ2VcIixvKSl9fSxzLnByb3RvdHlwZS5fY2xlYW51cD1mdW5jdGlvbigpe2koXCJfY2xlYW51cFwiKSx0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpfSxzLnByb3RvdHlwZS5hYm9ydD1mdW5jdGlvbigpe2koXCJhYm9ydFwiKSx0aGlzLnhvJiYodGhpcy54by5jbG9zZSgpLGkoXCJjbG9zZVwiKSx0aGlzLmVtaXQoXCJjbG9zZVwiLG51bGwsXCJ1c2VyXCIpLHRoaXMueG89bnVsbCksdGhpcy5fY2xlYW51cCgpfSx0LmV4cG9ydHM9c30se1wiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDMzOltmdW5jdGlvbihlLHQsbil7KGZ1bmN0aW9uKGYpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBzLGEsbD1lKFwiLi4vLi4vdXRpbHMvcmFuZG9tXCIpLHU9ZShcIi4uLy4uL3V0aWxzL3VybFwiKSxjPWZ1bmN0aW9uKCl7fTt0LmV4cG9ydHM9ZnVuY3Rpb24oZSx0LG4pe2MoZSx0KSxzfHwoYyhcImNyZWF0ZUZvcm1cIiksKHM9Zi5kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZm9ybVwiKSkuc3R5bGUuZGlzcGxheT1cIm5vbmVcIixzLnN0eWxlLnBvc2l0aW9uPVwiYWJzb2x1dGVcIixzLm1ldGhvZD1cIlBPU1RcIixzLmVuY3R5cGU9XCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIixzLmFjY2VwdENoYXJzZXQ9XCJVVEYtOFwiLChhPWYuZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInRleHRhcmVhXCIpKS5uYW1lPVwiZFwiLHMuYXBwZW5kQ2hpbGQoYSksZi5kb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHMpKTt2YXIgcj1cImFcIitsLnN0cmluZyg4KTtzLnRhcmdldD1yLHMuYWN0aW9uPXUuYWRkUXVlcnkodS5hZGRQYXRoKGUsXCIvanNvbnBfc2VuZFwiKSxcImk9XCIrcik7dmFyIG89ZnVuY3Rpb24odCl7YyhcImNyZWF0ZUlmcmFtZVwiLHQpO3RyeXtyZXR1cm4gZi5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCc8aWZyYW1lIG5hbWU9XCInK3QrJ1wiPicpfWNhdGNoKGUpe3ZhciBuPWYuZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImlmcmFtZVwiKTtyZXR1cm4gbi5uYW1lPXQsbn19KHIpO28uaWQ9cixvLnN0eWxlLmRpc3BsYXk9XCJub25lXCIscy5hcHBlbmRDaGlsZChvKTt0cnl7YS52YWx1ZT10fWNhdGNoKGUpe31zLnN1Ym1pdCgpO2Z1bmN0aW9uIGkoZSl7YyhcImNvbXBsZXRlZFwiLHIsZSksby5vbmVycm9yJiYoby5vbnJlYWR5c3RhdGVjaGFuZ2U9by5vbmVycm9yPW8ub25sb2FkPW51bGwsc2V0VGltZW91dChmdW5jdGlvbigpe2MoXCJjbGVhbmluZyB1cFwiLHIpLG8ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChvKSxvPW51bGx9LDUwMCksYS52YWx1ZT1cIlwiLG4oZSkpfXJldHVybiBvLm9uZXJyb3I9ZnVuY3Rpb24oKXtjKFwib25lcnJvclwiLHIpLGkoKX0sby5vbmxvYWQ9ZnVuY3Rpb24oKXtjKFwib25sb2FkXCIsciksaSgpfSxvLm9ucmVhZHlzdGF0ZWNoYW5nZT1mdW5jdGlvbihlKXtjKFwib25yZWFkeXN0YXRlY2hhbmdlXCIscixvLnJlYWR5U3RhdGUsZSksXCJjb21wbGV0ZVwiPT09by5yZWFkeVN0YXRlJiZpKCl9LGZ1bmN0aW9uKCl7YyhcImFib3J0ZWRcIixyKSxpKG5ldyBFcnJvcihcIkFib3J0ZWRcIikpfX19KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7XCIuLi8uLi91dGlscy9yYW5kb21cIjo1MCxcIi4uLy4uL3V0aWxzL3VybFwiOjUyLFwiZGVidWdcIjp2b2lkIDB9XSwzNDpbZnVuY3Rpb24ocix1LGUpeyhmdW5jdGlvbihsKXsoZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjt2YXIgbz1yKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlcixlPXIoXCJpbmhlcml0c1wiKSxpPXIoXCIuLi8uLi91dGlscy9ldmVudFwiKSx0PXIoXCIuLi8uLi91dGlscy9icm93c2VyXCIpLHM9cihcIi4uLy4uL3V0aWxzL3VybFwiKSxhPWZ1bmN0aW9uKCl7fTtmdW5jdGlvbiBuKGUsdCxuKXthKGUsdCk7dmFyIHI9dGhpcztvLmNhbGwodGhpcyksc2V0VGltZW91dChmdW5jdGlvbigpe3IuX3N0YXJ0KGUsdCxuKX0sMCl9ZShuLG8pLG4ucHJvdG90eXBlLl9zdGFydD1mdW5jdGlvbihlLHQsbil7YShcIl9zdGFydFwiKTt2YXIgcj10aGlzLG89bmV3IGwuWERvbWFpblJlcXVlc3Q7dD1zLmFkZFF1ZXJ5KHQsXCJ0PVwiKyArbmV3IERhdGUpLG8ub25lcnJvcj1mdW5jdGlvbigpe2EoXCJvbmVycm9yXCIpLHIuX2Vycm9yKCl9LG8ub250aW1lb3V0PWZ1bmN0aW9uKCl7YShcIm9udGltZW91dFwiKSxyLl9lcnJvcigpfSxvLm9ucHJvZ3Jlc3M9ZnVuY3Rpb24oKXthKFwicHJvZ3Jlc3NcIixvLnJlc3BvbnNlVGV4dCksci5lbWl0KFwiY2h1bmtcIiwyMDAsby5yZXNwb25zZVRleHQpfSxvLm9ubG9hZD1mdW5jdGlvbigpe2EoXCJsb2FkXCIpLHIuZW1pdChcImZpbmlzaFwiLDIwMCxvLnJlc3BvbnNlVGV4dCksci5fY2xlYW51cCghMSl9LHRoaXMueGRyPW8sdGhpcy51bmxvYWRSZWY9aS51bmxvYWRBZGQoZnVuY3Rpb24oKXtyLl9jbGVhbnVwKCEwKX0pO3RyeXt0aGlzLnhkci5vcGVuKGUsdCksdGhpcy50aW1lb3V0JiYodGhpcy54ZHIudGltZW91dD10aGlzLnRpbWVvdXQpLHRoaXMueGRyLnNlbmQobil9Y2F0Y2goZSl7dGhpcy5fZXJyb3IoKX19LG4ucHJvdG90eXBlLl9lcnJvcj1mdW5jdGlvbigpe3RoaXMuZW1pdChcImZpbmlzaFwiLDAsXCJcIiksdGhpcy5fY2xlYW51cCghMSl9LG4ucHJvdG90eXBlLl9jbGVhbnVwPWZ1bmN0aW9uKGUpe2lmKGEoXCJjbGVhbnVwXCIsZSksdGhpcy54ZHIpe2lmKHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCksaS51bmxvYWREZWwodGhpcy51bmxvYWRSZWYpLHRoaXMueGRyLm9udGltZW91dD10aGlzLnhkci5vbmVycm9yPXRoaXMueGRyLm9ucHJvZ3Jlc3M9dGhpcy54ZHIub25sb2FkPW51bGwsZSl0cnl7dGhpcy54ZHIuYWJvcnQoKX1jYXRjaChlKXt9dGhpcy51bmxvYWRSZWY9dGhpcy54ZHI9bnVsbH19LG4ucHJvdG90eXBlLmNsb3NlPWZ1bmN0aW9uKCl7YShcImNsb3NlXCIpLHRoaXMuX2NsZWFudXAoITApfSxuLmVuYWJsZWQ9ISghbC5YRG9tYWluUmVxdWVzdHx8IXQuaGFzRG9tYWluKCkpLHUuZXhwb3J0cz1ufSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi4vLi4vdXRpbHMvYnJvd3NlclwiOjQ0LFwiLi4vLi4vdXRpbHMvZXZlbnRcIjo0NixcIi4uLy4uL3V0aWxzL3VybFwiOjUyLFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDM1OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcIi4uL2RyaXZlci94aHJcIik7ZnVuY3Rpb24gaShlLHQsbixyKXtvLmNhbGwodGhpcyxlLHQsbixyKX1yKGksbyksaS5lbmFibGVkPW8uZW5hYmxlZCYmby5zdXBwb3J0c0NPUlMsdC5leHBvcnRzPWl9LHtcIi4uL2RyaXZlci94aHJcIjoxNyxcImluaGVyaXRzXCI6NTR9XSwzNjpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciByPWUoXCJldmVudHNcIikuRXZlbnRFbWl0dGVyO2Z1bmN0aW9uIG8oKXt2YXIgZT10aGlzO3IuY2FsbCh0aGlzKSx0aGlzLnRvPXNldFRpbWVvdXQoZnVuY3Rpb24oKXtlLmVtaXQoXCJmaW5pc2hcIiwyMDAsXCJ7fVwiKX0sby50aW1lb3V0KX1lKFwiaW5oZXJpdHNcIikobyxyKSxvLnByb3RvdHlwZS5jbG9zZT1mdW5jdGlvbigpe2NsZWFyVGltZW91dCh0aGlzLnRvKX0sby50aW1lb3V0PTJlMyx0LmV4cG9ydHM9b30se1wiZXZlbnRzXCI6MyxcImluaGVyaXRzXCI6NTR9XSwzNzpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciByPWUoXCJpbmhlcml0c1wiKSxvPWUoXCIuLi9kcml2ZXIveGhyXCIpO2Z1bmN0aW9uIGkoZSx0LG4pe28uY2FsbCh0aGlzLGUsdCxuLHtub0NyZWRlbnRpYWxzOiEwfSl9cihpLG8pLGkuZW5hYmxlZD1vLmVuYWJsZWQsdC5leHBvcnRzPWl9LHtcIi4uL2RyaXZlci94aHJcIjoxNyxcImluaGVyaXRzXCI6NTR9XSwzODpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciBpPWUoXCIuLi91dGlscy9ldmVudFwiKSxzPWUoXCIuLi91dGlscy91cmxcIikscj1lKFwiaW5oZXJpdHNcIiksYT1lKFwiZXZlbnRzXCIpLkV2ZW50RW1pdHRlcixsPWUoXCIuL2RyaXZlci93ZWJzb2NrZXRcIiksdT1mdW5jdGlvbigpe307ZnVuY3Rpb24gYyhlLHQsbil7aWYoIWMuZW5hYmxlZCgpKXRocm93IG5ldyBFcnJvcihcIlRyYW5zcG9ydCBjcmVhdGVkIHdoZW4gZGlzYWJsZWRcIik7YS5jYWxsKHRoaXMpLHUoXCJjb25zdHJ1Y3RvclwiLGUpO3ZhciByPXRoaXMsbz1zLmFkZFBhdGgoZSxcIi93ZWJzb2NrZXRcIik7bz1cImh0dHBzXCI9PT1vLnNsaWNlKDAsNSk/XCJ3c3NcIitvLnNsaWNlKDUpOlwid3NcIitvLnNsaWNlKDQpLHRoaXMudXJsPW8sdGhpcy53cz1uZXcgbCh0aGlzLnVybCxbXSxuKSx0aGlzLndzLm9ubWVzc2FnZT1mdW5jdGlvbihlKXt1KFwibWVzc2FnZSBldmVudFwiLGUuZGF0YSksci5lbWl0KFwibWVzc2FnZVwiLGUuZGF0YSl9LHRoaXMudW5sb2FkUmVmPWkudW5sb2FkQWRkKGZ1bmN0aW9uKCl7dShcInVubG9hZFwiKSxyLndzLmNsb3NlKCl9KSx0aGlzLndzLm9uY2xvc2U9ZnVuY3Rpb24oZSl7dShcImNsb3NlIGV2ZW50XCIsZS5jb2RlLGUucmVhc29uKSxyLmVtaXQoXCJjbG9zZVwiLGUuY29kZSxlLnJlYXNvbiksci5fY2xlYW51cCgpfSx0aGlzLndzLm9uZXJyb3I9ZnVuY3Rpb24oZSl7dShcImVycm9yIGV2ZW50XCIsZSksci5lbWl0KFwiY2xvc2VcIiwxMDA2LFwiV2ViU29ja2V0IGNvbm5lY3Rpb24gYnJva2VuXCIpLHIuX2NsZWFudXAoKX19cihjLGEpLGMucHJvdG90eXBlLnNlbmQ9ZnVuY3Rpb24oZSl7dmFyIHQ9XCJbXCIrZStcIl1cIjt1KFwic2VuZFwiLHQpLHRoaXMud3Muc2VuZCh0KX0sYy5wcm90b3R5cGUuY2xvc2U9ZnVuY3Rpb24oKXt1KFwiY2xvc2VcIik7dmFyIGU9dGhpcy53czt0aGlzLl9jbGVhbnVwKCksZSYmZS5jbG9zZSgpfSxjLnByb3RvdHlwZS5fY2xlYW51cD1mdW5jdGlvbigpe3UoXCJfY2xlYW51cFwiKTt2YXIgZT10aGlzLndzO2UmJihlLm9ubWVzc2FnZT1lLm9uY2xvc2U9ZS5vbmVycm9yPW51bGwpLGkudW5sb2FkRGVsKHRoaXMudW5sb2FkUmVmKSx0aGlzLnVubG9hZFJlZj10aGlzLndzPW51bGwsdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKX0sYy5lbmFibGVkPWZ1bmN0aW9uKCl7cmV0dXJuIHUoXCJlbmFibGVkXCIpLCEhbH0sYy50cmFuc3BvcnROYW1lPVwid2Vic29ja2V0XCIsYy5yb3VuZFRyaXBzPTIsdC5leHBvcnRzPWN9LHtcIi4uL3V0aWxzL2V2ZW50XCI6NDYsXCIuLi91dGlscy91cmxcIjo1MixcIi4vZHJpdmVyL3dlYnNvY2tldFwiOjE5LFwiZGVidWdcIjp2b2lkIDAsXCJldmVudHNcIjozLFwiaW5oZXJpdHNcIjo1NH1dLDM5OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcIi4vbGliL2FqYXgtYmFzZWRcIiksaT1lKFwiLi94ZHItc3RyZWFtaW5nXCIpLHM9ZShcIi4vcmVjZWl2ZXIveGhyXCIpLGE9ZShcIi4vc2VuZGVyL3hkclwiKTtmdW5jdGlvbiBsKGUpe2lmKCFhLmVuYWJsZWQpdGhyb3cgbmV3IEVycm9yKFwiVHJhbnNwb3J0IGNyZWF0ZWQgd2hlbiBkaXNhYmxlZFwiKTtvLmNhbGwodGhpcyxlLFwiL3hoclwiLHMsYSl9cihsLG8pLGwuZW5hYmxlZD1pLmVuYWJsZWQsbC50cmFuc3BvcnROYW1lPVwieGRyLXBvbGxpbmdcIixsLnJvdW5kVHJpcHM9Mix0LmV4cG9ydHM9bH0se1wiLi9saWIvYWpheC1iYXNlZFwiOjI0LFwiLi9yZWNlaXZlci94aHJcIjozMixcIi4vc2VuZGVyL3hkclwiOjM0LFwiLi94ZHItc3RyZWFtaW5nXCI6NDAsXCJpbmhlcml0c1wiOjU0fV0sNDA6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgcj1lKFwiaW5oZXJpdHNcIiksbz1lKFwiLi9saWIvYWpheC1iYXNlZFwiKSxpPWUoXCIuL3JlY2VpdmVyL3hoclwiKSxzPWUoXCIuL3NlbmRlci94ZHJcIik7ZnVuY3Rpb24gYShlKXtpZighcy5lbmFibGVkKXRocm93IG5ldyBFcnJvcihcIlRyYW5zcG9ydCBjcmVhdGVkIHdoZW4gZGlzYWJsZWRcIik7by5jYWxsKHRoaXMsZSxcIi94aHJfc3RyZWFtaW5nXCIsaSxzKX1yKGEsbyksYS5lbmFibGVkPWZ1bmN0aW9uKGUpe3JldHVybiFlLmNvb2tpZV9uZWVkZWQmJiFlLm51bGxPcmlnaW4mJihzLmVuYWJsZWQmJmUuc2FtZVNjaGVtZSl9LGEudHJhbnNwb3J0TmFtZT1cInhkci1zdHJlYW1pbmdcIixhLnJvdW5kVHJpcHM9Mix0LmV4cG9ydHM9YX0se1wiLi9saWIvYWpheC1iYXNlZFwiOjI0LFwiLi9yZWNlaXZlci94aHJcIjozMixcIi4vc2VuZGVyL3hkclwiOjM0LFwiaW5oZXJpdHNcIjo1NH1dLDQxOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcImluaGVyaXRzXCIpLG89ZShcIi4vbGliL2FqYXgtYmFzZWRcIiksaT1lKFwiLi9yZWNlaXZlci94aHJcIikscz1lKFwiLi9zZW5kZXIveGhyLWNvcnNcIiksYT1lKFwiLi9zZW5kZXIveGhyLWxvY2FsXCIpO2Z1bmN0aW9uIGwoZSl7aWYoIWEuZW5hYmxlZCYmIXMuZW5hYmxlZCl0aHJvdyBuZXcgRXJyb3IoXCJUcmFuc3BvcnQgY3JlYXRlZCB3aGVuIGRpc2FibGVkXCIpO28uY2FsbCh0aGlzLGUsXCIveGhyXCIsaSxzKX1yKGwsbyksbC5lbmFibGVkPWZ1bmN0aW9uKGUpe3JldHVybiFlLm51bGxPcmlnaW4mJighKCFhLmVuYWJsZWR8fCFlLnNhbWVPcmlnaW4pfHxzLmVuYWJsZWQpfSxsLnRyYW5zcG9ydE5hbWU9XCJ4aHItcG9sbGluZ1wiLGwucm91bmRUcmlwcz0yLHQuZXhwb3J0cz1sfSx7XCIuL2xpYi9hamF4LWJhc2VkXCI6MjQsXCIuL3JlY2VpdmVyL3hoclwiOjMyLFwiLi9zZW5kZXIveGhyLWNvcnNcIjozNSxcIi4vc2VuZGVyL3hoci1sb2NhbFwiOjM3LFwiaW5oZXJpdHNcIjo1NH1dLDQyOltmdW5jdGlvbihsLHUsZSl7KGZ1bmN0aW9uKGEpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBlPWwoXCJpbmhlcml0c1wiKSx0PWwoXCIuL2xpYi9hamF4LWJhc2VkXCIpLG49bChcIi4vcmVjZWl2ZXIveGhyXCIpLHI9bChcIi4vc2VuZGVyL3hoci1jb3JzXCIpLG89bChcIi4vc2VuZGVyL3hoci1sb2NhbFwiKSxpPWwoXCIuLi91dGlscy9icm93c2VyXCIpO2Z1bmN0aW9uIHMoZSl7aWYoIW8uZW5hYmxlZCYmIXIuZW5hYmxlZCl0aHJvdyBuZXcgRXJyb3IoXCJUcmFuc3BvcnQgY3JlYXRlZCB3aGVuIGRpc2FibGVkXCIpO3QuY2FsbCh0aGlzLGUsXCIveGhyX3N0cmVhbWluZ1wiLG4scil9ZShzLHQpLHMuZW5hYmxlZD1mdW5jdGlvbihlKXtyZXR1cm4hZS5udWxsT3JpZ2luJiYoIWkuaXNPcGVyYSgpJiZyLmVuYWJsZWQpfSxzLnRyYW5zcG9ydE5hbWU9XCJ4aHItc3RyZWFtaW5nXCIscy5yb3VuZFRyaXBzPTIscy5uZWVkQm9keT0hIWEuZG9jdW1lbnQsdS5leHBvcnRzPXN9KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7XCIuLi91dGlscy9icm93c2VyXCI6NDQsXCIuL2xpYi9hamF4LWJhc2VkXCI6MjQsXCIuL3JlY2VpdmVyL3hoclwiOjMyLFwiLi9zZW5kZXIveGhyLWNvcnNcIjozNSxcIi4vc2VuZGVyL3hoci1sb2NhbFwiOjM3LFwiaW5oZXJpdHNcIjo1NH1dLDQzOltmdW5jdGlvbihlLHQsbil7KGZ1bmN0aW9uKG4peyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO24uY3J5cHRvJiZuLmNyeXB0by5nZXRSYW5kb21WYWx1ZXM/dC5leHBvcnRzLnJhbmRvbUJ5dGVzPWZ1bmN0aW9uKGUpe3ZhciB0PW5ldyBVaW50OEFycmF5KGUpO3JldHVybiBuLmNyeXB0by5nZXRSYW5kb21WYWx1ZXModCksdH06dC5leHBvcnRzLnJhbmRvbUJ5dGVzPWZ1bmN0aW9uKGUpe2Zvcih2YXIgdD1uZXcgQXJyYXkoZSksbj0wO248ZTtuKyspdFtuXT1NYXRoLmZsb29yKDI1NipNYXRoLnJhbmRvbSgpKTtyZXR1cm4gdH19KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7fV0sNDQ6W2Z1bmN0aW9uKGUsdCxuKXsoZnVuY3Rpb24oZSl7KGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dC5leHBvcnRzPXtpc09wZXJhOmZ1bmN0aW9uKCl7cmV0dXJuIGUubmF2aWdhdG9yJiYvb3BlcmEvaS50ZXN0KGUubmF2aWdhdG9yLnVzZXJBZ2VudCl9LGlzS29ucXVlcm9yOmZ1bmN0aW9uKCl7cmV0dXJuIGUubmF2aWdhdG9yJiYva29ucXVlcm9yL2kudGVzdChlLm5hdmlnYXRvci51c2VyQWdlbnQpfSxoYXNEb21haW46ZnVuY3Rpb24oKXtpZighZS5kb2N1bWVudClyZXR1cm4hMDt0cnl7cmV0dXJuISFlLmRvY3VtZW50LmRvbWFpbn1jYXRjaChlKXtyZXR1cm4hMX19fX0pLmNhbGwodGhpcyl9KS5jYWxsKHRoaXMsXCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbD9nbG9iYWw6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHNlbGY/c2VsZjpcInVuZGVmaW5lZFwiIT10eXBlb2Ygd2luZG93P3dpbmRvdzp7fSl9LHt9XSw0NTpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciByLG89L1tcXHgwMC1cXHgxZlxcdWQ4MDAtXFx1ZGZmZlxcdWZmZmVcXHVmZmZmXFx1MDMwMC1cXHUwMzMzXFx1MDMzZC1cXHUwMzQ2XFx1MDM0YS1cXHUwMzRjXFx1MDM1MC1cXHUwMzUyXFx1MDM1Ny1cXHUwMzU4XFx1MDM1Yy1cXHUwMzYyXFx1MDM3NFxcdTAzN2VcXHUwMzg3XFx1MDU5MS1cXHUwNWFmXFx1MDVjNFxcdTA2MTAtXFx1MDYxN1xcdTA2NTMtXFx1MDY1NFxcdTA2NTctXFx1MDY1YlxcdTA2NWQtXFx1MDY1ZVxcdTA2ZGYtXFx1MDZlMlxcdTA2ZWItXFx1MDZlY1xcdTA3MzBcXHUwNzMyLVxcdTA3MzNcXHUwNzM1LVxcdTA3MzZcXHUwNzNhXFx1MDczZFxcdTA3M2YtXFx1MDc0MVxcdTA3NDNcXHUwNzQ1XFx1MDc0N1xcdTA3ZWItXFx1MDdmMVxcdTA5NTFcXHUwOTU4LVxcdTA5NWZcXHUwOWRjLVxcdTA5ZGRcXHUwOWRmXFx1MGEzM1xcdTBhMzZcXHUwYTU5LVxcdTBhNWJcXHUwYTVlXFx1MGI1Yy1cXHUwYjVkXFx1MGUzOC1cXHUwZTM5XFx1MGY0M1xcdTBmNGRcXHUwZjUyXFx1MGY1N1xcdTBmNWNcXHUwZjY5XFx1MGY3Mi1cXHUwZjc2XFx1MGY3OFxcdTBmODAtXFx1MGY4M1xcdTBmOTNcXHUwZjlkXFx1MGZhMlxcdTBmYTdcXHUwZmFjXFx1MGZiOVxcdTE5MzktXFx1MTkzYVxcdTFhMTdcXHUxYjZiXFx1MWNkYS1cXHUxY2RiXFx1MWRjMC1cXHUxZGNmXFx1MWRmY1xcdTFkZmVcXHUxZjcxXFx1MWY3M1xcdTFmNzVcXHUxZjc3XFx1MWY3OVxcdTFmN2JcXHUxZjdkXFx1MWZiYlxcdTFmYmVcXHUxZmM5XFx1MWZjYlxcdTFmZDNcXHUxZmRiXFx1MWZlM1xcdTFmZWJcXHUxZmVlLVxcdTFmZWZcXHUxZmY5XFx1MWZmYlxcdTFmZmRcXHUyMDAwLVxcdTIwMDFcXHUyMGQwLVxcdTIwZDFcXHUyMGQ0LVxcdTIwZDdcXHUyMGU3LVxcdTIwZTlcXHUyMTI2XFx1MjEyYS1cXHUyMTJiXFx1MjMyOS1cXHUyMzJhXFx1MmFkY1xcdTMwMmItXFx1MzAyY1xcdWFhYjItXFx1YWFiM1xcdWY5MDAtXFx1ZmEwZFxcdWZhMTBcXHVmYTEyXFx1ZmExNS1cXHVmYTFlXFx1ZmEyMFxcdWZhMjJcXHVmYTI1LVxcdWZhMjZcXHVmYTJhLVxcdWZhMmRcXHVmYTMwLVxcdWZhNmRcXHVmYTcwLVxcdWZhZDlcXHVmYjFkXFx1ZmIxZlxcdWZiMmEtXFx1ZmIzNlxcdWZiMzgtXFx1ZmIzY1xcdWZiM2VcXHVmYjQwLVxcdWZiNDFcXHVmYjQzLVxcdWZiNDRcXHVmYjQ2LVxcdWZiNGVcXHVmZmYwLVxcdWZmZmZdL2c7dC5leHBvcnRzPXtxdW90ZTpmdW5jdGlvbihlKXt2YXIgdD1KU09OLnN0cmluZ2lmeShlKTtyZXR1cm4gby5sYXN0SW5kZXg9MCxvLnRlc3QodCk/KHI9cnx8ZnVuY3Rpb24oZSl7dmFyIHQsbj17fSxyPVtdO2Zvcih0PTA7dDw2NTUzNjt0Kyspci5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUodCkpO3JldHVybiBlLmxhc3RJbmRleD0wLHIuam9pbihcIlwiKS5yZXBsYWNlKGUsZnVuY3Rpb24oZSl7cmV0dXJuIG5bZV09XCJcXFxcdVwiKyhcIjAwMDBcIitlLmNoYXJDb2RlQXQoMCkudG9TdHJpbmcoMTYpKS5zbGljZSgtNCksXCJcIn0pLGUubGFzdEluZGV4PTAsbn0obyksdC5yZXBsYWNlKG8sZnVuY3Rpb24oZSl7cmV0dXJuIHJbZV19KSk6dH19fSx7fV0sNDY6W2Z1bmN0aW9uKGUsdCxuKXsoZnVuY3Rpb24ocyl7KGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIG49ZShcIi4vcmFuZG9tXCIpLHI9e30sbz0hMSxpPXMuY2hyb21lJiZzLmNocm9tZS5hcHAmJnMuY2hyb21lLmFwcC5ydW50aW1lO3QuZXhwb3J0cz17YXR0YWNoRXZlbnQ6ZnVuY3Rpb24oZSx0KXt2b2lkIDAhPT1zLmFkZEV2ZW50TGlzdGVuZXI/cy5hZGRFdmVudExpc3RlbmVyKGUsdCwhMSk6cy5kb2N1bWVudCYmcy5hdHRhY2hFdmVudCYmKHMuZG9jdW1lbnQuYXR0YWNoRXZlbnQoXCJvblwiK2UsdCkscy5hdHRhY2hFdmVudChcIm9uXCIrZSx0KSl9LGRldGFjaEV2ZW50OmZ1bmN0aW9uKGUsdCl7dm9pZCAwIT09cy5hZGRFdmVudExpc3RlbmVyP3MucmVtb3ZlRXZlbnRMaXN0ZW5lcihlLHQsITEpOnMuZG9jdW1lbnQmJnMuZGV0YWNoRXZlbnQmJihzLmRvY3VtZW50LmRldGFjaEV2ZW50KFwib25cIitlLHQpLHMuZGV0YWNoRXZlbnQoXCJvblwiK2UsdCkpfSx1bmxvYWRBZGQ6ZnVuY3Rpb24oZSl7aWYoaSlyZXR1cm4gbnVsbDt2YXIgdD1uLnN0cmluZyg4KTtyZXR1cm4gclt0XT1lLG8mJnNldFRpbWVvdXQodGhpcy50cmlnZ2VyVW5sb2FkQ2FsbGJhY2tzLDApLHR9LHVubG9hZERlbDpmdW5jdGlvbihlKXtlIGluIHImJmRlbGV0ZSByW2VdfSx0cmlnZ2VyVW5sb2FkQ2FsbGJhY2tzOmZ1bmN0aW9uKCl7Zm9yKHZhciBlIGluIHIpcltlXSgpLGRlbGV0ZSByW2VdfX07aXx8dC5leHBvcnRzLmF0dGFjaEV2ZW50KFwidW5sb2FkXCIsZnVuY3Rpb24oKXtvfHwobz0hMCx0LmV4cG9ydHMudHJpZ2dlclVubG9hZENhbGxiYWNrcygpKX0pfSkuY2FsbCh0aGlzKX0pLmNhbGwodGhpcyxcInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsP2dsb2JhbDpcInVuZGVmaW5lZFwiIT10eXBlb2Ygc2VsZj9zZWxmOlwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3c/d2luZG93Ont9KX0se1wiLi9yYW5kb21cIjo1MH1dLDQ3OltmdW5jdGlvbih0LHAsZSl7KGZ1bmN0aW9uKGQpeyhmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3ZhciBmPXQoXCIuL2V2ZW50XCIpLGU9dChcIi4vYnJvd3NlclwiKSxoPWZ1bmN0aW9uKCl7fTtwLmV4cG9ydHM9e1dQcmVmaXg6XCJfanBcIixjdXJyZW50V2luZG93SWQ6bnVsbCxwb2xsdXRlR2xvYmFsTmFtZXNwYWNlOmZ1bmN0aW9uKCl7cC5leHBvcnRzLldQcmVmaXggaW4gZHx8KGRbcC5leHBvcnRzLldQcmVmaXhdPXt9KX0scG9zdE1lc3NhZ2U6ZnVuY3Rpb24oZSx0KXtkLnBhcmVudCE9PWQ/ZC5wYXJlbnQucG9zdE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkoe3dpbmRvd0lkOnAuZXhwb3J0cy5jdXJyZW50V2luZG93SWQsdHlwZTplLGRhdGE6dHx8XCJcIn0pLFwiKlwiKTpoKFwiQ2Fubm90IHBvc3RNZXNzYWdlLCBubyBwYXJlbnQgd2luZG93LlwiLGUsdCl9LGNyZWF0ZUlmcmFtZTpmdW5jdGlvbihlLHQpe2Z1bmN0aW9uIG4oKXtoKFwidW5hdHRhY2hcIiksY2xlYXJUaW1lb3V0KGkpO3RyeXthLm9ubG9hZD1udWxsfWNhdGNoKGUpe31hLm9uZXJyb3I9bnVsbH1mdW5jdGlvbiByKCl7aChcImNsZWFudXBcIiksYSYmKG4oKSxzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7YSYmYS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGEpLGE9bnVsbH0sMCksZi51bmxvYWREZWwocykpfWZ1bmN0aW9uIG8oZSl7aChcIm9uZXJyb3JcIixlKSxhJiYocigpLHQoZSkpfXZhciBpLHMsYT1kLmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpZnJhbWVcIik7cmV0dXJuIGEuc3JjPWUsYS5zdHlsZS5kaXNwbGF5PVwibm9uZVwiLGEuc3R5bGUucG9zaXRpb249XCJhYnNvbHV0ZVwiLGEub25lcnJvcj1mdW5jdGlvbigpe28oXCJvbmVycm9yXCIpfSxhLm9ubG9hZD1mdW5jdGlvbigpe2goXCJvbmxvYWRcIiksY2xlYXJUaW1lb3V0KGkpLGk9c2V0VGltZW91dChmdW5jdGlvbigpe28oXCJvbmxvYWQgdGltZW91dFwiKX0sMmUzKX0sZC5kb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpLGk9c2V0VGltZW91dChmdW5jdGlvbigpe28oXCJ0aW1lb3V0XCIpfSwxNWUzKSxzPWYudW5sb2FkQWRkKHIpLHtwb3N0OmZ1bmN0aW9uKGUsdCl7aChcInBvc3RcIixlLHQpLHNldFRpbWVvdXQoZnVuY3Rpb24oKXt0cnl7YSYmYS5jb250ZW50V2luZG93JiZhLmNvbnRlbnRXaW5kb3cucG9zdE1lc3NhZ2UoZSx0KX1jYXRjaChlKXt9fSwwKX0sY2xlYW51cDpyLGxvYWRlZDpufX0sY3JlYXRlSHRtbGZpbGU6ZnVuY3Rpb24oZSx0KXtmdW5jdGlvbiBuKCl7Y2xlYXJUaW1lb3V0KGkpLGEub25lcnJvcj1udWxsfWZ1bmN0aW9uIHIoKXt1JiYobigpLGYudW5sb2FkRGVsKHMpLGEucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChhKSxhPXU9bnVsbCxDb2xsZWN0R2FyYmFnZSgpKX1mdW5jdGlvbiBvKGUpe2goXCJvbmVycm9yXCIsZSksdSYmKHIoKSx0KGUpKX12YXIgaSxzLGEsbD1bXCJBY3RpdmVcIl0uY29uY2F0KFwiT2JqZWN0XCIpLmpvaW4oXCJYXCIpLHU9bmV3IGRbbF0oXCJodG1sZmlsZVwiKTt1Lm9wZW4oKSx1LndyaXRlKCc8aHRtbD48c2NyaXB0PmRvY3VtZW50LmRvbWFpbj1cIicrZC5kb2N1bWVudC5kb21haW4rJ1wiOzxcXC9zY3JpcHQ+PC9odG1sPicpLHUuY2xvc2UoKSx1LnBhcmVudFdpbmRvd1twLmV4cG9ydHMuV1ByZWZpeF09ZFtwLmV4cG9ydHMuV1ByZWZpeF07dmFyIGM9dS5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO3JldHVybiB1LmJvZHkuYXBwZW5kQ2hpbGQoYyksYT11LmNyZWF0ZUVsZW1lbnQoXCJpZnJhbWVcIiksYy5hcHBlbmRDaGlsZChhKSxhLnNyYz1lLGEub25lcnJvcj1mdW5jdGlvbigpe28oXCJvbmVycm9yXCIpfSxpPXNldFRpbWVvdXQoZnVuY3Rpb24oKXtvKFwidGltZW91dFwiKX0sMTVlMykscz1mLnVubG9hZEFkZChyKSx7cG9zdDpmdW5jdGlvbihlLHQpe3RyeXtzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7YSYmYS5jb250ZW50V2luZG93JiZhLmNvbnRlbnRXaW5kb3cucG9zdE1lc3NhZ2UoZSx0KX0sMCl9Y2F0Y2goZSl7fX0sY2xlYW51cDpyLGxvYWRlZDpufX19LHAuZXhwb3J0cy5pZnJhbWVFbmFibGVkPSExLGQuZG9jdW1lbnQmJihwLmV4cG9ydHMuaWZyYW1lRW5hYmxlZD0oXCJmdW5jdGlvblwiPT10eXBlb2YgZC5wb3N0TWVzc2FnZXx8XCJvYmplY3RcIj09dHlwZW9mIGQucG9zdE1lc3NhZ2UpJiYhZS5pc0tvbnF1ZXJvcigpKX0pLmNhbGwodGhpcyl9KS5jYWxsKHRoaXMsXCJ1bmRlZmluZWRcIiE9dHlwZW9mIGdsb2JhbD9nbG9iYWw6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHNlbGY/c2VsZjpcInVuZGVmaW5lZFwiIT10eXBlb2Ygd2luZG93P3dpbmRvdzp7fSl9LHtcIi4vYnJvd3NlclwiOjQ0LFwiLi9ldmVudFwiOjQ2LFwiZGVidWdcIjp2b2lkIDB9XSw0ODpbZnVuY3Rpb24oZSx0LG4peyhmdW5jdGlvbihyKXsoZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjt2YXIgbj17fTtbXCJsb2dcIixcImRlYnVnXCIsXCJ3YXJuXCJdLmZvckVhY2goZnVuY3Rpb24oZSl7dmFyIHQ7dHJ5e3Q9ci5jb25zb2xlJiZyLmNvbnNvbGVbZV0mJnIuY29uc29sZVtlXS5hcHBseX1jYXRjaChlKXt9bltlXT10P2Z1bmN0aW9uKCl7cmV0dXJuIHIuY29uc29sZVtlXS5hcHBseShyLmNvbnNvbGUsYXJndW1lbnRzKX06XCJsb2dcIj09PWU/ZnVuY3Rpb24oKXt9Om4ubG9nfSksdC5leHBvcnRzPW59KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7fV0sNDk6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt0LmV4cG9ydHM9e2lzT2JqZWN0OmZ1bmN0aW9uKGUpe3ZhciB0PXR5cGVvZiBlO3JldHVyblwiZnVuY3Rpb25cIj09dHx8XCJvYmplY3RcIj09dCYmISFlfSxleHRlbmQ6ZnVuY3Rpb24oZSl7aWYoIXRoaXMuaXNPYmplY3QoZSkpcmV0dXJuIGU7Zm9yKHZhciB0LG4scj0xLG89YXJndW1lbnRzLmxlbmd0aDtyPG87cisrKWZvcihuIGluIHQ9YXJndW1lbnRzW3JdKU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh0LG4pJiYoZVtuXT10W25dKTtyZXR1cm4gZX19fSx7fV0sNTA6W2Z1bmN0aW9uKGUsdCxuKXtcInVzZSBzdHJpY3RcIjt2YXIgaT1lKFwiY3J5cHRvXCIpLHM9XCJhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NVwiO3QuZXhwb3J0cz17c3RyaW5nOmZ1bmN0aW9uKGUpe2Zvcih2YXIgdD1zLmxlbmd0aCxuPWkucmFuZG9tQnl0ZXMoZSkscj1bXSxvPTA7bzxlO28rKylyLnB1c2gocy5zdWJzdHIobltvXSV0LDEpKTtyZXR1cm4gci5qb2luKFwiXCIpfSxudW1iZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSplKX0sbnVtYmVyU3RyaW5nOmZ1bmN0aW9uKGUpe3ZhciB0PShcIlwiKyhlLTEpKS5sZW5ndGg7cmV0dXJuKG5ldyBBcnJheSh0KzEpLmpvaW4oXCIwXCIpK3RoaXMubnVtYmVyKGUpKS5zbGljZSgtdCl9fX0se1wiY3J5cHRvXCI6NDN9XSw1MTpbZnVuY3Rpb24oZSx0LG4pe1widXNlIHN0cmljdFwiO3ZhciBvPWZ1bmN0aW9uKCl7fTt0LmV4cG9ydHM9ZnVuY3Rpb24oZSl7cmV0dXJue2ZpbHRlclRvRW5hYmxlZDpmdW5jdGlvbih0LG4pe3ZhciByPXttYWluOltdLGZhY2FkZTpbXX07cmV0dXJuIHQ/XCJzdHJpbmdcIj09dHlwZW9mIHQmJih0PVt0XSk6dD1bXSxlLmZvckVhY2goZnVuY3Rpb24oZSl7ZSYmKFwid2Vic29ja2V0XCIhPT1lLnRyYW5zcG9ydE5hbWV8fCExIT09bi53ZWJzb2NrZXQ/dC5sZW5ndGgmJi0xPT09dC5pbmRleE9mKGUudHJhbnNwb3J0TmFtZSk/byhcIm5vdCBpbiB3aGl0ZWxpc3RcIixlLnRyYW5zcG9ydE5hbWUpOmUuZW5hYmxlZChuKT8obyhcImVuYWJsZWRcIixlLnRyYW5zcG9ydE5hbWUpLHIubWFpbi5wdXNoKGUpLGUuZmFjYWRlVHJhbnNwb3J0JiZyLmZhY2FkZS5wdXNoKGUuZmFjYWRlVHJhbnNwb3J0KSk6byhcImRpc2FibGVkXCIsZS50cmFuc3BvcnROYW1lKTpvKFwiZGlzYWJsZWQgZnJvbSBzZXJ2ZXJcIixcIndlYnNvY2tldFwiKSl9KSxyfX19fSx7XCJkZWJ1Z1wiOnZvaWQgMH1dLDUyOltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIHI9ZShcInVybC1wYXJzZVwiKSxvPWZ1bmN0aW9uKCl7fTt0LmV4cG9ydHM9e2dldE9yaWdpbjpmdW5jdGlvbihlKXtpZighZSlyZXR1cm4gbnVsbDt2YXIgdD1uZXcgcihlKTtpZihcImZpbGU6XCI9PT10LnByb3RvY29sKXJldHVybiBudWxsO3ZhciBuPXQucG9ydDtyZXR1cm4gbj1ufHwoXCJodHRwczpcIj09PXQucHJvdG9jb2w/XCI0NDNcIjpcIjgwXCIpLHQucHJvdG9jb2wrXCIvL1wiK3QuaG9zdG5hbWUrXCI6XCIrbn0saXNPcmlnaW5FcXVhbDpmdW5jdGlvbihlLHQpe3ZhciBuPXRoaXMuZ2V0T3JpZ2luKGUpPT09dGhpcy5nZXRPcmlnaW4odCk7cmV0dXJuIG8oXCJzYW1lXCIsZSx0LG4pLG59LGlzU2NoZW1lRXF1YWw6ZnVuY3Rpb24oZSx0KXtyZXR1cm4gZS5zcGxpdChcIjpcIilbMF09PT10LnNwbGl0KFwiOlwiKVswXX0sYWRkUGF0aDpmdW5jdGlvbihlLHQpe3ZhciBuPWUuc3BsaXQoXCI/XCIpO3JldHVybiBuWzBdK3QrKG5bMV0/XCI/XCIrblsxXTpcIlwiKX0sYWRkUXVlcnk6ZnVuY3Rpb24oZSx0KXtyZXR1cm4gZSsoLTE9PT1lLmluZGV4T2YoXCI/XCIpP1wiP1wiK3Q6XCImXCIrdCl9LGlzTG9vcGJhY2tBZGRyOmZ1bmN0aW9uKGUpe3JldHVybi9eMTI3XFwuKFswLTldezEsM30pXFwuKFswLTldezEsM30pXFwuKFswLTldezEsM30pJC9pLnRlc3QoZSl8fC9eXFxbOjoxXFxdJC8udGVzdChlKX19fSx7XCJkZWJ1Z1wiOnZvaWQgMCxcInVybC1wYXJzZVwiOjU3fV0sNTM6W2Z1bmN0aW9uKGUsdCxuKXt0LmV4cG9ydHM9XCIxLjYuMVwifSx7fV0sNTQ6W2Z1bmN0aW9uKGUsdCxuKXtcImZ1bmN0aW9uXCI9PXR5cGVvZiBPYmplY3QuY3JlYXRlP3QuZXhwb3J0cz1mdW5jdGlvbihlLHQpe3QmJihlLnN1cGVyXz10LGUucHJvdG90eXBlPU9iamVjdC5jcmVhdGUodC5wcm90b3R5cGUse2NvbnN0cnVjdG9yOnt2YWx1ZTplLGVudW1lcmFibGU6ITEsd3JpdGFibGU6ITAsY29uZmlndXJhYmxlOiEwfX0pKX06dC5leHBvcnRzPWZ1bmN0aW9uKGUsdCl7aWYodCl7ZS5zdXBlcl89dDtmdW5jdGlvbiBuKCl7fW4ucHJvdG90eXBlPXQucHJvdG90eXBlLGUucHJvdG90eXBlPW5ldyBuLGUucHJvdG90eXBlLmNvbnN0cnVjdG9yPWV9fX0se31dLDU1OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dmFyIGk9T2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtmdW5jdGlvbiBzKGUpe3RyeXtyZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KGUucmVwbGFjZSgvXFwrL2csXCIgXCIpKX1jYXRjaChlKXtyZXR1cm4gbnVsbH19bi5zdHJpbmdpZnk9ZnVuY3Rpb24oZSx0KXt0PXR8fFwiXCI7dmFyIG4scixvPVtdO2ZvcihyIGluXCJzdHJpbmdcIiE9dHlwZW9mIHQmJih0PVwiP1wiKSxlKWlmKGkuY2FsbChlLHIpKXtpZigobj1lW3JdKXx8bnVsbCE9biYmIWlzTmFOKG4pfHwobj1cIlwiKSxyPWVuY29kZVVSSUNvbXBvbmVudChyKSxuPWVuY29kZVVSSUNvbXBvbmVudChuKSxudWxsPT09cnx8bnVsbD09PW4pY29udGludWU7by5wdXNoKHIrXCI9XCIrbil9cmV0dXJuIG8ubGVuZ3RoP3Qrby5qb2luKFwiJlwiKTpcIlwifSxuLnBhcnNlPWZ1bmN0aW9uKGUpe2Zvcih2YXIgdCxuPS8oW149PyZdKyk9PyhbXiZdKikvZyxyPXt9O3Q9bi5leGVjKGUpOyl7dmFyIG89cyh0WzFdKSxpPXModFsyXSk7bnVsbD09PW98fG51bGw9PT1pfHxvIGluIHJ8fChyW29dPWkpfXJldHVybiByfX0se31dLDU2OltmdW5jdGlvbihlLHQsbil7XCJ1c2Ugc3RyaWN0XCI7dC5leHBvcnRzPWZ1bmN0aW9uKGUsdCl7aWYodD10LnNwbGl0KFwiOlwiKVswXSwhKGU9K2UpKXJldHVybiExO3N3aXRjaCh0KXtjYXNlXCJodHRwXCI6Y2FzZVwid3NcIjpyZXR1cm4gODAhPT1lO2Nhc2VcImh0dHBzXCI6Y2FzZVwid3NzXCI6cmV0dXJuIDQ0MyE9PWU7Y2FzZVwiZnRwXCI6cmV0dXJuIDIxIT09ZTtjYXNlXCJnb3BoZXJcIjpyZXR1cm4gNzAhPT1lO2Nhc2VcImZpbGVcIjpyZXR1cm4hMX1yZXR1cm4gMCE9PWV9fSx7fV0sNTc6W2Z1bmN0aW9uKGUsbix0KXsoZnVuY3Rpb24oYSl7KGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIGQ9ZShcInJlcXVpcmVzLXBvcnRcIikscD1lKFwicXVlcnlzdHJpbmdpZnlcIiksdD0vXltcXHgwMC1cXHgyMFxcdTAwYTBcXHUxNjgwXFx1MjAwMC1cXHUyMDBhXFx1MjAyOFxcdTIwMjlcXHUyMDJmXFx1MjA1ZlxcdTMwMDBcXHVmZWZmXSsvLG09L1tcXG5cXHJcXHRdL2csaT0vXltBLVphLXpdW0EtWmEtejAtOSstLl0qOlxcL1xcLy8sbD0vOlxcZCskLyx1PS9eKFthLXpdW2EtejAtOS4rLV0qOik/KFxcL1xcLyk/KFtcXFxcL10rKT8oW1xcU1xcc10qKS9pLHY9L15bYS16QS1aXTovO2Z1bmN0aW9uIGIoZSl7cmV0dXJuKGV8fFwiXCIpLnRvU3RyaW5nKCkucmVwbGFjZSh0LFwiXCIpfXZhciB5PVtbXCIjXCIsXCJoYXNoXCJdLFtcIj9cIixcInF1ZXJ5XCJdLGZ1bmN0aW9uKGUsdCl7cmV0dXJuIHcodC5wcm90b2NvbCk/ZS5yZXBsYWNlKC9cXFxcL2csXCIvXCIpOmV9LFtcIi9cIixcInBhdGhuYW1lXCJdLFtcIkBcIixcImF1dGhcIiwxXSxbTmFOLFwiaG9zdFwiLHZvaWQgMCwxLDFdLFsvOihcXGQqKSQvLFwicG9ydFwiLHZvaWQgMCwxXSxbTmFOLFwiaG9zdG5hbWVcIix2b2lkIDAsMSwxXV0scz17aGFzaDoxLHF1ZXJ5OjF9O2Z1bmN0aW9uIGcoZSl7dmFyIHQsbj0oXCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6dm9pZCAwIT09YT9hOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6e30pLmxvY2F0aW9ufHx7fSxyPXt9LG89dHlwZW9mKGU9ZXx8bik7aWYoXCJibG9iOlwiPT09ZS5wcm90b2NvbClyPW5ldyBfKHVuZXNjYXBlKGUucGF0aG5hbWUpLHt9KTtlbHNlIGlmKFwic3RyaW5nXCI9PW8pZm9yKHQgaW4gcj1uZXcgXyhlLHt9KSxzKWRlbGV0ZSByW3RdO2Vsc2UgaWYoXCJvYmplY3RcIj09byl7Zm9yKHQgaW4gZSl0IGluIHN8fChyW3RdPWVbdF0pO3ZvaWQgMD09PXIuc2xhc2hlcyYmKHIuc2xhc2hlcz1pLnRlc3QoZS5ocmVmKSl9cmV0dXJuIHJ9ZnVuY3Rpb24gdyhlKXtyZXR1cm5cImZpbGU6XCI9PT1lfHxcImZ0cDpcIj09PWV8fFwiaHR0cDpcIj09PWV8fFwiaHR0cHM6XCI9PT1lfHxcIndzOlwiPT09ZXx8XCJ3c3M6XCI9PT1lfWZ1bmN0aW9uIHgoZSx0KXtlPShlPWIoZSkpLnJlcGxhY2UobSxcIlwiKSx0PXR8fHt9O3ZhciBuLHI9dS5leGVjKGUpLG89clsxXT9yWzFdLnRvTG93ZXJDYXNlKCk6XCJcIixpPSEhclsyXSxzPSEhclszXSxhPTA7cmV0dXJuIGk/YT1zPyhuPXJbMl0rclszXStyWzRdLHJbMl0ubGVuZ3RoK3JbM10ubGVuZ3RoKToobj1yWzJdK3JbNF0sclsyXS5sZW5ndGgpOnM/KG49clszXStyWzRdLGE9clszXS5sZW5ndGgpOm49cls0XSxcImZpbGU6XCI9PT1vPzI8PWEmJihuPW4uc2xpY2UoMikpOncobyk/bj1yWzRdOm8/aSYmKG49bi5zbGljZSgyKSk6Mjw9YSYmdyh0LnByb3RvY29sKSYmKG49cls0XSkse3Byb3RvY29sOm8sc2xhc2hlczppfHx3KG8pLHNsYXNoZXNDb3VudDphLHJlc3Q6bn19ZnVuY3Rpb24gXyhlLHQsbil7aWYoZT0oZT1iKGUpKS5yZXBsYWNlKG0sXCJcIiksISh0aGlzIGluc3RhbmNlb2YgXykpcmV0dXJuIG5ldyBfKGUsdCxuKTt2YXIgcixvLGkscyxhLGwsdT15LnNsaWNlKCksYz10eXBlb2YgdCxmPXRoaXMsaD0wO2ZvcihcIm9iamVjdFwiIT1jJiZcInN0cmluZ1wiIT1jJiYobj10LHQ9bnVsbCksbiYmXCJmdW5jdGlvblwiIT10eXBlb2YgbiYmKG49cC5wYXJzZSkscj0hKG89eChlfHxcIlwiLHQ9Zyh0KSkpLnByb3RvY29sJiYhby5zbGFzaGVzLGYuc2xhc2hlcz1vLnNsYXNoZXN8fHImJnQuc2xhc2hlcyxmLnByb3RvY29sPW8ucHJvdG9jb2x8fHQucHJvdG9jb2x8fFwiXCIsZT1vLnJlc3QsKFwiZmlsZTpcIj09PW8ucHJvdG9jb2wmJigyIT09by5zbGFzaGVzQ291bnR8fHYudGVzdChlKSl8fCFvLnNsYXNoZXMmJihvLnByb3RvY29sfHxvLnNsYXNoZXNDb3VudDwyfHwhdyhmLnByb3RvY29sKSkpJiYodVszXT1bLyguKikvLFwicGF0aG5hbWVcIl0pO2g8dS5sZW5ndGg7aCsrKVwiZnVuY3Rpb25cIiE9dHlwZW9mKHM9dVtoXSk/KGk9c1swXSxsPXNbMV0saSE9aT9mW2xdPWU6XCJzdHJpbmdcIj09dHlwZW9mIGk/fihhPVwiQFwiPT09aT9lLmxhc3RJbmRleE9mKGkpOmUuaW5kZXhPZihpKSkmJihlPVwibnVtYmVyXCI9PXR5cGVvZiBzWzJdPyhmW2xdPWUuc2xpY2UoMCxhKSxlLnNsaWNlKGErc1syXSkpOihmW2xdPWUuc2xpY2UoYSksZS5zbGljZSgwLGEpKSk6KGE9aS5leGVjKGUpKSYmKGZbbF09YVsxXSxlPWUuc2xpY2UoMCxhLmluZGV4KSksZltsXT1mW2xdfHxyJiZzWzNdJiZ0W2xdfHxcIlwiLHNbNF0mJihmW2xdPWZbbF0udG9Mb3dlckNhc2UoKSkpOmU9cyhlLGYpO24mJihmLnF1ZXJ5PW4oZi5xdWVyeSkpLHImJnQuc2xhc2hlcyYmXCIvXCIhPT1mLnBhdGhuYW1lLmNoYXJBdCgwKSYmKFwiXCIhPT1mLnBhdGhuYW1lfHxcIlwiIT09dC5wYXRobmFtZSkmJihmLnBhdGhuYW1lPWZ1bmN0aW9uKGUsdCl7aWYoXCJcIj09PWUpcmV0dXJuIHQ7Zm9yKHZhciBuPSh0fHxcIi9cIikuc3BsaXQoXCIvXCIpLnNsaWNlKDAsLTEpLmNvbmNhdChlLnNwbGl0KFwiL1wiKSkscj1uLmxlbmd0aCxvPW5bci0xXSxpPSExLHM9MDtyLS07KVwiLlwiPT09bltyXT9uLnNwbGljZShyLDEpOlwiLi5cIj09PW5bcl0/KG4uc3BsaWNlKHIsMSkscysrKTpzJiYoMD09PXImJihpPSEwKSxuLnNwbGljZShyLDEpLHMtLSk7cmV0dXJuIGkmJm4udW5zaGlmdChcIlwiKSxcIi5cIiE9PW8mJlwiLi5cIiE9PW98fG4ucHVzaChcIlwiKSxuLmpvaW4oXCIvXCIpfShmLnBhdGhuYW1lLHQucGF0aG5hbWUpKSxcIi9cIiE9PWYucGF0aG5hbWUuY2hhckF0KDApJiZ3KGYucHJvdG9jb2wpJiYoZi5wYXRobmFtZT1cIi9cIitmLnBhdGhuYW1lKSxkKGYucG9ydCxmLnByb3RvY29sKXx8KGYuaG9zdD1mLmhvc3RuYW1lLGYucG9ydD1cIlwiKSxmLnVzZXJuYW1lPWYucGFzc3dvcmQ9XCJcIixmLmF1dGgmJih+KGE9Zi5hdXRoLmluZGV4T2YoXCI6XCIpKT8oZi51c2VybmFtZT1mLmF1dGguc2xpY2UoMCxhKSxmLnVzZXJuYW1lPWVuY29kZVVSSUNvbXBvbmVudChkZWNvZGVVUklDb21wb25lbnQoZi51c2VybmFtZSkpLGYucGFzc3dvcmQ9Zi5hdXRoLnNsaWNlKGErMSksZi5wYXNzd29yZD1lbmNvZGVVUklDb21wb25lbnQoZGVjb2RlVVJJQ29tcG9uZW50KGYucGFzc3dvcmQpKSk6Zi51c2VybmFtZT1lbmNvZGVVUklDb21wb25lbnQoZGVjb2RlVVJJQ29tcG9uZW50KGYuYXV0aCkpLGYuYXV0aD1mLnBhc3N3b3JkP2YudXNlcm5hbWUrXCI6XCIrZi5wYXNzd29yZDpmLnVzZXJuYW1lKSxmLm9yaWdpbj1cImZpbGU6XCIhPT1mLnByb3RvY29sJiZ3KGYucHJvdG9jb2wpJiZmLmhvc3Q/Zi5wcm90b2NvbCtcIi8vXCIrZi5ob3N0OlwibnVsbFwiLGYuaHJlZj1mLnRvU3RyaW5nKCl9Xy5wcm90b3R5cGU9e3NldDpmdW5jdGlvbihlLHQsbil7dmFyIHI9dGhpcztzd2l0Y2goZSl7Y2FzZVwicXVlcnlcIjpcInN0cmluZ1wiPT10eXBlb2YgdCYmdC5sZW5ndGgmJih0PShufHxwLnBhcnNlKSh0KSkscltlXT10O2JyZWFrO2Nhc2VcInBvcnRcIjpyW2VdPXQsZCh0LHIucHJvdG9jb2wpP3QmJihyLmhvc3Q9ci5ob3N0bmFtZStcIjpcIit0KTooci5ob3N0PXIuaG9zdG5hbWUscltlXT1cIlwiKTticmVhaztjYXNlXCJob3N0bmFtZVwiOnJbZV09dCxyLnBvcnQmJih0Kz1cIjpcIityLnBvcnQpLHIuaG9zdD10O2JyZWFrO2Nhc2VcImhvc3RcIjpyW2VdPXQsbC50ZXN0KHQpPyh0PXQuc3BsaXQoXCI6XCIpLHIucG9ydD10LnBvcCgpLHIuaG9zdG5hbWU9dC5qb2luKFwiOlwiKSk6KHIuaG9zdG5hbWU9dCxyLnBvcnQ9XCJcIik7YnJlYWs7Y2FzZVwicHJvdG9jb2xcIjpyLnByb3RvY29sPXQudG9Mb3dlckNhc2UoKSxyLnNsYXNoZXM9IW47YnJlYWs7Y2FzZVwicGF0aG5hbWVcIjpjYXNlXCJoYXNoXCI6aWYodCl7dmFyIG89XCJwYXRobmFtZVwiPT09ZT9cIi9cIjpcIiNcIjtyW2VdPXQuY2hhckF0KDApIT09bz9vK3Q6dH1lbHNlIHJbZV09dDticmVhaztjYXNlXCJ1c2VybmFtZVwiOmNhc2VcInBhc3N3b3JkXCI6cltlXT1lbmNvZGVVUklDb21wb25lbnQodCk7YnJlYWs7Y2FzZVwiYXV0aFwiOnZhciBpPXQuaW5kZXhPZihcIjpcIik7fmk/KHIudXNlcm5hbWU9dC5zbGljZSgwLGkpLHIudXNlcm5hbWU9ZW5jb2RlVVJJQ29tcG9uZW50KGRlY29kZVVSSUNvbXBvbmVudChyLnVzZXJuYW1lKSksci5wYXNzd29yZD10LnNsaWNlKGkrMSksci5wYXNzd29yZD1lbmNvZGVVUklDb21wb25lbnQoZGVjb2RlVVJJQ29tcG9uZW50KHIucGFzc3dvcmQpKSk6ci51c2VybmFtZT1lbmNvZGVVUklDb21wb25lbnQoZGVjb2RlVVJJQ29tcG9uZW50KHQpKX1mb3IodmFyIHM9MDtzPHkubGVuZ3RoO3MrKyl7dmFyIGE9eVtzXTthWzRdJiYoclthWzFdXT1yW2FbMV1dLnRvTG93ZXJDYXNlKCkpfXJldHVybiByLmF1dGg9ci5wYXNzd29yZD9yLnVzZXJuYW1lK1wiOlwiK3IucGFzc3dvcmQ6ci51c2VybmFtZSxyLm9yaWdpbj1cImZpbGU6XCIhPT1yLnByb3RvY29sJiZ3KHIucHJvdG9jb2wpJiZyLmhvc3Q/ci5wcm90b2NvbCtcIi8vXCIrci5ob3N0OlwibnVsbFwiLHIuaHJlZj1yLnRvU3RyaW5nKCkscn0sdG9TdHJpbmc6ZnVuY3Rpb24oZSl7ZSYmXCJmdW5jdGlvblwiPT10eXBlb2YgZXx8KGU9cC5zdHJpbmdpZnkpO3ZhciB0LG49dGhpcyxyPW4uaG9zdCxvPW4ucHJvdG9jb2w7byYmXCI6XCIhPT1vLmNoYXJBdChvLmxlbmd0aC0xKSYmKG8rPVwiOlwiKTt2YXIgaT1vKyhuLnByb3RvY29sJiZuLnNsYXNoZXN8fHcobi5wcm90b2NvbCk/XCIvL1wiOlwiXCIpO3JldHVybiBuLnVzZXJuYW1lPyhpKz1uLnVzZXJuYW1lLG4ucGFzc3dvcmQmJihpKz1cIjpcIituLnBhc3N3b3JkKSxpKz1cIkBcIik6bi5wYXNzd29yZD8oaSs9XCI6XCIrbi5wYXNzd29yZCxpKz1cIkBcIik6XCJmaWxlOlwiIT09bi5wcm90b2NvbCYmdyhuLnByb3RvY29sKSYmIXImJlwiL1wiIT09bi5wYXRobmFtZSYmKGkrPVwiQFwiKSwoXCI6XCI9PT1yW3IubGVuZ3RoLTFdfHxsLnRlc3Qobi5ob3N0bmFtZSkmJiFuLnBvcnQpJiYocis9XCI6XCIpLGkrPXIrbi5wYXRobmFtZSwodD1cIm9iamVjdFwiPT10eXBlb2Ygbi5xdWVyeT9lKG4ucXVlcnkpOm4ucXVlcnkpJiYoaSs9XCI/XCIhPT10LmNoYXJBdCgwKT9cIj9cIit0OnQpLG4uaGFzaCYmKGkrPW4uaGFzaCksaX19LF8uZXh0cmFjdFByb3RvY29sPXgsXy5sb2NhdGlvbj1nLF8udHJpbUxlZnQ9YixfLnFzPXAsbi5leHBvcnRzPV99KS5jYWxsKHRoaXMpfSkuY2FsbCh0aGlzLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWw/Z2xvYmFsOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmP3NlbGY6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdz93aW5kb3c6e30pfSx7XCJxdWVyeXN0cmluZ2lmeVwiOjU1LFwicmVxdWlyZXMtcG9ydFwiOjU2fV19LHt9LFsxXSkoMSl9KTtcclxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c29ja2pzLm1pbi5qcy5tYXAiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdGlmICghKG1vZHVsZUlkIGluIF9fd2VicGFja19tb2R1bGVzX18pKSB7XG5cdFx0ZGVsZXRlIF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdFx0dmFyIGUgPSBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiICsgbW9kdWxlSWQgKyBcIidcIik7XG5cdFx0ZS5jb2RlID0gJ01PRFVMRV9OT1RfRk9VTkQnO1xuXHRcdHRocm93IGU7XG5cdH1cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmcgPSAoZnVuY3Rpb24oKSB7XG5cdGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ29iamVjdCcpIHJldHVybiBnbG9iYWxUaGlzO1xuXHR0cnkge1xuXHRcdHJldHVybiB0aGlzIHx8IG5ldyBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnKSByZXR1cm4gd2luZG93O1xuXHR9XG59KSgpOyIsIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBTb2NrSlMgPSByZXF1aXJlKCdAc3JjL2pzL2xpYnMvc29ja2pzJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc29jayA9IG5ldyBTb2NrSlMoXCJodHRwOi8vMTI3LjAuMC4xOjk5MDBcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc29jay5vbm1lc3NhZ2UgPSBmdW5jdGlvbihldmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtZXNzYWdlID0gSlNPTi5wYXJzZShldmVudC5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cobWVzc2FnZSwxODE4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChtZXNzYWdlLnR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ3JlbG9hZEV4dGVuZCc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+aehOW7uuWujOaIkCEg6ICX5pe2OiAnICsgbWVzc2FnZS5kYXRhLnRpbWUgKyAnbXMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5kYXRhLnN1Y2Nlc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUucmVsb2FkKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+KchSDmnoTlu7rmiJDlip/vvIzliLfmlrDmianlsZUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCfinYwg5p6E5bu65aSx6LSl77yM6ZSZ6K+v5pWwOiAnICsgbWVzc2FnZS5kYXRhLmVycm9ycyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn5pS25Yiw5raI5oGvOicsIG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuLyoqXHJcbiAqIENyZWF0ZWQgYnkgQWxsZW4gTGl1IG9uIDIwMjYvMy8yMC5cclxuICovXHJcblxyXG4vL+m7mOiupOaYr+aJk+W8gOW8ueeql++8jOaDs+imgeaWsHRhYuaJk+W8gOmcgOimgeWOu+aOiW1hbmlmZXN0Lmpzb27ph4znmoQgXCJkZWZhdWx0X3BvcHVwXCI6IFwicG9wdXAuaHRtbFwi6YWN572uXHJcbmNocm9tZS5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICh0YWIpID0+IHtcclxuICBjaHJvbWUudGFicy5jcmVhdGUoe1xyXG4gICAgdXJsOiBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJwb3B1cC5odG1sXCIpLFxyXG4gICAgYWN0aXZlOiB0cnVlXHJcbiAgfSk7XHJcbn0pO1xyXG4iXSwibmFtZXMiOlsiZSIsImV4cG9ydHMiLCJtb2R1bGUiLCJkZWZpbmUiLCJhbWQiLCJ3aW5kb3ciLCJnbG9iYWwiLCJzZWxmIiwiU29ja0pTIiwiaSIsInMiLCJhIiwibCIsInUiLCJ0IiwibiIsInJlcXVpcmUiLCJjIiwiciIsIkVycm9yIiwiY29kZSIsIm8iLCJjYWxsIiwibGVuZ3RoIiwic2V0VGltZW91dCIsIl9zb2NranNfb25sb2FkIiwiaW5pdEV2ZW50Iiwid2FzQ2xlYW4iLCJyZWFzb24iLCJwcm90b3R5cGUiLCJyZW1vdmVBbGxMaXN0ZW5lcnMiLCJfbGlzdGVuZXJzIiwib25jZSIsIm9uIiwicmVtb3ZlTGlzdGVuZXIiLCJhcHBseSIsImFyZ3VtZW50cyIsImVtaXQiLCJBcnJheSIsImFkZExpc3RlbmVyIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJFdmVudEVtaXR0ZXIiLCJ0eXBlIiwiYnViYmxlcyIsImNhbmNlbGFibGUiLCJ0aW1lU3RhbXAiLCJEYXRlIiwic3RvcFByb3BhZ2F0aW9uIiwicHJldmVudERlZmF1bHQiLCJDQVBUVVJJTkdfUEhBU0UiLCJBVF9UQVJHRVQiLCJCVUJCTElOR19QSEFTRSIsImluZGV4T2YiLCJjb25jYXQiLCJzbGljZSIsImRpc3BhdGNoRXZlbnQiLCJkYXRhIiwiX3RyYW5zcG9ydCIsIl90cmFuc3BvcnRNZXNzYWdlIiwiYmluZCIsIl90cmFuc3BvcnRDbG9zZSIsInBvc3RNZXNzYWdlIiwiSlNPTiIsInN0cmluZ2lmeSIsIl9zZW5kIiwic2VuZCIsIl9jbG9zZSIsImNsb3NlIiwiZiIsImgiLCJkIiwicCIsIm0iLCJmb3JFYWNoIiwiZmFjYWRlVHJhbnNwb3J0IiwidHJhbnNwb3J0TmFtZSIsImJvb3RzdHJhcF9pZnJhbWUiLCJjdXJyZW50V2luZG93SWQiLCJoYXNoIiwiYXR0YWNoRXZlbnQiLCJzb3VyY2UiLCJwYXJlbnQiLCJvcmlnaW4iLCJwYXJzZSIsIndpbmRvd0lkIiwidmVyc2lvbiIsImlzT3JpZ2luRXF1YWwiLCJocmVmIiwieG8iLCJpc09iamVjdCIsImlyIiwiaWZyIiwiZG9jdW1lbnQiLCJib2R5IiwiZW5hYmxlZCIsImRvWGhyIiwiX2dldFJlY2VpdmVyIiwic2FtZU9yaWdpbiIsInNhbWVTY2hlbWUiLCJhZGRQYXRoIiwidGltZW91dFJlZiIsIl9jbGVhbnVwIiwidGltZW91dCIsImNsZWFyVGltZW91dCIsImxvY2F0aW9uIiwicHJvdG9jb2wiLCJob3N0IiwicG9ydCIsIngiLCJfIiwidyIsInYiLCJiIiwieSIsIlR5cGVFcnJvciIsInJlYWR5U3RhdGUiLCJDT05ORUNUSU5HIiwiZXh0ZW5zaW9ucyIsInByb3RvY29sc193aGl0ZWxpc3QiLCJ3YXJuIiwiX3RyYW5zcG9ydHNXaGl0ZWxpc3QiLCJ0cmFuc3BvcnRzIiwiX3RyYW5zcG9ydE9wdGlvbnMiLCJ0cmFuc3BvcnRPcHRpb25zIiwiX3RpbWVvdXQiLCJzZXNzaW9uSWQiLCJfZ2VuZXJhdGVTZXNzaW9uSWQiLCJzdHJpbmciLCJfc2VydmVyIiwic2VydmVyIiwibnVtYmVyU3RyaW5nIiwiU3ludGF4RXJyb3IiLCJpc0xvb3BiYWNrQWRkciIsImhvc3RuYW1lIiwiaXNBcnJheSIsInNvcnQiLCJnZXRPcmlnaW4iLCJfb3JpZ2luIiwidG9Mb3dlckNhc2UiLCJzZXQiLCJwYXRobmFtZSIsInJlcGxhY2UiLCJ1cmwiLCJfdXJsSW5mbyIsIm51bGxPcmlnaW4iLCJoYXNEb21haW4iLCJpc1NjaGVtZUVxdWFsIiwiX2lyIiwiX3JlY2VpdmVJbmZvIiwiZyIsIkNMT1NJTkciLCJDTE9TRUQiLCJPUEVOIiwicXVvdGUiLCJfcnRvIiwiY291bnRSVE8iLCJfdHJhbnNVcmwiLCJiYXNlX3VybCIsImV4dGVuZCIsImZpbHRlclRvRW5hYmxlZCIsIl90cmFuc3BvcnRzIiwibWFpbiIsIl9jb25uZWN0Iiwic2hpZnQiLCJuZWVkQm9keSIsInVuc2hpZnQiLCJNYXRoIiwibWF4Iiwicm91bmRUcmlwcyIsIl90cmFuc3BvcnRUaW1lb3V0SWQiLCJfdHJhbnNwb3J0VGltZW91dCIsIl9vcGVuIiwidHJhbnNwb3J0Iiwib25tZXNzYWdlIiwib25jbG9zZSIsIm9uZXJyb3IiLCJ0b1N0cmluZyIsIk9iamVjdCIsIkZ1bmN0aW9uIiwiU3RyaW5nIiwiZGVmaW5lUHJvcGVydHkiLCJjb25maWd1cmFibGUiLCJlbnVtZXJhYmxlIiwid3JpdGFibGUiLCJ2YWx1ZSIsImhhc093blByb3BlcnR5IiwicHVzaCIsImpvaW4iLCJzcGxpdCIsImZsb29yIiwiYWJzIiwiRSIsImV4ZWMiLCJpZ25vcmVDYXNlIiwibXVsdGlsaW5lIiwiZXh0ZW5kZWQiLCJzdGlja3kiLCJSZWdFeHAiLCJpbmRleCIsImxhc3RJbmRleCIsInRlc3QiLCJTIiwic3Vic3RyIiwiTyIsIlhNTEh0dHBSZXF1ZXN0IiwiX3N0YXJ0IiwieGhyIiwiYWRkUXVlcnkiLCJ1bmxvYWRSZWYiLCJ1bmxvYWRBZGQiLCJvcGVuIiwib250aW1lb3V0Iiwibm9DcmVkZW50aWFscyIsInN1cHBvcnRzQ09SUyIsIndpdGhDcmVkZW50aWFscyIsImhlYWRlcnMiLCJzZXRSZXF1ZXN0SGVhZGVyIiwib25yZWFkeXN0YXRlY2hhbmdlIiwic3RhdHVzIiwicmVzcG9uc2VUZXh0IiwidW5sb2FkRGVsIiwiYWJvcnQiLCJFdmVudFNvdXJjZSIsIldlYlNvY2tldCIsIk1veldlYlNvY2tldCIsImJhc2VVcmwiLCJ0cmFuc1VybCIsImlmcmFtZU9iaiIsImNyZWF0ZUlmcmFtZSIsIm9ubWVzc2FnZUNhbGxiYWNrIiwiX21lc3NhZ2UiLCJkZXRhY2hFdmVudCIsImNsZWFudXAiLCJsb2FkZWQiLCJwb3N0IiwiaWZyYW1lRW5hYmxlZCIsInNlbmRCdWZmZXIiLCJzZW5kZXIiLCJzZW5kU3RvcCIsInNlbmRTY2hlZHVsZSIsInNlbmRTY2hlZHVsZVdhaXQiLCJSZWNlaXZlciIsInJlY2VpdmVVcmwiLCJBamF4T2JqZWN0IiwiX3NjaGVkdWxlUmVjZWl2ZXIiLCJwb2xsIiwicG9sbElzQ2xvc2luZyIsImVzIiwiZGVjb2RlVVJJIiwicG9sbHV0ZUdsb2JhbE5hbWVzcGFjZSIsImlkIiwiZGVjb2RlVVJJQ29tcG9uZW50IiwiV1ByZWZpeCIsImh0bWxmaWxlRW5hYmxlZCIsImNyZWF0ZUh0bWxmaWxlIiwic3RhcnQiLCJtZXNzYWdlIiwic3RvcCIsImVuY29kZVVSSUNvbXBvbmVudCIsIl9jYWxsYmFjayIsIl9jcmVhdGVTY3JpcHQiLCJ0aW1lb3V0SWQiLCJfYWJvcnQiLCJzY3JpcHRFcnJvclRpbWVvdXQiLCJhYm9ydGluZyIsInNjcmlwdDIiLCJwYXJlbnROb2RlIiwicmVtb3ZlQ2hpbGQiLCJzY3JpcHQiLCJvbmxvYWQiLCJvbmNsaWNrIiwiX3NjcmlwdEVycm9yIiwiZXJyb3JUaW1lciIsImxvYWRlZE9rYXkiLCJjcmVhdGVFbGVtZW50Iiwic3JjIiwiY2hhcnNldCIsImh0bWxGb3IiLCJhc3luYyIsImlzT3BlcmEiLCJ0ZXh0IiwiZXZlbnQiLCJnZXRFbGVtZW50c0J5VGFnTmFtZSIsImluc2VydEJlZm9yZSIsImZpcnN0Q2hpbGQiLCJidWZmZXJQb3NpdGlvbiIsIl9jaHVua0hhbmRsZXIiLCJzdHlsZSIsImRpc3BsYXkiLCJwb3NpdGlvbiIsIm1ldGhvZCIsImVuY3R5cGUiLCJhY2NlcHRDaGFyc2V0IiwibmFtZSIsImFwcGVuZENoaWxkIiwidGFyZ2V0IiwiYWN0aW9uIiwic3VibWl0IiwiWERvbWFpblJlcXVlc3QiLCJfZXJyb3IiLCJvbnByb2dyZXNzIiwieGRyIiwidG8iLCJ3cyIsImNvb2tpZV9uZWVkZWQiLCJjcnlwdG8iLCJnZXRSYW5kb21WYWx1ZXMiLCJyYW5kb21CeXRlcyIsIlVpbnQ4QXJyYXkiLCJyYW5kb20iLCJuYXZpZ2F0b3IiLCJ1c2VyQWdlbnQiLCJpc0tvbnF1ZXJvciIsImRvbWFpbiIsImZyb21DaGFyQ29kZSIsImNoYXJDb2RlQXQiLCJjaHJvbWUiLCJhcHAiLCJydW50aW1lIiwidHJpZ2dlclVubG9hZENhbGxiYWNrcyIsImNvbnRlbnRXaW5kb3ciLCJDb2xsZWN0R2FyYmFnZSIsIndyaXRlIiwicGFyZW50V2luZG93IiwiY29uc29sZSIsImxvZyIsIm51bWJlciIsImZhY2FkZSIsIndlYnNvY2tldCIsImNyZWF0ZSIsInN1cGVyXyIsImNvbnN0cnVjdG9yIiwiaXNOYU4iLCJOYU4iLCJxdWVyeSIsInVuZXNjYXBlIiwic2xhc2hlcyIsInNsYXNoZXNDb3VudCIsInJlc3QiLCJsYXN0SW5kZXhPZiIsImNoYXJBdCIsInNwbGljZSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJhdXRoIiwicG9wIiwiZXh0cmFjdFByb3RvY29sIiwidHJpbUxlZnQiLCJxcyIsInNvY2siLCJ0aW1lIiwic3VjY2VzcyIsInJlbG9hZCIsImVycm9yIiwiZXJyb3JzIiwib25DbGlja2VkIiwidGFiIiwidGFicyIsImdldFVSTCIsImFjdGl2ZSJdLCJzb3VyY2VSb290IjoiIn0=