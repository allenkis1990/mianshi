"use strict";
(self["webpackChunkshare_chrome_extensions_by_lwh"] = self["webpackChunkshare_chrome_extensions_by_lwh"] || []).push([["js/entrys/popup"],{

/***/ "./src/js/entrys/popup.js"
/*!********************************!*\
  !*** ./src/js/entrys/popup.js ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _src_vue_popup_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @src/vue/popup.vue */ "./src/vue/popup.vue");

let app = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createApp)(_src_vue_popup_vue__WEBPACK_IMPORTED_MODULE_1__["default"]);
app.mount('#app');

/***/ },

/***/ "./src/js/utils/fun.js"
/*!*****************************!*\
  !*** ./src/js/utils/fun.js ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getToken: () => (/* binding */ getToken)
/* harmony export */ });
/**
 * Created by Allen Liu on 2026/3/24.
 */

let getToken = async function () {
  return new Promise(resolve => {
    chrome.storage.local.get(["token"], result => {
      resolve(result.token);
    });
  });
};

/***/ },

/***/ "./src/js/utils/hostConfig.js"
/*!************************************!*\
  !*** ./src/js/utils/hostConfig.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const baseUrl = 'https://pre-api.thedeer.cn';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  baseUrl
});

/***/ },

/***/ "./src/js/utils/http.js"
/*!******************************!*\
  !*** ./src/js/utils/http.js ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @src/js/utils/modal */ "./src/js/utils/modal.js");
/* harmony import */ var _src_js_utils_hostConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @src/js/utils/hostConfig */ "./src/js/utils/hostConfig.js");
/* harmony import */ var _src_js_utils_md5__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @src/js/utils/md5 */ "./src/js/utils/md5.js");
/* harmony import */ var _src_js_utils_fun__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @src/js/utils/fun */ "./src/js/utils/fun.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/lib/axios.js");
/*****************************************************
 * 基于Axios封装的Http请求类，可支持不同域源的调用
 * eq： this.$http.httpPost()
 ****************************************************/







/**
 * 获取签名串sign
 * @param "path"
 * @param {data}
 * @param "path"
 * @return "sign"
 */
let SecretKey = "piw38kulfozrea7ydmjnvbc965q1gt2x";
let createSign = function (method, URL, param, ClientTimestamp) {
  let StringToSign = method + "\n" + URL + "\n" + ClientTimestamp + "\n" + (param ? JSON.stringify(param) : "");
  console.log(StringToSign);
  let HmacSignature = crypto_js__WEBPACK_IMPORTED_MODULE_0__.enc.Base64.stringify((0,crypto_js__WEBPACK_IMPORTED_MODULE_0__.HmacSHA256)(StringToSign, SecretKey));
  let Base64URL = function (base64Str) {
    let safeB64 = base64Str.replace(/\+/g, "-");
    safeB64 = safeB64.replace(/\//g, "_");
    let mod4 = safeB64.length % 4;
    let modAddStr = "====";
    safeB64 = safeB64 + modAddStr.substring(0, mod4);
    return safeB64;
  };
  //logZYKJ(HmacSignature, Base64URL(HmacSignature), StringToSign);
  return Base64URL(HmacSignature);
};

/**
 * 全局默认配置
 */
//  Axios.defaults.baseURL = process.env.VUE_APP_SERVER2;
axios__WEBPACK_IMPORTED_MODULE_5__["default"].defaults.timeout = 60000;
axios__WEBPACK_IMPORTED_MODULE_5__["default"].defaults.withCredentials = true;
let transformRequest = (req, headers) => {
  if (headers && headers["Content-Type"] && headers["Content-Type"].indexOf("multipart/form-data") != -1) {
    let formData = new FormData();
    for (let key in req) {
      formData.append(key, req[key]);
    }
    return formData;
  }
  return JSON.stringify(req);
};
let transformResponse = config => {
  return function (res) {
    if (res && res.length > 0) {
      res = JSON.parse(res);
      // console.log(res,8888);
      let {
        error_code,
        message
      } = res;
      // error_code = 100002001
      if (error_code) {
        let duration = 4500;
        //登录失效
        if (error_code === 20000) {
          duration = 2000;
        }
        _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__["default"].msgError(message);
      }
    }
    return res;
  };
};
let request = async (method, url, path, d_p, config) => {
  let data = undefined;
  let params = undefined;
  method = method.toUpperCase();
  let isRemote = path.indexOf("http") > -1 && path.indexOf("http") < 9;
  if (isRemote) {
    url = path;
  } else {
    url = url + (path.indexOf("/") === 0 ? path.substr(1) : path);
  }
  //开发环境启用mock
  let isMock = window.isMock;
  if (typeof config !== "undefined") {
    if (typeof config.isMock !== "undefined") {
      isMock = config.isMock;
      delete config.isMock;
    }
  }
  if (isMock) {
    url = url + (path.indexOf("/") === 0 ? path.substr(1) : path);
    //mock接口要禁用上传进度回调
    if (config && config.onUploadProgress) {
      delete config.onUploadProgress;
    }
  }

  //合并请求
  let token = await (0,_src_js_utils_fun__WEBPACK_IMPORTED_MODULE_4__.getToken)();
  let timestamp = new Date().getTime();
  let headers = {
    ts: timestamp,
    sign: createSign(method, url, d_p, timestamp),
    token
  };
  switch (method) {
    case "GET":
      params = d_p || {};
      break;
    default:
    case "POST":
      data = d_p || {};
      headers["Content-Type"] = config && config.contentType ? config.contentType : "application/json";
      break;
  }
  if (url instanceof Array) {
    return axios__WEBPACK_IMPORTED_MODULE_5__["default"].all([]).then(axios__WEBPACK_IMPORTED_MODULE_5__["default"].spread(function () {}));
  } else {
    let resTransformer = transformResponse(config);
    if (config && config.headers) {
      headers = {
        ...headers,
        ...config.headers
      };
      delete config.headers;
    }
    return (0,axios__WEBPACK_IMPORTED_MODULE_5__["default"])(Object.assign({
      baseURL: _src_js_utils_hostConfig__WEBPACK_IMPORTED_MODULE_2__["default"].baseUrl,
      headers,
      method,
      url,
      data,
      params,
      transformRequest,
      transformResponse: resTransformer
    }, config)).then(response => {
      return response.data;
    }).catch(error => {
      console.error("服务端请求/响应错误：", error, error.config);
      return Promise.reject(error);
    });
  }
};

/**
 * Array/Object原型扩展，根据URL赋值数组
 * @author liubaohuo
 * @param variable <Array/Object> 变量
 * @param path <String> 支持完整URL，默认资源中心地址
 * @param params <Object> 数据参数
 * @param config <Object> 请求配置
 */
let assignByUrl = (variable, path, params, config) => {
  let self = variable;
  //不能直接赋值，因为Vue对组件定义的数组进行观察者模式的封装
  if (self instanceof Array) {
    self.splice(0, self.length);
  } else {
    for (var key in self) {
      delete self[key];
    }
  }
  postWeb(path, params || {}, config).then(res => {
    let {
      error_code,
      data
    } = res;
    if (!error_code) {
      //不能直接赋值，因为Vue对组件定义的数组进行观察者模式的封装
      let fieldData = data;
      if (config && config.field) {
        fieldData = data[config.field];
        delete config.field;
      }
      if (fieldData instanceof Array) {
        self.push(...fieldData);
      } else {
        for (var key in fieldData) {
          if (vm) {
            vm.$set(variable, key, fieldData[key]);
          } else {
            self[key] = fieldData[key];
          }
        }
      }
    }
  });
};
function encryptStr(str) {
  let sKey = '2EACC318510775E786F9C5DC94B5CC6B';
  let md5Str = _src_js_utils_md5__WEBPACK_IMPORTED_MODULE_3__["default"].hex_md5(`${str}${sKey}`).toUpperCase() + sKey.toUpperCase();
  return _src_js_utils_md5__WEBPACK_IMPORTED_MODULE_3__["default"].hex_md5(md5Str);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  request,
  httpGet: (path, params, config) => request("GET", "/", path, params, config),
  httpPost: (path, body, config) => request("POST", "/", path, body, config),
  httpUpload: (path, body, config) => request("POST", "/upload/", path, body, config),
  httpPatch: (path, body, config) => request("PATCH", "/", path, body, config),
  httpPut: (path, body, config) => request("PUT", "/", path, body, config),
  httpDelete: (path, body, config) => request("DELETE", "/", path, body, config),
  uploadWeb: (path, body = {}, config) => {
    config = Object.assign({}, config, {
      contentType: "multipart/form-data;boundary=------WebKitFormBoundaryJi04kSpfYXB9AWBZ"
    });
    return request("POST", "/", path, body, config);
  },
  encryptStr
});

/***/ },

/***/ "./src/js/utils/md5.js"
/*!*****************************!*\
  !*** ./src/js/utils/md5.js ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.1 Copyright (C) Paul Johnston 1999 - 2002.
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */

/*
 * Configurable variables. You may need to tweak these to be compatible with
 * the server-side, but the defaults work in most cases.
 */
var hexcase = 0; /* hex output format. 0 - lowercase; 1 - uppercase        */
var b64pad = ""; /* base-64 pad character. "=" for strict RFC compliance   */
var chrsz = 8; /* bits per input character. 8 - ASCII; 16 - Unicode      */

/*
 * These are the functions you'll usually want to call
 * They take string arguments and return either hex or base-64 encoded strings
 */
function hex_md5(s) {
  return binl2hex(core_md5(str2binl(s), s.length * chrsz));
}
function b64_md5(s) {
  return binl2b64(core_md5(str2binl(s), s.length * chrsz));
}
function str_md5(s) {
  return binl2str(core_md5(str2binl(s), s.length * chrsz));
}
function hex_hmac_md5(key, data) {
  return binl2hex(core_hmac_md5(key, data));
}
function b64_hmac_md5(key, data) {
  return binl2b64(core_hmac_md5(key, data));
}
function str_hmac_md5(key, data) {
  return binl2str(core_hmac_md5(key, data));
}

/*
 * Perform a simple self-test to see if the VM is working
 */
function md5_vm_test() {
  return hex_md5("abc") == "900150983cd24fb0d6963f7d28e17f72";
}

/*
 * Calculate the MD5 of an array of little-endian words, and a bit length
 */
function core_md5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[(len + 64 >>> 9 << 4) + 14] = len;
  var a = 1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d = 271733878;
  for (var i = 0; i < x.length; i += 16) {
    var olda = a;
    var oldb = b;
    var oldc = c;
    var oldd = d;
    a = md5_ff(a, b, c, d, x[i + 0], 7, -680876936);
    d = md5_ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5_ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5_ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5_ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5_ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5_ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5_ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5_ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5_ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5_ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5_ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5_ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5_ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5_ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5_ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5_gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5_gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5_gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5_gg(b, c, d, a, x[i + 0], 20, -373897302);
    a = md5_gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5_gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5_gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5_gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5_gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5_gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5_gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5_gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5_gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5_gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5_gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5_gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5_hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5_hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5_hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5_hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5_hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5_hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5_hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5_hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5_hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5_hh(d, a, b, c, x[i + 0], 11, -358537222);
    c = md5_hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5_hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5_hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5_hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5_hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5_hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5_ii(a, b, c, d, x[i + 0], 6, -198630844);
    d = md5_ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5_ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5_ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5_ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5_ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5_ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5_ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5_ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5_ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5_ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5_ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5_ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5_ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5_ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5_ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safe_add(a, olda);
    b = safe_add(b, oldb);
    c = safe_add(c, oldc);
    d = safe_add(d, oldd);
  }
  return Array(a, b, c, d);
}

/*
 * These functions implement the four basic operations the algorithm uses.
 */
function md5_cmn(q, a, b, x, s, t) {
  return safe_add(bit_rol(safe_add(safe_add(a, q), safe_add(x, t)), s), b);
}
function md5_ff(a, b, c, d, x, s, t) {
  return md5_cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5_gg(a, b, c, d, x, s, t) {
  return md5_cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5_hh(a, b, c, d, x, s, t) {
  return md5_cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5_ii(a, b, c, d, x, s, t) {
  return md5_cmn(c ^ (b | ~d), a, b, x, s, t);
}

/*
 * Calculate the HMAC-MD5, of a key and some data
 */
function core_hmac_md5(key, data) {
  var bkey = str2binl(key);
  if (bkey.length > 16) bkey = core_md5(bkey, key.length * chrsz);
  var ipad = Array(16),
    opad = Array(16);
  for (var i = 0; i < 16; i++) {
    ipad[i] = bkey[i] ^ 0x36363636;
    opad[i] = bkey[i] ^ 0x5C5C5C5C;
  }
  var hash = core_md5(ipad.concat(str2binl(data)), 512 + data.length * chrsz);
  return core_md5(opad.concat(hash), 512 + 128);
}

/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */
function safe_add(x, y) {
  var lsw = (x & 0xFFFF) + (y & 0xFFFF);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xFFFF;
}

/*
 * Bitwise rotate a 32-bit number to the left.
 */
function bit_rol(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}

/*
 * Convert a string to an array of little-endian words
 * If chrsz is ASCII, characters >255 have their hi-byte silently ignored.
 */
function str2binl(str) {
  var bin = Array();
  var mask = (1 << chrsz) - 1;
  for (var i = 0; i < str.length * chrsz; i += chrsz) bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << i % 32;
  return bin;
}

/*
 * Convert an array of little-endian words to a string
 */
function binl2str(bin) {
  var str = "";
  var mask = (1 << chrsz) - 1;
  for (var i = 0; i < bin.length * 32; i += chrsz) str += String.fromCharCode(bin[i >> 5] >>> i % 32 & mask);
  return str;
}

/*
 * Convert an array of little-endian words to a hex string.
 */
function binl2hex(binarray) {
  var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
  var str = "";
  for (var i = 0; i < binarray.length * 4; i++) {
    str += hex_tab.charAt(binarray[i >> 2] >> i % 4 * 8 + 4 & 0xF) + hex_tab.charAt(binarray[i >> 2] >> i % 4 * 8 & 0xF);
  }
  return str;
}

/*
 * Convert an array of little-endian words to a base-64 string
 */
function binl2b64(binarray) {
  var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var str = "";
  for (var i = 0; i < binarray.length * 4; i += 3) {
    var triplet = (binarray[i >> 2] >> 8 * (i % 4) & 0xFF) << 16 | (binarray[i + 1 >> 2] >> 8 * ((i + 1) % 4) & 0xFF) << 8 | binarray[i + 2 >> 2] >> 8 * ((i + 2) % 4) & 0xFF;
    for (var j = 0; j < 4; j++) {
      if (i * 8 + j * 6 > binarray.length * 32) str += b64pad;else str += tab.charAt(triplet >> 6 * (3 - j) & 0x3F);
    }
  }
  return str;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  hex_md5: hex_md5
});

/***/ },

/***/ "./src/js/utils/modal.js"
/*!*******************************!*\
  !*** ./src/js/utils/modal.js ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var element_plus_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! element-plus/es */ "./node_modules/element-plus/es/components/loading/index.mjs");
/* harmony import */ var element_plus_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! element-plus/es */ "./node_modules/element-plus/es/components/message/index.mjs");
/* harmony import */ var element_plus_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! element-plus/es */ "./node_modules/element-plus/es/components/message-box/index.mjs");
/* harmony import */ var element_plus_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! element-plus/es */ "./node_modules/element-plus/es/components/notification/index.mjs");
/* harmony import */ var element_plus_es_components_message_style_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! element-plus/es/components/message/style/css */ "./node_modules/element-plus/es/components/message/style/css.mjs");
/* harmony import */ var element_plus_es_components_message_box_style_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! element-plus/es/components/message-box/style/css */ "./node_modules/element-plus/es/components/message-box/style/css.mjs");
/* harmony import */ var element_plus_es_components_notification_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! element-plus/es/components/notification/style/css */ "./node_modules/element-plus/es/components/notification/style/css.mjs");
/* harmony import */ var element_plus_es_components_loading_style_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! element-plus/es/components/loading/style/css */ "./node_modules/element-plus/es/components/loading/style/css.mjs");
let loadingInstance;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  // 消息提示
  msg(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_1__.ElMessage.info(content);
  },
  // 错误消息
  msgError(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_1__.ElMessage.error(content);
  },
  // 成功消息
  msgSuccess(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_1__.ElMessage.success(content);
  },
  // 警告消息
  msgWarning(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_1__.ElMessage.warning(content);
  },
  // 弹出提示
  alert(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_2__.ElMessageBox.alert(content, "系统提示");
  },
  // 错误提示
  alertError(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_2__.ElMessageBox.alert(content, "系统提示", {
      type: 'error'
    });
  },
  // 成功提示
  alertSuccess(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_2__.ElMessageBox.alert(content, "系统提示", {
      type: 'success'
    });
  },
  // 警告提示
  alertWarning(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_2__.ElMessageBox.alert(content, "系统提示", {
      type: 'warning'
    });
  },
  // 通知提示
  notify(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_3__.ElNotification.info(content);
  },
  // 错误通知
  notifyError(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_3__.ElNotification.error(content);
  },
  // 成功通知
  notifySuccess(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_3__.ElNotification.success(content);
  },
  // 警告通知
  notifyWarning(content) {
    element_plus_es__WEBPACK_IMPORTED_MODULE_3__.ElNotification.warning(content);
  },
  // 确认窗体
  confirm(content, options = {}) {
    return element_plus_es__WEBPACK_IMPORTED_MODULE_2__.ElMessageBox.confirm(content, "系统提示", {
      confirmButtonText: options.confirmButtonText || '确定',
      cancelButtonText: options.cancelButtonText || '取消',
      type: "warning",
      dangerouslyUseHTMLString: options.dangerouslyUseHTMLString
    });
  },
  // 提交内容
  prompt(content) {
    return element_plus_es__WEBPACK_IMPORTED_MODULE_2__.ElMessageBox.prompt(content, "系统提示", {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: "warning"
    });
  },
  // 打开遮罩层
  loading(content) {
    loadingInstance = element_plus_es__WEBPACK_IMPORTED_MODULE_0__.ElLoading.service({
      lock: true,
      text: content,
      background: "rgba(0, 0, 0, 0.7)"
    });
  },
  // 关闭遮罩层
  closeLoading() {
    loadingInstance.close();
  }
});

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=script&setup=true&lang=js"
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=script&setup=true&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @src/js/utils/modal */ "./src/js/utils/modal.js");
/* harmony import */ var _src_js_utils_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @src/js/utils/http */ "./src/js/utils/http.js");
/* unplugin-vue-components disabled */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'login',
  emits: ['loginSuccess'],
  setup(__props, {
    expose: __expose,
    emit: __emit
  }) {
    __expose();
    const emit = __emit;
    let model = (0,vue__WEBPACK_IMPORTED_MODULE_0__.reactive)({
      username: '',
      password: ''
    });
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(async () => {});
    function login() {
      let phone = model.username.replace(/\s+/ig, '');
      let password = model.password.replace(/^\s+/ig, '').replace(/\s+$/ig, '');
      if (!phone) {
        _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__["default"].msgWarning("请输入账号");
        return;
      }
      if (!password) {
        _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__["default"].msgWarning("请输入密码");
        return;
      }
      _src_js_utils_http__WEBPACK_IMPORTED_MODULE_2__["default"].httpPost('/teacher-ding-talk/login', {
        password: _src_js_utils_http__WEBPACK_IMPORTED_MODULE_2__["default"].encryptStr(model.password).toUpperCase(),
        username: model.username
      }).then(async res => {
        let {
          error_code,
          data
        } = res;
        if (!error_code) {
          emit('loginSuccess');
          _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__["default"].msgSuccess('登录成功！');
          await chrome.storage.local.set({
            token: res.data.token
          });
        }
      });
    }
    const __returned__ = {
      emit,
      get model() {
        return model;
      },
      set model(v) {
        model = v;
      },
      login,
      get modal() {
        return _src_js_utils_modal__WEBPACK_IMPORTED_MODULE_1__["default"];
      },
      get http() {
        return _src_js_utils_http__WEBPACK_IMPORTED_MODULE_2__["default"];
      }
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=script&setup=true&lang=js"
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=script&setup=true&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unplugin-vue-components disabled *//* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'main',
  setup(__props, {
    expose: __expose
  }) {
    __expose();
    let colors = ['red', 'blue', 'yellow', 'pink', 'green', 'orange'];
    function changeBg() {
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      chrome.tabs.query({
        active: true,
        currentWindow: false
      }, function (tabs) {
        let baiduTabs = tabs.filter(tab => tab.url.includes('https://www.baidu.com'));
        console.log(baiduTabs, 'baiduTabs');
        if (baiduTabs.length) {
          baiduTabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
              action: 'changeBg',
              data: randomColor
            });
          });
        } else {
          chrome.windows.create({
            url: "https://www.baidu.com",
            type: "normal",
            // 可选: "normal", "popup", "panel"
            width: 1000,
            height: 800,
            left: 100,
            top: 100,
            focused: true
          });
        }
      });
    }
    const __returned__ = {
      get colors() {
        return colors;
      },
      set colors(v) {
        colors = v;
      },
      changeBg
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=script&setup=true&lang=js"
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=script&setup=true&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* harmony import */ var _src_js_utils_fun__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @src/js/utils/fun */ "./src/js/utils/fun.js");
/* harmony import */ var _src_vue_components_login_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @src/vue/components/login.vue */ "./src/vue/components/login.vue");
/* harmony import */ var _src_vue_components_main_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @src/vue/components/main.vue */ "./src/vue/components/main.vue");
/* unplugin-vue-components disabled */


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  __name: 'popup',
  setup(__props, {
    expose: __expose
  }) {
    __expose();
    let isLogin = (0,vue__WEBPACK_IMPORTED_MODULE_0__.ref)(null);
    (0,vue__WEBPACK_IMPORTED_MODULE_0__.onMounted)(async () => {
      let token = await (0,_src_js_utils_fun__WEBPACK_IMPORTED_MODULE_1__.getToken)();
      isLogin.value = token ? true : false;
    });
    const __returned__ = {
      get isLogin() {
        return isLogin;
      },
      set isLogin(v) {
        isLogin = v;
      },
      get getToken() {
        return _src_js_utils_fun__WEBPACK_IMPORTED_MODULE_1__.getToken;
      },
      Login: _src_vue_components_login_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
      Main: _src_vue_components_main_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
    };
    Object.defineProperty(__returned__, '__isScriptSetup', {
      enumerable: false,
      value: true
    });
    return __returned__;
  }
});

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=template&id=3105ef72&scoped=true"
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=template&id=3105ef72&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* unplugin-vue-components disabled */
const _hoisted_1 = {
  class: "login-box"
};
const _hoisted_2 = {
  class: "loginFrame"
};
const _hoisted_3 = {
  class: "login-main"
};
const _hoisted_4 = {
  class: "login-ipt account-main"
};
const _hoisted_5 = {
  class: "login-ipt pwd-main"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_2, [_cache[4] || (_cache[4] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "main-text"
  }, "密码登录", -1 /* CACHED */)), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_3, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_4, [_cache[2] || (_cache[2] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "ipt-ico ico-phone"
  }, null, -1 /* CACHED */)), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
    type: "text",
    "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => $setup.model.username = $event),
    class: "ipt",
    placeholder: "请输入账号"
  }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.model.username]])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", _hoisted_5, [_cache[3] || (_cache[3] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "ipt-ico ico-eye"
  }, null, -1 /* CACHED */)), (0,vue__WEBPACK_IMPORTED_MODULE_0__.withDirectives)((0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("input", {
    type: "password",
    "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => $setup.model.password = $event),
    class: "ipt",
    placeholder: "请输入密码"
  }, null, 512 /* NEED_PATCH */), [[vue__WEBPACK_IMPORTED_MODULE_0__.vModelText, $setup.model.password]])]), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "btn btn-orange btn-login",
    onClick: $setup.login
  }, "登录")])])]);
}

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=template&id=49f0f080&scoped=true"
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=template&id=49f0f080&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* unplugin-vue-components disabled */
const _hoisted_1 = {
  class: "main-box"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)("div", _hoisted_1, [(0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "mainFrame"
  }, [_cache[0] || (_cache[0] = (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "main-text"
  }, "点击即可为百度页面更换皮肤", -1 /* CACHED */)), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementVNode)("div", {
    class: "btn btn-orange",
    onClick: $setup.changeBg
  }, "换一换")])]);
}

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=template&id=2d668dda"
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=template&id=2d668dda ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* binding */ render)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm-bundler.js");
/* unplugin-vue-components disabled */
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createElementBlock)(vue__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, [$setup.isLogin === false ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)($setup["Login"], {
    key: 0,
    onLoginSuccess: _cache[0] || (_cache[0] = $event => $setup.isLogin = true)
  })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true), $setup.isLogin ? ((0,vue__WEBPACK_IMPORTED_MODULE_0__.openBlock)(), (0,vue__WEBPACK_IMPORTED_MODULE_0__.createBlock)($setup["Main"], {
    key: 1
  })) : (0,vue__WEBPACK_IMPORTED_MODULE_0__.createCommentVNode)("v-if", true)], 64 /* STABLE_FRAGMENT */);
}

/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true"
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* unplugin-vue-components disabled */// extracted by mini-css-extract-plugin


/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true"
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* unplugin-vue-components disabled */// extracted by mini-css-extract-plugin


/***/ },

/***/ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss"
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* unplugin-vue-components disabled */// extracted by mini-css-extract-plugin


/***/ },

/***/ "./src/vue/components/login.vue"
/*!**************************************!*\
  !*** ./src/vue/components/login.vue ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _login_vue_vue_type_template_id_3105ef72_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.vue?vue&type=template&id=3105ef72&scoped=true */ "./src/vue/components/login.vue?vue&type=template&id=3105ef72&scoped=true");
/* harmony import */ var _login_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.vue?vue&type=script&setup=true&lang=js */ "./src/vue/components/login.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _login_vue_vue_type_style_index_0_id_3105ef72_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true */ "./src/vue/components/login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/dist/exportHelper.js */ "./node_modules/vue-loader/dist/exportHelper.js");
/* unplugin-vue-components disabled */



;


const __exports__ = /*#__PURE__*/(0,_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_login_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_login_vue_vue_type_template_id_3105ef72_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-3105ef72"],['__file',"src/vue/components/login.vue"]])
/* hot reload */
if (false) // removed by dead control flow
{}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ },

/***/ "./src/vue/components/main.vue"
/*!*************************************!*\
  !*** ./src/vue/components/main.vue ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _main_vue_vue_type_template_id_49f0f080_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./main.vue?vue&type=template&id=49f0f080&scoped=true */ "./src/vue/components/main.vue?vue&type=template&id=49f0f080&scoped=true");
/* harmony import */ var _main_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main.vue?vue&type=script&setup=true&lang=js */ "./src/vue/components/main.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _main_vue_vue_type_style_index_0_id_49f0f080_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true */ "./src/vue/components/main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/dist/exportHelper.js */ "./node_modules/vue-loader/dist/exportHelper.js");
/* unplugin-vue-components disabled */



;


const __exports__ = /*#__PURE__*/(0,_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_main_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_main_vue_vue_type_template_id_49f0f080_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render],['__scopeId',"data-v-49f0f080"],['__file',"src/vue/components/main.vue"]])
/* hot reload */
if (false) // removed by dead control flow
{}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ },

/***/ "./src/vue/popup.vue"
/*!***************************!*\
  !*** ./src/vue/popup.vue ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _popup_vue_vue_type_template_id_2d668dda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./popup.vue?vue&type=template&id=2d668dda */ "./src/vue/popup.vue?vue&type=template&id=2d668dda");
/* harmony import */ var _popup_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./popup.vue?vue&type=script&setup=true&lang=js */ "./src/vue/popup.vue?vue&type=script&setup=true&lang=js");
/* harmony import */ var _popup_vue_vue_type_style_index_0_id_2d668dda_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss */ "./src/vue/popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss");
/* harmony import */ var _node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/vue-loader/dist/exportHelper.js */ "./node_modules/vue-loader/dist/exportHelper.js");
/* unplugin-vue-components disabled */



;


const __exports__ = /*#__PURE__*/(0,_node_modules_vue_loader_dist_exportHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_popup_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"], [['render',_popup_vue_vue_type_template_id_2d668dda__WEBPACK_IMPORTED_MODULE_0__.render],['__file',"src/vue/popup.vue"]])
/* hot reload */
if (false) // removed by dead control flow
{}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__exports__);

/***/ },

/***/ "./src/vue/components/login.vue?vue&type=script&setup=true&lang=js"
/*!*************************************************************************!*\
  !*** ./src/vue/components/login.vue?vue&type=script&setup=true&lang=js ***!
  \*************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_login_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_login_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../../node_modules/babel-loader/lib/index.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./login.vue?vue&type=script&setup=true&lang=js */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=script&setup=true&lang=js");
/* unplugin-vue-components disabled */ 

/***/ },

/***/ "./src/vue/components/main.vue?vue&type=script&setup=true&lang=js"
/*!************************************************************************!*\
  !*** ./src/vue/components/main.vue?vue&type=script&setup=true&lang=js ***!
  \************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_main_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_main_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../../node_modules/babel-loader/lib/index.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./main.vue?vue&type=script&setup=true&lang=js */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=script&setup=true&lang=js");
/* unplugin-vue-components disabled */ 

/***/ },

/***/ "./src/vue/popup.vue?vue&type=script&setup=true&lang=js"
/*!**************************************************************!*\
  !*** ./src/vue/popup.vue?vue&type=script&setup=true&lang=js ***!
  \**************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_popup_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_popup_vue_vue_type_script_setup_true_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../node_modules/babel-loader/lib/index.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./popup.vue?vue&type=script&setup=true&lang=js */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=script&setup=true&lang=js");
/* unplugin-vue-components disabled */ 

/***/ },

/***/ "./src/vue/components/login.vue?vue&type=template&id=3105ef72&scoped=true"
/*!********************************************************************************!*\
  !*** ./src/vue/components/login.vue?vue&type=template&id=3105ef72&scoped=true ***!
  \********************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_login_vue_vue_type_template_id_3105ef72_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_login_vue_vue_type_template_id_3105ef72_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../../node_modules/babel-loader/lib/index.js!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./login.vue?vue&type=template&id=3105ef72&scoped=true */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=template&id=3105ef72&scoped=true");
/* unplugin-vue-components disabled */

/***/ },

/***/ "./src/vue/components/main.vue?vue&type=template&id=49f0f080&scoped=true"
/*!*******************************************************************************!*\
  !*** ./src/vue/components/main.vue?vue&type=template&id=49f0f080&scoped=true ***!
  \*******************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_main_vue_vue_type_template_id_49f0f080_scoped_true__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_main_vue_vue_type_template_id_49f0f080_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../../node_modules/babel-loader/lib/index.js!../../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./main.vue?vue&type=template&id=49f0f080&scoped=true */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=template&id=49f0f080&scoped=true");
/* unplugin-vue-components disabled */

/***/ },

/***/ "./src/vue/popup.vue?vue&type=template&id=2d668dda"
/*!*********************************************************!*\
  !*** ./src/vue/popup.vue?vue&type=template&id=2d668dda ***!
  \*********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* reexport safe */ _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_popup_vue_vue_type_template_id_2d668dda__WEBPACK_IMPORTED_MODULE_0__.render)
/* harmony export */ });
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_dist_templateLoader_js_ruleSet_1_rules_2_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_popup_vue_vue_type_template_id_2d668dda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../node_modules/babel-loader/lib/index.js!../../node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./popup.vue?vue&type=template&id=2d668dda */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=template&id=2d668dda");
/* unplugin-vue-components disabled */

/***/ },

/***/ "./src/vue/components/login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true"
/*!***********************************************************************************************!*\
  !*** ./src/vue/components/login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true ***!
  \***********************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_mini_css_extract_plugin_dist_loader_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_login_vue_vue_type_style_index_0_id_3105ef72_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../../node_modules/mini-css-extract-plugin/dist/loader.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/sass-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/login.vue?vue&type=style&index=0&id=3105ef72&lang=scss&scoped=true");
/* unplugin-vue-components disabled */

/***/ },

/***/ "./src/vue/components/main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true"
/*!**********************************************************************************************!*\
  !*** ./src/vue/components/main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true ***!
  \**********************************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_mini_css_extract_plugin_dist_loader_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_main_vue_vue_type_style_index_0_id_49f0f080_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../../node_modules/mini-css-extract-plugin/dist/loader.js!../../../node_modules/css-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/stylePostLoader.js!../../../node_modules/sass-loader/dist/cjs.js!../../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/components/main.vue?vue&type=style&index=0&id=49f0f080&lang=scss&scoped=true");
/* unplugin-vue-components disabled */

/***/ },

/***/ "./src/vue/popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss"
/*!************************************************************************!*\
  !*** ./src/vue/popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss ***!
  \************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_16_use_0_node_modules_unplugin_vue_components_node_modules_unplugin_dist_webpack_loaders_transform_js_ruleSet_1_rules_17_use_0_node_modules_mini_css_extract_plugin_dist_loader_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_dist_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_dist_index_js_ruleSet_1_rules_9_use_0_popup_vue_vue_type_style_index_0_id_2d668dda_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!../../node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!../../node_modules/mini-css-extract-plugin/dist/loader.js!../../node_modules/css-loader/dist/cjs.js!../../node_modules/vue-loader/dist/stylePostLoader.js!../../node_modules/sass-loader/dist/cjs.js!../../node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss */ "./node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[16].use[0]!./node_modules/unplugin-vue-components/node_modules/unplugin/dist/webpack/loaders/transform.js??ruleSet[1].rules[17].use[0]!./node_modules/mini-css-extract-plugin/dist/loader.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/dist/index.js??ruleSet[1].rules[9].use[0]!./src/vue/popup.vue?vue&type=style&index=0&id=2d668dda&lang=scss");
/* unplugin-vue-components disabled */

/***/ }

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["js/common/vendor"], () => (__webpack_exec__("./src/js/entrys/popup.js")));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvZW50cnlzL3BvcHVwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFvQztBQUNwQyxJQUFJQyxHQUFHLEdBQUdDLDhDQUFTLENBQUNGLDBEQUFHLENBQUM7QUFDeEJDLEdBQUcsQ0FBQ0UsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDOzs7Ozs7Ozs7Ozs7OztBQ0ZqQjtBQUNBO0FBQ0E7O0FBRU8sSUFBSUMsUUFBUSxHQUFHLGVBQUFBLENBQUEsRUFBa0I7RUFDdEMsT0FBTyxJQUFJQyxPQUFPLENBQUVDLE9BQU8sSUFBSztJQUM5QkMsTUFBTSxDQUFDQyxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUdDLE1BQU0sSUFBSztNQUM5Q0wsT0FBTyxDQUFDSyxNQUFNLENBQUNDLEtBQUssQ0FBQztJQUN2QixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7O0FDVEQsTUFBTUMsT0FBTyxHQUFHLDRCQUE0QjtBQUU1QyxpRUFBZTtFQUNiQTtBQUNGLENBQUMsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEQ7QUFDQTtBQUNBO0FBQ0E7QUFDNEM7QUFDTDtBQUNVO0FBQ2Q7QUFDTztBQUdoQjs7QUFFMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJTyxTQUFTLEdBQUcsa0NBQWtDO0FBQ2xELElBQUlDLFVBQVUsR0FBRyxTQUFBQSxDQUFVQyxNQUFNLEVBQUVDLEdBQUcsRUFBRUMsS0FBSyxFQUFFQyxlQUFlLEVBQUU7RUFDOUQsSUFBSUMsWUFBWSxHQUFHSixNQUFNLEdBQUcsSUFBSSxHQUFHQyxHQUFHLEdBQUcsSUFBSSxHQUFHRSxlQUFlLEdBQUcsSUFBSSxJQUFJRCxLQUFLLEdBQUdHLElBQUksQ0FBQ0MsU0FBUyxDQUFDSixLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7RUFDN0dLLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSixZQUFZLENBQUM7RUFDekIsSUFBSUssYUFBYSxHQUFHakIsMENBQUcsQ0FBQ2tCLE1BQU0sQ0FBQ0osU0FBUyxDQUFDYixxREFBVSxDQUFDVyxZQUFZLEVBQUVOLFNBQVMsQ0FBQyxDQUFDO0VBQzdFLElBQUlhLFNBQVMsR0FBRyxTQUFBQSxDQUFVQyxTQUFTLEVBQUU7SUFDbkMsSUFBSUMsT0FBTyxHQUFHRCxTQUFTLENBQUNFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDO0lBQzNDRCxPQUFPLEdBQUdBLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUM7SUFDckMsSUFBSUMsSUFBSSxHQUFHRixPQUFPLENBQUNHLE1BQU0sR0FBRyxDQUFDO0lBQzdCLElBQUlDLFNBQVMsR0FBRyxNQUFNO0lBQ3RCSixPQUFPLEdBQUdBLE9BQU8sR0FBR0ksU0FBUyxDQUFDQyxTQUFTLENBQUMsQ0FBQyxFQUFFSCxJQUFJLENBQUM7SUFDaEQsT0FBT0YsT0FBTztFQUNoQixDQUFDO0VBQ0Q7RUFDQSxPQUFPRixTQUFTLENBQUNGLGFBQWEsQ0FBQztBQUNqQyxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0FaLDZDQUFLLENBQUNzQixRQUFRLENBQUNDLE9BQU8sR0FBRyxLQUFLO0FBQzlCdkIsNkNBQUssQ0FBQ3NCLFFBQVEsQ0FBQ0UsZUFBZSxHQUFHLElBQUk7QUFDckMsSUFBSUMsZ0JBQWdCLEdBQUdBLENBQUNDLEdBQUcsRUFBRUMsT0FBTyxLQUFLO0VBQ3ZDLElBQUlBLE9BQU8sSUFBSUEsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJQSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFO0lBQ3RHLElBQUlDLFFBQVEsR0FBRyxJQUFJQyxRQUFRLENBQUMsQ0FBQztJQUM3QixLQUFLLElBQUlDLEdBQUcsSUFBSUwsR0FBRyxFQUFFO01BQ25CRyxRQUFRLENBQUNHLE1BQU0sQ0FBQ0QsR0FBRyxFQUFFTCxHQUFHLENBQUNLLEdBQUcsQ0FBQyxDQUFDO0lBQ2hDO0lBQ0EsT0FBT0YsUUFBUTtFQUNqQjtFQUVBLE9BQU9yQixJQUFJLENBQUNDLFNBQVMsQ0FBQ2lCLEdBQUcsQ0FBQztBQUM1QixDQUFDO0FBRUQsSUFBSU8saUJBQWlCLEdBQUlDLE1BQU0sSUFBSztFQUNsQyxPQUFPLFVBQVNDLEdBQUcsRUFBQztJQUNsQixJQUFJQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ2hCLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDekJnQixHQUFHLEdBQUczQixJQUFJLENBQUM0QixLQUFLLENBQUNELEdBQUcsQ0FBQztNQUNyQjtNQUNBLElBQUk7UUFBRUUsVUFBVTtRQUFFQztNQUFRLENBQUMsR0FBR0gsR0FBRztNQUNqQztNQUNBLElBQUlFLFVBQVUsRUFBRTtRQUNkLElBQUlFLFFBQVEsR0FBRyxJQUFJO1FBQ25CO1FBQ0EsSUFBSUYsVUFBVSxLQUFLLEtBQUssRUFBRTtVQUN4QkUsUUFBUSxHQUFHLElBQUk7UUFDakI7UUFDQTFDLDJEQUFLLENBQUMyQyxRQUFRLENBQUNGLE9BQU8sQ0FBQztNQUN6QjtJQUNGO0lBQ0EsT0FBT0gsR0FBRztFQUNaLENBQUM7QUFDSCxDQUFDO0FBRUQsSUFBSU0sT0FBTyxHQUFHLE1BQUFBLENBQU90QyxNQUFNLEVBQUV1QyxHQUFHLEVBQUVDLElBQUksRUFBRUMsR0FBRyxFQUFFVixNQUFNLEtBQUs7RUFDdEQsSUFBSVcsSUFBSSxHQUFHQyxTQUFTO0VBQ3BCLElBQUlDLE1BQU0sR0FBR0QsU0FBUztFQUN0QjNDLE1BQU0sR0FBR0EsTUFBTSxDQUFDNkMsV0FBVyxDQUFDLENBQUM7RUFDN0IsSUFBSUMsUUFBUSxHQUFHTixJQUFJLENBQUNmLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSWUsSUFBSSxDQUFDZixPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztFQUNwRSxJQUFJcUIsUUFBUSxFQUFFO0lBQ1pQLEdBQUcsR0FBR0MsSUFBSTtFQUNaLENBQUMsTUFBTTtJQUNMRCxHQUFHLEdBQUdBLEdBQUcsSUFBSUMsSUFBSSxDQUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHZSxJQUFJLENBQUNPLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBR1AsSUFBSSxDQUFDO0VBQy9EO0VBQ0E7RUFDQSxJQUFJUSxNQUFNLEdBQUdDLE1BQU0sQ0FBQ0QsTUFBTTtFQUMxQixJQUFJLE9BQU9qQixNQUFNLEtBQUssV0FBVyxFQUFFO0lBQ2pDLElBQUksT0FBT0EsTUFBTSxDQUFDaUIsTUFBTSxLQUFLLFdBQVcsRUFBRTtNQUN4Q0EsTUFBTSxHQUFHakIsTUFBTSxDQUFDaUIsTUFBTTtNQUN0QixPQUFPakIsTUFBTSxDQUFDaUIsTUFBTTtJQUN0QjtFQUNGO0VBQ0EsSUFBSUEsTUFBTSxFQUFFO0lBQ1ZULEdBQUcsR0FBR0EsR0FBRyxJQUFJQyxJQUFJLENBQUNmLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUdlLElBQUksQ0FBQ08sTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHUCxJQUFJLENBQUM7SUFDN0Q7SUFDQSxJQUFJVCxNQUFNLElBQUlBLE1BQU0sQ0FBQ21CLGdCQUFnQixFQUFFO01BQ3JDLE9BQU9uQixNQUFNLENBQUNtQixnQkFBZ0I7SUFDaEM7RUFDRjs7RUFFQTtFQUNBLElBQUk1RCxLQUFLLEdBQUcsTUFBTVIsMkRBQVEsQ0FBQyxDQUFDO0VBQzVCLElBQUlxRSxTQUFTLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDcEMsSUFBSTdCLE9BQU8sR0FBRztJQUNaOEIsRUFBRSxFQUFFSCxTQUFTO0lBQ2JJLElBQUksRUFBRXhELFVBQVUsQ0FBQ0MsTUFBTSxFQUFFdUMsR0FBRyxFQUFFRSxHQUFHLEVBQUVVLFNBQVMsQ0FBQztJQUM3QzdEO0VBQ0YsQ0FBQztFQUNELFFBQVFVLE1BQU07SUFDWixLQUFLLEtBQUs7TUFDUjRDLE1BQU0sR0FBR0gsR0FBRyxJQUFJLENBQUMsQ0FBQztNQUNsQjtJQUNGO0lBQ0EsS0FBSyxNQUFNO01BQ1RDLElBQUksR0FBR0QsR0FBRyxJQUFJLENBQUMsQ0FBQztNQUNoQmpCLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBR08sTUFBTSxJQUFJQSxNQUFNLENBQUN5QixXQUFXLEdBQUd6QixNQUFNLENBQUN5QixXQUFXLEdBQUcsa0JBQWtCO01BQ2hHO0VBQ0o7RUFDQSxJQUFJakIsR0FBRyxZQUFZa0IsS0FBSyxFQUFFO0lBQ3hCLE9BQU81RCw2Q0FBSyxDQUFDNkQsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUM5RCw2Q0FBSyxDQUFDK0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN6RCxDQUFDLE1BQU07SUFDTCxJQUFJQyxjQUFjLEdBQUcvQixpQkFBaUIsQ0FBQ0MsTUFBTSxDQUFDO0lBQzlDLElBQUdBLE1BQU0sSUFBSUEsTUFBTSxDQUFDUCxPQUFPLEVBQUM7TUFDMUJBLE9BQU8sR0FBRztRQUFDLEdBQUdBLE9BQU87UUFBQyxHQUFHTyxNQUFNLENBQUNQO01BQU8sQ0FBQztNQUN4QyxPQUFPTyxNQUFNLENBQUNQLE9BQU87SUFDdkI7SUFDQSxPQUFPM0IsaURBQUssQ0FDVmlFLE1BQU0sQ0FBQ0MsTUFBTSxDQUNYO01BQ0VDLE9BQU8sRUFBRXJFLGdFQUFVLENBQUNKLE9BQU87TUFDM0JpQyxPQUFPO01BQ1B4QixNQUFNO01BQ051QyxHQUFHO01BQ0hHLElBQUk7TUFDSkUsTUFBTTtNQUNOdEIsZ0JBQWdCO01BQ2hCUSxpQkFBaUIsRUFBQytCO0lBQ3BCLENBQUMsRUFDRDlCLE1BQ0YsQ0FDRixDQUFDLENBQ0U0QixJQUFJLENBQUVNLFFBQVEsSUFBSztNQUNsQixPQUFPQSxRQUFRLENBQUN2QixJQUFJO0lBQ3RCLENBQUMsQ0FBQyxDQUNEd0IsS0FBSyxDQUFFQyxLQUFLLElBQUs7TUFDaEI1RCxPQUFPLENBQUM0RCxLQUFLLENBQUMsYUFBYSxFQUFFQSxLQUFLLEVBQUVBLEtBQUssQ0FBQ3BDLE1BQU0sQ0FBQztNQUNqRCxPQUFPaEQsT0FBTyxDQUFDcUYsTUFBTSxDQUFDRCxLQUFLLENBQUM7SUFDOUIsQ0FBQyxDQUFDO0VBQ047QUFDRixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJRSxXQUFXLEdBQUdBLENBQUNDLFFBQVEsRUFBRTlCLElBQUksRUFBRUksTUFBTSxFQUFFYixNQUFNLEtBQUs7RUFDcEQsSUFBSXdDLElBQUksR0FBR0QsUUFBUTtFQUNuQjtFQUNBLElBQUlDLElBQUksWUFBWWQsS0FBSyxFQUFFO0lBQ3pCYyxJQUFJLENBQUNDLE1BQU0sQ0FBQyxDQUFDLEVBQUVELElBQUksQ0FBQ3ZELE1BQU0sQ0FBQztFQUM3QixDQUFDLE1BQU07SUFDTCxLQUFLLElBQUlZLEdBQUcsSUFBSTJDLElBQUksRUFBRTtNQUNwQixPQUFPQSxJQUFJLENBQUMzQyxHQUFHLENBQUM7SUFDbEI7RUFDRjtFQUNBNkMsT0FBTyxDQUFDakMsSUFBSSxFQUFFSSxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUViLE1BQU0sQ0FBQyxDQUFDNEIsSUFBSSxDQUFFM0IsR0FBRyxJQUFLO0lBQ2hELElBQUk7TUFBRUUsVUFBVTtNQUFFUTtJQUFLLENBQUMsR0FBR1YsR0FBRztJQUM5QixJQUFJLENBQUNFLFVBQVUsRUFBRTtNQUNmO01BQ0EsSUFBSXdDLFNBQVMsR0FBR2hDLElBQUk7TUFDcEIsSUFBSVgsTUFBTSxJQUFJQSxNQUFNLENBQUM0QyxLQUFLLEVBQUU7UUFDMUJELFNBQVMsR0FBR2hDLElBQUksQ0FBQ1gsTUFBTSxDQUFDNEMsS0FBSyxDQUFDO1FBQzlCLE9BQU81QyxNQUFNLENBQUM0QyxLQUFLO01BQ3JCO01BQ0EsSUFBSUQsU0FBUyxZQUFZakIsS0FBSyxFQUFFO1FBQzlCYyxJQUFJLENBQUNLLElBQUksQ0FBQyxHQUFHRixTQUFTLENBQUM7TUFDekIsQ0FBQyxNQUFNO1FBQ0wsS0FBSyxJQUFJOUMsR0FBRyxJQUFJOEMsU0FBUyxFQUFFO1VBQ3pCLElBQUlHLEVBQUUsRUFBRTtZQUNOQSxFQUFFLENBQUNDLElBQUksQ0FBQ1IsUUFBUSxFQUFFMUMsR0FBRyxFQUFFOEMsU0FBUyxDQUFDOUMsR0FBRyxDQUFDLENBQUM7VUFDeEMsQ0FBQyxNQUFNO1lBQ0wyQyxJQUFJLENBQUMzQyxHQUFHLENBQUMsR0FBRzhDLFNBQVMsQ0FBQzlDLEdBQUcsQ0FBQztVQUM1QjtRQUNGO01BQ0Y7SUFDRjtFQUNGLENBQUMsQ0FBQztBQUNKLENBQUM7QUFFRCxTQUFTbUQsVUFBVUEsQ0FBQ0MsR0FBRyxFQUFFO0VBQ3ZCLElBQUlDLElBQUksR0FBRyxrQ0FBa0M7RUFDN0MsSUFBSUMsTUFBTSxHQUFHdEYseURBQUcsQ0FBQ3VGLE9BQU8sQ0FBQyxHQUFHSCxHQUFHLEdBQUdDLElBQUksRUFBRSxDQUFDLENBQUNwQyxXQUFXLENBQUMsQ0FBQyxHQUFHb0MsSUFBSSxDQUFDcEMsV0FBVyxDQUFDLENBQUM7RUFDNUUsT0FBT2pELHlEQUFHLENBQUN1RixPQUFPLENBQUNELE1BQU0sQ0FBQztBQUM1QjtBQUVBLGlFQUFlO0VBQ2I1QyxPQUFPO0VBQ1A4QyxPQUFPLEVBQUVBLENBQUM1QyxJQUFJLEVBQUVJLE1BQU0sRUFBRWIsTUFBTSxLQUFLTyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRUUsSUFBSSxFQUFFSSxNQUFNLEVBQUViLE1BQU0sQ0FBQztFQUM1RXNELFFBQVEsRUFBRUEsQ0FBQzdDLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sS0FBS08sT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUVFLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sQ0FBQztFQUMxRXdELFVBQVUsRUFBRUEsQ0FBQy9DLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sS0FBS08sT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUVFLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sQ0FBQztFQUNuRnlELFNBQVMsRUFBRUEsQ0FBQ2hELElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sS0FBS08sT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUVFLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sQ0FBQztFQUM1RTBELE9BQU8sRUFBRUEsQ0FBQ2pELElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sS0FBS08sT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUVFLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sQ0FBQztFQUN4RTJELFVBQVUsRUFBRUEsQ0FBQ2xELElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sS0FBS08sT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUVFLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sQ0FBQztFQUM5RTRELFNBQVMsRUFBRUEsQ0FBQ25ELElBQUksRUFBRThDLElBQUksR0FBRyxDQUFDLENBQUMsRUFBRXZELE1BQU0sS0FBSztJQUN0Q0EsTUFBTSxHQUFHK0IsTUFBTSxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUVoQyxNQUFNLEVBQUU7TUFDakN5QixXQUFXLEVBQUU7SUFDZixDQUFDLENBQUM7SUFDRixPQUFPbEIsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUVFLElBQUksRUFBRThDLElBQUksRUFBRXZELE1BQU0sQ0FBQztFQUNqRCxDQUFDO0VBQ0RnRDtBQUNGLENBQUMsRTs7Ozs7Ozs7Ozs7Ozs7QUN2TkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlhLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBRTtBQUNsQixJQUFJQyxNQUFNLEdBQUksRUFBRSxDQUFDLENBQUM7QUFDbEIsSUFBSUMsS0FBSyxHQUFLLENBQUMsQ0FBQyxDQUFFOztBQUVsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNYLE9BQU9BLENBQUNZLENBQUMsRUFBQztFQUFFLE9BQU9DLFFBQVEsQ0FBQ0MsUUFBUSxDQUFDQyxRQUFRLENBQUNILENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUMvRSxNQUFNLEdBQUc4RSxLQUFLLENBQUMsQ0FBQztBQUFDO0FBQzlFLFNBQVNLLE9BQU9BLENBQUNKLENBQUMsRUFBQztFQUFFLE9BQU9LLFFBQVEsQ0FBQ0gsUUFBUSxDQUFDQyxRQUFRLENBQUNILENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUMvRSxNQUFNLEdBQUc4RSxLQUFLLENBQUMsQ0FBQztBQUFDO0FBQzlFLFNBQVNPLE9BQU9BLENBQUNOLENBQUMsRUFBQztFQUFFLE9BQU9PLFFBQVEsQ0FBQ0wsUUFBUSxDQUFDQyxRQUFRLENBQUNILENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUMvRSxNQUFNLEdBQUc4RSxLQUFLLENBQUMsQ0FBQztBQUFDO0FBQzlFLFNBQVNTLFlBQVlBLENBQUMzRSxHQUFHLEVBQUVjLElBQUksRUFBRTtFQUFFLE9BQU9zRCxRQUFRLENBQUNRLGFBQWEsQ0FBQzVFLEdBQUcsRUFBRWMsSUFBSSxDQUFDLENBQUM7QUFBRTtBQUM5RSxTQUFTK0QsWUFBWUEsQ0FBQzdFLEdBQUcsRUFBRWMsSUFBSSxFQUFFO0VBQUUsT0FBTzBELFFBQVEsQ0FBQ0ksYUFBYSxDQUFDNUUsR0FBRyxFQUFFYyxJQUFJLENBQUMsQ0FBQztBQUFFO0FBQzlFLFNBQVNnRSxZQUFZQSxDQUFDOUUsR0FBRyxFQUFFYyxJQUFJLEVBQUU7RUFBRSxPQUFPNEQsUUFBUSxDQUFDRSxhQUFhLENBQUM1RSxHQUFHLEVBQUVjLElBQUksQ0FBQyxDQUFDO0FBQUU7O0FBRTlFO0FBQ0E7QUFDQTtBQUNBLFNBQVNpRSxXQUFXQSxDQUFBLEVBQ3BCO0VBQ0UsT0FBT3hCLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxrQ0FBa0M7QUFDN0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBU2MsUUFBUUEsQ0FBQ1csQ0FBQyxFQUFFQyxHQUFHLEVBQ3hCO0VBQ0U7RUFDQUQsQ0FBQyxDQUFDQyxHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFNQSxHQUFHLEdBQUksRUFBRztFQUNuQ0QsQ0FBQyxDQUFDLENBQUdDLEdBQUcsR0FBRyxFQUFFLEtBQU0sQ0FBQyxJQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBR0EsR0FBRztFQUV2QyxJQUFJQyxDQUFDLEdBQUksVUFBVTtFQUNuQixJQUFJQyxDQUFDLEdBQUcsQ0FBQyxTQUFTO0VBQ2xCLElBQUlDLENBQUMsR0FBRyxDQUFDLFVBQVU7RUFDbkIsSUFBSUMsQ0FBQyxHQUFJLFNBQVM7RUFFbEIsS0FBSSxJQUFJQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdOLENBQUMsQ0FBQzVGLE1BQU0sRUFBRWtHLENBQUMsSUFBSSxFQUFFLEVBQ3BDO0lBQ0UsSUFBSUMsSUFBSSxHQUFHTCxDQUFDO0lBQ1osSUFBSU0sSUFBSSxHQUFHTCxDQUFDO0lBQ1osSUFBSU0sSUFBSSxHQUFHTCxDQUFDO0lBQ1osSUFBSU0sSUFBSSxHQUFHTCxDQUFDO0lBRVpILENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRyxDQUFDLFNBQVMsQ0FBQztJQUMvQ0QsQ0FBQyxHQUFHTSxNQUFNLENBQUNOLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUosQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQy9DRixDQUFDLEdBQUdPLE1BQU0sQ0FBQ1AsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUcsU0FBUyxDQUFDO0lBQy9DSCxDQUFDLEdBQUdRLE1BQU0sQ0FBQ1IsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDaERKLENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRyxDQUFDLFNBQVMsQ0FBQztJQUMvQ0QsQ0FBQyxHQUFHTSxNQUFNLENBQUNOLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUosQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFHLFVBQVUsQ0FBQztJQUNoREYsQ0FBQyxHQUFHTyxNQUFNLENBQUNQLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDO0lBQ2hESCxDQUFDLEdBQUdRLE1BQU0sQ0FBQ1IsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUM7SUFDOUNKLENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBSSxVQUFVLENBQUM7SUFDaERELENBQUMsR0FBR00sTUFBTSxDQUFDTixDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUNoREYsQ0FBQyxHQUFHTyxNQUFNLENBQUNQLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDO0lBQzNDSCxDQUFDLEdBQUdRLE1BQU0sQ0FBQ1IsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDaERKLENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBSSxVQUFVLENBQUM7SUFDaERELENBQUMsR0FBR00sTUFBTSxDQUFDTixDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUM5Q0YsQ0FBQyxHQUFHTyxNQUFNLENBQUNQLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDO0lBQ2hESCxDQUFDLEdBQUdRLE1BQU0sQ0FBQ1IsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUcsVUFBVSxDQUFDO0lBRWhESixDQUFDLEdBQUdVLE1BQU0sQ0FBQ1YsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFTCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUcsQ0FBQyxTQUFTLENBQUM7SUFDL0NELENBQUMsR0FBR08sTUFBTSxDQUFDUCxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRyxDQUFDLFVBQVUsQ0FBQztJQUNoREYsQ0FBQyxHQUFHUSxNQUFNLENBQUNSLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFHLFNBQVMsQ0FBQztJQUMvQ0gsQ0FBQyxHQUFHUyxNQUFNLENBQUNULENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUYsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQy9DSixDQUFDLEdBQUdVLE1BQU0sQ0FBQ1YsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFTCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUcsQ0FBQyxTQUFTLENBQUM7SUFDL0NELENBQUMsR0FBR08sTUFBTSxDQUFDUCxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBSSxRQUFRLENBQUM7SUFDOUNGLENBQUMsR0FBR1EsTUFBTSxDQUFDUixDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUMvQ0gsQ0FBQyxHQUFHUyxNQUFNLENBQUNULENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUYsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQy9DSixDQUFDLEdBQUdVLE1BQU0sQ0FBQ1YsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFTCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUksU0FBUyxDQUFDO0lBQy9DRCxDQUFDLEdBQUdPLE1BQU0sQ0FBQ1AsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSixDQUFDLENBQUNNLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUcsQ0FBQyxVQUFVLENBQUM7SUFDaERGLENBQUMsR0FBR1EsTUFBTSxDQUFDUixDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQztJQUMvQ0gsQ0FBQyxHQUFHUyxNQUFNLENBQUNULENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUYsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFHLFVBQVUsQ0FBQztJQUNoREosQ0FBQyxHQUFHVSxNQUFNLENBQUNWLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUwsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFHLENBQUMsVUFBVSxDQUFDO0lBQ2hERCxDQUFDLEdBQUdPLE1BQU0sQ0FBQ1AsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUcsQ0FBQyxRQUFRLENBQUM7SUFDOUNGLENBQUMsR0FBR1EsTUFBTSxDQUFDUixDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRyxVQUFVLENBQUM7SUFDaERILENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVGLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUVoREosQ0FBQyxHQUFHVyxNQUFNLENBQUNYLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUwsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFHLENBQUMsTUFBTSxDQUFDO0lBQzVDRCxDQUFDLEdBQUdRLE1BQU0sQ0FBQ1IsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDaERGLENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRyxVQUFVLENBQUM7SUFDaERILENBQUMsR0FBR1UsTUFBTSxDQUFDVixDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVGLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUM5Q0osQ0FBQyxHQUFHVyxNQUFNLENBQUNYLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUwsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFHLENBQUMsVUFBVSxDQUFDO0lBQ2hERCxDQUFDLEdBQUdRLE1BQU0sQ0FBQ1IsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUcsVUFBVSxDQUFDO0lBQ2hERixDQUFDLEdBQUdTLE1BQU0sQ0FBQ1QsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDL0NILENBQUMsR0FBR1UsTUFBTSxDQUFDVixDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVGLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUNoREosQ0FBQyxHQUFHVyxNQUFNLENBQUNYLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUwsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFJLFNBQVMsQ0FBQztJQUMvQ0QsQ0FBQyxHQUFHUSxNQUFNLENBQUNSLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUosQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQy9DRixDQUFDLEdBQUdTLE1BQU0sQ0FBQ1QsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFDL0NILENBQUMsR0FBR1UsTUFBTSxDQUFDVixDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVGLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRyxRQUFRLENBQUM7SUFDOUNKLENBQUMsR0FBR1csTUFBTSxDQUFDWCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRyxDQUFDLFNBQVMsQ0FBQztJQUMvQ0QsQ0FBQyxHQUFHUSxNQUFNLENBQUNSLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUosQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDO0lBQy9DRixDQUFDLEdBQUdTLE1BQU0sQ0FBQ1QsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLENBQUNNLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUcsU0FBUyxDQUFDO0lBQy9DSCxDQUFDLEdBQUdVLE1BQU0sQ0FBQ1YsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxTQUFTLENBQUM7SUFFL0NKLENBQUMsR0FBR1ksTUFBTSxDQUFDWixDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRyxDQUFDLFNBQVMsQ0FBQztJQUMvQ0QsQ0FBQyxHQUFHUyxNQUFNLENBQUNULENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUosQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFHLFVBQVUsQ0FBQztJQUNoREYsQ0FBQyxHQUFHVSxNQUFNLENBQUNWLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDO0lBQ2hESCxDQUFDLEdBQUdXLE1BQU0sQ0FBQ1gsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUM7SUFDOUNKLENBQUMsR0FBR1ksTUFBTSxDQUFDWixDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBSSxVQUFVLENBQUM7SUFDaERELENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUNoREYsQ0FBQyxHQUFHVSxNQUFNLENBQUNWLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDO0lBQzdDSCxDQUFDLEdBQUdXLE1BQU0sQ0FBQ1gsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUM7SUFDaERKLENBQUMsR0FBR1ksTUFBTSxDQUFDWixDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ00sQ0FBQyxHQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBSSxVQUFVLENBQUM7SUFDaERELENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQztJQUM5Q0YsQ0FBQyxHQUFHVSxNQUFNLENBQUNWLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDO0lBQ2hESCxDQUFDLEdBQUdXLE1BQU0sQ0FBQ1gsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxFQUFFRixDQUFDLENBQUNNLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUcsVUFBVSxDQUFDO0lBQ2hESixDQUFDLEdBQUdZLE1BQU0sQ0FBQ1osQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFTCxDQUFDLENBQUNNLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUcsQ0FBQyxTQUFTLENBQUM7SUFDL0NELENBQUMsR0FBR1MsTUFBTSxDQUFDVCxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVKLENBQUMsQ0FBQ00sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQztJQUNoREYsQ0FBQyxHQUFHVSxNQUFNLENBQUNWLENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRUgsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFHLFNBQVMsQ0FBQztJQUMvQ0gsQ0FBQyxHQUFHVyxNQUFNLENBQUNYLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRUYsQ0FBQyxDQUFDTSxDQUFDLEdBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDO0lBRS9DSixDQUFDLEdBQUdhLFFBQVEsQ0FBQ2IsQ0FBQyxFQUFFSyxJQUFJLENBQUM7SUFDckJKLENBQUMsR0FBR1ksUUFBUSxDQUFDWixDQUFDLEVBQUVLLElBQUksQ0FBQztJQUNyQkosQ0FBQyxHQUFHVyxRQUFRLENBQUNYLENBQUMsRUFBRUssSUFBSSxDQUFDO0lBQ3JCSixDQUFDLEdBQUdVLFFBQVEsQ0FBQ1YsQ0FBQyxFQUFFSyxJQUFJLENBQUM7RUFDdkI7RUFDQSxPQUFPN0QsS0FBSyxDQUFDcUQsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxDQUFDO0FBRTFCOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNXLE9BQU9BLENBQUNDLENBQUMsRUFBRWYsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRWIsQ0FBQyxFQUFFK0IsQ0FBQyxFQUNqQztFQUNFLE9BQU9ILFFBQVEsQ0FBQ0ksT0FBTyxDQUFDSixRQUFRLENBQUNBLFFBQVEsQ0FBQ2IsQ0FBQyxFQUFFZSxDQUFDLENBQUMsRUFBRUYsUUFBUSxDQUFDZixDQUFDLEVBQUVrQixDQUFDLENBQUMsQ0FBQyxFQUFFL0IsQ0FBQyxDQUFDLEVBQUNnQixDQUFDLENBQUM7QUFDekU7QUFDQSxTQUFTUSxNQUFNQSxDQUFDVCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVMLENBQUMsRUFBRWIsQ0FBQyxFQUFFK0IsQ0FBQyxFQUNuQztFQUNFLE9BQU9GLE9BQU8sQ0FBRWIsQ0FBQyxHQUFHQyxDQUFDLEdBQU0sQ0FBQ0QsQ0FBQyxHQUFJRSxDQUFFLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUViLENBQUMsRUFBRStCLENBQUMsQ0FBQztBQUNyRDtBQUNBLFNBQVNOLE1BQU1BLENBQUNWLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUwsQ0FBQyxFQUFFYixDQUFDLEVBQUUrQixDQUFDLEVBQ25DO0VBQ0UsT0FBT0YsT0FBTyxDQUFFYixDQUFDLEdBQUdFLENBQUMsR0FBS0QsQ0FBQyxHQUFJLENBQUNDLENBQUcsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRWIsQ0FBQyxFQUFFK0IsQ0FBQyxDQUFDO0FBQ3JEO0FBQ0EsU0FBU0wsTUFBTUEsQ0FBQ1gsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFTCxDQUFDLEVBQUViLENBQUMsRUFBRStCLENBQUMsRUFDbkM7RUFDRSxPQUFPRixPQUFPLENBQUNiLENBQUMsR0FBR0MsQ0FBQyxHQUFHQyxDQUFDLEVBQUVILENBQUMsRUFBRUMsQ0FBQyxFQUFFSCxDQUFDLEVBQUViLENBQUMsRUFBRStCLENBQUMsQ0FBQztBQUMxQztBQUNBLFNBQVNKLE1BQU1BLENBQUNaLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsRUFBRUwsQ0FBQyxFQUFFYixDQUFDLEVBQUUrQixDQUFDLEVBQ25DO0VBQ0UsT0FBT0YsT0FBTyxDQUFDWixDQUFDLElBQUlELENBQUMsR0FBSSxDQUFDRSxDQUFFLENBQUMsRUFBRUgsQ0FBQyxFQUFFQyxDQUFDLEVBQUVILENBQUMsRUFBRWIsQ0FBQyxFQUFFK0IsQ0FBQyxDQUFDO0FBQy9DOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVN0QixhQUFhQSxDQUFDNUUsR0FBRyxFQUFFYyxJQUFJLEVBQ2hDO0VBQ0UsSUFBSXNGLElBQUksR0FBRzlCLFFBQVEsQ0FBQ3RFLEdBQUcsQ0FBQztFQUN4QixJQUFHb0csSUFBSSxDQUFDaEgsTUFBTSxHQUFHLEVBQUUsRUFBRWdILElBQUksR0FBRy9CLFFBQVEsQ0FBQytCLElBQUksRUFBRXBHLEdBQUcsQ0FBQ1osTUFBTSxHQUFHOEUsS0FBSyxDQUFDO0VBRTlELElBQUltQyxJQUFJLEdBQUd4RSxLQUFLLENBQUMsRUFBRSxDQUFDO0lBQUV5RSxJQUFJLEdBQUd6RSxLQUFLLENBQUMsRUFBRSxDQUFDO0VBQ3RDLEtBQUksSUFBSXlELENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRyxFQUFFLEVBQUVBLENBQUMsRUFBRSxFQUMxQjtJQUNFZSxJQUFJLENBQUNmLENBQUMsQ0FBQyxHQUFHYyxJQUFJLENBQUNkLENBQUMsQ0FBQyxHQUFHLFVBQVU7SUFDOUJnQixJQUFJLENBQUNoQixDQUFDLENBQUMsR0FBR2MsSUFBSSxDQUFDZCxDQUFDLENBQUMsR0FBRyxVQUFVO0VBQ2hDO0VBRUEsSUFBSWlCLElBQUksR0FBR2xDLFFBQVEsQ0FBQ2dDLElBQUksQ0FBQ0csTUFBTSxDQUFDbEMsUUFBUSxDQUFDeEQsSUFBSSxDQUFDLENBQUMsRUFBRSxHQUFHLEdBQUdBLElBQUksQ0FBQzFCLE1BQU0sR0FBRzhFLEtBQUssQ0FBQztFQUMzRSxPQUFPRyxRQUFRLENBQUNpQyxJQUFJLENBQUNFLE1BQU0sQ0FBQ0QsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUMvQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNSLFFBQVFBLENBQUNmLENBQUMsRUFBRXlCLENBQUMsRUFDdEI7RUFDRSxJQUFJQyxHQUFHLEdBQUcsQ0FBQzFCLENBQUMsR0FBRyxNQUFNLEtBQUt5QixDQUFDLEdBQUcsTUFBTSxDQUFDO0VBQ3JDLElBQUlFLEdBQUcsR0FBRyxDQUFDM0IsQ0FBQyxJQUFJLEVBQUUsS0FBS3lCLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSUMsR0FBRyxJQUFJLEVBQUUsQ0FBQztFQUM3QyxPQUFRQyxHQUFHLElBQUksRUFBRSxHQUFLRCxHQUFHLEdBQUcsTUFBTztBQUNyQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTUCxPQUFPQSxDQUFDUyxHQUFHLEVBQUVDLEdBQUcsRUFDekI7RUFDRSxPQUFRRCxHQUFHLElBQUlDLEdBQUcsR0FBS0QsR0FBRyxLQUFNLEVBQUUsR0FBR0MsR0FBSztBQUM1Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVN2QyxRQUFRQSxDQUFDbEIsR0FBRyxFQUNyQjtFQUNFLElBQUkwRCxHQUFHLEdBQUdqRixLQUFLLENBQUMsQ0FBQztFQUNqQixJQUFJa0YsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJN0MsS0FBSyxJQUFJLENBQUM7RUFDM0IsS0FBSSxJQUFJb0IsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHbEMsR0FBRyxDQUFDaEUsTUFBTSxHQUFHOEUsS0FBSyxFQUFFb0IsQ0FBQyxJQUFJcEIsS0FBSyxFQUMvQzRDLEdBQUcsQ0FBQ3hCLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDbEMsR0FBRyxDQUFDNEQsVUFBVSxDQUFDMUIsQ0FBQyxHQUFHcEIsS0FBSyxDQUFDLEdBQUc2QyxJQUFJLEtBQU16QixDQUFDLEdBQUMsRUFBRztFQUMzRCxPQUFPd0IsR0FBRztBQUNaOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNwQyxRQUFRQSxDQUFDb0MsR0FBRyxFQUNyQjtFQUNFLElBQUkxRCxHQUFHLEdBQUcsRUFBRTtFQUNaLElBQUkyRCxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUk3QyxLQUFLLElBQUksQ0FBQztFQUMzQixLQUFJLElBQUlvQixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUd3QixHQUFHLENBQUMxSCxNQUFNLEdBQUcsRUFBRSxFQUFFa0csQ0FBQyxJQUFJcEIsS0FBSyxFQUM1Q2QsR0FBRyxJQUFJNkQsTUFBTSxDQUFDQyxZQUFZLENBQUVKLEdBQUcsQ0FBQ3hCLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBTUEsQ0FBQyxHQUFHLEVBQUcsR0FBSXlCLElBQUksQ0FBQztFQUM3RCxPQUFPM0QsR0FBRztBQUNaOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNnQixRQUFRQSxDQUFDK0MsUUFBUSxFQUMxQjtFQUNFLElBQUlDLE9BQU8sR0FBR3BELE9BQU8sR0FBRyxrQkFBa0IsR0FBRyxrQkFBa0I7RUFDL0QsSUFBSVosR0FBRyxHQUFHLEVBQUU7RUFDWixLQUFJLElBQUlrQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc2QixRQUFRLENBQUMvSCxNQUFNLEdBQUcsQ0FBQyxFQUFFa0csQ0FBQyxFQUFFLEVBQzNDO0lBQ0VsQyxHQUFHLElBQUlnRSxPQUFPLENBQUNDLE1BQU0sQ0FBRUYsUUFBUSxDQUFDN0IsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFNQSxDQUFDLEdBQUMsQ0FBQyxHQUFFLENBQUMsR0FBQyxDQUFFLEdBQUksR0FBRyxDQUFDLEdBQ3JEOEIsT0FBTyxDQUFDQyxNQUFNLENBQUVGLFFBQVEsQ0FBQzdCLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBTUEsQ0FBQyxHQUFDLENBQUMsR0FBRSxDQUFJLEdBQUksR0FBRyxDQUFDO0VBQzlEO0VBQ0EsT0FBT2xDLEdBQUc7QUFDWjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTb0IsUUFBUUEsQ0FBQzJDLFFBQVEsRUFDMUI7RUFDRSxJQUFJRyxHQUFHLEdBQUcsa0VBQWtFO0VBQzVFLElBQUlsRSxHQUFHLEdBQUcsRUFBRTtFQUNaLEtBQUksSUFBSWtDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRzZCLFFBQVEsQ0FBQy9ILE1BQU0sR0FBRyxDQUFDLEVBQUVrRyxDQUFDLElBQUksQ0FBQyxFQUM5QztJQUNFLElBQUlpQyxPQUFPLEdBQUksQ0FBRUosUUFBUSxDQUFDN0IsQ0FBQyxJQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBS0EsQ0FBQyxHQUFJLENBQUMsQ0FBQyxHQUFJLElBQUksS0FBSyxFQUFFLEdBQ3BELENBQUU2QixRQUFRLENBQUM3QixDQUFDLEdBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDQSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFJLElBQUksS0FBSyxDQUFHLEdBQ25ENkIsUUFBUSxDQUFDN0IsQ0FBQyxHQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQ0EsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBSSxJQUFLO0lBQzdELEtBQUksSUFBSWtDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsRUFBRSxFQUN6QjtNQUNFLElBQUdsQyxDQUFDLEdBQUcsQ0FBQyxHQUFHa0MsQ0FBQyxHQUFHLENBQUMsR0FBR0wsUUFBUSxDQUFDL0gsTUFBTSxHQUFHLEVBQUUsRUFBRWdFLEdBQUcsSUFBSWEsTUFBTSxDQUFDLEtBQ2xEYixHQUFHLElBQUlrRSxHQUFHLENBQUNELE1BQU0sQ0FBRUUsT0FBTyxJQUFJLENBQUMsSUFBRSxDQUFDLEdBQUNDLENBQUMsQ0FBQyxHQUFJLElBQUksQ0FBQztJQUNyRDtFQUNGO0VBQ0EsT0FBT3BFLEdBQUc7QUFDWjtBQUdBLGlFQUFlO0VBQ2JHLE9BQU8sRUFBQ0E7QUFDVixDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuUWtCO0FBQ25CLGlFQUFlO0VBQ2I7RUFDQW1FLEdBQUdBLENBQUNDLE9BQU8sRUFBRTtJQUNYQyxzREFBUyxDQUFDQyxJQUFJLENBQUNGLE9BQU8sQ0FBQztFQUN6QixDQUFDO0VBQ0Q7RUFDQWxILFFBQVFBLENBQUNrSCxPQUFPLEVBQUU7SUFDaEJDLHNEQUFTLENBQUNyRixLQUFLLENBQUNvRixPQUFPLENBQUM7RUFDMUIsQ0FBQztFQUNEO0VBQ0FHLFVBQVVBLENBQUNILE9BQU8sRUFBRTtJQUNsQkMsc0RBQVMsQ0FBQ0csT0FBTyxDQUFDSixPQUFPLENBQUM7RUFDNUIsQ0FBQztFQUNEO0VBQ0FLLFVBQVVBLENBQUNMLE9BQU8sRUFBRTtJQUNsQkMsc0RBQVMsQ0FBQ0ssT0FBTyxDQUFDTixPQUFPLENBQUM7RUFDNUIsQ0FBQztFQUNEO0VBQ0FPLEtBQUtBLENBQUNQLE9BQU8sRUFBRTtJQUNiUSx5REFBWSxDQUFDRCxLQUFLLENBQUNQLE9BQU8sRUFBRSxNQUFNLENBQUM7RUFDckMsQ0FBQztFQUNEO0VBQ0FTLFVBQVVBLENBQUNULE9BQU8sRUFBRTtJQUNsQlEseURBQVksQ0FBQ0QsS0FBSyxDQUFDUCxPQUFPLEVBQUUsTUFBTSxFQUFFO01BQUVVLElBQUksRUFBRTtJQUFRLENBQUMsQ0FBQztFQUN4RCxDQUFDO0VBQ0Q7RUFDQUMsWUFBWUEsQ0FBQ1gsT0FBTyxFQUFFO0lBQ3BCUSx5REFBWSxDQUFDRCxLQUFLLENBQUNQLE9BQU8sRUFBRSxNQUFNLEVBQUU7TUFBRVUsSUFBSSxFQUFFO0lBQVUsQ0FBQyxDQUFDO0VBQzFELENBQUM7RUFDRDtFQUNBRSxZQUFZQSxDQUFDWixPQUFPLEVBQUU7SUFDcEJRLHlEQUFZLENBQUNELEtBQUssQ0FBQ1AsT0FBTyxFQUFFLE1BQU0sRUFBRTtNQUFFVSxJQUFJLEVBQUU7SUFBVSxDQUFDLENBQUM7RUFDMUQsQ0FBQztFQUNEO0VBQ0FHLE1BQU1BLENBQUNiLE9BQU8sRUFBRTtJQUNkYywyREFBYyxDQUFDWixJQUFJLENBQUNGLE9BQU8sQ0FBQztFQUM5QixDQUFDO0VBQ0Q7RUFDQWUsV0FBV0EsQ0FBQ2YsT0FBTyxFQUFFO0lBQ25CYywyREFBYyxDQUFDbEcsS0FBSyxDQUFDb0YsT0FBTyxDQUFDO0VBQy9CLENBQUM7RUFDRDtFQUNBZ0IsYUFBYUEsQ0FBQ2hCLE9BQU8sRUFBRTtJQUNyQmMsMkRBQWMsQ0FBQ1YsT0FBTyxDQUFDSixPQUFPLENBQUM7RUFDakMsQ0FBQztFQUNEO0VBQ0FpQixhQUFhQSxDQUFDakIsT0FBTyxFQUFFO0lBQ3JCYywyREFBYyxDQUFDUixPQUFPLENBQUNOLE9BQU8sQ0FBQztFQUNqQyxDQUFDO0VBQ0Q7RUFDQWtCLE9BQU9BLENBQUNsQixPQUFPLEVBQUNtQixPQUFPLEdBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDMUIsT0FBT1gseURBQVksQ0FBQ1UsT0FBTyxDQUFDbEIsT0FBTyxFQUFFLE1BQU0sRUFBRTtNQUMzQ29CLGlCQUFpQixFQUFFRCxPQUFPLENBQUNDLGlCQUFpQixJQUFJLElBQUk7TUFDcERDLGdCQUFnQixFQUFFRixPQUFPLENBQUNFLGdCQUFnQixJQUFJLElBQUk7TUFDbERYLElBQUksRUFBRSxTQUFTO01BQ2ZZLHdCQUF3QixFQUFFSCxPQUFPLENBQUNHO0lBQ3BDLENBQUMsQ0FBQztFQUNKLENBQUM7RUFDRDtFQUNBQyxNQUFNQSxDQUFDdkIsT0FBTyxFQUFFO0lBQ2QsT0FBT1EseURBQVksQ0FBQ2UsTUFBTSxDQUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFBRTtNQUMxQ29CLGlCQUFpQixFQUFFLElBQUk7TUFDdkJDLGdCQUFnQixFQUFFLElBQUk7TUFDdEJYLElBQUksRUFBRTtJQUNSLENBQUMsQ0FBQztFQUNKLENBQUM7RUFDRDtFQUNBYyxPQUFPQSxDQUFDeEIsT0FBTyxFQUFFO0lBQ2ZGLGVBQWUsR0FBRzJCLHNEQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNsQ0MsSUFBSSxFQUFFLElBQUk7TUFDVkMsSUFBSSxFQUFFNUIsT0FBTztNQUNiNkIsVUFBVSxFQUFFO0lBQ2QsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNEO0VBQ0FDLFlBQVlBLENBQUEsRUFBRztJQUNiaEMsZUFBZSxDQUFDaUMsS0FBSyxDQUFDLENBQUM7RUFDekI7QUFDRixDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEZELHNDQUF3QztBQUNGO0FBQ3RDLGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiw2Q0FBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhDQUFTO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLDJEQUFLO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsUUFBUSwyREFBSztBQUNiO0FBQ0E7QUFDQSxNQUFNLDBEQUFJO0FBQ1Ysa0JBQWtCLDBEQUFJO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLDJEQUFLO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLDJEQUFLO0FBQ3BCO0FBQ0E7QUFDQSxlQUFlLDBEQUFJO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7O3NDQ2xFRCxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQ25ERCxxQ0FBNkM7QUFDSztBQUNGO0FBQ2hELGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQix3Q0FBRztBQUNyQixJQUFJLDhDQUFTO0FBQ2Isd0JBQXdCLDJEQUFRO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx1REFBUTtBQUN2QjtBQUNBLFdBQVc7QUFDWCxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7OztzQ0NqQ2lNO0FBQ2xNO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsU0FBUyw4Q0FBVSxJQUFJLHVEQUFtQixxQkFBcUIsdURBQW1CLCtDQUErQyx1REFBbUI7QUFDcEo7QUFDQSxnQ0FBZ0MsdURBQW1CLHFCQUFxQix1REFBbUIsK0NBQStDLHVEQUFtQjtBQUM3SjtBQUNBLDhCQUE4QixtREFBZSxDQUFDLHVEQUFtQjtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQywyQ0FBVyw4QkFBOEIsdURBQW1CLCtDQUErQyx1REFBbUI7QUFDbEs7QUFDQSw4QkFBOEIsbURBQWUsQ0FBQyx1REFBbUI7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsMkNBQVcsOEJBQThCLHVEQUFtQjtBQUNoRztBQUNBO0FBQ0E7QUFDQSxDOzs7Ozs7Ozs7Ozs7Ozs7c0NDckNvSTtBQUNwSTtBQUNBO0FBQ0E7QUFDTztBQUNQLFNBQVMsOENBQVUsSUFBSSx1REFBbUIscUJBQXFCLHVEQUFtQjtBQUNsRjtBQUNBLGdDQUFnQyx1REFBbUI7QUFDbkQ7QUFDQSx5Q0FBeUMsdURBQW1CO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7OztzQ0Nid0w7QUFDakw7QUFDUCxTQUFTLDhDQUFVLElBQUksdURBQW1CLENBQUMseUNBQVMscUNBQXFDLDhDQUFVLElBQUksZ0RBQVk7QUFDbkg7QUFDQTtBQUNBLFFBQVEsdURBQW1CLGtDQUFrQyw4Q0FBVSxJQUFJLGdEQUFZO0FBQ3ZGO0FBQ0EsUUFBUSx1REFBbUI7QUFDM0IsQzs7Ozs7Ozs7Ozs7QUNSQTs7Ozs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEsc0NBQW9IO0FBQ2pEO0FBQ0w7O0FBRTlELENBQTZFOztBQUVNO0FBQ25GLGlDQUFpQyx5RkFBZSxDQUFDLHFGQUFNLGFBQWEsd0ZBQU07QUFDMUU7QUFDQSxJQUFJLEtBQVUsRUFBRTtBQUFBLEVBWWY7OztBQUdELGlFQUFlLFc7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCZixzQ0FBbUg7QUFDakQ7QUFDTDs7QUFFN0QsQ0FBNEU7O0FBRU87QUFDbkYsaUNBQWlDLHlGQUFlLENBQUMsb0ZBQU0sYUFBYSx1RkFBTTtBQUMxRTtBQUNBLElBQUksS0FBVSxFQUFFO0FBQUEsRUFZZjs7O0FBR0QsaUVBQWUsVzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEJmLHNDQUF3RztBQUNyQztBQUNMOztBQUU5RCxDQUFpRTs7QUFFZTtBQUNoRixpQ0FBaUMseUZBQWUsQ0FBQyxxRkFBTSxhQUFhLDRFQUFNO0FBQzFFO0FBQ0EsSUFBSSxLQUFVLEVBQUU7QUFBQSxFQVlmOzs7QUFHRCxpRUFBZSxXOzs7Ozs7Ozs7Ozs7Ozs7QUN4QmYsc0NBQTZjLEM7Ozs7Ozs7Ozs7Ozs7OztBQ0E3YyxzQ0FBNGMsQzs7Ozs7Ozs7Ozs7Ozs7O0FDQTVjLHNDQUFpYyxDOzs7Ozs7Ozs7Ozs7Ozs7QUNBamMsc0M7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7Ozs7Ozs7QUNBQSxzQzs7Ozs7Ozs7Ozs7O0FDQUEsc0M7Ozs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7Ozs7QUNBQSxzQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NoYXJlLWNocm9tZS1leHRlbnNpb25zLWJ5LWx3aC8uL3NyYy9qcy9lbnRyeXMvcG9wdXAuanMiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL2pzL3V0aWxzL2Z1bi5qcyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvanMvdXRpbHMvaG9zdENvbmZpZy5qcyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvanMvdXRpbHMvaHR0cC5qcyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvanMvdXRpbHMvbWQ1LmpzIiwid2VicGFjazovL3NoYXJlLWNocm9tZS1leHRlbnNpb25zLWJ5LWx3aC8uL3NyYy9qcy91dGlscy9tb2RhbC5qcyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlPzVjOGIiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlPzE3NWIiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/MTNmMyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlP2MzMTkiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlPzY4YTUiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/YzQ0YyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlPzRjZGMiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlPzMxOTgiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/MzEyYSIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlPzlkM2MiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlP2UyMTYiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/MmI3YyIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlP2U1YjgiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlPzJiMzAiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/ZDA1YiIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlPzJjNGUiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlPzE4YmEiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/OWYyZiIsIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlPzQzNzMiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9jb21wb25lbnRzL21haW4udnVlPzY5OWMiLCJ3ZWJwYWNrOi8vc2hhcmUtY2hyb21lLWV4dGVuc2lvbnMtYnktbHdoLy4vc3JjL3Z1ZS9wb3B1cC52dWU/MDJmNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQXBwIGZyb20gJ0BzcmMvdnVlL3BvcHVwLnZ1ZSdcclxubGV0IGFwcCA9IGNyZWF0ZUFwcChBcHApXHJcbmFwcC5tb3VudCgnI2FwcCcpXHJcbiIsIi8qKlxyXG4gKiBDcmVhdGVkIGJ5IEFsbGVuIExpdSBvbiAyMDI2LzMvMjQuXHJcbiAqL1xyXG5cclxuZXhwb3J0IGxldCBnZXRUb2tlbiA9IGFzeW5jIGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcclxuICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXCJ0b2tlblwiXSwgKHJlc3VsdCkgPT4ge1xyXG4gICAgICByZXNvbHZlKHJlc3VsdC50b2tlbik7XHJcbiAgICB9KTtcclxuICB9KTtcclxufTsiLCJcclxuY29uc3QgYmFzZVVybCA9ICdodHRwczovL3ByZS1hcGkudGhlZGVlci5jbidcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICBiYXNlVXJsXHJcbn0iLCIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICog5Z+65LqOQXhpb3PlsIHoo4XnmoRIdHRw6K+35rGC57G777yM5Y+v5pSv5oyB5LiN5ZCM5Z+f5rqQ55qE6LCD55SoXHJcbiAqIGVx77yaIHRoaXMuJGh0dHAuaHR0cFBvc3QoKVxyXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuaW1wb3J0IHsgZW5jLCBIbWFjU0hBMjU2IH0gZnJvbSBcImNyeXB0by1qc1wiO1xyXG5pbXBvcnQgbW9kYWwgZnJvbSAnQHNyYy9qcy91dGlscy9tb2RhbCdcclxuaW1wb3J0IGhvc3RDb25maWcgZnJvbSAnQHNyYy9qcy91dGlscy9ob3N0Q29uZmlnJ1xyXG5pbXBvcnQgbWQ1IGZyb20gJ0BzcmMvanMvdXRpbHMvbWQ1J1xyXG5pbXBvcnQge2dldFRva2VufSBmcm9tICdAc3JjL2pzL3V0aWxzL2Z1bidcclxuXHJcblxyXG5pbXBvcnQgQXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcblxyXG4vKipcclxuICog6I635Y+W562+5ZCN5Liyc2lnblxyXG4gKiBAcGFyYW0gXCJwYXRoXCJcclxuICogQHBhcmFtIHtkYXRhfVxyXG4gKiBAcGFyYW0gXCJwYXRoXCJcclxuICogQHJldHVybiBcInNpZ25cIlxyXG4gKi9cclxubGV0IFNlY3JldEtleSA9IFwicGl3MzhrdWxmb3pyZWE3eWRtam52YmM5NjVxMWd0MnhcIjtcclxubGV0IGNyZWF0ZVNpZ24gPSBmdW5jdGlvbiAobWV0aG9kLCBVUkwsIHBhcmFtLCBDbGllbnRUaW1lc3RhbXApIHtcclxuICBsZXQgU3RyaW5nVG9TaWduID0gbWV0aG9kICsgXCJcXG5cIiArIFVSTCArIFwiXFxuXCIgKyBDbGllbnRUaW1lc3RhbXAgKyBcIlxcblwiICsgKHBhcmFtID8gSlNPTi5zdHJpbmdpZnkocGFyYW0pIDogXCJcIik7XHJcbiAgY29uc29sZS5sb2coU3RyaW5nVG9TaWduKTtcclxuICBsZXQgSG1hY1NpZ25hdHVyZSA9IGVuYy5CYXNlNjQuc3RyaW5naWZ5KEhtYWNTSEEyNTYoU3RyaW5nVG9TaWduLCBTZWNyZXRLZXkpKTtcclxuICBsZXQgQmFzZTY0VVJMID0gZnVuY3Rpb24gKGJhc2U2NFN0cikge1xyXG4gICAgbGV0IHNhZmVCNjQgPSBiYXNlNjRTdHIucmVwbGFjZSgvXFwrL2csIFwiLVwiKTtcclxuICAgIHNhZmVCNjQgPSBzYWZlQjY0LnJlcGxhY2UoL1xcLy9nLCBcIl9cIik7XHJcbiAgICBsZXQgbW9kNCA9IHNhZmVCNjQubGVuZ3RoICUgNDtcclxuICAgIGxldCBtb2RBZGRTdHIgPSBcIj09PT1cIjtcclxuICAgIHNhZmVCNjQgPSBzYWZlQjY0ICsgbW9kQWRkU3RyLnN1YnN0cmluZygwLCBtb2Q0KTtcclxuICAgIHJldHVybiBzYWZlQjY0O1xyXG4gIH07XHJcbiAgLy9sb2daWUtKKEhtYWNTaWduYXR1cmUsIEJhc2U2NFVSTChIbWFjU2lnbmF0dXJlKSwgU3RyaW5nVG9TaWduKTtcclxuICByZXR1cm4gQmFzZTY0VVJMKEhtYWNTaWduYXR1cmUpO1xyXG59O1xyXG5cclxuLyoqXHJcbiAqIOWFqOWxgOm7mOiupOmFjee9rlxyXG4gKi9cclxuLy8gIEF4aW9zLmRlZmF1bHRzLmJhc2VVUkwgPSBwcm9jZXNzLmVudi5WVUVfQVBQX1NFUlZFUjI7XHJcbkF4aW9zLmRlZmF1bHRzLnRpbWVvdXQgPSA2MDAwMDtcclxuQXhpb3MuZGVmYXVsdHMud2l0aENyZWRlbnRpYWxzID0gdHJ1ZTtcclxubGV0IHRyYW5zZm9ybVJlcXVlc3QgPSAocmVxLCBoZWFkZXJzKSA9PiB7XHJcbiAgaWYgKGhlYWRlcnMgJiYgaGVhZGVyc1tcIkNvbnRlbnQtVHlwZVwiXSAmJiBoZWFkZXJzW1wiQ29udGVudC1UeXBlXCJdLmluZGV4T2YoXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIpICE9IC0xKSB7XHJcbiAgICBsZXQgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGZvciAobGV0IGtleSBpbiByZXEpIHtcclxuICAgICAgZm9ybURhdGEuYXBwZW5kKGtleSwgcmVxW2tleV0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZvcm1EYXRhO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHJlcSk7XHJcbn07XHJcblxyXG5sZXQgdHJhbnNmb3JtUmVzcG9uc2UgPSAoY29uZmlnKSA9PiB7XHJcbiAgcmV0dXJuIGZ1bmN0aW9uKHJlcyl7XHJcbiAgICBpZiAocmVzICYmIHJlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHJlcyA9IEpTT04ucGFyc2UocmVzKTtcclxuICAgICAgLy8gY29uc29sZS5sb2cocmVzLDg4ODgpO1xyXG4gICAgICBsZXQgeyBlcnJvcl9jb2RlLCBtZXNzYWdlIH0gPSByZXM7XHJcbiAgICAgIC8vIGVycm9yX2NvZGUgPSAxMDAwMDIwMDFcclxuICAgICAgaWYgKGVycm9yX2NvZGUpIHtcclxuICAgICAgICBsZXQgZHVyYXRpb24gPSA0NTAwO1xyXG4gICAgICAgIC8v55m75b2V5aSx5pWIXHJcbiAgICAgICAgaWYgKGVycm9yX2NvZGUgPT09IDIwMDAwKSB7XHJcbiAgICAgICAgICBkdXJhdGlvbiA9IDIwMDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1vZGFsLm1zZ0Vycm9yKG1lc3NhZ2UpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiByZXM7XHJcbiAgfVxyXG59O1xyXG5cclxubGV0IHJlcXVlc3QgPSBhc3luYyAobWV0aG9kLCB1cmwsIHBhdGgsIGRfcCwgY29uZmlnKSA9PiB7XHJcbiAgbGV0IGRhdGEgPSB1bmRlZmluZWQ7XHJcbiAgbGV0IHBhcmFtcyA9IHVuZGVmaW5lZDtcclxuICBtZXRob2QgPSBtZXRob2QudG9VcHBlckNhc2UoKTtcclxuICBsZXQgaXNSZW1vdGUgPSBwYXRoLmluZGV4T2YoXCJodHRwXCIpID4gLTEgJiYgcGF0aC5pbmRleE9mKFwiaHR0cFwiKSA8IDk7XHJcbiAgaWYgKGlzUmVtb3RlKSB7XHJcbiAgICB1cmwgPSBwYXRoO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB1cmwgPSB1cmwgKyAocGF0aC5pbmRleE9mKFwiL1wiKSA9PT0gMCA/IHBhdGguc3Vic3RyKDEpIDogcGF0aCk7XHJcbiAgfVxyXG4gIC8v5byA5Y+R546v5aKD5ZCv55SobW9ja1xyXG4gIGxldCBpc01vY2sgPSB3aW5kb3cuaXNNb2NrO1xyXG4gIGlmICh0eXBlb2YgY29uZmlnICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICBpZiAodHlwZW9mIGNvbmZpZy5pc01vY2sgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgaXNNb2NrID0gY29uZmlnLmlzTW9jaztcclxuICAgICAgZGVsZXRlIGNvbmZpZy5pc01vY2s7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChpc01vY2spIHtcclxuICAgIHVybCA9IHVybCArIChwYXRoLmluZGV4T2YoXCIvXCIpID09PSAwID8gcGF0aC5zdWJzdHIoMSkgOiBwYXRoKTtcclxuICAgIC8vbW9ja+aOpeWPo+imgeemgeeUqOS4iuS8oOi/m+W6puWbnuiwg1xyXG4gICAgaWYgKGNvbmZpZyAmJiBjb25maWcub25VcGxvYWRQcm9ncmVzcykge1xyXG4gICAgICBkZWxldGUgY29uZmlnLm9uVXBsb2FkUHJvZ3Jlc3M7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL+WQiOW5tuivt+axglxyXG4gIGxldCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XHJcbiAgbGV0IHRpbWVzdGFtcCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xyXG4gIGxldCBoZWFkZXJzID0ge1xyXG4gICAgdHM6IHRpbWVzdGFtcCxcclxuICAgIHNpZ246IGNyZWF0ZVNpZ24obWV0aG9kLCB1cmwsIGRfcCwgdGltZXN0YW1wKSxcclxuICAgIHRva2VuXHJcbiAgfTtcclxuICBzd2l0Y2ggKG1ldGhvZCkge1xyXG4gICAgY2FzZSBcIkdFVFwiOlxyXG4gICAgICBwYXJhbXMgPSBkX3AgfHwge307XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgZGVmYXVsdDpcclxuICAgIGNhc2UgXCJQT1NUXCI6XHJcbiAgICAgIGRhdGEgPSBkX3AgfHwge307XHJcbiAgICAgIGhlYWRlcnNbXCJDb250ZW50LVR5cGVcIl0gPSBjb25maWcgJiYgY29uZmlnLmNvbnRlbnRUeXBlID8gY29uZmlnLmNvbnRlbnRUeXBlIDogXCJhcHBsaWNhdGlvbi9qc29uXCI7XHJcbiAgICAgIGJyZWFrO1xyXG4gIH1cclxuICBpZiAodXJsIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgIHJldHVybiBBeGlvcy5hbGwoW10pLnRoZW4oQXhpb3Muc3ByZWFkKGZ1bmN0aW9uICgpIHt9KSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGxldCByZXNUcmFuc2Zvcm1lciA9IHRyYW5zZm9ybVJlc3BvbnNlKGNvbmZpZylcclxuICAgIGlmKGNvbmZpZyAmJiBjb25maWcuaGVhZGVycyl7XHJcbiAgICAgIGhlYWRlcnMgPSB7Li4uaGVhZGVycywuLi5jb25maWcuaGVhZGVyc31cclxuICAgICAgZGVsZXRlIGNvbmZpZy5oZWFkZXJzXHJcbiAgICB9XHJcbiAgICByZXR1cm4gQXhpb3MoXHJcbiAgICAgIE9iamVjdC5hc3NpZ24oXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgYmFzZVVSTDogaG9zdENvbmZpZy5iYXNlVXJsLFxyXG4gICAgICAgICAgaGVhZGVycyxcclxuICAgICAgICAgIG1ldGhvZCxcclxuICAgICAgICAgIHVybCxcclxuICAgICAgICAgIGRhdGEsXHJcbiAgICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgICB0cmFuc2Zvcm1SZXF1ZXN0LFxyXG4gICAgICAgICAgdHJhbnNmb3JtUmVzcG9uc2U6cmVzVHJhbnNmb3JtZXJcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNvbmZpZ1xyXG4gICAgICApXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIuacjeWKoeerr+ivt+axgi/lk43lupTplJnor6/vvJpcIiwgZXJyb3IsIGVycm9yLmNvbmZpZyk7XHJcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgfVxyXG59O1xyXG5cclxuLyoqXHJcbiAqIEFycmF5L09iamVjdOWOn+Wei+aJqeWxle+8jOagueaNrlVSTOi1i+WAvOaVsOe7hFxyXG4gKiBAYXV0aG9yIGxpdWJhb2h1b1xyXG4gKiBAcGFyYW0gdmFyaWFibGUgPEFycmF5L09iamVjdD4g5Y+Y6YePXHJcbiAqIEBwYXJhbSBwYXRoIDxTdHJpbmc+IOaUr+aMgeWujOaVtFVSTO+8jOm7mOiupOi1hOa6kOS4reW/g+WcsOWdgFxyXG4gKiBAcGFyYW0gcGFyYW1zIDxPYmplY3Q+IOaVsOaNruWPguaVsFxyXG4gKiBAcGFyYW0gY29uZmlnIDxPYmplY3Q+IOivt+axgumFjee9rlxyXG4gKi9cclxubGV0IGFzc2lnbkJ5VXJsID0gKHZhcmlhYmxlLCBwYXRoLCBwYXJhbXMsIGNvbmZpZykgPT4ge1xyXG4gIGxldCBzZWxmID0gdmFyaWFibGU7XHJcbiAgLy/kuI3og73nm7TmjqXotYvlgLzvvIzlm6DkuLpWdWXlr7nnu4Tku7blrprkuYnnmoTmlbDnu4Tov5vooYzop4Llr5/ogIXmqKHlvI/nmoTlsIHoo4VcclxuICBpZiAoc2VsZiBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICBzZWxmLnNwbGljZSgwLCBzZWxmLmxlbmd0aCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGZvciAodmFyIGtleSBpbiBzZWxmKSB7XHJcbiAgICAgIGRlbGV0ZSBzZWxmW2tleV07XHJcbiAgICB9XHJcbiAgfVxyXG4gIHBvc3RXZWIocGF0aCwgcGFyYW1zIHx8IHt9LCBjb25maWcpLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgbGV0IHsgZXJyb3JfY29kZSwgZGF0YSB9ID0gcmVzO1xyXG4gICAgaWYgKCFlcnJvcl9jb2RlKSB7XHJcbiAgICAgIC8v5LiN6IO955u05o6l6LWL5YC877yM5Zug5Li6VnVl5a+557uE5Lu25a6a5LmJ55qE5pWw57uE6L+b6KGM6KeC5a+f6ICF5qih5byP55qE5bCB6KOFXHJcbiAgICAgIGxldCBmaWVsZERhdGEgPSBkYXRhO1xyXG4gICAgICBpZiAoY29uZmlnICYmIGNvbmZpZy5maWVsZCkge1xyXG4gICAgICAgIGZpZWxkRGF0YSA9IGRhdGFbY29uZmlnLmZpZWxkXTtcclxuICAgICAgICBkZWxldGUgY29uZmlnLmZpZWxkO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmaWVsZERhdGEgaW5zdGFuY2VvZiBBcnJheSkge1xyXG4gICAgICAgIHNlbGYucHVzaCguLi5maWVsZERhdGEpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAodmFyIGtleSBpbiBmaWVsZERhdGEpIHtcclxuICAgICAgICAgIGlmICh2bSkge1xyXG4gICAgICAgICAgICB2bS4kc2V0KHZhcmlhYmxlLCBrZXksIGZpZWxkRGF0YVtrZXldKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNlbGZba2V5XSA9IGZpZWxkRGF0YVtrZXldO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0pO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gZW5jcnlwdFN0cihzdHIpIHtcclxuICBsZXQgc0tleSA9ICcyRUFDQzMxODUxMDc3NUU3ODZGOUM1REM5NEI1Q0M2QidcclxuICBsZXQgbWQ1U3RyID0gbWQ1LmhleF9tZDUoYCR7c3RyfSR7c0tleX1gKS50b1VwcGVyQ2FzZSgpICsgc0tleS50b1VwcGVyQ2FzZSgpO1xyXG4gIHJldHVybiBtZDUuaGV4X21kNShtZDVTdHIpXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICByZXF1ZXN0LFxyXG4gIGh0dHBHZXQ6IChwYXRoLCBwYXJhbXMsIGNvbmZpZykgPT4gcmVxdWVzdChcIkdFVFwiLCBcIi9cIiwgcGF0aCwgcGFyYW1zLCBjb25maWcpLFxyXG4gIGh0dHBQb3N0OiAocGF0aCwgYm9keSwgY29uZmlnKSA9PiByZXF1ZXN0KFwiUE9TVFwiLCBcIi9cIiwgcGF0aCwgYm9keSwgY29uZmlnKSxcclxuICBodHRwVXBsb2FkOiAocGF0aCwgYm9keSwgY29uZmlnKSA9PiByZXF1ZXN0KFwiUE9TVFwiLCBcIi91cGxvYWQvXCIsIHBhdGgsIGJvZHksIGNvbmZpZyksXHJcbiAgaHR0cFBhdGNoOiAocGF0aCwgYm9keSwgY29uZmlnKSA9PiByZXF1ZXN0KFwiUEFUQ0hcIiwgXCIvXCIsIHBhdGgsIGJvZHksIGNvbmZpZyksXHJcbiAgaHR0cFB1dDogKHBhdGgsIGJvZHksIGNvbmZpZykgPT4gcmVxdWVzdChcIlBVVFwiLCBcIi9cIiwgcGF0aCwgYm9keSwgY29uZmlnKSxcclxuICBodHRwRGVsZXRlOiAocGF0aCwgYm9keSwgY29uZmlnKSA9PiByZXF1ZXN0KFwiREVMRVRFXCIsIFwiL1wiLCBwYXRoLCBib2R5LCBjb25maWcpLFxyXG4gIHVwbG9hZFdlYjogKHBhdGgsIGJvZHkgPSB7fSwgY29uZmlnKSA9PiB7XHJcbiAgICBjb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBjb25maWcsIHtcclxuICAgICAgY29udGVudFR5cGU6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YTtib3VuZGFyeT0tLS0tLS1XZWJLaXRGb3JtQm91bmRhcnlKaTA0a1NwZllYQjlBV0JaXCIsXHJcbiAgICB9KTtcclxuICAgIHJldHVybiByZXF1ZXN0KFwiUE9TVFwiLCBcIi9cIiwgcGF0aCwgYm9keSwgY29uZmlnKTtcclxuICB9LFxyXG4gIGVuY3J5cHRTdHJcclxufTtcclxuIiwiLypcclxuICogQSBKYXZhU2NyaXB0IGltcGxlbWVudGF0aW9uIG9mIHRoZSBSU0EgRGF0YSBTZWN1cml0eSwgSW5jLiBNRDUgTWVzc2FnZVxyXG4gKiBEaWdlc3QgQWxnb3JpdGhtLCBhcyBkZWZpbmVkIGluIFJGQyAxMzIxLlxyXG4gKiBWZXJzaW9uIDIuMSBDb3B5cmlnaHQgKEMpIFBhdWwgSm9obnN0b24gMTk5OSAtIDIwMDIuXHJcbiAqIE90aGVyIGNvbnRyaWJ1dG9yczogR3JlZyBIb2x0LCBBbmRyZXcgS2VwZXJ0LCBZZG5hciwgTG9zdGluZXRcclxuICogRGlzdHJpYnV0ZWQgdW5kZXIgdGhlIEJTRCBMaWNlbnNlXHJcbiAqIFNlZSBodHRwOi8vcGFqaG9tZS5vcmcudWsvY3J5cHQvbWQ1IGZvciBtb3JlIGluZm8uXHJcbiAqL1xyXG5cclxuLypcclxuICogQ29uZmlndXJhYmxlIHZhcmlhYmxlcy4gWW91IG1heSBuZWVkIHRvIHR3ZWFrIHRoZXNlIHRvIGJlIGNvbXBhdGlibGUgd2l0aFxyXG4gKiB0aGUgc2VydmVyLXNpZGUsIGJ1dCB0aGUgZGVmYXVsdHMgd29yayBpbiBtb3N0IGNhc2VzLlxyXG4gKi9cclxudmFyIGhleGNhc2UgPSAwOyAgLyogaGV4IG91dHB1dCBmb3JtYXQuIDAgLSBsb3dlcmNhc2U7IDEgLSB1cHBlcmNhc2UgICAgICAgICovXHJcbnZhciBiNjRwYWQgID0gXCJcIjsgLyogYmFzZS02NCBwYWQgY2hhcmFjdGVyLiBcIj1cIiBmb3Igc3RyaWN0IFJGQyBjb21wbGlhbmNlICAgKi9cclxudmFyIGNocnN6ICAgPSA4OyAgLyogYml0cyBwZXIgaW5wdXQgY2hhcmFjdGVyLiA4IC0gQVNDSUk7IDE2IC0gVW5pY29kZSAgICAgICovXHJcblxyXG4vKlxyXG4gKiBUaGVzZSBhcmUgdGhlIGZ1bmN0aW9ucyB5b3UnbGwgdXN1YWxseSB3YW50IHRvIGNhbGxcclxuICogVGhleSB0YWtlIHN0cmluZyBhcmd1bWVudHMgYW5kIHJldHVybiBlaXRoZXIgaGV4IG9yIGJhc2UtNjQgZW5jb2RlZCBzdHJpbmdzXHJcbiAqL1xyXG5mdW5jdGlvbiBoZXhfbWQ1KHMpeyByZXR1cm4gYmlubDJoZXgoY29yZV9tZDUoc3RyMmJpbmwocyksIHMubGVuZ3RoICogY2hyc3opKTt9XHJcbmZ1bmN0aW9uIGI2NF9tZDUocyl7IHJldHVybiBiaW5sMmI2NChjb3JlX21kNShzdHIyYmlubChzKSwgcy5sZW5ndGggKiBjaHJzeikpO31cclxuZnVuY3Rpb24gc3RyX21kNShzKXsgcmV0dXJuIGJpbmwyc3RyKGNvcmVfbWQ1KHN0cjJiaW5sKHMpLCBzLmxlbmd0aCAqIGNocnN6KSk7fVxyXG5mdW5jdGlvbiBoZXhfaG1hY19tZDUoa2V5LCBkYXRhKSB7IHJldHVybiBiaW5sMmhleChjb3JlX2htYWNfbWQ1KGtleSwgZGF0YSkpOyB9XHJcbmZ1bmN0aW9uIGI2NF9obWFjX21kNShrZXksIGRhdGEpIHsgcmV0dXJuIGJpbmwyYjY0KGNvcmVfaG1hY19tZDUoa2V5LCBkYXRhKSk7IH1cclxuZnVuY3Rpb24gc3RyX2htYWNfbWQ1KGtleSwgZGF0YSkgeyByZXR1cm4gYmlubDJzdHIoY29yZV9obWFjX21kNShrZXksIGRhdGEpKTsgfVxyXG5cclxuLypcclxuICogUGVyZm9ybSBhIHNpbXBsZSBzZWxmLXRlc3QgdG8gc2VlIGlmIHRoZSBWTSBpcyB3b3JraW5nXHJcbiAqL1xyXG5mdW5jdGlvbiBtZDVfdm1fdGVzdCgpXHJcbntcclxuICByZXR1cm4gaGV4X21kNShcImFiY1wiKSA9PSBcIjkwMDE1MDk4M2NkMjRmYjBkNjk2M2Y3ZDI4ZTE3ZjcyXCI7XHJcbn1cclxuXHJcbi8qXHJcbiAqIENhbGN1bGF0ZSB0aGUgTUQ1IG9mIGFuIGFycmF5IG9mIGxpdHRsZS1lbmRpYW4gd29yZHMsIGFuZCBhIGJpdCBsZW5ndGhcclxuICovXHJcbmZ1bmN0aW9uIGNvcmVfbWQ1KHgsIGxlbilcclxue1xyXG4gIC8qIGFwcGVuZCBwYWRkaW5nICovXHJcbiAgeFtsZW4gPj4gNV0gfD0gMHg4MCA8PCAoKGxlbikgJSAzMik7XHJcbiAgeFsoKChsZW4gKyA2NCkgPj4+IDkpIDw8IDQpICsgMTRdID0gbGVuO1xyXG5cclxuICB2YXIgYSA9ICAxNzMyNTg0MTkzO1xyXG4gIHZhciBiID0gLTI3MTczMzg3OTtcclxuICB2YXIgYyA9IC0xNzMyNTg0MTk0O1xyXG4gIHZhciBkID0gIDI3MTczMzg3ODtcclxuXHJcbiAgZm9yKHZhciBpID0gMDsgaSA8IHgubGVuZ3RoOyBpICs9IDE2KVxyXG4gIHtcclxuICAgIHZhciBvbGRhID0gYTtcclxuICAgIHZhciBvbGRiID0gYjtcclxuICAgIHZhciBvbGRjID0gYztcclxuICAgIHZhciBvbGRkID0gZDtcclxuXHJcbiAgICBhID0gbWQ1X2ZmKGEsIGIsIGMsIGQsIHhbaSsgMF0sIDcgLCAtNjgwODc2OTM2KTtcclxuICAgIGQgPSBtZDVfZmYoZCwgYSwgYiwgYywgeFtpKyAxXSwgMTIsIC0zODk1NjQ1ODYpO1xyXG4gICAgYyA9IG1kNV9mZihjLCBkLCBhLCBiLCB4W2krIDJdLCAxNywgIDYwNjEwNTgxOSk7XHJcbiAgICBiID0gbWQ1X2ZmKGIsIGMsIGQsIGEsIHhbaSsgM10sIDIyLCAtMTA0NDUyNTMzMCk7XHJcbiAgICBhID0gbWQ1X2ZmKGEsIGIsIGMsIGQsIHhbaSsgNF0sIDcgLCAtMTc2NDE4ODk3KTtcclxuICAgIGQgPSBtZDVfZmYoZCwgYSwgYiwgYywgeFtpKyA1XSwgMTIsICAxMjAwMDgwNDI2KTtcclxuICAgIGMgPSBtZDVfZmYoYywgZCwgYSwgYiwgeFtpKyA2XSwgMTcsIC0xNDczMjMxMzQxKTtcclxuICAgIGIgPSBtZDVfZmYoYiwgYywgZCwgYSwgeFtpKyA3XSwgMjIsIC00NTcwNTk4Myk7XHJcbiAgICBhID0gbWQ1X2ZmKGEsIGIsIGMsIGQsIHhbaSsgOF0sIDcgLCAgMTc3MDAzNTQxNik7XHJcbiAgICBkID0gbWQ1X2ZmKGQsIGEsIGIsIGMsIHhbaSsgOV0sIDEyLCAtMTk1ODQxNDQxNyk7XHJcbiAgICBjID0gbWQ1X2ZmKGMsIGQsIGEsIGIsIHhbaSsxMF0sIDE3LCAtNDIwNjMpO1xyXG4gICAgYiA9IG1kNV9mZihiLCBjLCBkLCBhLCB4W2krMTFdLCAyMiwgLTE5OTA0MDQxNjIpO1xyXG4gICAgYSA9IG1kNV9mZihhLCBiLCBjLCBkLCB4W2krMTJdLCA3ICwgIDE4MDQ2MDM2ODIpO1xyXG4gICAgZCA9IG1kNV9mZihkLCBhLCBiLCBjLCB4W2krMTNdLCAxMiwgLTQwMzQxMTAxKTtcclxuICAgIGMgPSBtZDVfZmYoYywgZCwgYSwgYiwgeFtpKzE0XSwgMTcsIC0xNTAyMDAyMjkwKTtcclxuICAgIGIgPSBtZDVfZmYoYiwgYywgZCwgYSwgeFtpKzE1XSwgMjIsICAxMjM2NTM1MzI5KTtcclxuXHJcbiAgICBhID0gbWQ1X2dnKGEsIGIsIGMsIGQsIHhbaSsgMV0sIDUgLCAtMTY1Nzk2NTEwKTtcclxuICAgIGQgPSBtZDVfZ2coZCwgYSwgYiwgYywgeFtpKyA2XSwgOSAsIC0xMDY5NTAxNjMyKTtcclxuICAgIGMgPSBtZDVfZ2coYywgZCwgYSwgYiwgeFtpKzExXSwgMTQsICA2NDM3MTc3MTMpO1xyXG4gICAgYiA9IG1kNV9nZyhiLCBjLCBkLCBhLCB4W2krIDBdLCAyMCwgLTM3Mzg5NzMwMik7XHJcbiAgICBhID0gbWQ1X2dnKGEsIGIsIGMsIGQsIHhbaSsgNV0sIDUgLCAtNzAxNTU4NjkxKTtcclxuICAgIGQgPSBtZDVfZ2coZCwgYSwgYiwgYywgeFtpKzEwXSwgOSAsICAzODAxNjA4Myk7XHJcbiAgICBjID0gbWQ1X2dnKGMsIGQsIGEsIGIsIHhbaSsxNV0sIDE0LCAtNjYwNDc4MzM1KTtcclxuICAgIGIgPSBtZDVfZ2coYiwgYywgZCwgYSwgeFtpKyA0XSwgMjAsIC00MDU1Mzc4NDgpO1xyXG4gICAgYSA9IG1kNV9nZyhhLCBiLCBjLCBkLCB4W2krIDldLCA1ICwgIDU2ODQ0NjQzOCk7XHJcbiAgICBkID0gbWQ1X2dnKGQsIGEsIGIsIGMsIHhbaSsxNF0sIDkgLCAtMTAxOTgwMzY5MCk7XHJcbiAgICBjID0gbWQ1X2dnKGMsIGQsIGEsIGIsIHhbaSsgM10sIDE0LCAtMTg3MzYzOTYxKTtcclxuICAgIGIgPSBtZDVfZ2coYiwgYywgZCwgYSwgeFtpKyA4XSwgMjAsICAxMTYzNTMxNTAxKTtcclxuICAgIGEgPSBtZDVfZ2coYSwgYiwgYywgZCwgeFtpKzEzXSwgNSAsIC0xNDQ0NjgxNDY3KTtcclxuICAgIGQgPSBtZDVfZ2coZCwgYSwgYiwgYywgeFtpKyAyXSwgOSAsIC01MTQwMzc4NCk7XHJcbiAgICBjID0gbWQ1X2dnKGMsIGQsIGEsIGIsIHhbaSsgN10sIDE0LCAgMTczNTMyODQ3Myk7XHJcbiAgICBiID0gbWQ1X2dnKGIsIGMsIGQsIGEsIHhbaSsxMl0sIDIwLCAtMTkyNjYwNzczNCk7XHJcblxyXG4gICAgYSA9IG1kNV9oaChhLCBiLCBjLCBkLCB4W2krIDVdLCA0ICwgLTM3ODU1OCk7XHJcbiAgICBkID0gbWQ1X2hoKGQsIGEsIGIsIGMsIHhbaSsgOF0sIDExLCAtMjAyMjU3NDQ2Myk7XHJcbiAgICBjID0gbWQ1X2hoKGMsIGQsIGEsIGIsIHhbaSsxMV0sIDE2LCAgMTgzOTAzMDU2Mik7XHJcbiAgICBiID0gbWQ1X2hoKGIsIGMsIGQsIGEsIHhbaSsxNF0sIDIzLCAtMzUzMDk1NTYpO1xyXG4gICAgYSA9IG1kNV9oaChhLCBiLCBjLCBkLCB4W2krIDFdLCA0ICwgLTE1MzA5OTIwNjApO1xyXG4gICAgZCA9IG1kNV9oaChkLCBhLCBiLCBjLCB4W2krIDRdLCAxMSwgIDEyNzI4OTMzNTMpO1xyXG4gICAgYyA9IG1kNV9oaChjLCBkLCBhLCBiLCB4W2krIDddLCAxNiwgLTE1NTQ5NzYzMik7XHJcbiAgICBiID0gbWQ1X2hoKGIsIGMsIGQsIGEsIHhbaSsxMF0sIDIzLCAtMTA5NDczMDY0MCk7XHJcbiAgICBhID0gbWQ1X2hoKGEsIGIsIGMsIGQsIHhbaSsxM10sIDQgLCAgNjgxMjc5MTc0KTtcclxuICAgIGQgPSBtZDVfaGgoZCwgYSwgYiwgYywgeFtpKyAwXSwgMTEsIC0zNTg1MzcyMjIpO1xyXG4gICAgYyA9IG1kNV9oaChjLCBkLCBhLCBiLCB4W2krIDNdLCAxNiwgLTcyMjUyMTk3OSk7XHJcbiAgICBiID0gbWQ1X2hoKGIsIGMsIGQsIGEsIHhbaSsgNl0sIDIzLCAgNzYwMjkxODkpO1xyXG4gICAgYSA9IG1kNV9oaChhLCBiLCBjLCBkLCB4W2krIDldLCA0ICwgLTY0MDM2NDQ4Nyk7XHJcbiAgICBkID0gbWQ1X2hoKGQsIGEsIGIsIGMsIHhbaSsxMl0sIDExLCAtNDIxODE1ODM1KTtcclxuICAgIGMgPSBtZDVfaGgoYywgZCwgYSwgYiwgeFtpKzE1XSwgMTYsICA1MzA3NDI1MjApO1xyXG4gICAgYiA9IG1kNV9oaChiLCBjLCBkLCBhLCB4W2krIDJdLCAyMywgLTk5NTMzODY1MSk7XHJcblxyXG4gICAgYSA9IG1kNV9paShhLCBiLCBjLCBkLCB4W2krIDBdLCA2ICwgLTE5ODYzMDg0NCk7XHJcbiAgICBkID0gbWQ1X2lpKGQsIGEsIGIsIGMsIHhbaSsgN10sIDEwLCAgMTEyNjg5MTQxNSk7XHJcbiAgICBjID0gbWQ1X2lpKGMsIGQsIGEsIGIsIHhbaSsxNF0sIDE1LCAtMTQxNjM1NDkwNSk7XHJcbiAgICBiID0gbWQ1X2lpKGIsIGMsIGQsIGEsIHhbaSsgNV0sIDIxLCAtNTc0MzQwNTUpO1xyXG4gICAgYSA9IG1kNV9paShhLCBiLCBjLCBkLCB4W2krMTJdLCA2ICwgIDE3MDA0ODU1NzEpO1xyXG4gICAgZCA9IG1kNV9paShkLCBhLCBiLCBjLCB4W2krIDNdLCAxMCwgLTE4OTQ5ODY2MDYpO1xyXG4gICAgYyA9IG1kNV9paShjLCBkLCBhLCBiLCB4W2krMTBdLCAxNSwgLTEwNTE1MjMpO1xyXG4gICAgYiA9IG1kNV9paShiLCBjLCBkLCBhLCB4W2krIDFdLCAyMSwgLTIwNTQ5MjI3OTkpO1xyXG4gICAgYSA9IG1kNV9paShhLCBiLCBjLCBkLCB4W2krIDhdLCA2ICwgIDE4NzMzMTMzNTkpO1xyXG4gICAgZCA9IG1kNV9paShkLCBhLCBiLCBjLCB4W2krMTVdLCAxMCwgLTMwNjExNzQ0KTtcclxuICAgIGMgPSBtZDVfaWkoYywgZCwgYSwgYiwgeFtpKyA2XSwgMTUsIC0xNTYwMTk4MzgwKTtcclxuICAgIGIgPSBtZDVfaWkoYiwgYywgZCwgYSwgeFtpKzEzXSwgMjEsICAxMzA5MTUxNjQ5KTtcclxuICAgIGEgPSBtZDVfaWkoYSwgYiwgYywgZCwgeFtpKyA0XSwgNiAsIC0xNDU1MjMwNzApO1xyXG4gICAgZCA9IG1kNV9paShkLCBhLCBiLCBjLCB4W2krMTFdLCAxMCwgLTExMjAyMTAzNzkpO1xyXG4gICAgYyA9IG1kNV9paShjLCBkLCBhLCBiLCB4W2krIDJdLCAxNSwgIDcxODc4NzI1OSk7XHJcbiAgICBiID0gbWQ1X2lpKGIsIGMsIGQsIGEsIHhbaSsgOV0sIDIxLCAtMzQzNDg1NTUxKTtcclxuXHJcbiAgICBhID0gc2FmZV9hZGQoYSwgb2xkYSk7XHJcbiAgICBiID0gc2FmZV9hZGQoYiwgb2xkYik7XHJcbiAgICBjID0gc2FmZV9hZGQoYywgb2xkYyk7XHJcbiAgICBkID0gc2FmZV9hZGQoZCwgb2xkZCk7XHJcbiAgfVxyXG4gIHJldHVybiBBcnJheShhLCBiLCBjLCBkKTtcclxuXHJcbn1cclxuXHJcbi8qXHJcbiAqIFRoZXNlIGZ1bmN0aW9ucyBpbXBsZW1lbnQgdGhlIGZvdXIgYmFzaWMgb3BlcmF0aW9ucyB0aGUgYWxnb3JpdGhtIHVzZXMuXHJcbiAqL1xyXG5mdW5jdGlvbiBtZDVfY21uKHEsIGEsIGIsIHgsIHMsIHQpXHJcbntcclxuICByZXR1cm4gc2FmZV9hZGQoYml0X3JvbChzYWZlX2FkZChzYWZlX2FkZChhLCBxKSwgc2FmZV9hZGQoeCwgdCkpLCBzKSxiKTtcclxufVxyXG5mdW5jdGlvbiBtZDVfZmYoYSwgYiwgYywgZCwgeCwgcywgdClcclxue1xyXG4gIHJldHVybiBtZDVfY21uKChiICYgYykgfCAoKH5iKSAmIGQpLCBhLCBiLCB4LCBzLCB0KTtcclxufVxyXG5mdW5jdGlvbiBtZDVfZ2coYSwgYiwgYywgZCwgeCwgcywgdClcclxue1xyXG4gIHJldHVybiBtZDVfY21uKChiICYgZCkgfCAoYyAmICh+ZCkpLCBhLCBiLCB4LCBzLCB0KTtcclxufVxyXG5mdW5jdGlvbiBtZDVfaGgoYSwgYiwgYywgZCwgeCwgcywgdClcclxue1xyXG4gIHJldHVybiBtZDVfY21uKGIgXiBjIF4gZCwgYSwgYiwgeCwgcywgdCk7XHJcbn1cclxuZnVuY3Rpb24gbWQ1X2lpKGEsIGIsIGMsIGQsIHgsIHMsIHQpXHJcbntcclxuICByZXR1cm4gbWQ1X2NtbihjIF4gKGIgfCAofmQpKSwgYSwgYiwgeCwgcywgdCk7XHJcbn1cclxuXHJcbi8qXHJcbiAqIENhbGN1bGF0ZSB0aGUgSE1BQy1NRDUsIG9mIGEga2V5IGFuZCBzb21lIGRhdGFcclxuICovXHJcbmZ1bmN0aW9uIGNvcmVfaG1hY19tZDUoa2V5LCBkYXRhKVxyXG57XHJcbiAgdmFyIGJrZXkgPSBzdHIyYmlubChrZXkpO1xyXG4gIGlmKGJrZXkubGVuZ3RoID4gMTYpIGJrZXkgPSBjb3JlX21kNShia2V5LCBrZXkubGVuZ3RoICogY2hyc3opO1xyXG5cclxuICB2YXIgaXBhZCA9IEFycmF5KDE2KSwgb3BhZCA9IEFycmF5KDE2KTtcclxuICBmb3IodmFyIGkgPSAwOyBpIDwgMTY7IGkrKylcclxuICB7XHJcbiAgICBpcGFkW2ldID0gYmtleVtpXSBeIDB4MzYzNjM2MzY7XHJcbiAgICBvcGFkW2ldID0gYmtleVtpXSBeIDB4NUM1QzVDNUM7XHJcbiAgfVxyXG5cclxuICB2YXIgaGFzaCA9IGNvcmVfbWQ1KGlwYWQuY29uY2F0KHN0cjJiaW5sKGRhdGEpKSwgNTEyICsgZGF0YS5sZW5ndGggKiBjaHJzeik7XHJcbiAgcmV0dXJuIGNvcmVfbWQ1KG9wYWQuY29uY2F0KGhhc2gpLCA1MTIgKyAxMjgpO1xyXG59XHJcblxyXG4vKlxyXG4gKiBBZGQgaW50ZWdlcnMsIHdyYXBwaW5nIGF0IDJeMzIuIFRoaXMgdXNlcyAxNi1iaXQgb3BlcmF0aW9ucyBpbnRlcm5hbGx5XHJcbiAqIHRvIHdvcmsgYXJvdW5kIGJ1Z3MgaW4gc29tZSBKUyBpbnRlcnByZXRlcnMuXHJcbiAqL1xyXG5mdW5jdGlvbiBzYWZlX2FkZCh4LCB5KVxyXG57XHJcbiAgdmFyIGxzdyA9ICh4ICYgMHhGRkZGKSArICh5ICYgMHhGRkZGKTtcclxuICB2YXIgbXN3ID0gKHggPj4gMTYpICsgKHkgPj4gMTYpICsgKGxzdyA+PiAxNik7XHJcbiAgcmV0dXJuIChtc3cgPDwgMTYpIHwgKGxzdyAmIDB4RkZGRik7XHJcbn1cclxuXHJcbi8qXHJcbiAqIEJpdHdpc2Ugcm90YXRlIGEgMzItYml0IG51bWJlciB0byB0aGUgbGVmdC5cclxuICovXHJcbmZ1bmN0aW9uIGJpdF9yb2wobnVtLCBjbnQpXHJcbntcclxuICByZXR1cm4gKG51bSA8PCBjbnQpIHwgKG51bSA+Pj4gKDMyIC0gY250KSk7XHJcbn1cclxuXHJcbi8qXHJcbiAqIENvbnZlcnQgYSBzdHJpbmcgdG8gYW4gYXJyYXkgb2YgbGl0dGxlLWVuZGlhbiB3b3Jkc1xyXG4gKiBJZiBjaHJzeiBpcyBBU0NJSSwgY2hhcmFjdGVycyA+MjU1IGhhdmUgdGhlaXIgaGktYnl0ZSBzaWxlbnRseSBpZ25vcmVkLlxyXG4gKi9cclxuZnVuY3Rpb24gc3RyMmJpbmwoc3RyKVxyXG57XHJcbiAgdmFyIGJpbiA9IEFycmF5KCk7XHJcbiAgdmFyIG1hc2sgPSAoMSA8PCBjaHJzeikgLSAxO1xyXG4gIGZvcih2YXIgaSA9IDA7IGkgPCBzdHIubGVuZ3RoICogY2hyc3o7IGkgKz0gY2hyc3opXHJcbiAgICBiaW5baT4+NV0gfD0gKHN0ci5jaGFyQ29kZUF0KGkgLyBjaHJzeikgJiBtYXNrKSA8PCAoaSUzMik7XHJcbiAgcmV0dXJuIGJpbjtcclxufVxyXG5cclxuLypcclxuICogQ29udmVydCBhbiBhcnJheSBvZiBsaXR0bGUtZW5kaWFuIHdvcmRzIHRvIGEgc3RyaW5nXHJcbiAqL1xyXG5mdW5jdGlvbiBiaW5sMnN0cihiaW4pXHJcbntcclxuICB2YXIgc3RyID0gXCJcIjtcclxuICB2YXIgbWFzayA9ICgxIDw8IGNocnN6KSAtIDE7XHJcbiAgZm9yKHZhciBpID0gMDsgaSA8IGJpbi5sZW5ndGggKiAzMjsgaSArPSBjaHJzeilcclxuICAgIHN0ciArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKChiaW5baT4+NV0gPj4+IChpICUgMzIpKSAmIG1hc2spO1xyXG4gIHJldHVybiBzdHI7XHJcbn1cclxuXHJcbi8qXHJcbiAqIENvbnZlcnQgYW4gYXJyYXkgb2YgbGl0dGxlLWVuZGlhbiB3b3JkcyB0byBhIGhleCBzdHJpbmcuXHJcbiAqL1xyXG5mdW5jdGlvbiBiaW5sMmhleChiaW5hcnJheSlcclxue1xyXG4gIHZhciBoZXhfdGFiID0gaGV4Y2FzZSA/IFwiMDEyMzQ1Njc4OUFCQ0RFRlwiIDogXCIwMTIzNDU2Nzg5YWJjZGVmXCI7XHJcbiAgdmFyIHN0ciA9IFwiXCI7XHJcbiAgZm9yKHZhciBpID0gMDsgaSA8IGJpbmFycmF5Lmxlbmd0aCAqIDQ7IGkrKylcclxuICB7XHJcbiAgICBzdHIgKz0gaGV4X3RhYi5jaGFyQXQoKGJpbmFycmF5W2k+PjJdID4+ICgoaSU0KSo4KzQpKSAmIDB4RikgK1xyXG4gICAgICAgICAgIGhleF90YWIuY2hhckF0KChiaW5hcnJheVtpPj4yXSA+PiAoKGklNCkqOCAgKSkgJiAweEYpO1xyXG4gIH1cclxuICByZXR1cm4gc3RyO1xyXG59XHJcblxyXG4vKlxyXG4gKiBDb252ZXJ0IGFuIGFycmF5IG9mIGxpdHRsZS1lbmRpYW4gd29yZHMgdG8gYSBiYXNlLTY0IHN0cmluZ1xyXG4gKi9cclxuZnVuY3Rpb24gYmlubDJiNjQoYmluYXJyYXkpXHJcbntcclxuICB2YXIgdGFiID0gXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvXCI7XHJcbiAgdmFyIHN0ciA9IFwiXCI7XHJcbiAgZm9yKHZhciBpID0gMDsgaSA8IGJpbmFycmF5Lmxlbmd0aCAqIDQ7IGkgKz0gMylcclxuICB7XHJcbiAgICB2YXIgdHJpcGxldCA9ICgoKGJpbmFycmF5W2kgICA+PiAyXSA+PiA4ICogKCBpICAgJTQpKSAmIDB4RkYpIDw8IDE2KVxyXG4gICAgICAgICAgICAgICAgfCAoKChiaW5hcnJheVtpKzEgPj4gMl0gPj4gOCAqICgoaSsxKSU0KSkgJiAweEZGKSA8PCA4IClcclxuICAgICAgICAgICAgICAgIHwgICgoYmluYXJyYXlbaSsyID4+IDJdID4+IDggKiAoKGkrMiklNCkpICYgMHhGRik7XHJcbiAgICBmb3IodmFyIGogPSAwOyBqIDwgNDsgaisrKVxyXG4gICAge1xyXG4gICAgICBpZihpICogOCArIGogKiA2ID4gYmluYXJyYXkubGVuZ3RoICogMzIpIHN0ciArPSBiNjRwYWQ7XHJcbiAgICAgIGVsc2Ugc3RyICs9IHRhYi5jaGFyQXQoKHRyaXBsZXQgPj4gNiooMy1qKSkgJiAweDNGKTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHN0cjtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICBoZXhfbWQ1OmhleF9tZDVcclxufSIsIlxyXG5sZXQgbG9hZGluZ0luc3RhbmNlO1xyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgLy8g5raI5oGv5o+Q56S6XHJcbiAgbXNnKGNvbnRlbnQpIHtcclxuICAgIEVsTWVzc2FnZS5pbmZvKGNvbnRlbnQpXHJcbiAgfSxcclxuICAvLyDplJnor6/mtojmga9cclxuICBtc2dFcnJvcihjb250ZW50KSB7XHJcbiAgICBFbE1lc3NhZ2UuZXJyb3IoY29udGVudClcclxuICB9LFxyXG4gIC8vIOaIkOWKn+a2iOaBr1xyXG4gIG1zZ1N1Y2Nlc3MoY29udGVudCkge1xyXG4gICAgRWxNZXNzYWdlLnN1Y2Nlc3MoY29udGVudClcclxuICB9LFxyXG4gIC8vIOitpuWRiua2iOaBr1xyXG4gIG1zZ1dhcm5pbmcoY29udGVudCkge1xyXG4gICAgRWxNZXNzYWdlLndhcm5pbmcoY29udGVudClcclxuICB9LFxyXG4gIC8vIOW8ueWHuuaPkOekulxyXG4gIGFsZXJ0KGNvbnRlbnQpIHtcclxuICAgIEVsTWVzc2FnZUJveC5hbGVydChjb250ZW50LCBcIuezu+e7n+aPkOekulwiKVxyXG4gIH0sXHJcbiAgLy8g6ZSZ6K+v5o+Q56S6XHJcbiAgYWxlcnRFcnJvcihjb250ZW50KSB7XHJcbiAgICBFbE1lc3NhZ2VCb3guYWxlcnQoY29udGVudCwgXCLns7vnu5/mj5DnpLpcIiwgeyB0eXBlOiAnZXJyb3InIH0pXHJcbiAgfSxcclxuICAvLyDmiJDlip/mj5DnpLpcclxuICBhbGVydFN1Y2Nlc3MoY29udGVudCkge1xyXG4gICAgRWxNZXNzYWdlQm94LmFsZXJ0KGNvbnRlbnQsIFwi57O757uf5o+Q56S6XCIsIHsgdHlwZTogJ3N1Y2Nlc3MnIH0pXHJcbiAgfSxcclxuICAvLyDorablkYrmj5DnpLpcclxuICBhbGVydFdhcm5pbmcoY29udGVudCkge1xyXG4gICAgRWxNZXNzYWdlQm94LmFsZXJ0KGNvbnRlbnQsIFwi57O757uf5o+Q56S6XCIsIHsgdHlwZTogJ3dhcm5pbmcnIH0pXHJcbiAgfSxcclxuICAvLyDpgJrnn6Xmj5DnpLpcclxuICBub3RpZnkoY29udGVudCkge1xyXG4gICAgRWxOb3RpZmljYXRpb24uaW5mbyhjb250ZW50KVxyXG4gIH0sXHJcbiAgLy8g6ZSZ6K+v6YCa55+lXHJcbiAgbm90aWZ5RXJyb3IoY29udGVudCkge1xyXG4gICAgRWxOb3RpZmljYXRpb24uZXJyb3IoY29udGVudCk7XHJcbiAgfSxcclxuICAvLyDmiJDlip/pgJrnn6VcclxuICBub3RpZnlTdWNjZXNzKGNvbnRlbnQpIHtcclxuICAgIEVsTm90aWZpY2F0aW9uLnN1Y2Nlc3MoY29udGVudClcclxuICB9LFxyXG4gIC8vIOitpuWRiumAmuefpVxyXG4gIG5vdGlmeVdhcm5pbmcoY29udGVudCkge1xyXG4gICAgRWxOb3RpZmljYXRpb24ud2FybmluZyhjb250ZW50KVxyXG4gIH0sXHJcbiAgLy8g56Gu6K6k56qX5L2TXHJcbiAgY29uZmlybShjb250ZW50LG9wdGlvbnM9e30pIHtcclxuICAgIHJldHVybiBFbE1lc3NhZ2VCb3guY29uZmlybShjb250ZW50LCBcIuezu+e7n+aPkOekulwiLCB7XHJcbiAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiBvcHRpb25zLmNvbmZpcm1CdXR0b25UZXh0IHx8ICfnoa7lrponLFxyXG4gICAgICBjYW5jZWxCdXR0b25UZXh0OiBvcHRpb25zLmNhbmNlbEJ1dHRvblRleHQgfHwgJ+WPlua2iCcsXHJcbiAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICBkYW5nZXJvdXNseVVzZUhUTUxTdHJpbmc6IG9wdGlvbnMuZGFuZ2Vyb3VzbHlVc2VIVE1MU3RyaW5nLFxyXG4gICAgfSlcclxuICB9LFxyXG4gIC8vIOaPkOS6pOWGheWuuVxyXG4gIHByb21wdChjb250ZW50KSB7XHJcbiAgICByZXR1cm4gRWxNZXNzYWdlQm94LnByb21wdChjb250ZW50LCBcIuezu+e7n+aPkOekulwiLCB7XHJcbiAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAn56Gu5a6aJyxcclxuICAgICAgY2FuY2VsQnV0dG9uVGV4dDogJ+WPlua2iCcsXHJcbiAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgfSlcclxuICB9LFxyXG4gIC8vIOaJk+W8gOmBrue9qeWxglxyXG4gIGxvYWRpbmcoY29udGVudCkge1xyXG4gICAgbG9hZGluZ0luc3RhbmNlID0gRWxMb2FkaW5nLnNlcnZpY2Uoe1xyXG4gICAgICBsb2NrOiB0cnVlLFxyXG4gICAgICB0ZXh0OiBjb250ZW50LFxyXG4gICAgICBiYWNrZ3JvdW5kOiBcInJnYmEoMCwgMCwgMCwgMC43KVwiLFxyXG4gICAgfSlcclxuICB9LFxyXG4gIC8vIOWFs+mXremBrue9qeWxglxyXG4gIGNsb3NlTG9hZGluZygpIHtcclxuICAgIGxvYWRpbmdJbnN0YW5jZS5jbG9zZSgpO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbW9kYWwgZnJvbSAnQHNyYy9qcy91dGlscy9tb2RhbCc7XG5pbXBvcnQgaHR0cCBmcm9tICdAc3JjL2pzL3V0aWxzL2h0dHAnO1xuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdsb2dpbicsXG4gIGVtaXRzOiBbJ2xvZ2luU3VjY2VzcyddLFxuICBzZXR1cChfX3Byb3BzLCB7XG4gICAgZXhwb3NlOiBfX2V4cG9zZSxcbiAgICBlbWl0OiBfX2VtaXRcbiAgfSkge1xuICAgIF9fZXhwb3NlKCk7XG4gICAgY29uc3QgZW1pdCA9IF9fZW1pdDtcbiAgICBsZXQgbW9kZWwgPSByZWFjdGl2ZSh7XG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICBwYXNzd29yZDogJydcbiAgICB9KTtcbiAgICBvbk1vdW50ZWQoYXN5bmMgKCkgPT4ge30pO1xuICAgIGZ1bmN0aW9uIGxvZ2luKCkge1xuICAgICAgbGV0IHBob25lID0gbW9kZWwudXNlcm5hbWUucmVwbGFjZSgvXFxzKy9pZywgJycpO1xuICAgICAgbGV0IHBhc3N3b3JkID0gbW9kZWwucGFzc3dvcmQucmVwbGFjZSgvXlxccysvaWcsICcnKS5yZXBsYWNlKC9cXHMrJC9pZywgJycpO1xuICAgICAgaWYgKCFwaG9uZSkge1xuICAgICAgICBtb2RhbC5tc2dXYXJuaW5nKFwi6K+36L6T5YWl6LSm5Y+3XCIpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIXBhc3N3b3JkKSB7XG4gICAgICAgIG1vZGFsLm1zZ1dhcm5pbmcoXCLor7fovpPlhaXlr4bnoIFcIik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGh0dHAuaHR0cFBvc3QoJy90ZWFjaGVyLWRpbmctdGFsay9sb2dpbicsIHtcbiAgICAgICAgcGFzc3dvcmQ6IGh0dHAuZW5jcnlwdFN0cihtb2RlbC5wYXNzd29yZCkudG9VcHBlckNhc2UoKSxcbiAgICAgICAgdXNlcm5hbWU6IG1vZGVsLnVzZXJuYW1lXG4gICAgICB9KS50aGVuKGFzeW5jIHJlcyA9PiB7XG4gICAgICAgIGxldCB7XG4gICAgICAgICAgZXJyb3JfY29kZSxcbiAgICAgICAgICBkYXRhXG4gICAgICAgIH0gPSByZXM7XG4gICAgICAgIGlmICghZXJyb3JfY29kZSkge1xuICAgICAgICAgIGVtaXQoJ2xvZ2luU3VjY2VzcycpO1xuICAgICAgICAgIG1vZGFsLm1zZ1N1Y2Nlc3MoJ+eZu+W9leaIkOWKn++8gScpO1xuICAgICAgICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICAgICAgICB0b2tlbjogcmVzLmRhdGEudG9rZW5cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIGVtaXQsXG4gICAgICBnZXQgbW9kZWwoKSB7XG4gICAgICAgIHJldHVybiBtb2RlbDtcbiAgICAgIH0sXG4gICAgICBzZXQgbW9kZWwodikge1xuICAgICAgICBtb2RlbCA9IHY7XG4gICAgICB9LFxuICAgICAgbG9naW4sXG4gICAgICBnZXQgbW9kYWwoKSB7XG4gICAgICAgIHJldHVybiBtb2RhbDtcbiAgICAgIH0sXG4gICAgICBnZXQgaHR0cCgpIHtcbiAgICAgICAgcmV0dXJuIGh0dHA7XG4gICAgICB9XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoX19yZXR1cm5lZF9fLCAnX19pc1NjcmlwdFNldHVwJywge1xuICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICB2YWx1ZTogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBfX3JldHVybmVkX187XG4gIH1cbn07IiwiZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdtYWluJyxcbiAgc2V0dXAoX19wcm9wcywge1xuICAgIGV4cG9zZTogX19leHBvc2VcbiAgfSkge1xuICAgIF9fZXhwb3NlKCk7XG4gICAgbGV0IGNvbG9ycyA9IFsncmVkJywgJ2JsdWUnLCAneWVsbG93JywgJ3BpbmsnLCAnZ3JlZW4nLCAnb3JhbmdlJ107XG4gICAgZnVuY3Rpb24gY2hhbmdlQmcoKSB7XG4gICAgICBjb25zdCByYW5kb21Db2xvciA9IGNvbG9yc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBjb2xvcnMubGVuZ3RoKV07XG4gICAgICBjaHJvbWUudGFicy5xdWVyeSh7XG4gICAgICAgIGFjdGl2ZTogdHJ1ZSxcbiAgICAgICAgY3VycmVudFdpbmRvdzogZmFsc2VcbiAgICAgIH0sIGZ1bmN0aW9uICh0YWJzKSB7XG4gICAgICAgIGxldCBiYWlkdVRhYnMgPSB0YWJzLmZpbHRlcih0YWIgPT4gdGFiLnVybC5pbmNsdWRlcygnaHR0cHM6Ly93d3cuYmFpZHUuY29tJykpO1xuICAgICAgICBjb25zb2xlLmxvZyhiYWlkdVRhYnMsICdiYWlkdVRhYnMnKTtcbiAgICAgICAgaWYgKGJhaWR1VGFicy5sZW5ndGgpIHtcbiAgICAgICAgICBiYWlkdVRhYnMuZm9yRWFjaCh0YWIgPT4ge1xuICAgICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCB7XG4gICAgICAgICAgICAgIGFjdGlvbjogJ2NoYW5nZUJnJyxcbiAgICAgICAgICAgICAgZGF0YTogcmFuZG9tQ29sb3JcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNocm9tZS53aW5kb3dzLmNyZWF0ZSh7XG4gICAgICAgICAgICB1cmw6IFwiaHR0cHM6Ly93d3cuYmFpZHUuY29tXCIsXG4gICAgICAgICAgICB0eXBlOiBcIm5vcm1hbFwiLFxuICAgICAgICAgICAgLy8g5Y+v6YCJOiBcIm5vcm1hbFwiLCBcInBvcHVwXCIsIFwicGFuZWxcIlxuICAgICAgICAgICAgd2lkdGg6IDEwMDAsXG4gICAgICAgICAgICBoZWlnaHQ6IDgwMCxcbiAgICAgICAgICAgIGxlZnQ6IDEwMCxcbiAgICAgICAgICAgIHRvcDogMTAwLFxuICAgICAgICAgICAgZm9jdXNlZDogdHJ1ZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgX19yZXR1cm5lZF9fID0ge1xuICAgICAgZ2V0IGNvbG9ycygpIHtcbiAgICAgICAgcmV0dXJuIGNvbG9ycztcbiAgICAgIH0sXG4gICAgICBzZXQgY29sb3JzKHYpIHtcbiAgICAgICAgY29sb3JzID0gdjtcbiAgICAgIH0sXG4gICAgICBjaGFuZ2VCZ1xuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsImltcG9ydCB7IGdldFRva2VuIH0gZnJvbSAnQHNyYy9qcy91dGlscy9mdW4nO1xuaW1wb3J0IExvZ2luIGZyb20gJ0BzcmMvdnVlL2NvbXBvbmVudHMvbG9naW4udnVlJztcbmltcG9ydCBNYWluIGZyb20gJ0BzcmMvdnVlL2NvbXBvbmVudHMvbWFpbi52dWUnO1xuZXhwb3J0IGRlZmF1bHQge1xuICBfX25hbWU6ICdwb3B1cCcsXG4gIHNldHVwKF9fcHJvcHMsIHtcbiAgICBleHBvc2U6IF9fZXhwb3NlXG4gIH0pIHtcbiAgICBfX2V4cG9zZSgpO1xuICAgIGxldCBpc0xvZ2luID0gcmVmKG51bGwpO1xuICAgIG9uTW91bnRlZChhc3luYyAoKSA9PiB7XG4gICAgICBsZXQgdG9rZW4gPSBhd2FpdCBnZXRUb2tlbigpO1xuICAgICAgaXNMb2dpbi52YWx1ZSA9IHRva2VuID8gdHJ1ZSA6IGZhbHNlO1xuICAgIH0pO1xuICAgIGNvbnN0IF9fcmV0dXJuZWRfXyA9IHtcbiAgICAgIGdldCBpc0xvZ2luKCkge1xuICAgICAgICByZXR1cm4gaXNMb2dpbjtcbiAgICAgIH0sXG4gICAgICBzZXQgaXNMb2dpbih2KSB7XG4gICAgICAgIGlzTG9naW4gPSB2O1xuICAgICAgfSxcbiAgICAgIGdldCBnZXRUb2tlbigpIHtcbiAgICAgICAgcmV0dXJuIGdldFRva2VuO1xuICAgICAgfSxcbiAgICAgIExvZ2luLFxuICAgICAgTWFpblxuICAgIH07XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KF9fcmV0dXJuZWRfXywgJ19faXNTY3JpcHRTZXR1cCcsIHtcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgdmFsdWU6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gX19yZXR1cm5lZF9fO1xuICB9XG59OyIsImltcG9ydCB7IGNyZWF0ZUVsZW1lbnRWTm9kZSBhcyBfY3JlYXRlRWxlbWVudFZOb2RlLCB2TW9kZWxUZXh0IGFzIF92TW9kZWxUZXh0LCB3aXRoRGlyZWN0aXZlcyBhcyBfd2l0aERpcmVjdGl2ZXMsIG9wZW5CbG9jayBhcyBfb3BlbkJsb2NrLCBjcmVhdGVFbGVtZW50QmxvY2sgYXMgX2NyZWF0ZUVsZW1lbnRCbG9jayB9IGZyb20gXCJ2dWVcIjtcbmNvbnN0IF9ob2lzdGVkXzEgPSB7XG4gIGNsYXNzOiBcImxvZ2luLWJveFwiXG59O1xuY29uc3QgX2hvaXN0ZWRfMiA9IHtcbiAgY2xhc3M6IFwibG9naW5GcmFtZVwiXG59O1xuY29uc3QgX2hvaXN0ZWRfMyA9IHtcbiAgY2xhc3M6IFwibG9naW4tbWFpblwiXG59O1xuY29uc3QgX2hvaXN0ZWRfNCA9IHtcbiAgY2xhc3M6IFwibG9naW4taXB0IGFjY291bnQtbWFpblwiXG59O1xuY29uc3QgX2hvaXN0ZWRfNSA9IHtcbiAgY2xhc3M6IFwibG9naW4taXB0IHB3ZC1tYWluXCJcbn07XG5leHBvcnQgZnVuY3Rpb24gcmVuZGVyKF9jdHgsIF9jYWNoZSwgJHByb3BzLCAkc2V0dXAsICRkYXRhLCAkb3B0aW9ucykge1xuICByZXR1cm4gX29wZW5CbG9jaygpLCBfY3JlYXRlRWxlbWVudEJsb2NrKFwiZGl2XCIsIF9ob2lzdGVkXzEsIFtfY3JlYXRlRWxlbWVudFZOb2RlKFwiZGl2XCIsIF9ob2lzdGVkXzIsIFtfY2FjaGVbNF0gfHwgKF9jYWNoZVs0XSA9IF9jcmVhdGVFbGVtZW50Vk5vZGUoXCJkaXZcIiwge1xuICAgIGNsYXNzOiBcIm1haW4tdGV4dFwiXG4gIH0sIFwi5a+G56CB55m75b2VXCIsIC0xIC8qIENBQ0hFRCAqLykpLCBfY3JlYXRlRWxlbWVudFZOb2RlKFwiZGl2XCIsIF9ob2lzdGVkXzMsIFtfY3JlYXRlRWxlbWVudFZOb2RlKFwiZGl2XCIsIF9ob2lzdGVkXzQsIFtfY2FjaGVbMl0gfHwgKF9jYWNoZVsyXSA9IF9jcmVhdGVFbGVtZW50Vk5vZGUoXCJkaXZcIiwge1xuICAgIGNsYXNzOiBcImlwdC1pY28gaWNvLXBob25lXCJcbiAgfSwgbnVsbCwgLTEgLyogQ0FDSEVEICovKSksIF93aXRoRGlyZWN0aXZlcyhfY3JlYXRlRWxlbWVudFZOb2RlKFwiaW5wdXRcIiwge1xuICAgIHR5cGU6IFwidGV4dFwiLFxuICAgIFwib25VcGRhdGU6bW9kZWxWYWx1ZVwiOiBfY2FjaGVbMF0gfHwgKF9jYWNoZVswXSA9ICRldmVudCA9PiAkc2V0dXAubW9kZWwudXNlcm5hbWUgPSAkZXZlbnQpLFxuICAgIGNsYXNzOiBcImlwdFwiLFxuICAgIHBsYWNlaG9sZGVyOiBcIuivt+i+k+WFpei0puWPt1wiXG4gIH0sIG51bGwsIDUxMiAvKiBORUVEX1BBVENIICovKSwgW1tfdk1vZGVsVGV4dCwgJHNldHVwLm1vZGVsLnVzZXJuYW1lXV0pXSksIF9jcmVhdGVFbGVtZW50Vk5vZGUoXCJkaXZcIiwgX2hvaXN0ZWRfNSwgW19jYWNoZVszXSB8fCAoX2NhY2hlWzNdID0gX2NyZWF0ZUVsZW1lbnRWTm9kZShcImRpdlwiLCB7XG4gICAgY2xhc3M6IFwiaXB0LWljbyBpY28tZXllXCJcbiAgfSwgbnVsbCwgLTEgLyogQ0FDSEVEICovKSksIF93aXRoRGlyZWN0aXZlcyhfY3JlYXRlRWxlbWVudFZOb2RlKFwiaW5wdXRcIiwge1xuICAgIHR5cGU6IFwicGFzc3dvcmRcIixcbiAgICBcIm9uVXBkYXRlOm1vZGVsVmFsdWVcIjogX2NhY2hlWzFdIHx8IChfY2FjaGVbMV0gPSAkZXZlbnQgPT4gJHNldHVwLm1vZGVsLnBhc3N3b3JkID0gJGV2ZW50KSxcbiAgICBjbGFzczogXCJpcHRcIixcbiAgICBwbGFjZWhvbGRlcjogXCLor7fovpPlhaXlr4bnoIFcIlxuICB9LCBudWxsLCA1MTIgLyogTkVFRF9QQVRDSCAqLyksIFtbX3ZNb2RlbFRleHQsICRzZXR1cC5tb2RlbC5wYXNzd29yZF1dKV0pLCBfY3JlYXRlRWxlbWVudFZOb2RlKFwiZGl2XCIsIHtcbiAgICBjbGFzczogXCJidG4gYnRuLW9yYW5nZSBidG4tbG9naW5cIixcbiAgICBvbkNsaWNrOiAkc2V0dXAubG9naW5cbiAgfSwgXCLnmbvlvZVcIildKV0pXSk7XG59IiwiaW1wb3J0IHsgY3JlYXRlRWxlbWVudFZOb2RlIGFzIF9jcmVhdGVFbGVtZW50Vk5vZGUsIG9wZW5CbG9jayBhcyBfb3BlbkJsb2NrLCBjcmVhdGVFbGVtZW50QmxvY2sgYXMgX2NyZWF0ZUVsZW1lbnRCbG9jayB9IGZyb20gXCJ2dWVcIjtcbmNvbnN0IF9ob2lzdGVkXzEgPSB7XG4gIGNsYXNzOiBcIm1haW4tYm94XCJcbn07XG5leHBvcnQgZnVuY3Rpb24gcmVuZGVyKF9jdHgsIF9jYWNoZSwgJHByb3BzLCAkc2V0dXAsICRkYXRhLCAkb3B0aW9ucykge1xuICByZXR1cm4gX29wZW5CbG9jaygpLCBfY3JlYXRlRWxlbWVudEJsb2NrKFwiZGl2XCIsIF9ob2lzdGVkXzEsIFtfY3JlYXRlRWxlbWVudFZOb2RlKFwiZGl2XCIsIHtcbiAgICBjbGFzczogXCJtYWluRnJhbWVcIlxuICB9LCBbX2NhY2hlWzBdIHx8IChfY2FjaGVbMF0gPSBfY3JlYXRlRWxlbWVudFZOb2RlKFwiZGl2XCIsIHtcbiAgICBjbGFzczogXCJtYWluLXRleHRcIlxuICB9LCBcIueCueWHu+WNs+WPr+S4uueZvuW6pumhtemdouabtOaNouearuiCpFwiLCAtMSAvKiBDQUNIRUQgKi8pKSwgX2NyZWF0ZUVsZW1lbnRWTm9kZShcImRpdlwiLCB7XG4gICAgY2xhc3M6IFwiYnRuIGJ0bi1vcmFuZ2VcIixcbiAgICBvbkNsaWNrOiAkc2V0dXAuY2hhbmdlQmdcbiAgfSwgXCLmjaLkuIDmjaJcIildKV0pO1xufSIsImltcG9ydCB7IG9wZW5CbG9jayBhcyBfb3BlbkJsb2NrLCBjcmVhdGVCbG9jayBhcyBfY3JlYXRlQmxvY2ssIGNyZWF0ZUNvbW1lbnRWTm9kZSBhcyBfY3JlYXRlQ29tbWVudFZOb2RlLCBGcmFnbWVudCBhcyBfRnJhZ21lbnQsIGNyZWF0ZUVsZW1lbnRCbG9jayBhcyBfY3JlYXRlRWxlbWVudEJsb2NrIH0gZnJvbSBcInZ1ZVwiO1xuZXhwb3J0IGZ1bmN0aW9uIHJlbmRlcihfY3R4LCBfY2FjaGUsICRwcm9wcywgJHNldHVwLCAkZGF0YSwgJG9wdGlvbnMpIHtcbiAgcmV0dXJuIF9vcGVuQmxvY2soKSwgX2NyZWF0ZUVsZW1lbnRCbG9jayhfRnJhZ21lbnQsIG51bGwsIFskc2V0dXAuaXNMb2dpbiA9PT0gZmFsc2UgPyAoX29wZW5CbG9jaygpLCBfY3JlYXRlQmxvY2soJHNldHVwW1wiTG9naW5cIl0sIHtcbiAgICBrZXk6IDAsXG4gICAgb25Mb2dpblN1Y2Nlc3M6IF9jYWNoZVswXSB8fCAoX2NhY2hlWzBdID0gJGV2ZW50ID0+ICRzZXR1cC5pc0xvZ2luID0gdHJ1ZSlcbiAgfSkpIDogX2NyZWF0ZUNvbW1lbnRWTm9kZShcInYtaWZcIiwgdHJ1ZSksICRzZXR1cC5pc0xvZ2luID8gKF9vcGVuQmxvY2soKSwgX2NyZWF0ZUJsb2NrKCRzZXR1cFtcIk1haW5cIl0sIHtcbiAgICBrZXk6IDFcbiAgfSkpIDogX2NyZWF0ZUNvbW1lbnRWTm9kZShcInYtaWZcIiwgdHJ1ZSldLCA2NCAvKiBTVEFCTEVfRlJBR01FTlQgKi8pO1xufSIsIi8qIHVucGx1Z2luLXZ1ZS1jb21wb25lbnRzIGRpc2FibGVkICovLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5leHBvcnQge307IiwiLyogdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMgZGlzYWJsZWQgKi8vLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiLCIvKiB1bnBsdWdpbi12dWUtY29tcG9uZW50cyBkaXNhYmxlZCAqLy8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxuZXhwb3J0IHt9OyIsIi8qIHVucGx1Z2luLXZ1ZS1jb21wb25lbnRzIGRpc2FibGVkICovaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIi4vbG9naW4udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTMxMDVlZjcyJnNjb3BlZD10cnVlXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vbG9naW4udnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vbG9naW4udnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuXG5pbXBvcnQgXCIuL2xvZ2luLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTMxMDVlZjcyJmxhbmc9c2NzcyZzY29wZWQ9dHJ1ZVwiXG5cbmltcG9ydCBleHBvcnRDb21wb25lbnQgZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvZXhwb3J0SGVscGVyLmpzXCJcbmNvbnN0IF9fZXhwb3J0c19fID0gLyojX19QVVJFX18qL2V4cG9ydENvbXBvbmVudChzY3JpcHQsIFtbJ3JlbmRlcicscmVuZGVyXSxbJ19fc2NvcGVJZCcsXCJkYXRhLXYtMzEwNWVmNzJcIl0sWydfX2ZpbGUnLFwic3JjL3Z1ZS9jb21wb25lbnRzL2xvZ2luLnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCIzMTA1ZWY3MlwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzMxMDVlZjcyJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnMzEwNWVmNzInLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL2xvZ2luLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0zMTA1ZWY3MiZzY29wZWQ9dHJ1ZVwiLCAoKSA9PiB7XG4gICAgYXBpLnJlcmVuZGVyKCczMTA1ZWY3MicsIHJlbmRlcilcbiAgfSlcblxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IF9fZXhwb3J0c19fIiwiLyogdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMgZGlzYWJsZWQgKi9pbXBvcnQgeyByZW5kZXIgfSBmcm9tIFwiLi9tYWluLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD00OWYwZjA4MCZzY29wZWQ9dHJ1ZVwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL21haW4udnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIlxuZXhwb3J0ICogZnJvbSBcIi4vbWFpbi52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiXG5cbmltcG9ydCBcIi4vbWFpbi52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD00OWYwZjA4MCZsYW5nPXNjc3Mmc2NvcGVkPXRydWVcIlxuXG5pbXBvcnQgZXhwb3J0Q29tcG9uZW50IGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2V4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX3Njb3BlSWQnLFwiZGF0YS12LTQ5ZjBmMDgwXCJdLFsnX19maWxlJyxcInNyYy92dWUvY29tcG9uZW50cy9tYWluLnZ1ZVwiXV0pXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICBfX2V4cG9ydHNfXy5fX2htcklkID0gXCI0OWYwZjA4MFwiXG4gIGNvbnN0IGFwaSA9IF9fVlVFX0hNUl9SVU5USU1FX19cbiAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICBpZiAoIWFwaS5jcmVhdGVSZWNvcmQoJzQ5ZjBmMDgwJywgX19leHBvcnRzX18pKSB7XG4gICAgYXBpLnJlbG9hZCgnNDlmMGYwODAnLCBfX2V4cG9ydHNfXylcbiAgfVxuICBcbiAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL21haW4udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTQ5ZjBmMDgwJnNjb3BlZD10cnVlXCIsICgpID0+IHtcbiAgICBhcGkucmVyZW5kZXIoJzQ5ZjBmMDgwJywgcmVuZGVyKVxuICB9KVxuXG59XG5cblxuZXhwb3J0IGRlZmF1bHQgX19leHBvcnRzX18iLCIvKiB1bnBsdWdpbi12dWUtY29tcG9uZW50cyBkaXNhYmxlZCAqL2ltcG9ydCB7IHJlbmRlciB9IGZyb20gXCIuL3BvcHVwLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0yZDY2OGRkYVwiXG5pbXBvcnQgc2NyaXB0IGZyb20gXCIuL3BvcHVwLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcbmV4cG9ydCAqIGZyb20gXCIuL3BvcHVwLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCJcblxuaW1wb3J0IFwiLi9wb3B1cC52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD0yZDY2OGRkYSZsYW5nPXNjc3NcIlxuXG5pbXBvcnQgZXhwb3J0Q29tcG9uZW50IGZyb20gXCIuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2V4cG9ydEhlbHBlci5qc1wiXG5jb25zdCBfX2V4cG9ydHNfXyA9IC8qI19fUFVSRV9fKi9leHBvcnRDb21wb25lbnQoc2NyaXB0LCBbWydyZW5kZXInLHJlbmRlcl0sWydfX2ZpbGUnLFwic3JjL3Z1ZS9wb3B1cC52dWVcIl1dKVxuLyogaG90IHJlbG9hZCAqL1xuaWYgKG1vZHVsZS5ob3QpIHtcbiAgX19leHBvcnRzX18uX19obXJJZCA9IFwiMmQ2NjhkZGFcIlxuICBjb25zdCBhcGkgPSBfX1ZVRV9ITVJfUlVOVElNRV9fXG4gIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgaWYgKCFhcGkuY3JlYXRlUmVjb3JkKCcyZDY2OGRkYScsIF9fZXhwb3J0c19fKSkge1xuICAgIGFwaS5yZWxvYWQoJzJkNjY4ZGRhJywgX19leHBvcnRzX18pXG4gIH1cbiAgXG4gIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9wb3B1cC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MmQ2NjhkZGFcIiwgKCkgPT4ge1xuICAgIGFwaS5yZXJlbmRlcignMmQ2NjhkZGEnLCByZW5kZXIpXG4gIH0pXG5cbn1cblxuXG5leHBvcnQgZGVmYXVsdCBfX2V4cG9ydHNfXyIsIi8qIHVucGx1Z2luLXZ1ZS1jb21wb25lbnRzIGRpc2FibGVkICovZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/P3J1bGVTZXRbMV0ucnVsZXNbMTZdLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMvbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbOV0udXNlWzBdIS4vbG9naW4udnVlP3Z1ZSZ0eXBlPXNjcmlwdCZzZXR1cD10cnVlJmxhbmc9anNcIjsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxNl0udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi12dWUtY29tcG9uZW50cy9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1s5XS51c2VbMF0hLi9sb2dpbi52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiLyogdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMgZGlzYWJsZWQgKi9leHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxNl0udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi12dWUtY29tcG9uZW50cy9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1s5XS51c2VbMF0hLi9tYWluLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCI7IGV4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/P3J1bGVTZXRbMV0ucnVsZXNbMTZdLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMvbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbOV0udXNlWzBdIS4vbWFpbi52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiIiwiLyogdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMgZGlzYWJsZWQgKi9leHBvcnQgeyBkZWZhdWx0IH0gZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxNl0udXNlWzBdIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi12dWUtY29tcG9uZW50cy9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1s5XS51c2VbMF0hLi9wb3B1cC52dWU/dnVlJnR5cGU9c2NyaXB0JnNldHVwPXRydWUmbGFuZz1qc1wiOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE2XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luLXZ1ZS1jb21wb25lbnRzL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzldLnVzZVswXSEuL3BvcHVwLnZ1ZT92dWUmdHlwZT1zY3JpcHQmc2V0dXA9dHJ1ZSZsYW5nPWpzXCIiLCIvKiB1bnBsdWdpbi12dWUtY29tcG9uZW50cyBkaXNhYmxlZCAqL2V4cG9ydCAqIGZyb20gXCItIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/P3J1bGVTZXRbMV0ucnVsZXNbMTZdLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMvbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbMl0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1s5XS51c2VbMF0hLi9sb2dpbi52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MzEwNWVmNzImc2NvcGVkPXRydWVcIiIsIi8qIHVucGx1Z2luLXZ1ZS1jb21wb25lbnRzIGRpc2FibGVkICovZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxNl0udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi12dWUtY29tcG9uZW50cy9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC90ZW1wbGF0ZUxvYWRlci5qcz8/cnVsZVNldFsxXS5ydWxlc1syXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzldLnVzZVswXSEuL21haW4udnVlP3Z1ZSZ0eXBlPXRlbXBsYXRlJmlkPTQ5ZjBmMDgwJnNjb3BlZD10cnVlXCIiLCIvKiB1bnBsdWdpbi12dWUtY29tcG9uZW50cyBkaXNhYmxlZCAqL2V4cG9ydCAqIGZyb20gXCItIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/P3J1bGVTZXRbMV0ucnVsZXNbMTZdLnVzZVswXSEuLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMvbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxN10udXNlWzBdIS4uLy4uL25vZGVfbW9kdWxlcy9iYWJlbC1sb2FkZXIvbGliL2luZGV4LmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvdGVtcGxhdGVMb2FkZXIuanM/P3J1bGVTZXRbMV0ucnVsZXNbMl0hLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9pbmRleC5qcz8/cnVsZVNldFsxXS5ydWxlc1s5XS51c2VbMF0hLi9wb3B1cC52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MmQ2NjhkZGFcIiIsIi8qIHVucGx1Z2luLXZ1ZS1jb21wb25lbnRzIGRpc2FibGVkICovZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxNl0udXNlWzBdIS4uLy4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi12dWUtY29tcG9uZW50cy9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvbG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9zYXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzldLnVzZVswXSEuL2xvZ2luLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTMxMDVlZjcyJmxhbmc9c2NzcyZzY29wZWQ9dHJ1ZVwiIiwiLyogdW5wbHVnaW4tdnVlLWNvbXBvbmVudHMgZGlzYWJsZWQgKi9leHBvcnQgKiBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE2XS51c2VbMF0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luLXZ1ZS1jb21wb25lbnRzL25vZGVfbW9kdWxlcy91bnBsdWdpbi9kaXN0L3dlYnBhY2svbG9hZGVycy90cmFuc2Zvcm0uanM/P3J1bGVTZXRbMV0ucnVsZXNbMTddLnVzZVswXSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vZGlzdC9sb2FkZXIuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvZGlzdC9zdHlsZVBvc3RMb2FkZXIuanMhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3Nhc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3QvaW5kZXguanM/P3J1bGVTZXRbMV0ucnVsZXNbOV0udXNlWzBdIS4vbWFpbi52dWU/dnVlJnR5cGU9c3R5bGUmaW5kZXg9MCZpZD00OWYwZjA4MCZsYW5nPXNjc3Mmc2NvcGVkPXRydWVcIiIsIi8qIHVucGx1Z2luLXZ1ZS1jb21wb25lbnRzIGRpc2FibGVkICovZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vbm9kZV9tb2R1bGVzL3VucGx1Z2luL2Rpc3Qvd2VicGFjay9sb2FkZXJzL3RyYW5zZm9ybS5qcz8/cnVsZVNldFsxXS5ydWxlc1sxNl0udXNlWzBdIS4uLy4uL25vZGVfbW9kdWxlcy91bnBsdWdpbi12dWUtY29tcG9uZW50cy9ub2RlX21vZHVsZXMvdW5wbHVnaW4vZGlzdC93ZWJwYWNrL2xvYWRlcnMvdHJhbnNmb3JtLmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzE3XS51c2VbMF0hLi4vLi4vbm9kZV9tb2R1bGVzL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2Rpc3QvbG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2Rpc3Qvc3R5bGVQb3N0TG9hZGVyLmpzIS4uLy4uL25vZGVfbW9kdWxlcy9zYXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9kaXN0L2luZGV4LmpzPz9ydWxlU2V0WzFdLnJ1bGVzWzldLnVzZVswXSEuL3BvcHVwLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTJkNjY4ZGRhJmxhbmc9c2Nzc1wiIl0sIm5hbWVzIjpbIkFwcCIsImFwcCIsImNyZWF0ZUFwcCIsIm1vdW50IiwiZ2V0VG9rZW4iLCJQcm9taXNlIiwicmVzb2x2ZSIsImNocm9tZSIsInN0b3JhZ2UiLCJsb2NhbCIsImdldCIsInJlc3VsdCIsInRva2VuIiwiYmFzZVVybCIsImVuYyIsIkhtYWNTSEEyNTYiLCJtb2RhbCIsImhvc3RDb25maWciLCJtZDUiLCJBeGlvcyIsIlNlY3JldEtleSIsImNyZWF0ZVNpZ24iLCJtZXRob2QiLCJVUkwiLCJwYXJhbSIsIkNsaWVudFRpbWVzdGFtcCIsIlN0cmluZ1RvU2lnbiIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zb2xlIiwibG9nIiwiSG1hY1NpZ25hdHVyZSIsIkJhc2U2NCIsIkJhc2U2NFVSTCIsImJhc2U2NFN0ciIsInNhZmVCNjQiLCJyZXBsYWNlIiwibW9kNCIsImxlbmd0aCIsIm1vZEFkZFN0ciIsInN1YnN0cmluZyIsImRlZmF1bHRzIiwidGltZW91dCIsIndpdGhDcmVkZW50aWFscyIsInRyYW5zZm9ybVJlcXVlc3QiLCJyZXEiLCJoZWFkZXJzIiwiaW5kZXhPZiIsImZvcm1EYXRhIiwiRm9ybURhdGEiLCJrZXkiLCJhcHBlbmQiLCJ0cmFuc2Zvcm1SZXNwb25zZSIsImNvbmZpZyIsInJlcyIsInBhcnNlIiwiZXJyb3JfY29kZSIsIm1lc3NhZ2UiLCJkdXJhdGlvbiIsIm1zZ0Vycm9yIiwicmVxdWVzdCIsInVybCIsInBhdGgiLCJkX3AiLCJkYXRhIiwidW5kZWZpbmVkIiwicGFyYW1zIiwidG9VcHBlckNhc2UiLCJpc1JlbW90ZSIsInN1YnN0ciIsImlzTW9jayIsIndpbmRvdyIsIm9uVXBsb2FkUHJvZ3Jlc3MiLCJ0aW1lc3RhbXAiLCJEYXRlIiwiZ2V0VGltZSIsInRzIiwic2lnbiIsImNvbnRlbnRUeXBlIiwiQXJyYXkiLCJhbGwiLCJ0aGVuIiwic3ByZWFkIiwicmVzVHJhbnNmb3JtZXIiLCJPYmplY3QiLCJhc3NpZ24iLCJiYXNlVVJMIiwicmVzcG9uc2UiLCJjYXRjaCIsImVycm9yIiwicmVqZWN0IiwiYXNzaWduQnlVcmwiLCJ2YXJpYWJsZSIsInNlbGYiLCJzcGxpY2UiLCJwb3N0V2ViIiwiZmllbGREYXRhIiwiZmllbGQiLCJwdXNoIiwidm0iLCIkc2V0IiwiZW5jcnlwdFN0ciIsInN0ciIsInNLZXkiLCJtZDVTdHIiLCJoZXhfbWQ1IiwiaHR0cEdldCIsImh0dHBQb3N0IiwiYm9keSIsImh0dHBVcGxvYWQiLCJodHRwUGF0Y2giLCJodHRwUHV0IiwiaHR0cERlbGV0ZSIsInVwbG9hZFdlYiIsImhleGNhc2UiLCJiNjRwYWQiLCJjaHJzeiIsInMiLCJiaW5sMmhleCIsImNvcmVfbWQ1Iiwic3RyMmJpbmwiLCJiNjRfbWQ1IiwiYmlubDJiNjQiLCJzdHJfbWQ1IiwiYmlubDJzdHIiLCJoZXhfaG1hY19tZDUiLCJjb3JlX2htYWNfbWQ1IiwiYjY0X2htYWNfbWQ1Iiwic3RyX2htYWNfbWQ1IiwibWQ1X3ZtX3Rlc3QiLCJ4IiwibGVuIiwiYSIsImIiLCJjIiwiZCIsImkiLCJvbGRhIiwib2xkYiIsIm9sZGMiLCJvbGRkIiwibWQ1X2ZmIiwibWQ1X2dnIiwibWQ1X2hoIiwibWQ1X2lpIiwic2FmZV9hZGQiLCJtZDVfY21uIiwicSIsInQiLCJiaXRfcm9sIiwiYmtleSIsImlwYWQiLCJvcGFkIiwiaGFzaCIsImNvbmNhdCIsInkiLCJsc3ciLCJtc3ciLCJudW0iLCJjbnQiLCJiaW4iLCJtYXNrIiwiY2hhckNvZGVBdCIsIlN0cmluZyIsImZyb21DaGFyQ29kZSIsImJpbmFycmF5IiwiaGV4X3RhYiIsImNoYXJBdCIsInRhYiIsInRyaXBsZXQiLCJqIiwibG9hZGluZ0luc3RhbmNlIiwibXNnIiwiY29udGVudCIsIkVsTWVzc2FnZSIsImluZm8iLCJtc2dTdWNjZXNzIiwic3VjY2VzcyIsIm1zZ1dhcm5pbmciLCJ3YXJuaW5nIiwiYWxlcnQiLCJFbE1lc3NhZ2VCb3giLCJhbGVydEVycm9yIiwidHlwZSIsImFsZXJ0U3VjY2VzcyIsImFsZXJ0V2FybmluZyIsIm5vdGlmeSIsIkVsTm90aWZpY2F0aW9uIiwibm90aWZ5RXJyb3IiLCJub3RpZnlTdWNjZXNzIiwibm90aWZ5V2FybmluZyIsImNvbmZpcm0iLCJvcHRpb25zIiwiY29uZmlybUJ1dHRvblRleHQiLCJjYW5jZWxCdXR0b25UZXh0IiwiZGFuZ2Vyb3VzbHlVc2VIVE1MU3RyaW5nIiwicHJvbXB0IiwibG9hZGluZyIsIkVsTG9hZGluZyIsInNlcnZpY2UiLCJsb2NrIiwidGV4dCIsImJhY2tncm91bmQiLCJjbG9zZUxvYWRpbmciLCJjbG9zZSJdLCJzb3VyY2VSb290IjoiIn0=