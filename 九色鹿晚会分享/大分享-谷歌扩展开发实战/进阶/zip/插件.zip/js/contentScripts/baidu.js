/******/ (() => { // webpackBootstrap
/*!****************************************!*\
  !*** ./src/js/contentScripts/baidu.js ***!
  \****************************************/
/**
 * Created by Allen Liu on 2026/3/11.
 */

// fetch('https://www.163.com/')

// 监听来自后台的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'changeBg') {
    document.body.style.backgroundColor = message.data;
  }
});
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvY29udGVudFNjcmlwdHMvYmFpZHUuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBQSxNQUFNLENBQUNDLE9BQU8sQ0FBQ0MsU0FBUyxDQUFDQyxXQUFXLENBQUMsQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEVBQUVDLFlBQVksS0FBSztFQUN0RSxJQUFJRixPQUFPLENBQUNHLE1BQU0sS0FBSyxVQUFVLEVBQUU7SUFDakNDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxLQUFLLENBQUNDLGVBQWUsR0FBR1AsT0FBTyxDQUFDUSxJQUFJO0VBQ3BEO0FBQ0YsQ0FBQyxDQUFDLEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zaGFyZS1jaHJvbWUtZXh0ZW5zaW9ucy1ieS1sd2gvLi9zcmMvanMvY29udGVudFNjcmlwdHMvYmFpZHUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIENyZWF0ZWQgYnkgQWxsZW4gTGl1IG9uIDIwMjYvMy8xMS5cclxuICovXHJcblxyXG4vLyBmZXRjaCgnaHR0cHM6Ly93d3cuMTYzLmNvbS8nKVxyXG5cclxuLy8g55uR5ZCs5p2l6Ieq5ZCO5Y+w55qE5raI5oGvXHJcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcclxuICBpZiAobWVzc2FnZS5hY3Rpb24gPT09ICdjaGFuZ2VCZycpIHtcclxuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gbWVzc2FnZS5kYXRhO1xyXG4gIH1cclxufSk7XHJcblxyXG4iXSwibmFtZXMiOlsiY2hyb21lIiwicnVudGltZSIsIm9uTWVzc2FnZSIsImFkZExpc3RlbmVyIiwibWVzc2FnZSIsInNlbmRlciIsInNlbmRSZXNwb25zZSIsImFjdGlvbiIsImRvY3VtZW50IiwiYm9keSIsInN0eWxlIiwiYmFja2dyb3VuZENvbG9yIiwiZGF0YSJdLCJzb3VyY2VSb290IjoiIn0=